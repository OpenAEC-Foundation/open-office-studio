from pathlib import Path
import json,hashlib,gzip,subprocess
r=Path.cwd();w=r/'.local/controle-2026-10-31';d=r/'native/docs';uit=d/'documentmeldingen-2026-11-02-alpha45/ci-afsluiting';uit.mkdir();arte=w/'native-alpha45-ci-verslagen';run='41389707284';status=json.loads(subprocess.check_output(['gh','run','view',run,'--json','status,conclusion,jobs'],text=True));assert status['status']=='completed' and status['conclusion']=='success' and len(status['jobs'])==5 and all(j['conclusion']=='success' for j in status['jobs']);(w/'native-alpha45-ci-eindstatus.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
folders=sorted(p.name for p in arte.iterdir() if p.is_dir());assert len(folders)==14

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
items=[{'bestand':p.relative_to(arte).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(arte.rglob('*')) if p.is_file()];(uit/'artefactinventaris.json').write_text(json.dumps({'bouwronde':run,'artefacten':folders,'bestanden':items},ensure_ascii=False,indent=2)+'\n')
v=json.loads((d/'platformen-2026-11-02-alpha45.json').read_text());assert v['geslaagd'] and len(v['beelden'])==122 and all(p['bronbestanden']==5417 and p['alle_bronbytes_gelijk'] for p in v['pakketten']);kopieen=[]
for p in [arte/'native-platformvergelijking/rapport.json',w/'native-alpha45-ci-eindstatus.json',w/'native-alpha45-ci-verwerking.log',w/'verwerk-ci-rapport-versie.py',w/'native-alpha45-geteste-gitbron.json',Path(__file__)]:
 raw=p.read_bytes();q=uit/(p.name+'.gz');q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw;kopieen.append({'bron':p.relative_to(r).as_posix(),'bestand':q.name,'bron_sha256':hashlib.sha256(raw).hexdigest(),'opgeslagen_sha256':sha(q)})
(uit/'bewijskopieen.json').write_text(json.dumps({'omvang':'Alle vijf alpha45-CI-taken groen; veertien artefacten gedownload en geïnventariseerd, 122 native beeldparen exact, drie bronpakketten met elk 5417 bytegelijke bestanden, 21 paginabezoeken exact. Geteste mergebron is voor native, templates, voorbeelden, workflow, attributen en licentie gelijk aan broncommit 68cd58986ea422bfe023f947fccf3ff7c473e94d. Windows en macOS uitsluitend CI; geen fysieke GUI, installatie- of oorspronkelijke suitepariteit.','kopieen':kopieen},ensure_ascii=False,indent=2)+'\n')

print({'artefacten':len(folders),'gehashte_bestanden':len(items),'bronbestanden_per_platform':5417,'beeldparen':122,'paginabezoeken':21})
