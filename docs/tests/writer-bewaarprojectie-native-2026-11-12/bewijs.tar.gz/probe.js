(() => {
 const s=api().getEditorRef().getYrsSession(), el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');
 const doelen=new Set();
 function zoek(){const gevonden=new Set();for(let f=el?.[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)
  for(let n=f.memoizedState,i=0;n&&i<1500;n=n.next,i++)
   for(const v of [n.memoizedState,n.memoizedState?.current])if(v?.queries?.sourceState&&typeof v.queries.caretRect==='function')gevonden.add(v.queries);return gevonden;}
 const oud=[],regels=[],stacks={};let diepte=0,over=0;
 const noteer=(naam,fout)=>{if(regels.length>=4096){over++;return}const sleutel=naam+'|'+(diepte>0)+'|'+!!s.oosBewaarUpdate+'|'+!!fout;if(!(sleutel in stacks)&&Object.keys(stacks).length<24)stacks[sleutel]=new Error().stack.slice(0,2200);regels.push({naam,ms:performance.now(),updateDiepte:diepte,bewaarAdoptie:!!s.oosBewaarUpdate,fout:fout?String(fout):null,stack:sleutel})};
 function volg(doel,naam,update=false){const fn=doel[naam],descriptor=Object.getOwnPropertyDescriptor(doel,naam);if(typeof fn!=='function'||descriptor&&!descriptor.configurable)throw Error('Methode niet veilig te volgen: '+naam);
  const wrapper=function(...args){let fout=null;if(update)diepte++;try{if(update){try{ververs()}catch(e){noteer('probe_scan_fout',e)}}noteer(naam+':begin',null);return Reflect.apply(fn,this,args)}catch(e){fout=e;throw e}finally{noteer(naam+':eind',fout);if(update)diepte--}};
  Object.defineProperty(doel,naam,{value:wrapper,configurable:true,writable:true,enumerable:descriptor?.enumerable??false});oud.push({doel,naam,fn,descriptor,wrapper});
 }
 function ververs(){for(const q of zoek())if(!doelen.has(q)){volg(q,'caretRect');if(typeof q.rangeRects==='function')volg(q,'rangeRects');doelen.add(q)}}
 ververs();if(!doelen.size)throw Error('Geen bestaande caretquery gevonden');volg(s,'applyUpdate',true);
 window._herstelProbe={lees:()=>({regels,stacks,over,queryObjecten:doelen.size}),stop:()=>{for(const o of oud){if(o.doel[o.naam]!==o.wrapper)throw Error('Methode onderweg vervangen: '+o.naam);if(o.descriptor)Object.defineProperty(o.doel,o.naam,o.descriptor);else delete o.doel[o.naam]}return {regels,stacks,over,queryObjecten:doelen.size,hersteld:oud.every(o=>o.doel[o.naam]===o.fn)}}};return {queryObjecten:doelen.size};
})()
