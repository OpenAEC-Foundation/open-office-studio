from pathlib import Path
import tarfile,json,hashlib,stat,os,shutil
u=Path(__file__).resolve().parent;r=Path.cwd();namen=['native-voorbereiding/meet','native-voorbereiding/meet-beide','native-voorbereiding/meet-controle','bronhergebruik/herhaal','bronhergebruik/herhaal-desktop','bronhergebruik/huidige-bronkosten'];m={}
for n in namen:
 p=r/'.local/integratiecontrole'/n;s=p.stat();assert p.read_bytes()[:4]==b'\x7fELF';m[n]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'bytes':s.st_size}
a=u/'eigen-oude-clis.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n in namen:t.add(r/'.local/integratiecontrole'/n,arcname=n,recursive=False)
with tarfile.open(a,'r:gz') as t:
 assert len(t.getmembers())==len(namen)
 for n,v in m.items():
  b=t.extractfile(n).read();assert hashlib.sha256(b).hexdigest()==v['sha256'];p=u/'herstelproef';p.write_bytes(b);os.chmod(p,v['mode']);os.utime(p,ns=(v['mtime_ns'],v['mtime_ns']));assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and p.stat().st_mtime_ns==v['mtime_ns'] and stat.S_IMODE(p.stat().st_mode)==v['mode'];p.unlink()
(u/'cli-archief.json').write_text(json.dumps({'archief':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'leden':m,'elk_lid_ook_los_hersteld_en_gecontroleerd':True},indent=2)+'\n')
for n,v in m.items():
 p=r/'.local/integratiecontrole'/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'];p.unlink()
print('Eigen oude diagnose-ELFs verliesloos gearchiveerd; vrij',shutil.disk_usage(u).free)
