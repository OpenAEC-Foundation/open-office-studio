from pathlib import Path
import json,statistics,hashlib
from zipfile import ZipFile
from xml.etree import ElementTree as E
u=Path(__file__).resolve().parent
uit={}
for n in ['oud-klein-a','nieuw-klein-a','nieuw-klein-b','oud-klein-b','oud-rijk-a','nieuw-rijk-a','nieuw-rijk-b','oud-rijk-b']:
 r=json.loads((u/n/'rapport.json').read_text());assert r['geslaagd'] and not any(r['fouten'].values());assert r['schema']==2
 tekst=' Een korte zin. EINDEPROEF.' if 'klein' in n else ' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.'
 prefix='';calls=[]
 for m in r['native_opdrachten']:
  calls.append(m)
  if m.get('caret'):prefix+=m['text']
  assert tekst.startswith(prefix)
  if prefix==tekst:break
 assert prefix==tekst and all(m['bronbinding'] and not m.get('vertragingMs') for m in calls)
 uit[n]={'geslaagd':True,'programma_sha256':r['programma_sha256'],'invoer':r['lange_invoer'],'gewone_native_opdrachten':len(calls),'stappen':r['stappen'],'fouten':r['fouten']}
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for n,r in uit.items():print(n,r['invoer']['wall_begin_tot_frame_ms'],r['invoer']['laatste_keyup_tot_frame_ms'],r['gewone_native_opdrachten'])
