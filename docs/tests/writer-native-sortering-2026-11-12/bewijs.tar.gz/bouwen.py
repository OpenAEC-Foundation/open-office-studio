from pathlib import Path
import subprocess,shutil,os,signal,time,json,hashlib,re
r=Path.cwd();u=r/'.local/integratiecontrole/native-sortering';root=r.parent/'Open-Office-Studio';target=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
status=subprocess.check_output(['git','status','--porcelain']);diff=subprocess.check_output(['git','diff','--binary']);test=r/'native/vendor/docx-edit/src/deterministic/sorteringproeven.rs';testsha=sha(test)
assert '\nOK\n' in (u/'python-herhaling.log').read_text();assert (u/'controle-nieuw.log').read_text().count('test result: ok.')==5
assert {s[3:] for s in status.decode().splitlines()}=={'native/vendor/docx-edit/OPENAEC-WIJZIGINGEN.md','native/vendor/docx-edit/src/deterministic.rs','native/vendor/docx-edit/src/deterministic/','native/onderzoek/referenties/','native/onderzoek/writer-encodercache/README.md','native/onderzoek/writer-encodercache/uitvoeren.py','tests/test_writer_sortering.py'}
refs=json.loads((r/'.local/integratiecontrole/native-voorbereiding/referenties-na.json').read_text())
for p,h in {**refs['programmas'],**refs['extra_prototypes']}.items():assert sha(Path(p))==h
bundle={str(p.relative_to(r/'dist')):sha(p) for p in (r/'dist').rglob('*') if p.is_file()};assert len(bundle)==529
(u/'bron.diff').write_bytes(diff);(u/'bundelpinnen.json').write_text(json.dumps(bundle,indent=2)+'\n')
vrij=shutil.disk_usage(r).free;assert vrij>3.25*1024**3
# Bestaande afhankelijkheden blijven gecachet: uitsluitend drie bekende eigen crates.
# Geen brede werkruimte-/afhankelijkheidsbouw binnen deze begrensde ruimte.
allow={'betteroffice-docx-edit','office-writer-plakken','open-office-studio'}
env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true')
cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];begin=time.monotonic();reden=None;minimum=vrij
with (u/'desktop.log').open('x') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  time.sleep(1);minimum=min(minimum,shutil.disk_usage(r).free);s=(u/'desktop.log').read_text(errors='replace');crates=set(re.findall(r'^\s*Compiling ([^ ]+)',s,re.M))
  if crates-allow or minimum<3*1024**3 or time.monotonic()-begin>1200:
   reden='Onverwachte afhankelijkheidsbouw, minder dan3GiB of20min';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
uit={'code':p.returncode,'reden':reden,'seconden':time.monotonic()-begin,'opdracht':cmd,'minimum_vrije_bytes':minimum,'start_vrije_bytes':vrij,'toegestane_crates':sorted(allow),'bron_sha256':sha(r/'native/vendor/docx-edit/src/deterministic.rs'),'test_sha256':testsha,'gecompileerde_crates':sorted(crates)}
assert subprocess.check_output(['git','status','--porcelain'])==status and subprocess.check_output(['git','diff','--binary'])==diff and sha(test)==testsha
assert bundle=={str(p.relative_to(r/'dist')):sha(p) for p in (r/'dist').rglob('*') if p.is_file()}
for path,h in {**refs['programmas'],**refs['extra_prototypes']}.items():assert sha(Path(path))==h
if p.returncode==0:
 exe=u/'open-office-studio-sortering';shutil.copy2(target/'release/open-office-studio',exe);uit.update(programma=str(exe),programma_sha256=sha(exe))
(u/'desktop.json').write_text(json.dumps(uit,indent=2)+'\n');print(json.dumps(uit));raise SystemExit(p.returncode)
