from pathlib import Path
import subprocess,json,os,time,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/native-sortering';libs=json.loads((r/'.local/integratiecontrole/native-voorbereiding/bibliotheken.json').read_text())['pinnen'];cache=Path(libs['docx_edit']).parent
assert json.loads((u/'desktop.json').read_text())['code']==0
cmd=['/home/aia01/.cargo/bin/rustc','--test','--edition=2024','-C','opt-level=3','--cfg','feature="writer-bronjournaal"','-L','dependency='+str(cache),str(r/'native/crates/office-writer-plakken/src/lib.rs'),'-o',str(u/'native-tests')]
for naam in ['docx_edit','yrs','serde','serde_json','base64','sha2']:cmd+=['--extern',naam+'='+libs[naam]]
env=os.environ.copy();env['CARGO_MANIFEST_DIR']=str(r/'native/crates/office-writer-plakken')
with (u/'native-tests-bouw.log').open('x') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
with (u/'native-tests.log').open('x') as log:subprocess.run([str(u/'native-tests'),'--test-threads=1'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
(u/'native-tests.json').write_text(json.dumps({'opdracht':cmd,'code':0,'bibliotheken':{k:hashlib.sha256(Path(v).read_bytes()).hexdigest() for k,v in libs.items()},'grens':'Echte office-writer-plakken-cratetests met nieuwe docx_edit en bestaande gepinde afhankelijkheden; geen volledige Rust-werkruimtetest of alle upstream-bewerkkernproeven.'},indent=2)+'\n')
print((u/'native-tests.log').read_text().splitlines()[-2:])
