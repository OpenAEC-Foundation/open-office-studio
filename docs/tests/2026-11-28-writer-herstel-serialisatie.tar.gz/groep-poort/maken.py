from pathlib import Path
import json
p=Path.cwd()/'.local/integratiecontrole/groep-poort';s=(p.parent/'groep-eventloop/proef.py').read_text();a=s.index("                await toets(p, 'ctrl+End')");b=s.index('            finally:\n                try:',a)
body='''                r['geval'] = os.environ['OFFICE_TEST_POORT']
                await p.ev(__POORT__)
                await toets(p, 'ctrl+End')
                await p.ev('window._poortVoor=tekst();window._poortStand=stand();window._poortIndex=_rust.aanvragen.length;window._poortUpdates=_rust.updates;_rust.houd=true;true')
                subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'A'], check=True)
                await p.run('const eind=performance.now()+30000;while(!_rust.aanvragen.at(-1)?.wacht){if(performance.now()>eind)throw Error("Geen eerste native antwoord vast");await new Promise(r=>setTimeout(r,20))}return true')
                await p.ev('__poort.arm();true')
                subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'B'], check=True)
                await p.ev('_rust.los();true')
                await p.run('const eind=performance.now()+30000;while(!__poort.gehouden){if(performance.now()>eind)throw Error("Geen eigen yieldbericht vast");await new Promise(r=>setTimeout(r,20))}return true')
                r['vast'] = await p.ev('({tekstCorrect:tekst()===_poortVoor+"A",aanvragen:_rust.aanvragen.length-_poortIndex,updates:_rust.updates-_poortUpdates,teller:__poort.gehouden.teller,buffer:__poort.scan().buffers.map(b=>b.waarde.text)})')
                assert r['vast']['tekstCorrect'] and r['vast']['aanvragen'] == 1 and r['vast']['updates'] == 1
                assert r['vast']['buffer'] == ['B']
                if r['geval'] == 'selectie':
                    await toets(p, 'Left', leeg=False)
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'C'], check=True)
                    await p.ev('__poort.los();true')
                    await p.run('await api().flushPendingInput();return true')
                    r['uitkomst'] = await p.ev('({eind:tekst().slice(-30),verwacht:(_poortVoor+"ACB").slice(-30),correct:tekst()===_poortVoor+"ACB"})')
                    assert r['uitkomst']['correct'], 'Selectiebarrière verandert de volgorde A,B,Left,C'
                    r['stappen'].append('Vastgezet bericht behoudt fysieke selectiebarrière en invoervolgorde')
                elif r['geval'] == 'bewaren':
                    mtime = bron.stat().st_mtime_ns
                    await p.ev('window._flushKlaar=false;window._poortFlush=api().flushPendingInput().then(()=>{_flushKlaar=true});true')
                    await toets(p, 'ctrl+s', leeg=False)
                    await asyncio.sleep(.3)
                    assert not await p.ev('_flushKlaar'), 'Flush loopt vóór het eigen bericht uit'
                    assert bron.stat().st_mtime_ns == mtime, 'Save schrijft vóór de eigen invoergroep'
                    await p.ev('__poort.los();true')
                    await p.run('await _poortFlush;await api().flushPendingInput();return true')
                    eind = time.monotonic()+45
                    while bron.stat().st_mtime_ns == mtime:
                        assert time.monotonic() < eind, 'Geen fysiek opgeslagen document'
                        await asyncio.sleep(.1)
                    assert await p.ev('tekst()===_poortVoor+"AB"')
                    with ZipFile(bron) as z:
                        xml = ET.fromstring(z.read('word/document.xml'))
                    assert [ET.tostring(t) for t in xml.findall('.//w:tbl', ns)] == tabelbron
                    terug = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                    assert terug == await p.ev('tekst()')
                    r['stappen'].append('Flush en fysieke Save wachten; onafhankelijke DOCX behoudt AB en 128 tabellen')
                elif r['geval'] == 'wachtrij':
                    r['vervanging'] = await p.ev('__poort.vervangRij()')
                    assert not r['vervanging']['zelfdeRij']
                    await p.ev('__poort.resterend=1;true')
                    await toets(p, 'Return', leeg=False)
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'C'], check=True)
                    await p.ev('window._nieuweBuffer=__poort.buffer.current;true')
                    assert await p.ev('_nieuweBuffer?.text') == 'C'
                    await p.ev('__poort.los();true')
                    await p.run('const eind=performance.now()+30000;while(!__poort.gehouden){if(performance.now()>eind)throw Error("Geen tweede eigen bericht vast");await new Promise(r=>setTimeout(r,20))}return true')
                    assert await p.ev('__poort.buffer.current===_nieuweBuffer'), 'Oude abort wist een nieuwere invoerbuffer'
                    assert await p.ev('tekst()===_poortVoor+"A"'), 'Oude groep schrijft na wisselen van rij'
                    assert await p.ev('_rust.aanvragen.length-_poortIndex') == 1
                    await p.ev('__poort.los();true')
                    await p.run('await api().flushPendingInput();return true')
                    assert await p.ev('tekst()===_poortVoor+"AC"')
                    await p.ev('__poort.herstelRij();true')
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'D'], check=True)
                    await toets(p, 'Right')
                    assert await p.ev('tekst()===_poortVoor+"ACD"')
                    r['stappen'].append('Alleen rij-identiteit vervangen: oude B geweigerd, nieuwere buffer en herstelde rij bruikbaar')
                elif r['geval'] == 'verwerpen':
                    bestandVoor = hashlib.sha256(bron.read_bytes()).hexdigest()
                    updatesVoor = await p.ev('_rust.updates')
                    await toets(p, 'ctrl+w', leeg=False)
                    await p.run('const eind=performance.now()+10000;while(!document.querySelector(".office-dialoogacties")){if(performance.now()>eind)throw Error("Geen sluitdialoog vóór eigen bericht");await new Promise(r=>setTimeout(r,20))}return true')
                    await klik(p, 'Array.from(document.querySelectorAll(".office-dialoogacties button")).find(b=>/Don.t save|Niet opslaan/.test(b.textContent))')
                    await p.run('const eind=performance.now()+10000;while(document.querySelector(".office-tekst")||document.querySelector(".office-dialoogacties")){if(performance.now()>eind)throw Error("Sluiten wacht op eigen bericht");await new Promise(r=>setTimeout(r,20))}return true')
                    await klik(p, 'document.querySelector("button.start-sjabloon.module-docx")')
                    await p.run('const eind=performance.now()+30000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error("Geen nieuw document");await new Promise(r=>setTimeout(r,20))}api().focus();return true')
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '20', 'Nieuw document'], check=True)
                    await toets(p, 'Right')
                    assert await p.ev('tekst()') == 'Nieuw document'
                    aanvragenVoor = await p.ev('_rust.aanvragen.length')
                    await p.ev('__poort.los();true')
                    await asyncio.sleep(.2)
                    await p.run('await api().flushPendingInput();return true')
                    assert await p.ev('tekst()') == 'Nieuw document'
                    assert await p.ev('_rust.aanvragen.length') == aanvragenVoor, 'Oude groep begint alsnog een native aanvraag'
                    assert await p.ev('_rust.updates') == updatesVoor, 'Oude groep schrijft in gesloten sessie'
                    assert hashlib.sha256(bron.read_bytes()).hexdigest() == bestandVoor
                    r['stappen'].append('Niet opslaan, nieuw document en late eigen berichtvrijgave zonder oude aanvraag/mutatie')
                else:
                    raise AssertionError('Onbekend poortgeval')
                r['poortopnames'] = await p.ev('__poort.opnames.map(h=>({teller:h.teller,vast:h.vast,los:h.los,stack:h.stack}))')
                r['poort_herstel'] = await p.ev('__poort.opruimen()')
                assert r['poort_herstel']
                r['native_opdrachten'] = await p.ev('_rust.aanvragen')
                r['fouten'] = await p.fouten()
                assert not any(r['fouten'].values())
                await beeld_stabiel(p, 'poort-'+r['geval'])
                r['geslaagd'] = True
'''
body=body.replace('__POORT__',repr((p/'poort.js').read_text()));s=s[:a]+body+s[b:];s=s.replace('            finally:\n                try:',"            finally:\n                try:\n                    r['opruiming'] = await p.ev('window.__poort?.opruimen();true')\n                except Exception as fout:\n                    r['opruimfout'] = str(fout)\n                try:",1);(p/'proef.py').write_text(s)
