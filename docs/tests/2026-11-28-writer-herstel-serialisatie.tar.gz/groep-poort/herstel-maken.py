from pathlib import Path
p=Path.cwd()/'.local/integratiecontrole/groep-poort';s=(p/'proef-rustig-frame.py').read_text();anchor="                r['letters'] = []";assert s.count(anchor)==1;s=s.replace(anchor,"                fase = os.environ.get('OFFICE_TEST_HERSTELFASE') == 'verschuiven'\n                await p.ev("+repr((p/'herstelfase.js').read_text())+"+'('+str(fase).lower()+')')\n"+anchor)
anchor="                r['herstel'] = await p.ev('__lat.stop()')";new='''                await p.run('const eind=performance.now()+45000;while(!__herstelfase.opnames.some(x=>x.geslaagd)){if(performance.now()>eind)throw Error("Geen voltooide herstelkopie");await new Promise(r=>setTimeout(r,50))}return true', t=50)
                r['herstelfase'] = await p.ev('({verschuif:__herstelfase.verschuif,wijziging:__herstelfase.wijziging,opnames:__herstelfase.opnames})')
                import base64
                bytes_herstel = await p.ev('(()=>{const a=__herstelfase.bytes;if(!a)throw Error("Geen binaire herstelkopie gevangen");let s="";for(let i=0;i<a.length;i+=16384)s+=String.fromCharCode(...a.subarray(i,i+16384));return btoa(s)})()')
                kopie = a.uitvoer/'werkelijke-herstelkopie.docx'
                kopie.write_bytes(base64.b64decode(bytes_herstel))
                with ZipFile(kopie) as z:
                    xml = ET.fromstring(z.read('word/document.xml'))
                assert [ET.tostring(t) for t in xml.findall('.//w:tbl', ns)] == tabelbron
                terug = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                r['herstel_tekst'] = await p.ev('({voor:_rustigVoor,eind:_rustigVoor+_rustigGetypt})')
                assert terug.startswith(r['herstel_tekst']['voor']) and r['herstel_tekst']['eind'].startswith(terug)
                if fase: assert terug == r['herstel_tekst']['eind']
                r['herstel_tekst'] = {'prefix_exact':True,'actueel':terug == r['herstel_tekst']['eind'],'tabellen':len(tabelbron),'sha256':hashlib.sha256(kopie.read_bytes()).hexdigest()}
                r['herstel_herstel'] = await p.ev('__herstelfase.stop()')
                assert r['herstel_herstel']
''';s=s.replace(anchor,new+anchor);s=s.replace("r['opruiming'] = await p.ev('window.__lat?.stop();true')","r['opruiming'] = await p.ev('window.__herstelfase?.stop();window.__lat?.stop();true')");(p/'proef-herstel.py').write_text(s)
s=(p/'start-profiel.py').read_text().replace("[('profiel-rustig','proef-profiel.py',False)]","[('herstel-normaal','proef-herstel.py',False),('herstel-verschoven','proef-herstel.py',False)]").replace("p/'runs-profiel.json'","p/'runs-herstel.json'").replace("'OFFICE_TEST_GROEPYIELD':'1'if flag else'0'","'OFFICE_TEST_GROEPYIELD':'1'if flag else'0','OFFICE_TEST_HERSTELFASE':'verschuiven'if label=='herstel-verschoven'else'normaal'");(p/'start-herstel.py').write_text(s)
