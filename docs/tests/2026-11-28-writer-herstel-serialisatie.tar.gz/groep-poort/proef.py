#!/usr/bin/env python3
"""Eigen rijke bron: lange fysieke invoer, rendergereedheid en gegevensbehoud.

De gewone invoermeting voegt geen antwoordvertraging toe. Daarna worden
selectie/bewaren/verwerpen afzonderlijk met vastgehouden echte antwoorden getest.
Alle tijden gelden voor deze eigen virtuele X11-proef, niet fysieke scherm-FPS.
OFFICE_TEST_JOURNAAL=1 kiest de echte schema-3-route; standaard schema 2.
"""
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
from xml.etree import ElementTree as ET
from zipfile import ZipFile

REPO = Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06')
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('basis', REPO / 'scripts/test-writer-lang-native.py')
basis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(basis)


async def proef(a):
    from Xlib import X, display
    from PIL import Image
    from gui.webkit_inspector import Inspector
    a.uitvoer.mkdir(parents=True, exist_ok=False)
    bron = a.uitvoer / 'Ontwerpnotitie.docx'
    shutil.copyfile(REPO / 'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx', bron)
    with ZipFile(bron) as pakket:
        begin_xml = ET.fromstring(pakket.read('word/document.xml'))
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    tabelbron = [ET.tostring(t) for t in begin_xml.findall('.//w:tbl', ns)]
    assert len(tabelbron) == 128, 'Vaste rijke bron heeft niet 128 tabellen'
    cfg = Path(os.environ['XDG_CONFIG_HOME']) / 'org.openaec.office-studio'
    cfg.mkdir(parents=True)
    (cfg / 'voorkeuren.json').write_text(json.dumps({'taal': 'en', 'thema': 'forge', 'updates': {'automatisch': False}}))
    subprocess.run(['dbus-update-activation-environment', 'DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME'], check=True)
    d = display.Display()
    log = (a.uitvoer / 'programma.log').open('w')
    app = subprocess.Popen([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    r = {'geslaagd': False, 'versie': a.versie, 'programma_sha256': hashlib.sha256(a.programma.read_bytes()).hexdigest(), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'stappen': [], 'grenzen': __doc__}
    v = None

    def stop():
        if app.poll() is None:
            try:
                os.killpg(app.pid, signal.SIGTERM)
                app.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(app.pid, signal.SIGKILL)
                app.wait(timeout=10)
            except ProcessLookupError:
                pass

    timer = threading.Timer(360, stop)
    timer.daemon = True
    timer.start()

    def beeld(naam):
        g = v.get_geometry()
        raw = v.get_image(0, 0, g.width, g.height, X.ZPixmap, 0xffffffff)
        Image.frombytes('RGB', (g.width, g.height), raw.data, 'raw', 'BGRX').save(a.uitvoer / (naam + '.png'))

    async def beeld_stabiel(p, naam):
        gegevens = await p.run('''await api().flushPendingInput();await document.fonts.ready;
          let begin=performance.now(),vorig=null,sinds=performance.now();
          while(true){
            const nu=performance.now();
            const melding=!!document.querySelector('.office-melding');
            const sleutel=document.body.innerText+Array.from(document.querySelectorAll('canvas')).map(c=>c.toDataURL()).join('|');
            if(melding||sleutel!==vorig){vorig=sleutel;sinds=nu}
            if(!melding&&nu-sinds>=1600&&nu-begin>=4000){await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return {wachtMs:performance.now()-begin,taal:document.querySelector('.statusbalk-taal')?.textContent,bron:stand(),selectie:sessie().selection()}}
            if(nu-begin>15000)throw Error('Beeld wordt niet stabiel: '+String(melding));
            await new Promise(r=>setTimeout(r,100));
          }
        ''')
        r.setdefault('beeldstabiliteit', {})[naam] = gegevens
        beeld(naam)

    async def toets(p, *toetsen, leeg=True):
        vanaf = await p.ev('_toetsen.length')
        subprocess.run(['xdotool', 'key', '--clearmodifiers', *toetsen], check=True)
        laatste = {'left': 'arrowleft', 'right': 'arrowright'}.get(toetsen[-1].split('+')[-1].lower(), toetsen[-1].split('+')[-1].lower())
        await p.run('let eind=performance.now()+10000;while(!_toetsen.slice(' + str(vanaf) + ').includes(' + json.dumps(laatste) + ')){if(performance.now()>eind)throw Error("Toets niet ontvangen");await new Promise(r=>setTimeout(r,20))}return true;')
        if leeg:
            await p.run('await api().flushPendingInput();return true;')

    async def klik(p, expressie):
        xy = await p.ev('(()=>{let e=' + expressie + ';if(!e)throw Error("Geen knop");let r=e.getBoundingClientRect();return{x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)}})()')
        subprocess.run(['xdotool', 'mousemove', '--window', str(v.id), str(xy['x']), str(xy['y']), 'click', '1'], check=True)

    try:
        eind = time.monotonic()+60
        while v is None and time.monotonic() < eind:
            assert app.poll() is None
            for w in d.screen().root.query_tree().children:
                pid = w.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
                if w.get_attributes().map_state == X.IsViewable and pid is not None and int(pid.value[0]) == app.pid:
                    v = w
                    break
            await asyncio.sleep(.1)
        assert v, 'Geen eigen venster'
        pid_prop = v.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
        pid = int(pid_prop.value[0])
        werkelijk = Path(f'/proc/{pid}/exe').read_bytes()
        assert werkelijk.startswith(b'\x7fELF')
        r['startprogramma_sha256'] = r['programma_sha256']
        r['programma_sha256'] = hashlib.sha256(werkelijk).hexdigest()
        v.configure(x=0, y=0, width=1440, height=1000)
        v.set_input_focus(X.RevertToParent, X.CurrentTime)
        d.sync()
        await asyncio.sleep(12)
        async with Inspector(int(os.environ['OFFICE_PROEF_HTTP'])) as p:
            try:
                await p.run("window.api=()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return null;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next){let v=s.memoizedState?.current;if(v?.getEditorRef&&v.commands)return v}return null};let eind=performance.now()+60000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen sessie');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true;")
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|version');") == a.versie
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|identifier');") == 'org.openaec.office-studio'
                # Zelfde eigen proefbron opnieuw openen na vastzetten van de testoptie.
                schema = 3 if os.environ.get('OFFICE_TEST_JOURNAAL') == '1' else 2
                await p.ev("history.replaceState(null,''," + json.dumps('?writerBronjournaal=1' if schema == 3 else '?writerBronjournaal=0') + ");true")
                subprocess.run(['xdotool', 'key', '--clearmodifiers', 'ctrl+w'], check=True)
                await p.run('let eind=performance.now()+15000;while(document.querySelector(".office-tekst")){if(document.querySelector(".office-dialoogacties"))throw Error("Verse bron onverwacht gewijzigd");if(performance.now()>eind)throw Error("Oude editor sluit niet");await new Promise(r=>setTimeout(r,50))}return true;')
                tweede = subprocess.run([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, timeout=30)
                assert tweede.returncode == 0
                await p.run("let eind=performance.now()+60000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen heropende sessie');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true;")
                r['schema'] = schema
                if schema == 3:
                    r['mogelijkheden'] = await p.run("return await window.__TAURI_INTERNALS__.invoke('writer_journaal_mogelijkheden');")
                    assert r['mogelijkheden']['beschikbaar'] is True
                await p.begin_foutbewaking()
                await p.ev('''(() => {
                  window.sessie=()=>api().getEditorRef().getYrsSession();
                  window.tekst=()=>sessie().paragraphs('body').map(p=>p.text).join('');
                  window.stand=()=>JSON.stringify(Object.fromEntries(sessie().storyIds().sort().map(id=>[id,sessie().storySegments(id)])));
                  window._toetsen=[];window._keyupTijden=[];window.addEventListener('keyup',e=>{_toetsen.push(e.key.toLowerCase());_keyupTijden.push({key:e.key.toLowerCase(),ms:performance.now()})},true);
                  window._rust={aanvragen:[],updates:0,houd:false,vertragingMs:0};window._diagnose=[];
                  const intern=window.__TAURI_INTERNALS__,oud=window.fetch,doel=intern.convertFileSrc('writer_tekst_voorbereiden','ipc'),doel3=intern.convertFileSrc('writer_journaal_voorbereiden','ipc'),s=sessie(),pasToe=s.applyLocalUpdate;
                  window.fetch=async function(url,args,...rest){
                    if(String(url)!==doel&&String(url)!==doel3)return oud.call(this,url,args,...rest);
                    const envelop=JSON.parse(args.body),a=envelop.gegevens?.aanvraag??envelop.aanvraag,m={fetchStartMs:performance.now(),schema:a.schema,levensduur:envelop.gegevens?.koppeling.levensduur,volgnummer:envelop.gegevens?.volgnummer,requestId:a.requestId,position:a.position,text:a.text,gereed:false,wacht:false};_rust.aanvragen.push(m);
                    const response=await oud.call(this,url,args,...rest),json=response.json.bind(response);
                    response.json=async()=>{
                      const antwoord=await json();
                      m.bronbinding=['schema','requestId','documentId','sourceVersion','snapshotSha256','clientId'].every(k=>antwoord[k]===a[k]);
                      m.bronbinding=m.bronbinding&&(a.schema!==3||(antwoord.levensduur===m.levensduur&&antwoord.volgnummer===m.volgnummer));m.antwoordMs=performance.now();m.gereed=true;m.caret=antwoord.caret;
                      m.vertragingMs=_rust.vertragingMs;
                      if(m.vertragingMs)await new Promise(resolve=>setTimeout(resolve,m.vertragingMs));
                      if(_rust.houd)await new Promise(resolve=>{m.wacht=true;_rust.los=()=>{_rust.houd=false;m.wacht=false;delete _rust.los;resolve()}});
                      return antwoord;
                    };
                    return response;
                  };
                  s.applyLocalUpdate=function(...args){_rust.updates++;_diagnose.push({soort:'delta',selection:s.selection()});return pasToe.apply(this,args)};
                  const selectie=s.setSelection;
                  s.setSelection=function(...args){_diagnose.push({soort:'selectie',args,stack:new Error().stack.slice(0,500)});return selectie.apply(this,args)};
                  const eerste=s.paragraphs('body')[0],e=api().getEditorRef();
                  e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:eerste.paraId,offset:0}));api().focus();
                  window._voor=stand();window._voorTekst=tekst();return true;
                })()''')
                r['geval'] = os.environ['OFFICE_TEST_POORT']
                await p.ev("(()=>{\n const proto=MessagePort.prototype,desc=Object.getOwnPropertyDescriptor(proto,'postMessage');\n if(!desc||typeof desc.value!=='function'||window.__poort)throw Error('Geen verse MessagePort-poort');\n const g={resterend:0,gezien:0,gehouden:null,opnames:[],origineel:desc.value,proto,desc,rij:null,buffer:null};\n g.arm=(n=1)=>{if(g.gehouden)throw Error('Poort al vast');g.resterend=n;g.gezien=globalThis.__OOS_GROEP_YIELD_AANTAL__??0};\n g.los=()=>{if(!g.gehouden)throw Error('Geen eigen bericht vast');const h=g.gehouden;g.gehouden=null;h.los=performance.now();return desc.value.apply(h.port,h.args)};\n g.scan=()=>{const fibers=new Set,rijen=new Map,buffers=new Map;\n  for(const el of document.querySelectorAll('.office-tabpaneel:not([hidden]) .office-tekst, .office-tabpaneel:not([hidden]) .office-tekst *')){\n   let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];for(;f&&!fibers.has(f);f=f.return){fibers.add(f);for(let h=f.memoizedState,n=0;h&&n++<1000;h=h.next){const ref=h.memoizedState,v=ref?.current;if(!v||typeof v!=='object')continue;\n    if(typeof v.enqueue==='function'&&typeof v.hasPending==='function'&&v.hasPending())rijen.set(v,ref);\n    if(typeof v.text==='string'&&typeof v.first==='number'&&typeof v.last==='number')buffers.set(v,ref);\n   }}\n  }return{rijen:[...rijen].map(([waarde,ref])=>({waarde,ref})),buffers:[...buffers].map(([waarde,ref])=>({waarde,ref}))};\n };\n g.vervangRij=()=>{const x=g.scan();if(x.rijen.length!==1||x.buffers.length!==1)throw Error('Geen unieke actieve SDK-rij/buffer: '+x.rijen.length+'/'+x.buffers.length);const r=x.rijen[0];g.rij={ref:r.ref,oud:r.waarde};g.buffer=x.buffers[0].ref;g.rij.nieuw=new Proxy(r.waarde,{get(t,k){const v=Reflect.get(t,k,t);return typeof v==='function'?v.bind(t):v}});r.ref.current=g.rij.nieuw;return{rijen:x.rijen.length,buffer:g.buffer.current.text,zelfdeRij:r.ref.current===g.rij.oud}};\n g.herstelRij=()=>{if(g.rij){if(g.rij.ref.current!==g.rij.nieuw)throw Error('Onverwachte rij vóór herstel');g.rij.ref.current=g.rij.oud;g.rij=null}return true};\n g.opruimen=()=>{g.resterend=0;if(g.gehouden)g.los();if(g.rij)g.herstelRij();Object.defineProperty(proto,'postMessage',desc);return Object.getOwnPropertyDescriptor(proto,'postMessage').value===desc.value};\n Object.defineProperty(proto,'postMessage',{...desc,value:function(...args){const teller=globalThis.__OOS_GROEP_YIELD_AANTAL__??0;if(g.resterend>0&&args[0]===null&&teller>g.gezien){if(g.gehouden)throw Error('Meer dan één eigen bericht tegelijk');g.resterend--;g.gezien=teller;const h={port:this,args,teller,vast:performance.now(),stack:new Error().stack};if(!h.stack.includes('/assets/editors-'))throw Error('Geen editorbericht');g.gehouden=h;g.opnames.push(h);return}return desc.value.apply(this,args)}});\n window.__poort=g;globalThis.__OOS_GROEP_YIELD__=true;globalThis.__OOS_GROEP_YIELD_AANTAL__=0;return true;\n})()\n")
                await toets(p, 'ctrl+End')
                await p.ev('window._poortVoor=tekst();window._poortStand=stand();window._poortIndex=_rust.aanvragen.length;window._poortUpdates=_rust.updates;_rust.houd=true;true')
                subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'A'], check=True)
                await p.run('const eind=performance.now()+30000;while(!_rust.aanvragen.at(-1)?.wacht){if(performance.now()>eind)throw Error("Geen eerste native antwoord vast");await new Promise(r=>setTimeout(r,20))}return true')
                await p.ev('__poort.arm();true')
                subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'B'], check=True)
                await p.ev('_rust.los();true')
                await p.run('const eind=performance.now()+30000;while(!__poort.gehouden){if(performance.now()>eind)throw Error("Geen eigen yieldbericht vast");await new Promise(r=>setTimeout(r,20))}return true')
                r['vast'] = await p.ev('({tekstCorrect:tekst()===_poortVoor+"A",aanvragen:_rust.aanvragen.length-_poortIndex,updates:_rust.updates-_poortUpdates,teller:__poort.gehouden.teller,buffer:__poort.scan().buffers.map(b=>b.waarde.text)})')
                assert r['vast']['tekstCorrect'] and r['vast']['aanvragen'] == 1 and r['vast']['updates'] == 1
                assert r['vast']['buffer'] == ['B']
                if r['geval'] == 'selectie':
                    await toets(p, 'Left', leeg=False)
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'C'], check=True)
                    await p.ev('__poort.los();true')
                    await p.run('await api().flushPendingInput();return true')
                    r['uitkomst'] = await p.ev('({eind:tekst().slice(-30),verwacht:(_poortVoor+"ACB").slice(-30),correct:tekst()===_poortVoor+"ACB"})')
                    assert r['uitkomst']['correct'], 'Selectiebarrière verandert de volgorde A,B,Left,C'
                    r['stappen'].append('Vastgezet bericht behoudt fysieke selectiebarrière en invoervolgorde')
                elif r['geval'] == 'bewaren':
                    mtime = bron.stat().st_mtime_ns
                    await p.ev('window._flushKlaar=false;window._poortFlush=api().flushPendingInput().then(()=>{_flushKlaar=true});true')
                    await toets(p, 'ctrl+s', leeg=False)
                    await asyncio.sleep(.3)
                    assert not await p.ev('_flushKlaar'), 'Flush loopt vóór het eigen bericht uit'
                    assert bron.stat().st_mtime_ns == mtime, 'Save schrijft vóór de eigen invoergroep'
                    await p.ev('__poort.los();true')
                    await p.run('await _poortFlush;await api().flushPendingInput();return true')
                    eind = time.monotonic()+45
                    while bron.stat().st_mtime_ns == mtime:
                        assert time.monotonic() < eind, 'Geen fysiek opgeslagen document'
                        await asyncio.sleep(.1)
                    assert await p.ev('tekst()===_poortVoor+"AB"')
                    with ZipFile(bron) as z:
                        xml = ET.fromstring(z.read('word/document.xml'))
                    assert [ET.tostring(t) for t in xml.findall('.//w:tbl', ns)] == tabelbron
                    terug = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                    assert terug == await p.ev('tekst()')
                    r['stappen'].append('Flush en fysieke Save wachten; onafhankelijke DOCX behoudt AB en 128 tabellen')
                elif r['geval'] == 'wachtrij':
                    r['vervanging'] = await p.ev('__poort.vervangRij()')
                    assert not r['vervanging']['zelfdeRij']
                    await p.ev('__poort.resterend=1;true')
                    await toets(p, 'Return', leeg=False)
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'C'], check=True)
                    await p.ev('window._nieuweBuffer=__poort.buffer.current;true')
                    assert await p.ev('_nieuweBuffer?.text') == 'C'
                    await p.ev('__poort.los();true')
                    await p.run('const eind=performance.now()+30000;while(!__poort.gehouden){if(performance.now()>eind)throw Error("Geen tweede eigen bericht vast");await new Promise(r=>setTimeout(r,20))}return true')
                    assert await p.ev('__poort.buffer.current===_nieuweBuffer'), 'Oude abort wist een nieuwere invoerbuffer'
                    assert await p.ev('tekst()===_poortVoor+"A"'), 'Oude groep schrijft na wisselen van rij'
                    assert await p.ev('_rust.aanvragen.length-_poortIndex') == 1
                    await p.ev('__poort.los();true')
                    await p.run('await api().flushPendingInput();return true')
                    assert await p.ev('tekst()===_poortVoor+"AC"')
                    await p.ev('__poort.herstelRij();true')
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', 'D'], check=True)
                    await toets(p, 'Right')
                    assert await p.ev('tekst()===_poortVoor+"ACD"')
                    r['stappen'].append('Alleen rij-identiteit vervangen: oude B geweigerd, nieuwere buffer en herstelde rij bruikbaar')
                elif r['geval'] == 'verwerpen':
                    bestandVoor = hashlib.sha256(bron.read_bytes()).hexdigest()
                    updatesVoor = await p.ev('_rust.updates')
                    await toets(p, 'ctrl+w', leeg=False)
                    await p.run('const eind=performance.now()+10000;while(!document.querySelector(".office-dialoogacties")){if(performance.now()>eind)throw Error("Geen sluitdialoog vóór eigen bericht");await new Promise(r=>setTimeout(r,20))}return true')
                    await klik(p, 'Array.from(document.querySelectorAll(".office-dialoogacties button")).find(b=>/Don.t save|Niet opslaan/.test(b.textContent))')
                    await p.run('const eind=performance.now()+10000;while(document.querySelector(".office-tekst")||document.querySelector(".office-dialoogacties")){if(performance.now()>eind)throw Error("Sluiten wacht op eigen bericht");await new Promise(r=>setTimeout(r,20))}return true')
                    await klik(p, 'document.querySelector("button.start-sjabloon.module-docx")')
                    await p.run('const eind=performance.now()+30000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error("Geen nieuw document");await new Promise(r=>setTimeout(r,20))}api().focus();return true')
                    subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '20', 'Nieuw document'], check=True)
                    await toets(p, 'Right')
                    assert await p.ev('tekst()') == 'Nieuw document'
                    aanvragenVoor = await p.ev('_rust.aanvragen.length')
                    await p.ev('__poort.los();true')
                    await asyncio.sleep(.2)
                    await p.run('await api().flushPendingInput();return true')
                    assert await p.ev('tekst()') == 'Nieuw document'
                    assert await p.ev('_rust.aanvragen.length') == aanvragenVoor, 'Oude groep begint alsnog een native aanvraag'
                    assert await p.ev('_rust.updates') == updatesVoor, 'Oude groep schrijft in gesloten sessie'
                    assert hashlib.sha256(bron.read_bytes()).hexdigest() == bestandVoor
                    r['stappen'].append('Niet opslaan, nieuw document en late eigen berichtvrijgave zonder oude aanvraag/mutatie')
                else:
                    raise AssertionError('Onbekend poortgeval')
                r['poortopnames'] = await p.ev('__poort.opnames.map(h=>({teller:h.teller,vast:h.vast,los:h.los,stack:h.stack}))')
                r['poort_herstel'] = await p.ev('__poort.opruimen()')
                assert r['poort_herstel']
                r['native_opdrachten'] = await p.ev('_rust.aanvragen')
                r['fouten'] = await p.fouten()
                assert not any(r['fouten'].values())
                await beeld_stabiel(p, 'poort-'+r['geval'])
                r['geslaagd'] = True
            finally:
                try:
                    r['opruiming'] = await p.ev('window.__poort?.opruimen();true')
                except Exception as fout:
                    r['opruimfout'] = str(fout)
                try:
                    r['diagnose'] = await p.ev('({toetsen:window._keyupTijden?.slice(-30),opdrachten:window._rust?.aanvragen,updates:window._rust?.updates,selecties:window._diagnose,selectie:api()?.getEditorRef()?.getYrsSession()?.selection(),begin:api()?tekst().slice(0,100):null,eind:api()?tekst().slice(-100):null})')
                except Exception as diagnosefout:
                    r['diagnosefout'] = str(diagnosefout)

    except Exception as fout:
        r['fout'] = repr(fout)
        if 'p' in locals():
            r['console_bij_afkeuring'] = p.consoleberichten
        if v and app.poll() is None:
            try:
                beeld('afgekeurd')
            except Exception as beeldfout:
                r['beeldfout'] = repr(beeldfout)
        raise
    finally:
        timer.cancel()
        stop()
        d.close()
        log.close()
        (a.uitvoer / 'rapport.json').write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
    return 0


basis.proef = proef
basis.__file__ = str(Path(__file__).resolve())
if __name__ == '__main__':
    raise SystemExit(basis.main())
