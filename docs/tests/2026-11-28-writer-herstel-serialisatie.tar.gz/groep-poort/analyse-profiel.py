from pathlib import Path
import gzip,json,collections,functools,hashlib
p=Path(__file__).resolve().parent;dist=p.parent/'tabel-paginavakken-productie/dist';events=json.load(gzip.open(p/'profiel-rustig/profielen.json.gz','rt'));profiles=[e['params']for e in events if e.get('method')=='ScriptProfiler.trackingComplete'];assert len(profiles)==1
traces=profiles[0]['samples']['stackTraces'];counter=collections.Counter();leaf=collections.Counter();parents={};sources={}
def key(f):return(f.get('name',''),f.get('url',''),f.get('line'),f.get('column'))
@functools.lru_cache(None)
def text(path):return Path(path).read_text().splitlines(True)
def detail(k):
 name,url,line,col=k;out={'naam':name,'url':url,'regel':line,'kolom':col}
 if '/assets/'in url and line and col and line>0 and col>0:
  f=dist/'assets'/url.split('/assets/',1)[1]
  if f.exists():
   lines=text(str(f));prefix=lines[line-1].encode('utf-16-le')[:(col-1)*2].decode('utf-16-le',errors='ignore');offset=len(prefix);out['functiebron']=lines[line-1][max(0,offset-70):offset+650];sources[str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 return out
for t in traces:
 fs=t['stackFrames'];counter.update(set(map(key,fs)))
 if fs:leaf.update([key(fs[0])])
 for target in ['readParagraphs','SI','dee','getComputedStyle','getBoundingClientRect','Ft','At','br','Dn']:
  i=next((i for i,f in enumerate(fs)if f.get('name')==target),None)
  if i is not None:parents.setdefault(target,collections.Counter()).update([tuple(key(x)for x in fs[i:i+10])])
result={'samples':len(traces),'nul_tijdstempels':sum(t['timestamp']==0 for t in traces),'inclusief':[dict(detail(k),samples=n)for k,n in counter.most_common(45)],'blad':[dict(detail(k),samples=n)for k,n in leaf.most_common(30)],'stacks':{target:[{'samples':n,'frames':[detail(k)for k in ks]}for ks,n in stacks.most_common(4)]for target,stacks in parents.items()},'bronpinnen':sources,'grens':'Hoofdthreadsamples uitsluitend rond achtste rustige toets op 0e1dc-basis, afzonderlijk leaf-first geijkt. Samples zijn geen aanroepen of CPU-milliseconden; inclusieve lidmaatschappen overlappen. Geen fasetoewijzing vanuit nul-tijdstempels.'};(p/'profiel-analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('SAMPLES',len(traces),'NUL',result['nul_tijdstempels'])
for x in result['inclusief'][:22]:print(x['samples'],x['naam'],x.get('functiebron','')[:180])
