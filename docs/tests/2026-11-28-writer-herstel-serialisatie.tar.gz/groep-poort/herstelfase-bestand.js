(verschuif=>{
 const intern=window.__TAURI_INTERNALS__,origineel=intern.invoke,g={verschuif,wijziging:null,timeOrigin:performance.timeOrigin};
 if(verschuif){
  const fibers=new Set,gevonden=new Map;
  for(const el of document.querySelectorAll('*'))for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f&&!fibers.has(f);f=f.return){fibers.add(f);for(let h=f.memoizedState,n=0;h&&n++<1000;h=h.next){const e=h.memoizedState;if(typeof e?.create!=='function')continue;const tekst=e.create.toString(),inst=e.inst??e;if(tekst.includes('recovery.copyFailed')&&tekst.includes('setInterval')&&typeof inst.destroy==='function')gevonden.set(inst,{e,inst,tekst})}}
  if(gevonden.size!==1)throw Error('Geen uniek herstelronde-effect: '+gevonden.size);
  const {e,inst,tekst}=[...gevonden.values()][0],set=window.setInterval,registraties=[];
  inst.destroy();
  window.setInterval=function(fn,periode,...args){const m={gemaakt:performance.now(),periode,tikken:[]};registraties.push(m);return set.call(this,(...a)=>{m.tikken.push(performance.now());return fn(...a)},periode,...args)};
  try{const opruimen=e.create();if(typeof opruimen!=='function')throw Error('Herstelronde mist opruiming');inst.destroy=opruimen}finally{window.setInterval=set}
  if(registraties.length!==1||registraties[0].periode!==30000)throw Error('Onverwachte hersteltimer');
  g.wijziging={bron:tekst,registraties};
 }
 g.stop=()=>intern.invoke===origineel;
 window.__herstelfase=g;return true;
})
