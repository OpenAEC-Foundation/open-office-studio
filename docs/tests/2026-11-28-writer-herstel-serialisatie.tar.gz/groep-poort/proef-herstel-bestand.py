#!/usr/bin/env python3
"""Eigen rijke bron: lange fysieke invoer, rendergereedheid en gegevensbehoud.

De gewone invoermeting voegt geen antwoordvertraging toe. Daarna worden
selectie/bewaren/verwerpen afzonderlijk met vastgehouden echte antwoorden getest.
Alle tijden gelden voor deze eigen virtuele X11-proef, niet fysieke scherm-FPS.
OFFICE_TEST_JOURNAAL=1 kiest de echte schema-3-route; standaard schema 2.
"""
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
from xml.etree import ElementTree as ET
from zipfile import ZipFile

REPO = Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06')
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('basis', REPO / 'scripts/test-writer-lang-native.py')
basis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(basis)


async def proef(a):
    from Xlib import X, display
    from PIL import Image
    from gui.webkit_inspector import Inspector
    a.uitvoer.mkdir(parents=True, exist_ok=False)
    bron = a.uitvoer / 'Ontwerpnotitie.docx'
    shutil.copyfile(REPO / 'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx', bron)
    with ZipFile(bron) as pakket:
        begin_xml = ET.fromstring(pakket.read('word/document.xml'))
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    tabelbron = [ET.tostring(t) for t in begin_xml.findall('.//w:tbl', ns)]
    assert len(tabelbron) == 128, 'Vaste rijke bron heeft niet 128 tabellen'
    cfg = Path(os.environ['XDG_CONFIG_HOME']) / 'org.openaec.office-studio'
    cfg.mkdir(parents=True)
    (cfg / 'voorkeuren.json').write_text(json.dumps({'taal': 'en', 'thema': 'forge', 'updates': {'automatisch': False}}))
    subprocess.run(['dbus-update-activation-environment', 'DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME'], check=True)
    d = display.Display()
    log = (a.uitvoer / 'programma.log').open('w')
    app = subprocess.Popen([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    r = {'geslaagd': False, 'versie': a.versie, 'programma_sha256': hashlib.sha256(a.programma.read_bytes()).hexdigest(), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'stappen': [], 'grenzen': __doc__}
    v = None

    def stop():
        if app.poll() is None:
            try:
                os.killpg(app.pid, signal.SIGTERM)
                app.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(app.pid, signal.SIGKILL)
                app.wait(timeout=10)
            except ProcessLookupError:
                pass

    timer = threading.Timer(360, stop)
    timer.daemon = True
    timer.start()

    def beeld(naam):
        g = v.get_geometry()
        raw = v.get_image(0, 0, g.width, g.height, X.ZPixmap, 0xffffffff)
        Image.frombytes('RGB', (g.width, g.height), raw.data, 'raw', 'BGRX').save(a.uitvoer / (naam + '.png'))

    async def beeld_stabiel(p, naam):
        gegevens = await p.run('''await api().flushPendingInput();await document.fonts.ready;
          let begin=performance.now(),vorig=null,sinds=performance.now();
          while(true){
            const nu=performance.now();
            const melding=!!document.querySelector('.office-melding');
            const sleutel=document.body.innerText+Array.from(document.querySelectorAll('canvas')).map(c=>c.toDataURL()).join('|');
            if(melding||sleutel!==vorig){vorig=sleutel;sinds=nu}
            if(!melding&&nu-sinds>=1600&&nu-begin>=4000){await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return {wachtMs:performance.now()-begin,taal:document.querySelector('.statusbalk-taal')?.textContent,bron:stand(),selectie:sessie().selection()}}
            if(nu-begin>15000)throw Error('Beeld wordt niet stabiel: '+String(melding));
            await new Promise(r=>setTimeout(r,100));
          }
        ''')
        r.setdefault('beeldstabiliteit', {})[naam] = gegevens
        beeld(naam)

    async def toets(p, *toetsen, leeg=True):
        vanaf = await p.ev('_toetsen.length')
        subprocess.run(['xdotool', 'key', '--clearmodifiers', *toetsen], check=True)
        laatste = {'left': 'arrowleft', 'right': 'arrowright'}.get(toetsen[-1].split('+')[-1].lower(), toetsen[-1].split('+')[-1].lower())
        await p.run('let eind=performance.now()+10000;while(!_toetsen.slice(' + str(vanaf) + ').includes(' + json.dumps(laatste) + ')){if(performance.now()>eind)throw Error("Toets niet ontvangen");await new Promise(r=>setTimeout(r,20))}return true;')
        if leeg:
            await p.run('await api().flushPendingInput();return true;')

    async def klik(p, expressie):
        xy = await p.ev('(()=>{let e=' + expressie + ';if(!e)throw Error("Geen knop");let r=e.getBoundingClientRect();return{x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)}})()')
        subprocess.run(['xdotool', 'mousemove', '--window', str(v.id), str(xy['x']), str(xy['y']), 'click', '1'], check=True)

    async def typ(p, letters):
        vanaf = await p.ev('_toetsen.length')
        subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '2', letters], check=True)
        await p.run('const eind=performance.now()+10000;while(!_toetsen.slice('+str(vanaf)+').includes('+json.dumps(letters[-1].lower())+')){if(performance.now()>eind)throw Error("Getypte toets niet ontvangen");await new Promise(r=>setTimeout(r,20))}return true')

    try:
        eind = time.monotonic()+60
        while v is None and time.monotonic() < eind:
            assert app.poll() is None
            for w in d.screen().root.query_tree().children:
                pid = w.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
                if w.get_attributes().map_state == X.IsViewable and pid is not None and int(pid.value[0]) == app.pid:
                    v = w
                    break
            await asyncio.sleep(.1)
        assert v, 'Geen eigen venster'
        pid_prop = v.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
        pid = int(pid_prop.value[0])
        werkelijk = Path(f'/proc/{pid}/exe').read_bytes()
        assert werkelijk.startswith(b'\x7fELF')
        r['startprogramma_sha256'] = r['programma_sha256']
        r['programma_sha256'] = hashlib.sha256(werkelijk).hexdigest()
        v.configure(x=0, y=0, width=1440, height=1000)
        v.set_input_focus(X.RevertToParent, X.CurrentTime)
        d.sync()
        await asyncio.sleep(12)
        async with Inspector(int(os.environ['OFFICE_PROEF_HTTP'])) as p:
            try:
                await p.run("window.api=()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return null;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next){let v=s.memoizedState?.current;if(v?.getEditorRef&&v.commands)return v}return null};let eind=performance.now()+60000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen sessie');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true;")
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|version');") == a.versie
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|identifier');") == 'org.openaec.office-studio'
                # Zelfde eigen proefbron opnieuw openen na vastzetten van de testoptie.
                schema = 3 if os.environ.get('OFFICE_TEST_JOURNAAL') == '1' else 2
                await p.ev("history.replaceState(null,''," + json.dumps('?writerBronjournaal=1' if schema == 3 else '?writerBronjournaal=0') + ");true")
                subprocess.run(['xdotool', 'key', '--clearmodifiers', 'ctrl+w'], check=True)
                await p.run('let eind=performance.now()+15000;while(document.querySelector(".office-tekst")){if(document.querySelector(".office-dialoogacties"))throw Error("Verse bron onverwacht gewijzigd");if(performance.now()>eind)throw Error("Oude editor sluit niet");await new Promise(r=>setTimeout(r,50))}return true;')
                tweede = subprocess.run([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, timeout=30)
                assert tweede.returncode == 0
                await p.run("let eind=performance.now()+60000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen heropende sessie');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true;")
                r['schema'] = schema
                if schema == 3:
                    r['mogelijkheden'] = await p.run("return await window.__TAURI_INTERNALS__.invoke('writer_journaal_mogelijkheden');")
                    assert r['mogelijkheden']['beschikbaar'] is True
                await p.begin_foutbewaking()
                await p.ev('''(() => {
                  window.sessie=()=>api().getEditorRef().getYrsSession();
                  window.tekst=()=>sessie().paragraphs('body').map(p=>p.text).join('');
                  window.stand=()=>JSON.stringify(Object.fromEntries(sessie().storyIds().sort().map(id=>[id,sessie().storySegments(id)])));
                  window._toetsen=[];window._keyupTijden=[];window.addEventListener('keyup',e=>{_toetsen.push(e.key.toLowerCase());_keyupTijden.push({key:e.key.toLowerCase(),ms:performance.now()})},true);
                  window._rust={aanvragen:[],updates:0,houd:false,vertragingMs:0};window._diagnose=[];
                  const intern=window.__TAURI_INTERNALS__,oud=window.fetch,doel=intern.convertFileSrc('writer_tekst_voorbereiden','ipc'),doel3=intern.convertFileSrc('writer_journaal_voorbereiden','ipc'),s=sessie(),pasToe=s.applyLocalUpdate;
                  window.fetch=async function(url,args,...rest){
                    if(String(url)!==doel&&String(url)!==doel3)return oud.call(this,url,args,...rest);
                    const envelop=JSON.parse(args.body),a=envelop.gegevens?.aanvraag??envelop.aanvraag,m={fetchStartMs:performance.now(),schema:a.schema,levensduur:envelop.gegevens?.koppeling.levensduur,volgnummer:envelop.gegevens?.volgnummer,requestId:a.requestId,position:a.position,text:a.text,gereed:false,wacht:false};_rust.aanvragen.push(m);
                    const response=await oud.call(this,url,args,...rest),json=response.json.bind(response);
                    response.json=async()=>{
                      const antwoord=await json();
                      m.bronbinding=['schema','requestId','documentId','sourceVersion','snapshotSha256','clientId'].every(k=>antwoord[k]===a[k]);
                      m.bronbinding=m.bronbinding&&(a.schema!==3||(antwoord.levensduur===m.levensduur&&antwoord.volgnummer===m.volgnummer));m.antwoordMs=performance.now();m.gereed=true;m.caret=antwoord.caret;
                      m.vertragingMs=_rust.vertragingMs;
                      if(m.vertragingMs)await new Promise(resolve=>setTimeout(resolve,m.vertragingMs));
                      if(_rust.houd)await new Promise(resolve=>{m.wacht=true;_rust.los=()=>{_rust.houd=false;m.wacht=false;delete _rust.los;resolve()}});
                      return antwoord;
                    };
                    return response;
                  };
                  s.applyLocalUpdate=function(...args){_rust.updates++;_diagnose.push({soort:'delta',selection:s.selection()});return pasToe.apply(this,args)};
                  const selectie=s.setSelection;
                  s.setSelection=function(...args){_diagnose.push({soort:'selectie',args,stack:new Error().stack.slice(0,500)});return selectie.apply(this,args)};
                  const eerste=s.paragraphs('body')[0],e=api().getEditorRef();
                  e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:eerste.paraId,offset:0}));api().focus();
                  window._voor=stand();window._voorTekst=tekst();return true;
                })()''')
                r['geval'] = 'rustig'
                vlag = os.environ.get('OFFICE_TEST_GROEPYIELD') == '1'
                await p.ev('window.__OOS_GROEP_YIELD__='+str(vlag).lower()+';window.__OOS_GROEP_YIELD_AANTAL__=0;true')
                await toets(p, 'ctrl+End')
                await p.ev("(()=>{\n const s=sessie(),namen=['setUndoInputTime','clearUndoInputTime'],oud=Object.fromEntries(namen.map(n=>[n,{fn:s[n],desc:Object.getOwnPropertyDescriptor(s,n)}]));\n const l={groepen:[],actief:null};\n s.setUndoInputTime=function(eerste,laatste,...rest){const g={eerste,laatste,voorMutatie:performance.now()};l.groepen.push(g);l.actief=g;return oud.setUndoInputTime.fn.call(this,eerste,laatste,...rest)};\n s.clearUndoInputTime=function(...args){const uit=oud.clearUndoInputTime.fn.apply(this,args);if(l.actief)l.actief.naMutatie=performance.now();l.actief=null;return uit};\n l.frame=(staart)=>{const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return false;const gedaan=new Set;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let h=f.memoizedState,n=0;h&&n++<1500;h=h.next)for(const v of[h.memoizedState,h.memoizedState?.current]){\n  if(!v?.displayList?.pages||!v.queries?.sourceState||gedaan.has(v))continue;gedaan.add(v);if(v.queries.sourceState().status==='error')throw Error('Renderbron geeft fout');\n  const tekst=v.displayList.pages.slice(-1).flatMap(p=>p.primitives??[]).filter(p=>typeof p.text==='string').map(p=>p.text).join('');if(tekst.includes(staart))return true;\n }return false};\n l.waarnemingen=[];l.rafs=new Set;\n const raf=fn=>{const id=requestAnimationFrame(()=>{l.rafs.delete(id);fn()});l.rafs.add(id)};\n l.arm=staart=>{const r={staart,begin:performance.now(),leesAantal:0,leesTijd:0,gereed:false};l.waarnemingen.push(r);const stap=()=>{const b=performance.now(),gevonden=l.frame(staart);r.leesTijd+=performance.now()-b;r.leesAantal++;if(!gevonden){raf(stap);return}r.renderlijst=performance.now();raf(()=>raf(()=>{r.frame=performance.now();r.gereed=true}))};raf(stap);return true};\n l.stop=()=>{for(const id of l.rafs)cancelAnimationFrame(id);l.rafs.clear();for(const n of namen){if(oud[n].desc)Object.defineProperty(s,n,oud[n].desc);else delete s[n]}return namen.map(n=>s[n]===oud[n].fn)};\n window.__lat=l;return true;\n})()\n")
                await p.ev('window._rustigVoor=tekst();window._rustigGetypt="";true')
                fase = os.environ.get('OFFICE_TEST_HERSTELFASE') == 'verschuiven'
                await p.ev("(verschuif=>{\n const intern=window.__TAURI_INTERNALS__,origineel=intern.invoke,g={verschuif,wijziging:null,timeOrigin:performance.timeOrigin};\n if(verschuif){\n  const fibers=new Set,gevonden=new Map;\n  for(const el of document.querySelectorAll('*'))for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f&&!fibers.has(f);f=f.return){fibers.add(f);for(let h=f.memoizedState,n=0;h&&n++<1000;h=h.next){const e=h.memoizedState;if(typeof e?.create!=='function')continue;const tekst=e.create.toString(),inst=e.inst??e;if(tekst.includes('recovery.copyFailed')&&tekst.includes('setInterval')&&typeof inst.destroy==='function')gevonden.set(inst,{e,inst,tekst})}}\n  if(gevonden.size!==1)throw Error('Geen uniek herstelronde-effect: '+gevonden.size);\n  const {e,inst,tekst}=[...gevonden.values()][0],set=window.setInterval,registraties=[];\n  inst.destroy();\n  window.setInterval=function(fn,periode,...args){const m={gemaakt:performance.now(),periode,tikken:[]};registraties.push(m);return set.call(this,(...a)=>{m.tikken.push(performance.now());return fn(...a)},periode,...args)};\n  try{const opruimen=e.create();if(typeof opruimen!=='function')throw Error('Herstelronde mist opruiming');inst.destroy=opruimen}finally{window.setInterval=set}\n  if(registraties.length!==1||registraties[0].periode!==30000)throw Error('Onverwachte hersteltimer');\n  g.wijziging={bron:tekst,registraties};\n }\n g.stop=()=>intern.invoke===origineel;\n window.__herstelfase=g;return true;\n})\n"+'('+str(fase).lower()+')')
                r['letters'] = []
                for letter in 'mnopqrst':
                    await p.ev('window._rustigGetypt+='+__import__('json').dumps(letter)+';window._rustigVanaf=_keyupTijden.length;__lat.arm(_rustigVoor.slice(-16)+_rustigGetypt);true')
                    await typ(p, letter)
                    row = await p.run("const eind=performance.now()+30000;while(!__lat.waarnemingen.at(-1)?.gereed){if(performance.now()>eind)throw Error('Geen waargenomen renderlijst');await new Promise(r=>setTimeout(r,10))}const r=__lat.waarnemingen.at(-1);await api().flushPendingInput();const g=__lat.groepen.at(-1),keyup=_keyupTijden.slice(_rustigVanaf).at(-1).ms;return{letter:_rustigGetypt.at(-1),eerste:g.eerste,laatste:g.laatste,voorMutatie:g.voorMutatie,naMutatie:g.naMutatie,renderlijst:r.renderlijst,frame:r.frame,keyup,eersteTotMutatie:g.naMutatie-g.eerste,eersteTotRenderlijst:r.renderlijst-g.eerste,eersteTotFrame:r.frame-g.eerste,keyupTotFrame:r.frame-keyup,mutatieVoorFrame:g.naMutatie<=r.frame,leesAantal:r.leesAantal,leesTijd:r.leesTijd,bronExact:tekst()===_rustigVoor+_rustigGetypt}")
                    assert row['bronExact']
                    r['letters'].append(row)
                    await asyncio.sleep(.25)
                r['groepen'] = await p.ev('__lat.groepen')
                r['yield_aantal'] = await p.ev('window.__OOS_GROEP_YIELD_AANTAL__')
                r['vlag'] = vlag
                eigen_data = Path(os.environ['XDG_DATA_HOME']).resolve()
                eind = time.monotonic()+45
                gevonden = []
                while not gevonden:
                    for f in eigen_data.rglob('*.bin'):
                        if 'herstel' not in f.relative_to(eigen_data).parts or not f.with_suffix('.json').exists(): continue
                        if __import__('json').loads(f.with_suffix('.json').read_text()).get('soort') == 'docx': gevonden.append(f)
                    assert time.monotonic() < eind, 'Geen werkelijke herstelkopie in eigen gegevensmap'
                    if not gevonden: await asyncio.sleep(.05)
                assert len(gevonden) == 1
                bestand = gevonden[0]
                assert bestand.resolve().is_relative_to(eigen_data)
                r['herstelfase'] = await p.ev('({verschuif:__herstelfase.verschuif,wijziging:__herstelfase.wijziging,timeOrigin:__herstelfase.timeOrigin})')
                r['herstel_metadata'] = __import__('json').loads(bestand.with_suffix('.json').read_text())
                r['herstel_begin_ms'] = r['herstel_metadata']['datum']-r['herstelfase']['timeOrigin']
                r['herstel_bestand_ms'] = bestand.stat().st_mtime_ns/1e6-r['herstelfase']['timeOrigin']
                kopie = a.uitvoer/'werkelijke-herstelkopie.docx'
                kopie.write_bytes(bestand.read_bytes())
                with ZipFile(kopie) as z:
                    xml = ET.fromstring(z.read('word/document.xml'))
                assert [ET.tostring(t) for t in xml.findall('.//w:tbl', ns)] == tabelbron
                terug = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                r['herstel_tekst'] = await p.ev('({voor:_rustigVoor,eind:_rustigVoor+_rustigGetypt})')
                assert terug.startswith(r['herstel_tekst']['voor']) and r['herstel_tekst']['eind'].startswith(terug)
                if fase: assert terug == r['herstel_tekst']['eind']
                r['herstel_tekst'] = {'prefix_exact':True,'actueel':terug == r['herstel_tekst']['eind'],'tabellen':len(tabelbron),'sha256':hashlib.sha256(kopie.read_bytes()).hexdigest()}
                r['herstel_bridge_ongewijzigd'] = await p.ev('__herstelfase.stop()')
                assert r['herstel_bridge_ongewijzigd']
                r['herstel'] = await p.ev('__lat.stop()')
                assert all(r['herstel']) and len(r['groepen']) == 8
                r['fouten'] = await p.fouten()
                assert not any(r['fouten'].values())
                await beeld_stabiel(p, 'rustige-invoer')
                r['stappen'].append('Acht rustige fysieke toetsen elk bronexact en aantoonbaar in renderlijst plus twee rAFs; geen fysieke paintmeting')
                r['geslaagd'] = True
            finally:
                try:
                    r['opruiming'] = await p.ev('window.__herstelfase?.stop();window.__lat?.stop();true')
                except Exception as fout:
                    r['opruimfout'] = str(fout)
                try:
                    r['diagnose'] = await p.ev('({toetsen:window._keyupTijden?.slice(-30),opdrachten:window._rust?.aanvragen,updates:window._rust?.updates,selecties:window._diagnose,selectie:api()?.getEditorRef()?.getYrsSession()?.selection(),begin:api()?tekst().slice(0,100):null,eind:api()?tekst().slice(-100):null})')
                except Exception as diagnosefout:
                    r['diagnosefout'] = str(diagnosefout)

    except Exception as fout:
        r['fout'] = repr(fout)
        if 'p' in locals():
            r['console_bij_afkeuring'] = p.consoleberichten
        if v and app.poll() is None:
            try:
                beeld('afgekeurd')
            except Exception as beeldfout:
                r['beeldfout'] = repr(beeldfout)
        raise
    finally:
        timer.cancel()
        stop()
        d.close()
        log.close()
        (a.uitvoer / 'rapport.json').write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
    return 0


basis.proef = proef
basis.__file__ = str(Path(__file__).resolve())
if __name__ == '__main__':
    raise SystemExit(basis.main())
