from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/groep-poort';exe=p.parent/'tabel-paginavakken-productie/open-office-studio-paginavakken-proef';assert hashlib.sha256(exe.read_bytes()).hexdigest()=='0e1dc8435cb83cde3e65aa7b696838f013dd0d919e51489bea0ff3d3c9289385';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};rows=[]
for label,script,flag in [('herstel-normaal','proef-herstel.py',False),('herstel-verschoven','proef-herstel.py',False)]:
 cmd=['/usr/bin/python3',str(p/script),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/label)];t=time.monotonic();print('START',label,flush=True)
 with(p/(label+'.log')).open('x')as log:
  child=subprocess.Popen(cmd,env={**env,'OFFICE_TEST_POORT':label,'OFFICE_TEST_GROEPYIELD':'1'if flag else'0','OFFICE_TEST_HERSTELFASE':'verschuiven'if label=='herstel-verschoven'else'normaal'},stdout=log,stderr=subprocess.STDOUT)
  while child.poll()is None:
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-t),flush=True)
 d=json.loads((p/label/'rapport.json').read_text());row={'label':label,'code':child.returncode,'geslaagd':d['geslaagd'],'fout':d.get('fout'),'yield_aantal':d.get('yield_aantal'),'zichtbaarheid':d.get('zichtbaarheid'),'seconden':time.monotonic()-t};rows.append(row);(p/'runs-herstel.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',json.dumps(row),flush=True)
