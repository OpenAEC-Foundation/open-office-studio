(()=>{
 const proto=MessagePort.prototype,desc=Object.getOwnPropertyDescriptor(proto,'postMessage');
 if(!desc||typeof desc.value!=='function'||window.__poort)throw Error('Geen verse MessagePort-poort');
 const g={resterend:0,gezien:0,gehouden:null,opnames:[],origineel:desc.value,proto,desc,rij:null,buffer:null};
 g.arm=(n=1)=>{if(g.gehouden)throw Error('Poort al vast');g.resterend=n;g.gezien=globalThis.__OOS_GROEP_YIELD_AANTAL__??0};
 g.los=()=>{if(!g.gehouden)throw Error('Geen eigen bericht vast');const h=g.gehouden;g.gehouden=null;h.los=performance.now();return desc.value.apply(h.port,h.args)};
 g.scan=()=>{const fibers=new Set,rijen=new Map,buffers=new Map;
  for(const el of document.querySelectorAll('.office-tabpaneel:not([hidden]) .office-tekst, .office-tabpaneel:not([hidden]) .office-tekst *')){
   let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];for(;f&&!fibers.has(f);f=f.return){fibers.add(f);for(let h=f.memoizedState,n=0;h&&n++<1000;h=h.next){const ref=h.memoizedState,v=ref?.current;if(!v||typeof v!=='object')continue;
    if(typeof v.enqueue==='function'&&typeof v.hasPending==='function'&&v.hasPending())rijen.set(v,ref);
    if(typeof v.text==='string'&&typeof v.first==='number'&&typeof v.last==='number')buffers.set(v,ref);
   }}
  }return{rijen:[...rijen].map(([waarde,ref])=>({waarde,ref})),buffers:[...buffers].map(([waarde,ref])=>({waarde,ref}))};
 };
 g.vervangRij=()=>{const x=g.scan();if(x.rijen.length!==1||x.buffers.length!==1)throw Error('Geen unieke actieve SDK-rij/buffer: '+x.rijen.length+'/'+x.buffers.length);const r=x.rijen[0];g.rij={ref:r.ref,oud:r.waarde};g.buffer=x.buffers[0].ref;g.rij.nieuw=new Proxy(r.waarde,{get(t,k){const v=Reflect.get(t,k,t);return typeof v==='function'?v.bind(t):v}});r.ref.current=g.rij.nieuw;return{rijen:x.rijen.length,buffer:g.buffer.current.text,zelfdeRij:r.ref.current===g.rij.oud}};
 g.herstelRij=()=>{if(g.rij){if(g.rij.ref.current!==g.rij.nieuw)throw Error('Onverwachte rij vóór herstel');g.rij.ref.current=g.rij.oud;g.rij=null}return true};
 g.opruimen=()=>{g.resterend=0;if(g.gehouden)g.los();if(g.rij)g.herstelRij();Object.defineProperty(proto,'postMessage',desc);return Object.getOwnPropertyDescriptor(proto,'postMessage').value===desc.value};
 Object.defineProperty(proto,'postMessage',{...desc,value:function(...args){const teller=globalThis.__OOS_GROEP_YIELD_AANTAL__??0;if(g.resterend>0&&args[0]===null&&teller>g.gezien){if(g.gehouden)throw Error('Meer dan één eigen bericht tegelijk');g.resterend--;g.gezien=teller;const h={port:this,args,teller,vast:performance.now(),stack:new Error().stack};if(!h.stack.includes('/assets/editors-'))throw Error('Geen editorbericht');g.gehouden=h;g.opnames.push(h);return}return desc.value.apply(this,args)}});
 window.__poort=g;globalThis.__OOS_GROEP_YIELD__=true;globalThis.__OOS_GROEP_YIELD_AANTAL__=0;return true;
})()
