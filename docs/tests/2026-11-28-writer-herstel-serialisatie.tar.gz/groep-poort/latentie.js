(()=>{
 const s=sessie(),namen=['setUndoInputTime','clearUndoInputTime'],oud=Object.fromEntries(namen.map(n=>[n,{fn:s[n],desc:Object.getOwnPropertyDescriptor(s,n)}]));
 const l={groepen:[],actief:null};
 s.setUndoInputTime=function(eerste,laatste,...rest){const g={eerste,laatste,voorMutatie:performance.now()};l.groepen.push(g);l.actief=g;return oud.setUndoInputTime.fn.call(this,eerste,laatste,...rest)};
 s.clearUndoInputTime=function(...args){const uit=oud.clearUndoInputTime.fn.apply(this,args);if(l.actief)l.actief.naMutatie=performance.now();l.actief=null;return uit};
 l.frame=(staart)=>{const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return false;const gedaan=new Set;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let h=f.memoizedState,n=0;h&&n++<1500;h=h.next)for(const v of[h.memoizedState,h.memoizedState?.current]){
  if(!v?.displayList?.pages||!v.queries?.sourceState||gedaan.has(v))continue;gedaan.add(v);if(v.queries.sourceState().status==='error')throw Error('Renderbron geeft fout');
  const tekst=v.displayList.pages.slice(-1).flatMap(p=>p.primitives??[]).filter(p=>typeof p.text==='string').map(p=>p.text).join('');if(tekst.includes(staart))return true;
 }return false};
 l.stop=()=>{for(const n of namen){if(oud[n].desc)Object.defineProperty(s,n,oud[n].desc);else delete s[n]}return namen.map(n=>s[n]===oud[n].fn)};
 window.__lat=l;return true;
})()
