from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/groep-poort';exe=p.parent/'groep-eventloop/open-office-studio-eventloop-gebonden';assert hashlib.sha256(exe.read_bytes()).hexdigest()=='7fb17770d45ca92bc6fa82471f4b69778bd597cc06fb229e2dd7c0a8d8432914';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};rows=[]
for label in ['wachtrij']:
 cmd=['/usr/bin/python3',str(p/'proef-wachtrij.py'),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/(label+'-herhaald'))];t=time.monotonic();print('START',label,flush=True)
 with(p/(label+'-herhaald.log')).open('x')as log:
  child=subprocess.Popen(cmd,env={**env,'OFFICE_TEST_POORT':label},stdout=log,stderr=subprocess.STDOUT)
  while child.poll()is None:
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-t),flush=True)
 d=json.loads((p/(label+'-herhaald')/'rapport.json').read_text());row={'label':label,'code':child.returncode,'geslaagd':d['geslaagd'],'fout':d.get('fout'),'vast':d.get('vast'),'uitkomst':d.get('uitkomst'),'seconden':time.monotonic()-t};rows.append(row);(p/'runs-wachtrij.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',json.dumps(row),flush=True)
