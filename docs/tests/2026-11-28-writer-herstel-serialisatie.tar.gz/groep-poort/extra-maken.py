from pathlib import Path
p=Path.cwd()/'.local/integratiecontrole/groep-poort';s=(p/'proef-herzien.py').read_text();a=s.index("                r['geval'] = os.environ['OFFICE_TEST_POORT']");b=s.index('            finally:\n                try:',a)
lat='''                r['geval'] = 'rustig'
                vlag = os.environ.get('OFFICE_TEST_GROEPYIELD') == '1'
                await p.ev('window.__OOS_GROEP_YIELD__='+str(vlag).lower()+';window.__OOS_GROEP_YIELD_AANTAL__=0;true')
                await toets(p, 'ctrl+End')
                await p.ev(__LATENTIE__)
                await p.ev('window._rustigVoor=tekst();window._rustigGetypt="";true')
                r['letters'] = []
                for letter in 'mnopqrst':
                    await p.ev('window._rustigGetypt+='+__import__('json').dumps(letter)+';window._rustigVanaf=_keyupTijden.length;true')
                    await typ(p, letter)
                    row = await p.run('''+repr('''const eind=performance.now()+30000;await api().flushPendingInput();const staart=_rustigVoor.slice(-16)+_rustigGetypt;while(!__lat.frame(staart)){if(performance.now()>eind)throw Error('Rustige invoer niet in renderlijst');await new Promise(r=>setTimeout(r,10))}const lijst=performance.now();await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const frame=performance.now(),g=__lat.groepen.at(-1),keyup=_keyupTijden.slice(_rustigVanaf).at(-1).ms;return{letter:_rustigGetypt.at(-1),eerste:g.eerste,laatste:g.laatste,voorMutatie:g.voorMutatie,naMutatie:g.naMutatie,renderlijst:lijst,frame,keyup,eersteTotMutatie:g.naMutatie-g.eerste,eersteTotRenderlijst:lijst-g.eerste,eersteTotFrame:frame-g.eerste,keyupTotFrame:frame-keyup,bronExact:tekst()===_rustigVoor+_rustigGetypt}''')+''')
                    assert row['bronExact']
                    r['letters'].append(row)
                    await asyncio.sleep(.25)
                r['groepen'] = await p.ev('__lat.groepen')
                r['yield_aantal'] = await p.ev('window.__OOS_GROEP_YIELD_AANTAL__')
                r['vlag'] = vlag
                r['herstel'] = await p.ev('__lat.stop()')
                assert all(r['herstel']) and len(r['groepen']) == 8
                r['fouten'] = await p.fouten()
                assert not any(r['fouten'].values())
                await beeld_stabiel(p, 'rustige-invoer')
                r['stappen'].append('Acht rustige fysieke toetsen elk bronexact en aantoonbaar in renderlijst plus twee rAFs; geen fysieke paintmeting')
                r['geslaagd'] = True
'''
lat=lat.replace('__LATENTIE__',repr((p/'latentie.js').read_text()));out=s[:a]+lat+s[b:];out=out.replace("r['opruiming'] = await p.ev('window.__poort?.opruimen();true')","r['opruiming'] = await p.ev('window.__lat?.stop();true')");(p/'proef-rustig.py').write_text(out)
# Zelfde eigen bericht vasthouden, daadwerkelijke vensterzichtbaarheid vastleggen.
s=(p/'proef-herzien.py').read_text();a=s.index("                if r['geval'] == 'selectie':");b=s.index("                r['poortopnames'] =",a)
hidden='''                assert r['geval'] == 'verborgen'
                v.unmap();d.sync()
                await asyncio.sleep(.5)
                r['zichtbaarheid'] = await p.ev('({hidden:document.hidden,status:document.visibilityState})')
                assert r['zichtbaarheid']['hidden'], 'Eigen verborgen X11-venster meldt geen document.hidden'
                r['verborgen'] = await p.run('''+repr('''const begin=performance.now();__poort.los();const eind=begin+10000;while(_rust.updates!==_poortUpdates+2){if(performance.now()>eind)throw Error('Geen bronmutatie binnen tien seconden in verborgen venster');await new Promise(r=>setTimeout(r,20))}return{begin,eind:performance.now(),hidden:document.hidden,bronExact:tekst()===_poortVoor+'AB'}''')+''')
                assert r['verborgen']['hidden'] and r['verborgen']['bronExact']
                v.map();v.set_input_focus(X.RevertToParent, X.CurrentTime);d.sync()
                await asyncio.sleep(.3)
                await p.run('await api().flushPendingInput();return true')
                assert await p.ev('tekst()===_poortVoor+"AB"')
                r['stappen'].append('Eigen verborgen venster verwerkt het vrijgegeven bericht bronexact; na tonen opnieuw bruikbaar')
'''
s=s[:a]+hidden+s[b:];s=s.replace("            finally:\n                try:","            finally:\n                v.map();d.sync()\n                try:",1);(p/'proef-verborgen.py').write_text(s)
