from pathlib import Path
import subprocess,json,time
p=Path('.local/integratiecontrole/herstel-serialisatie');node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';rows=[]
for label,cmd in [('typescript',[node,'node_modules/typescript/bin/tsc','--noEmit']),('frontend',[node,'node_modules/vite/bin/vite.js','build','--outDir',str(p/'dist')])]:
 t=time.monotonic()
 with(p/(label+'-definitief.log')).open('x')as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'label':label,'code':q.returncode,'opdracht':cmd,'seconden':time.monotonic()-t});(p/'frontend-bouw-definitief.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,q.returncode,flush=True);assert q.returncode==0
