from pathlib import Path
p=Path.cwd()/'.local/integratiecontrole/herstel-serialisatie';s=(p.parent/'groep-poort/proef-herstel-bestand.py').read_text();a=s.index("                r['geval'] = 'rustig'");b=s.index('            finally:\n                try:',a)
body='''                r['geval'] = 'wachtende-eigenschappen'
                await p.ev('localStorage.setItem("openaec-office-herstelinterval","1");true')
                await p.run('const eind=performance.now()+20000;while(performance.now()<35000){if(performance.now()>eind)throw Error("Eerste lege herstelronde niet verstreken");await new Promise(r=>setTimeout(r,50))}return true', t=25)
                bestandVoor = hashlib.sha256(bron.read_bytes()).hexdigest()
                await p.ev('window._metaVoor=tekst();true')
                await klik(p, 'document.querySelector(".ribbon-bestand")')
                await p.run('const eind=performance.now()+10000;while(!document.querySelector(".office-backstage:not([hidden])")){if(performance.now()>eind)throw Error("Geen Bestand-scherm");await new Promise(r=>setTimeout(r,50))}return true')
                await klik(p, 'Array.from(document.querySelectorAll(".office-backstage button")).find(b=>b.textContent.trim()==="Info")')
                await p.run('const eind=performance.now()+45000;while(!document.querySelector(".tekst-info input")){if(performance.now()>eind)throw Error("Geen documenteigenschappen");await new Promise(r=>setTimeout(r,50))}return true', t=50)
                await klik(p, 'document.querySelector(".tekst-info input")')
                await toets(p, 'ctrl+a', leeg=False)
                await typ(p, 'Eigen herstelproef')
                await toets(p, 'Right', leeg=False)
                assert await p.ev('document.querySelector(".tekst-info input").value') == 'Eigen herstelproef'
                beeld('wachtende-titel')
                await klik(p, 'document.querySelector(".tekst-info button.is-primair")')
                await p.run('const eind=performance.now()+10000;while(document.querySelector(".tekst-info")){if(performance.now()>eind)throw Error("Eigenschappen sluiten niet");await new Promise(r=>setTimeout(r,50))}return true')
                await klik(p, 'Array.from(document.querySelectorAll(".office-tabnaam")).find(b=>b.textContent==="Ontwerpnotitie.docx")')
                await p.run('const eind=performance.now()+15000;while(!api()){if(performance.now()>eind)throw Error("Geen actieve editor na Info");await new Promise(r=>setTimeout(r,50))}api().focus();return true')
                await toets(p, 'ctrl+End')
                await typ(p, ' Hersteltekst')
                await toets(p, 'Right')
                assert await p.ev('tekst()===_metaVoor+" Hersteltekst"')
                klaarUnix = await p.ev('Date.now()')
                eigen_data = Path(os.environ['XDG_DATA_HOME']).resolve()
                eind = time.monotonic()+100
                gevonden = []
                while not gevonden:
                    for f in eigen_data.rglob('*.bin'):
                        if 'herstel' not in f.relative_to(eigen_data).parts or not f.with_suffix('.json').exists(): continue
                        m = json.loads(f.with_suffix('.json').read_text())
                        if m.get('soort') == 'docx' and m.get('datum',0) >= klaarUnix: gevonden.append(f)
                    assert time.monotonic() < eind, 'Geen actuele herstelkopie na eigenschap en invoer'
                    if not gevonden: await asyncio.sleep(.1)
                assert len(gevonden) == 1
                herstelpad = gevonden[0]
                assert herstelpad.resolve().is_relative_to(eigen_data)
                kopie = a.uitvoer/'werkelijke-herstelkopie.docx'
                kopie.write_bytes(herstelpad.read_bytes())
                with ZipFile(kopie) as z:
                    xml = ET.fromstring(z.read('word/document.xml'))
                    kern = ET.fromstring(z.read('docProps/core.xml'))
                cp = {'dc':'http://purl.org/dc/elements/1.1/','cp':'http://schemas.openxmlformats.org/package/2006/metadata/core-properties'}
                assert kern.findtext('dc:title', namespaces=cp) == 'Eigen herstelproef'
                assert [ET.tostring(t) for t in xml.findall('.//w:tbl', ns)] == tabelbron
                terug = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                assert terug == await p.ev('tekst()')
                with ZipFile(bron) as z:
                    origineelKern = ET.fromstring(z.read('docProps/core.xml'))
                oorspronkelijkeRevisie = int(origineelKern.findtext('cp:revision',default='0',namespaces=cp))
                assert int(kern.findtext('cp:revision',default='0',namespaces=cp)) == oorspronkelijkeRevisie
                assert hashlib.sha256(bron.read_bytes()).hexdigest() == bestandVoor, 'Herstel overschrijft het oorspronkelijke bestand'
                r['herstelbewijs'] = {'titel':'Eigen herstelproef','revisie':oorspronkelijkeRevisie,'body_exact':True,'tabellen':len(tabelbron),'origineel_ongewijzigd':True,'sha256':hashlib.sha256(kopie.read_bytes()).hexdigest()}
                mtime = bron.stat().st_mtime_ns
                await toets(p, 'ctrl+s', leeg=False)
                eind = time.monotonic()+45
                while bron.stat().st_mtime_ns == mtime:
                    assert time.monotonic() < eind, 'Geen normale opslag'
                    await asyncio.sleep(.1)
                with ZipFile(bron) as z:
                    xml = ET.fromstring(z.read('word/document.xml'))
                    kern = ET.fromstring(z.read('docProps/core.xml'))
                    appxml = ET.fromstring(z.read('docProps/app.xml'))
                assert kern.findtext('dc:title',namespaces=cp) == 'Eigen herstelproef'
                assert int(kern.findtext('cp:revision',default='0',namespaces=cp)) == oorspronkelijkeRevisie+1
                assert [ET.tostring(t) for t in xml.findall('.//w:tbl', ns)] == tabelbron
                terug = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                assert terug == await p.ev('tekst()')
                import unicodedata
                alineas = [''.join(t.text or '' for t in el.findall('.//w:t', ns)).replace('\\ufffc','') for el in xml.findall('.//w:p',ns)]
                woorden = sum(any(unicodedata.category(c)[0] in 'LN' for c in woord) for alinea in alineas for woord in alinea.split())
                nsapp = {'a':'http://schemas.openxmlformats.org/officeDocument/2006/extended-properties'}
                assert int(appxml.findtext('a:Words',namespaces=nsapp)) == woorden
                assert int(appxml.findtext('a:CharactersWithSpaces',namespaces=nsapp)) == sum(len(t)for t in alineas)
                r['normale_opslag'] = {'titel':'Eigen herstelproef','revisie':oorspronkelijkeRevisie+1,'woorden':woorden,'tekens':sum(len(t)for t in alineas),'body_exact':True,'tabellen':len(tabelbron)}
                eind = time.monotonic()+15
                while herstelpad.exists():
                    assert time.monotonic() < eind, 'Normale opslag ruimt herstelkopie niet op'
                    await asyncio.sleep(.1)
                r['herstel_opgeruimd'] = True
                r['fouten'] = await p.fouten()
                assert not any(r['fouten'].values())
                await beeld_stabiel(p, 'eigenschappen-bewaard')
                r['geslaagd'] = True
''';(p/'proef-metadata.py').write_text(s[:a]+body+s[b:])
