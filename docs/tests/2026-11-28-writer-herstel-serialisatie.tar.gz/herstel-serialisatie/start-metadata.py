from pathlib import Path
import os,subprocess,time,json
r=Path.cwd();p=r/'.local/integratiecontrole/herstel-serialisatie';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};cmd=['/usr/bin/python3',str(p/'proef-metadata.py'),'--programma',str(p/'open-office-studio-herstel-proef'),'--versie','2026.45.52','--uitvoer',str(p/'metadata')];t=time.monotonic()
with(p/'metadata.log').open('x')as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while child.poll()is None:
  try:child.wait(timeout=20)
  except subprocess.TimeoutExpired:print('METADATA ACTIEF',round(time.monotonic()-t),flush=True)
d=json.loads((p/'metadata/rapport.json').read_text());row={'code':child.returncode,'geslaagd':d['geslaagd'],'fout':d.get('fout'),'seconden':time.monotonic()-t};(p/'metadata-run.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
