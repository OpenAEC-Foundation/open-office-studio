from pathlib import Path
p=Path.cwd()/'.local/integratiecontrole/herstel-serialisatie';s=(p.parent/'groep-poort/proef-herstel-bestand.py').read_text();s=s.replace("REPO / 'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'","REPO / '.local/integratiecontrole/herstel-serialisatie/metadata/Ontwerpnotitie.docx'");a=s.index("                r['geval'] = 'rustig'");b=s.index('            finally:\n                try:',a)
body="""                r['geval'] = 'nieuw-proces'
                with ZipFile(bron) as z:
                    xml = ET.fromstring(z.read('word/document.xml'))
                verwacht = ''.join(t.text or '' for el in xml.find('w:body', ns).findall('w:p', ns) for t in el.findall('.//w:t', ns))
                assert await p.ev('tekst()') == verwacht
                verwachtCellen = [[[''.join(t.text or '' for t in para.findall('.//w:t',ns)) for para in cel.findall('w:p',ns)] for rij in tabel.findall('w:tr',ns) for cel in rij.findall('w:tc',ns)] for tabel in xml.find('w:body',ns).findall('w:tbl',ns)]
                r['cellen'] = await p.run('const verwacht='+json.dumps(verwachtCellen)+''';const s=sessie(),versie=s.version(),cellen=verwacht.map((_,i)=>s.tablePayload('body',i).rows.flatMap(r=>r.cells.map(c=>c.story))),ids=cellen.flat(),gelezen=new Map;for(let i=0;i<ids.length;i+=32){const r=s.readStories({view:'accepted',stories:ids.slice(i,i+32),expectVersion:versie});if(!r.ok||r.truncated||r.version!==versie)throw Error('Celgroep onleesbaar');for(const v of r.stories){if(!v.ok)throw Error('Cel onleesbaar');gelezen.set(v.story,v.paragraphs.map(p=>p.text))}}for(let t=0;t<verwacht.length;t++){if(cellen[t].length!==verwacht[t].length)throw Error('Celgrootte niet gelijk');for(let c=0;c<cellen[t].length;c++)if(JSON.stringify(gelezen.get(cellen[t][c]))!==JSON.stringify(verwacht[t][c]))throw Error('Celtekst niet gelijk')}if(s.version()!==versie)throw Error('Lezing wijzigt bron');return{tabellen:cellen.length,cellen:ids.length,bronExact:true};''')
                await klik(p, 'document.querySelector(".ribbon-bestand")')
                await p.run('const eind=performance.now()+10000;while(!document.querySelector(".office-backstage:not([hidden])")){if(performance.now()>eind)throw Error("Geen Bestand");await new Promise(r=>setTimeout(r,50))}return true')
                await klik(p, 'Array.from(document.querySelectorAll(".office-backstage button")).find(b=>b.textContent.trim()==="Info")')
                await p.run('const eind=performance.now()+45000;while(!document.querySelector(".tekst-info input")){if(performance.now()>eind)throw Error("Geen eigenschappen");await new Promise(r=>setTimeout(r,50))}return true',t=50)
                r['titel'] = await p.ev('document.querySelector(".tekst-info input").value')
                assert r['titel'] == 'Eigen herstelproef'
                beeld('eigenschappen-heropend')
                r['fouten'] = await p.fouten()
                assert not any(r['fouten'].values())
                r['geslaagd'] = True
""";(p/'proef-heropen.py').write_text(s[:a]+body+s[b:])
s=(p/'start-metadata.py').read_text().replace("p/'proef-metadata.py'","p/'proef-heropen.py'").replace("p/'metadata'","p/'heropend'").replace("p/'metadata.log'","p/'heropend.log'").replace("p/'metadata/rapport.json'","p/'heropend/rapport.json'").replace("p/'metadata-run.json'","p/'heropend-run.json'");(p/'start-heropen.py').write_text(s)
