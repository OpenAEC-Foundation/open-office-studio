(()=>{
 'use strict';
 if(window._werkerProbe)throw Error('Werkermeting bestaat al');
 const proto=Worker.prototype,oud=Object.getOwnPropertyDescriptor(proto,'postMessage'),fn=proto.postMessage;
 if(typeof fn!=='function'||!oud?.configurable)throw Error('Werkermethode niet veilig te volgen');
 const regels=[],werkers=new Map(),strings=[];let stringBytes=0;
 const intern=s=>{if(typeof s!=="string")return null;let i=strings.indexOf(s);if(i>=0)return i;if(strings.length>=128||stringBytes+s.length>8*1024*1024){overgeslagen++;return null}strings.push(s);stringBytes+=s.length;return strings.length-1};
 const version=()=>{try{return typeof sessie==="function"?sessie()?.version():null}catch{return null}};
 const kopie=(o,d=0)=>{if(o===null||["string","number","boolean"].includes(typeof o))return o;if(typeof o!=="object")return undefined;if(d>8){overgeslagen++;return null}const keys=Object.keys(o);if(keys.length>256)overgeslagen++;const r=Array.isArray(o)?[]:{};for(const k of keys.slice(0,256)){const x=Object.getOwnPropertyDescriptor(o,k);if(x&&"value"in x)r[k]=kopie(x.value,d+1)}return r};let actief=true,overgeslagen=0;
 const waarde=(o,k)=>o&&Object.getOwnPropertyDescriptor(o,k)?.value;
 function voeg(r){if(!actief)return;if(regels.length<4096)regels.push(r);else overgeslagen++}
 function meta(o){
  const r={};for(const k of ['id','type','ok']){const v=waarde(o,k);if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')r[k]=typeof v==='string'?v.slice(0,80):v}
  const layoutInput=waarde(o,'layoutInput');if(r.type==='fontRequirements'&&typeof layoutInput==='string')r.layoutInput=layoutInput;
  if(typeof waarde(o,'requirementsJson')==='string')r.requirements=true;
  for(const k of ['documentVersion','layoutRevision','frameEpoch']){const v=waarde(o,k);if(typeof v==='string'||typeof v==='number')r[k]=v}
  if(r.type==='sync'){const s=waarde(o,'snapshot');r.sourceVersion=version();r.stack=intern(new Error().stack??'');r.snapshot={};for(const k of ['layoutRevision','fontsRevision','fontsBaseRevision','workerAuthoritative','layoutWithRegions','partialDocument']){const v=waarde(s,k);if(['string','number','boolean'].includes(typeof v))r.snapshot[k]=v}r.snapshot.stateBytes=waarde(s,'state')?.byteLength??null;r.snapshot.layoutInput=intern(waarde(s,'layoutInput'));r.snapshot.renderInputs=intern(JSON.stringify(kopie(waarde(s,'renderInputs'))));r.snapshot.measureInputs=waarde(s,'measureInputs')?.length??null;r.expectedFrameEpoch=waarde(o,'expectedFrameEpoch')??null;r.layoutReply=waarde(o,'layoutReply')??null}
  if(typeof r.documentVersion==='string')r.sourceVersion=version();
  const saved=waarde(o,'saved'),updates=waarde(o,'updates');
  if(saved instanceof ArrayBuffer)r.bewaarbytes=saved.byteLength;
  if(Array.isArray(updates))r.updates=updates.length;
  for(const k of ['commandFrame','caret','collabUpdates'])if(waarde(o,k))r[k]=true;
  return r;
 }
 const wrapper={postMessage(...args){
  if(!actief)return Reflect.apply(fn,this,args);
  let nr=werkers.get(this)?.nr;
  if(!nr&&werkers.size<8){nr=werkers.size+1;const luister=e=>{try{voeg({richting:'ontvangst',werker:nr,tijd:performance.now(),...meta(e.data)})}catch{}};this.addEventListener('message',luister,true);werkers.set(this,{nr,luister})}
  try{voeg({richting:'verzending',werker:nr??null,tijd:performance.now(),...meta(args[0])})}catch{}
  return Reflect.apply(fn,this,args);
 }}.postMessage;
 Object.defineProperty(proto,'postMessage',{...oud,value:wrapper});
 window._werkerProbe={stop(){actief=false;for(const [w,x]of werkers)w.removeEventListener('message',x.luister,true);const hersteld=proto.postMessage===wrapper;if(hersteld)Object.defineProperty(proto,'postMessage',oud);return {regels,overgeslagen,hersteld,werkers:werkers.size,grens:4096,werkergrens:8,geen_extra_aanvragen:true,strings,stringBytes}}};
 return {grens:4096,werkergrens:8};
})()
