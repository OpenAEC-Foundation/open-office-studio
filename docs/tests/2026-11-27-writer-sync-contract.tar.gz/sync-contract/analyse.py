from pathlib import Path
import json,collections,hashlib
p=Path(__file__).resolve().parent;out={}
for name in ['native','metadata-schoon']:
 d=json.loads((p/name/'rapport.json').read_text());assert d['geslaagd'];raw=d['fasen_eind'][0]['result']['result']['value'];tr=d['transport_eind'];assert raw['overgeslagen']==tr['overgeslagen']==0 and tr['hersteld'];ev=raw['regels'];sent={x['id']:x for x in tr['regels']if x['richting']=='verzending'and x.get('type')=='sync'};reply={x['id']:x for x in tr['regels']if x['richting']=='ontvangst'and x['id']in sent};metas={x['id']:x for x in raw['sync']};assert set(sent)==set(reply)==set(metas)
 starts={};phases=collections.defaultdict(list);tasks={}
 for e in ev:
  if e['soort']in ['taak.begin','taak.einde']:tasks.setdefault(e['id'],{})[e['soort']]=e
  if not e['soort'].startswith('sync.'):continue
  soort,edge=e['soort'].rsplit('.',1);key=(e['id'],soort)
  if edge=='begin':assert key not in starts;starts[key]=e['tijd']
  elif edge=='einde':begin=starts.pop(key);assert begin<=e['tijd'];phases[e['id']].append({'soort':soort,'begin':begin,'eind':e['tijd'],'ms':e['tijd']-begin})
 assert not starts;assert set(phases)==set(sent);totals=collections.Counter();counts=collections.Counter();rows=[]
 for i,s in sent.items():
  a=metas[i];b=reply[i];has_meta='snapshot'in s;snap=s.get('snapshot',{});task=tasks[i];assert task['taak.begin']['type']=='sync'
  if has_meta:assert a['layoutRevision']==snap['layoutRevision']and a['stateBytes']==snap['stateBytes']and a['workerAuthoritative']==snap.get('workerAuthoritative',False)
  stages=phases[i]
  for x in stages:assert task['taak.begin']['tijd']<=x['begin']<=x['eind']<=task['taak.einde']['tijd'];totals[x['soort']]+=x['ms'];counts[x['soort']]+=1
  layout=tr['strings'][snap['layoutInput']]if has_meta else None;render=tr['strings'][snap['renderInputs']]if has_meta else None;li=json.loads(layout)if has_meta else {};ri=json.loads(render)if has_meta else None;assert b['ok']
  if has_meta:assert len(ri)==a['renderInputs']and b['layoutRevision']==snap['layoutRevision']
  updates=[x for x in tr['regels']if x['richting']=='verzending'and x.get('type')=='applyUpdate'and s['tijd']<x['tijd']<b['tijd']]
  rows.append({'id':i,'layoutRevision':a['layoutRevision'],'workerAuthoritative':a['workerAuthoritative'],'stateBytes':a['stateBytes'],'renderInputs':ri,'measureInputs':a['measureInputs'],'fontsRevision':a['fontsRevision'],'main_source_bij_verzending':s.get('sourceVersion'),'worker_source_bij_start':a['version'],'reply_documentVersion':b.get('documentVersion'),'main_source_bij_ontvangst':b.get('sourceVersion'),'metadata_beschikbaar':has_meta,'main_source_gewijzigd_tijdens_rondreis':s.get('sourceVersion')!=b.get('sourceVersion')if has_meta else None,'latere_applyUpdate_verzendingen_voor_antwoord':len(updates),'rondreis_ms':b['tijd']-s['tijd'],'taak_ms':task['taak.einde']['tijd']-task['taak.begin']['tijd'],'layoutInput_sha256':hashlib.sha256(layout.encode()).hexdigest()if has_meta else None,'layoutInput_tekens':len(layout)if has_meta else None,'bodyStory':li.get('bodyStory'),'main_stack':tr['strings'][s['stack']]if has_meta else None,'fasen':stages})
 out[name]={'syncs':len(rows),'syncs_met_metadata':sum(x['metadata_beschikbaar']for x in rows),'fasen_ms_som':dict(totals),'faseaantallen':dict(counts),'workerAuthoritative':dict(collections.Counter(str(x['workerAuthoritative'])for x in rows)),'stateBytes':dict(collections.Counter(x['stateBytes']for x in rows)),'fontrevisies':sorted({x['fontsRevision']for x in rows}),'main_source_gewijzigd_tijdens_rondreis':sum(x['main_source_gewijzigd_tijdens_rondreis']is True for x in rows)if any(x['metadata_beschikbaar']for x in rows)else None,'syncs_met_later_updatebericht':sum(x['latere_applyUpdate_verzendingen_voor_antwoord']>0 for x in rows),'overgeslagen':0,'ruwe_syncs':rows,'grens':'Voorbereiding bevat load als geneste subfase; niet optellen. Publicatie is asynchroon en kan wachten/overlappen. Versietokens zijn replica-gebonden: main en Worker niet op gelijkheid vergelijken. Verandering binnen de main-rondreis bewijst evenmin dat het frame achterhaald of weggegooid is.'}
(p/'analyse.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({n:{k:v for k,v in d.items()if k!='ruwe_syncs'}for n,d in out.items()},ensure_ascii=False))
