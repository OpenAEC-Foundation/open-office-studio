import fs from 'node:fs';import ts from 'typescript';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const root='.local/integratiecontrole/projectie-context/dist/assets/',out={};
for(const file of ['index-DtZ2IWH9.js','editors-bODdYQ4o.js','chunk-Q7OC7M5Q-BzppsI5m.js']){
 const text=fs.readFileSync(root+file,'utf8'),ast=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),items=[];
 const target=text.indexOf('H.sync(Be');let owner=null;
 function visit(n){const name=n.name?.getText(ast);
 if(ts.isMethodDeclaration(n)&&['sync','request','recordSent','recordSync','invalidate'].includes(name))items.push({name,source:n.getText(ast)});
 if(ts.isFunctionDeclaration(n)&&['Ea','jl','x_','xr'].includes(name))items.push({name,source:n.getText(ast)});
 if(file.startsWith('editors')&&target>=0&&n.getStart(ast)<=target&&n.end>target&&(ts.isArrowFunction(n)||ts.isFunctionExpression(n))&&(!owner||n.end-n.pos<owner.end-owner.pos))owner=n;
 ts.forEachChild(n,visit)}visit(ast);if(owner)items.push({name:'layoutInWorker callback bo',source:owner.getText(ast)});
 out[file]={sha256:crypto.createHash('sha256').update(text).digest('hex'),items};
}
assert(out['index-DtZ2IWH9.js'].items.some(x=>x.name==='sync'));assert(out['chunk-Q7OC7M5Q-BzppsI5m.js'].items.some(x=>x.name==='Ea'));assert(out['editors-bODdYQ4o.js'].items.some(x=>x.name==='layoutInWorker callback bo'));
fs.writeFileSync('.local/integratiecontrole/sync-contract/bron.json',JSON.stringify(out,null,2)+'\n');console.log('Client, werkelijke layoutcallback, snapshotvoorbereiding en antwoorddecoder brongebonden');
