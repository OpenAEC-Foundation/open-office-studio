from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as E
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();docs={};pixels=[]
for name in ['native','herhaling','metadata','metadata-schoon']:
 q=p/name;report=json.loads((q/'rapport.json').read_text());f=q/'Ontwerpnotitie.docx';assert report['geslaagd']and sha(f.read_bytes())==report['bewaring_sha256']
 with zipfile.ZipFile(f)as z:
  assert z.testzip()is None;names=z.namelist();assert len(names)==len(set(names));assert all(not n.startswith('/')and '..'not in Path(n).parts for n in names);parts={}
  for n in names:
   b=z.read(n);parts[n]=sha(b)
   if n.endswith(('.xml','.rels')):E.fromstring(b)
  root=E.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(x.text or''for x in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128 and units==91423;docs[name]={'sha256':sha(f.read_bytes()),'tabellen':tables,'utf16':units,'delen':parts}
a=docs['native']['delen'];diff={}
for name in ['herhaling','metadata','metadata-schoon']:
 b=docs[name]['delen'];assert set(a)==set(b);diff[name]=[n for n in a if a[n]!=b[n]];assert set(diff[name])<={'docProps/core.xml'}
for n in ['invoer-redo.png','snel-getypt-bewaard.png','nieuw-na-laat-antwoord.png']:
 a=Image.open(p/'native'/n).convert('RGB');b=Image.open(p/'metadata-schoon'/n).convert('RGB');assert a.size==b.size;d=ImageChops.difference(a,b);box=d.getbbox();pixels.append({'bestand':n,'verschillende_pixels':0 if box is None else sum(any(x)for x in d.crop(box).getdata()),'bbox':box})
(p/'documenten.json').write_text(json.dumps({'geslaagd':True,'documenten':docs,'verschillende_delen':diff,'beelden':pixels,'grens':'ZIP/CRC/paden/XML/tekstgetal en drie vaste beelden; geen volledige visuele/formaatacceptatie.'},indent=2)+'\n');print(json.dumps({'geslaagd':True,'beelden':pixels,'verschillende_delen':diff}))
