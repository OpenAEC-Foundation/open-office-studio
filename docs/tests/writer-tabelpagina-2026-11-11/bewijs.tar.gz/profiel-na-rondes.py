from pathlib import Path
import json,time,subprocess,os
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-profiel';p=u/'tabelgrepen/rapport.json'
for _ in range(1800):
 if p.exists():break
 time.sleep(1)
assert json.loads(p.read_text())['geslaagd']
env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH']
cmd=['/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python',str(r/'scripts/profiel-writer-invoer-native.py'),'--programma',str(r/'.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal'),'--uitvoer',str(u/'schema2-geldige-tekst'),'--versie','2026.45.52','--bron',str(r/'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'),'--paginas','65','--tekst',' Een langere proefzin met woorden en spaties. Een langere proefzin met woorden en spaties. Een langere proefzin met woorden en spaties.']
with (u/'schema2-geldige-tekst.log').open('w') as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
print('profiel',res.returncode,flush=True);assert res.returncode==0
