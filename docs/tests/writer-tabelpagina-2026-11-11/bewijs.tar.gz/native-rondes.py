from pathlib import Path
import json,subprocess,os,time
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-profiel';p=u/'desktop.json'
for _ in range(1250):
 if p.exists():break
 time.sleep(1)
x=json.loads(p.read_text());assert x['code']==0,x
exe=Path(x['programma']);oud=r/'.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal'
env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python'
scenario=[('kandidaat2',exe,0,'test-writer-rijk-invoer-native.py'),('referentie2',oud,0,'test-writer-rijk-invoer-native.py'),('kandidaat3',exe,1,'test-writer-rijk-invoer-native.py'),('tabelgrepen',exe,0,'test-writer-tabelgrepen-native.py')]
for naam,app,schema,script in scenario:
 env['OFFICE_TEST_JOURNAAL']=str(schema)
 with (u/(naam+'.log')).open('w') as log:res=subprocess.run([python,str(r/'scripts'/script),'--programma',str(app),'--uitvoer',str(u/naam),'--versie','2026.45.52'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=450)
 x=json.loads((u/naam/'rapport.json').read_text());print(naam,res.returncode,x.get('lange_invoer'),x.get('fout'),flush=True)
 assert res.returncode==0 and x['geslaagd'],x.get('fout')
