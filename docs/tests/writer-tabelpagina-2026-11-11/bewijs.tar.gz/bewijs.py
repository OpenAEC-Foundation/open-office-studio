from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import json,hashlib,gzip,tarfile,subprocess
from PIL import Image,ImageChops
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-profiel';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bouw=json.loads((u/'desktop.json').read_text());assert bouw['code']==0 and sha(Path(bouw['programma']))==bouw['programma_sha256']
assert '2324 passed | 4 skipped (2328)' in (u/'volledig.log').read_text() and '4 passed (4)' in (u/'echte-host.log').read_text();assert not (u/'typescript.log').read_text();assert 'Ran 127 tests' in (u/'python.log').read_text() and '\nOK\n' in (u/'python.log').read_text()
resultaten={}
for naam in ['kandidaat2','referentie2','kandidaat3']:
 x=json.loads((u/naam/'rapport.json').read_text());assert x['geslaagd'] and x['bewaarde_tabellen_exact']==128 and not any(x['fouten'].values());assert len(x['stappen'])==3
 resultaten[naam]={'programma_sha256':x['programma_sha256'],'meting':x['lange_invoer'],'schema':x['schema'],'undo_groepen':x['undo_groepen_lange_invoer'],'native_opdrachten_totaal_inclusief_vervolg':len(x['native_opdrachten']),'stappen':x['stappen'],'fouten':x['fouten']}
tabel=json.loads((u/'tabelgrepen/rapport.json').read_text());assert tabel['geslaagd']
profiel=json.loads((u/'schema2-geldige-tekst/profiel.json').read_text());assert profiel['geslaagd'];assert profiel['na']==profiel['voor']+profiel['invoertekst']
assert profiel['programma_sha256']==resultaten['referentie2']['programma_sha256']
afgekeurd=json.loads((u/'schema2/profiel.json').read_text());assert not afgekeurd['geslaagd'];assert afgekeurd['na']!=afgekeurd['voor']+afgekeurd['invoertekst']
# Pakketverschillen exact behouden; geen ongedocumenteerde normalisatie.
with ZipFile(u/'kandidaat2/Ontwerpnotitie.docx') as a,ZipFile(u/'referentie2/Ontwerpnotitie.docx') as b:
 assert set(a.namelist())==set(b.namelist());pakket={'onderdelen':len(a.namelist()),'verschillend':[n for n in a.namelist() if a.read(n)!=b.read(n)]}
beelden={}
for naam in ['invoer-redo','snel-getypt-bewaard','nieuw-na-laat-antwoord']:
 a=Image.open(u/'kandidaat2'/(naam+'.png')).convert('RGB');b=Image.open(u/'referentie2'/(naam+'.png')).convert('RGB');d=ImageChops.difference(a,b);beelden[naam]={'bbox':d.getbbox(),'afwijkende_pixels':sum(v!=(0,0,0) for v in d.getdata()),'documentvlak_bbox':d.crop((321,211,1137,978)).getbbox()}
(u/'vergelijking.json').write_text(json.dumps({'pakket':pakket,'beelden':beelden},indent=2))
subprocess.run(['git','diff','--check'],check=True)
d=r/'docs/tests/writer-tabelpagina-2026-11-11';d.mkdir(parents=True,exist_ok=True);archief=d/'bewijs.tar.gz';leden={}
with tarfile.open(archief,'w:gz') as t:
 for p in u.rglob('*'):
  if not p.is_file() or 'dist-voor-bouw' in p.parts:continue
  if p.suffix in ['.py','.json','.log','.diff','.docx','.png','.gz']:
   n=str(p.relative_to(u));t.add(p,arcname=n);leden[n]=sha(p)
 for n in ['src/tekst/liniaal/geometrie.ts','src/tekst/liniaal/tabelpagina.test.ts']:
  t.add(r/n,arcname='bron/'+n);leden['bron/'+n]=sha(r/n)
with tarfile.open(archief,'r:gz') as t:
 for n,h in leden.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
rapport={'datum':'2026-11-11','bouw':bouw,'wijziging':'Celgeometrie bij tabelgrepen leest alleen pagina’s van zichtbare tabelidentiteiten. Alle eerdere/vervolgpagina’s met dezelfde identiteit blijven beschikbaar voor doorlopende cellen. Bij ontbrekende identiteiten blijft de volledige oude ankerroute bestaan. Geen renderer- of stijlwijziging.','tests':'Drie gerichte regressies vergelijken echte celvakken van een doorlopende cel met de volledige route, bewaken ontbrekende identiteiten en meerdere zichtbare/geneste identiteiten. Zeven echte geometrie-/klikvarianten en vijf tabelcachetests groen. Alle2324standaardtests groen; vier optionele hostdraadtests apart met echte Rust-CLI groen:2328in totaal. TypeScript, Vite en127Python-tests groen.','native':resultaten,'tabelgrepen':tabel,'profiel':{'bron':'Eigen rijke128tabellen/65pbron; oude16fELF. Begrensde1500msopname met WebKit-stackkalibratie en exacte ingebedde scriptbronnen.','programma_sha256':profiel['programma_sha256'],'samenvatting':profiel.get('samenvatting'),'afkeuring':'Eerste profiel gebruikte kleine letters na een punt en faalde op de inhoudsassertie doordat autocorrectie hoofdletters aanbracht. Alle data behouden; definitieve profieltekst heeft expliciete hoofdletters en broncontrole slaagt. Geen appdataverlies geclaimd.','grens':'Samplingfrequenties en inclusieve stacks zijn geen gemeten proces-CPUduur; runtime gaf geen trackingUpdate-intervallen. Geen oorzaak afgeleid uit minificatienamen van een andere build.'},'pakketvergelijking':pakket,'beelden':beelden,'ruimte':'Begrensde herbouw van uitsluitend de appcrate; startgrens3,25GiB, absolute stop3GiB en20min. Oude brede6GiB-marge niet gewijzigd. Frontendbundel verplaatst om dubbele kopie te vermijden; oude standaarddist behouden. Referentie-ELFs niet vervangen, normale Cargo-cache wel opnieuw gegenereerd.','grenzen':['Eén korte opeenvolgende fysieke vergelijking per nieuwe route, geen statistische of algemene snelheidsacceptatie. De ernstige Writer-vertraging blijft open.','Exacte1052tekens en echte native antwoorden; latere vastgehouden-antwoordenproeven vallen buiten de gewone invoertijd. WebKit-keyup en twee rAFs zijn geen fysieke schermpaint/FPS.','Beelden en pakketverschillen ongewijzigd vermeld; geen volledige pixelacceptatie.','Gebruikersapp en documenten niet gewijzigd. Experimentele journaalroute blijft standaard uit. Geen volledige Rust-/7editie-/platform-GUI-acceptatie. CI-groen43048315760/43048310231 geldt voor eerdere appbron4c13723b; nieuwe bron krijgt eigen remote controle.'],'volgende_stap':'Herhaal fysieke rijke invoer in omgekeerde volgorde en meet opnieuw hoofdthread/workerprofiel. Onderzoek resterende bronprojectie en mutatie/publicatiefrequentie; bewaak selectie tijdens echte achterstand. Nieuwe kandidaat nog niet installeren op basis van één ronde.','bewijs':{'pad':str(archief.relative_to(r)),'sha256':sha(archief),'bytes':archief.stat().st_size,'leden':len(leden)}}
(r/'docs/tests/2026-11-11-writer-tabelpagina.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'resultaten':resultaten,'beelden':beelden,'pakket':pakket,'bewijs':rapport['bewijs']}))
