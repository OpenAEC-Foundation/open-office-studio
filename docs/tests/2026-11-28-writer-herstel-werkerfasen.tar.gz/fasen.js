(() => {
 const g={metingen:[],methoden:[],herstel:[]},buiten=api(),binnen=buiten.getEditorRef(),s=binnen.getYrsSession();
 const voeg=(obj,label,namen)=>{
  for(const naam of namen){
   if(typeof obj?.[naam]!=='function')continue;
   const fn=obj[naam],desc=Object.getOwnPropertyDescriptor(obj,naam);
   if(desc&&!desc.writable&&!desc.set)throw Error('Methode niet schrijfbaar: '+label+'.'+naam);
   g.methoden.push({label,naam,bron:fn.toString()});
   const wrapper=function(...args){
    const m={label,naam,start:performance.now(),stack:new Error().stack.slice(0,1200)};g.metingen.push(m);
    try{
     const uit=fn.apply(this,args);m.syncEinde=performance.now();
     if(uit&&typeof uit.then==='function')return uit.then(v=>{m.einde=performance.now();if(v?.byteLength!==undefined)m.bytes=v.byteLength;return v},e=>{m.einde=performance.now();m.fout=String(e);throw e});
     m.einde=m.syncEinde;return uit;
    }catch(e){m.einde=performance.now();m.fout=String(e);throw e}
   };
   obj[naam]=wrapper;
   if(obj[naam]!==wrapper)throw Error('Wrapper mislukt');
   g.herstel.push(()=>{if(obj[naam]!==wrapper)throw Error('Methode tussentijds vervangen');if(desc)Object.defineProperty(obj,naam,desc);else delete obj[naam];return obj[naam]===fn});
  }
 };
 voeg(buiten,'ref',['getDocument','flushPendingInput','save']);
 voeg(binnen,'editor',['getDocument','save']);
 voeg(s,'sessie',['exportStructuredWithPages','exportStructured','exportDocx','save','readParagraphs']);
 g.stop=()=>g.herstel.splice(0).reverse().map(fn=>fn());
 window.__fasen=g;return true;
})()
