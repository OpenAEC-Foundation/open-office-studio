from pathlib import Path
import json,statistics
p=Path(__file__).resolve().parent
rows=[]
for label in ['levend-1','levend-2','werker-1','werker-2']:
 f=p/label/'rapport.json'
 if not f.exists():continue
 d=json.loads(f.read_text());assert d['geslaagd'],label
 g=d['fasen'];assert all(d['fasen_hersteld'])
 save=[m for m in g['metingen']if m['label']=='ref'and m['naam']=='save'];assert len(save)==1
 save=save[0];assert save.get('bytes',0)>0
 controles=[m for m in g['metingen']if m['label']=='ref'and m['naam']=='getDocument'and m['start']>=d['herstel_begin_ms']-1]
 flush=[m for m in g['metingen']if m['label']=='ref'and m['naam']=='flushPendingInput'and m['start']>=d['herstel_begin_ms']and m['start']<=save['start']]
 row={'label':label,'programma_sha256':d['programma_sha256'],'herstel_start_ms':d['herstel_begin_ms'],'bestand_ms':d['herstel_bestand_ms'],'save_start_ms':save['start'],'save_eind_ms':save['einde'],'save_duur_ms':save['einde']-save['start'],'save_sync_deel_ms':save['syncEinde']-save['start'],'gereedheidscontrole_ms':[m['einde']-m['start']for m in controles],'flush_voor_save_ms':[m['einde']-m['start']for m in flush],'native_behoud':d['herstel_tekst'],'levende_refwissels':len(g['wissels']),'bronexacte_toetsen':len(d['letters'])}
 if 'werker' in g:
  req=[m for m in g['werker']if m['richting']=='verzoek'and m['vorm'].get('type')=='save'];assert len(req)==1
  req=req[0];ans=next(m for m in g['werker']if m['richting']=='antwoord'and m['werker']==req['werker']and m['vorm'].get('id')==req['vorm']['id']);assert ans['vorm']['ok']
  row['werker_save']={'werker':req['werker'],'id':req['vorm']['id'],'verzoek_ms':req['ms'],'antwoord_ms':ans['ms'],'duur_ms':ans['ms']-req['ms'],'opgeslagen_bytes':ans['vorm']['saved']['bytes']}
  wacht=[]
  for m in g['werker']:
   if m['richting']!='verzoek'or m['werker']!=req['werker']or not req['ms']<m['ms']<ans['ms']:continue
   antwoorden=[a for a in g['werker']if a['richting']=='antwoord'and a['werker']==m['werker']and a['vorm'].get('id')==m['vorm'].get('id')]
   wacht.append({'type':m['vorm'].get('type'),'id':m['vorm'].get('id'),'verzoek_ms':m['ms'],'antwoord_ms':antwoorden[0]['ms']if antwoorden else None,'antwoord_na_save':antwoorden[0]['ms']>=ans['ms']if antwoorden else None})
  row['aanvragen_tijdens_save']=wacht
  paren=[(a,b,b-a)for a,b in zip(g['frames'],g['frames'][1:])if a>=req['ms']and b<=ans['ms']]
  row['rAF_terwijl_save_in_behandeling']={'intervallen':len(paren),'max_interval_ms':max(x[2]for x in paren),'mediaan_interval_ms':statistics.median(x[2]for x in paren),'betekenis':'Ontvangen hoofdthreadcallbacks, geen fysieke paint/FPS en geen afleiding van exclusieve worker-CPUtijd.'}
  row['mutaties_tijdens_save']=[a for a in d['groepen']if req['ms']<a['naMutatie']<ans['ms']]
  assert any(m['type']=='fontRequirements'and m['antwoord_na_save']for m in wacht)
 rows.append(row)
assert any(r.get('mutaties_tijdens_save')for r in rows)
(p/'analyse.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False,indent=2))
