(() => {
 const g={metingen:[],methoden:[],herstel:[],wissels:[]},buiten=api(),binnen=buiten.getEditorRef(),s=binnen.getYrsSession(),bekend=new WeakSet();
 const voeg=(obj,label,namen)=>{
  if(!obj||bekend.has(obj))return;bekend.add(obj);
  for(const naam of namen){
   if(typeof obj?.[naam]!=='function')continue;
   const fn=obj[naam],desc=Object.getOwnPropertyDescriptor(obj,naam);
   if(desc&&!desc.writable&&!desc.set)throw Error('Methode niet schrijfbaar: '+label+'.'+naam);
   g.methoden.push({label,naam,bron:fn.toString()});
   const wrapper=function(...args){
    const m={label,naam,start:performance.now(),stack:new Error().stack.slice(0,1200)};g.metingen.push(m);
    try{
     const uit=fn.apply(this,args);m.syncEinde=performance.now();
     if(uit&&typeof uit.then==='function')return uit.then(v=>{m.einde=performance.now();if(v?.byteLength!==undefined)m.bytes=v.byteLength;return v},e=>{m.einde=performance.now();m.fout=String(e);throw e});
     m.einde=m.syncEinde;return uit;
    }catch(e){m.einde=performance.now();m.fout=String(e);throw e}
   };
   obj[naam]=wrapper;
   if(obj[naam]!==wrapper)throw Error('Wrapper mislukt');
   g.herstel.push(()=>{if(obj[naam]!==wrapper)return false;if(desc)Object.defineProperty(obj,naam,desc);else delete obj[naam];return obj[naam]===fn});
  }
 };
 voeg(buiten,'ref',['getDocument','flushPendingInput','save']);
 voeg(binnen,'editor',['getDocument','save']);
 voeg(s,'sessie',['exportStructuredWithPages','exportStructured','exportDocx','save','readParagraphs']);
 const fibers=new Set,cellen=new Set;
 for(const el of document.querySelectorAll('*'))for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f&&!fibers.has(f);f=f.return){fibers.add(f);for(let h=f.memoizedState,n=0;h&&n++<1500;h=h.next){const c=h.memoizedState;if(c&&typeof c==='object'&&Object.hasOwn(c,'current')&&(c.current===buiten||c.current===binnen))cellen.add(c)}}
 g.cellen=cellen.size;if(!cellen.size)throw Error('Geen levende editorref');
 for(const c of cellen){const desc=Object.getOwnPropertyDescriptor(c,'current');if(!desc.configurable||!desc.writable)throw Error('Geen schrijfbare ref');let waarde=c.current;const label=waarde===buiten?'ref':'editor';Object.defineProperty(c,'current',{configurable:true,enumerable:desc.enumerable,get:()=>waarde,set:v=>{waarde=v;g.wissels.push({label,ms:performance.now(),leeg:!v});voeg(v,label,label==='ref'?['getDocument','flushPendingInput','save']:['getDocument','save'])}});g.herstel.push(()=>{Object.defineProperty(c,'current',{...desc,value:waarde});return c.current===waarde})}
 g.stop=()=>g.herstel.splice(0).reverse().map(fn=>fn());
 window.__fasen=g;return true;
})()
