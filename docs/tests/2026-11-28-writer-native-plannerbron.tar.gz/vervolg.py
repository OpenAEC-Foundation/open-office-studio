from pathlib import Path
import os,subprocess,time,json,shutil,signal
p=Path.cwd()/'.local/integratiecontrole/planner-bron';env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(p/'target')};rows=[{'label':'eerste-bouw','code':'timeout','grens_s':300,'opmerking':'Eerste losse dependency-resolutie/compilatie; geen achtergebleven compilerproces aangetroffen.'}]
for label,manifest,exe in [('profiel',p/'Cargo.toml','oos-planner-bronproef'),('controle',p/'control/Cargo.toml','oos-planner-controle')]:
 cmd=['cargo','build','--manifest-path',str(manifest),'--release','--offline'];begin=time.monotonic()
 with(p/('bouwen-'+label+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=proc.wait(timeout=300)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=15);code='timeout'
 rows.append({'label':label,'code':code,'duur_s':time.monotonic()-begin,'opdracht':cmd});(p/'vervolg.json').write_text(json.dumps(rows,indent=2)+'\n');print('BOUW',label,code,flush=True)
 if code!=0:break
 shutil.copy2(p/'target/release'/exe,p/('planner-'+label))
 with(p/(label+'.json')).open('w')as out,(p/(label+'.log')).open('w')as log:res=subprocess.run([str(p/('planner-'+label)),str(Path.cwd()/'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx')],stdout=out,stderr=log,timeout=180)
 rows.append({'label':label+'-proef','code':res.returncode});(p/'vervolg.json').write_text(json.dumps(rows,indent=2)+'\n');print('PROEF',label,res.returncode,flush=True)
 if res.returncode!=0:break
