from pathlib import Path
import json,statistics,hashlib
p=Path(__file__).resolve().parent;a=json.loads((p/'profiel.json').read_text());b=json.loads((p/'controle.json').read_text());assert len(a)==len(b)==18
for x,y in zip(a,b):assert(x['naam'],x['ronde'],x['plan'])==(y['naam'],y['ronde'],y['plan'])
marks={};cur=None
for l in(p/'profiel.log').read_text().splitlines():
 if l.startswith('OOS_BEGIN '):cur=tuple(l.split()[1:])
 if l.startswith('OOS_PLAN '):
  prev=0;v={}
  for k,n in json.loads(l[9:]):v[k]=(n-prev)/1e6;prev=n
  assert cur not in marks;marks[cur]=v
assert len(marks)==54
rows=[]
for naam in dict.fromkeys(r['naam']for r in a):
 group=[r for r in a if r['naam']==naam];control=[r for r in b if r['naam']==naam];first=[marks[(naam,str(i),'0')]for i in range(3)]
 rows.append({'geval':naam,'eerste_fasen_mediaan_ms':{k:statistics.median(v[k]for v in first)for k in first[0]},'eerste_totaal_mediaan_ms':statistics.median(r['planner_ns'][0]/1e6 for r in group),'controle_eerste_mediaan_ms':statistics.median(r['planner_ns'][0]/1e6 for r in control),'tweede_totaal_mediaan_ms':statistics.median(r['planner_ns'][1]/1e6 for r in group),'derde_totaal_mediaan_ms':statistics.median(r['planner_ns'][2]/1e6 for r in group),'identiteiten_mediaan_ms':statistics.median(r['identiteiten_ns']/1e6 for r in group),'openen_mediaan_ms':statistics.median(r['openen_ns']/1e6 for r in group)})
d={'volledige_plannen_gelijk':18,'bron_vector_exacte_planlezingen':108,'faseparen':54,'gevallen':rows,'fasen_betekenis':{'assignments':'Transactie en source_assignments samen.','committed_scan':'committed_scan, in geval identiteiten vooraf doorgaans gedeeld.','story_states':'story_states_in; omvat eigen scanlookup, commentankers en vingerafdrukken.','seed_states':'Voorbereiding plan/metadata plus seed_states; niet als exclusieve reseeding-CPUtijd interpreteren.','units':'Beide units_by_key-tabellen samen.','parts':'Onderdeelvergelijking en patches na voorgaande meetgrens.','totaal':'Buitenste tijd bevat ook source_index vóór eerste interne meetgrens.'}}
(p/'analyse.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(d,ensure_ascii=False,indent=2))
