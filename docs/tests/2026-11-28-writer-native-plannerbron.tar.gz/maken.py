from pathlib import Path
import shutil,json
r=Path.cwd();p=r/'.local/integratiecontrole/planner-bron';shutil.copytree(r/'native/vendor/docx-edit',p/'docx-edit')
f=p/'docx-edit/src/identity.rs';s=f.read_text();a=s.index('    pub fn paragraph_save_plan(&self)');end=s.index('\n        plan\n    }',a);body=s[a:end]
body=body.replace('        let txn = self.yrs_doc().transact();','        let __begin = std::time::Instant::now();\n        let mut __fasen = Vec::new();\n        let txn = self.yrs_doc().transact();',1)
for old,label in [('        let assignments = source_assignments(&txn);','assignments'),('        let scan = self.committed_scan(&txn);','committed_scan'),('        let live = story_states_in(self, &txn);','story_states'),('        let seeded_units = units_by_key(seeded);','seed_states'),('        let live_units = units_by_key(&live);','units')]:
 assert body.count(old)==1,old
 if label=='seed_states':body=body.replace(old,'        __fasen.push(("seed_states", __begin.elapsed().as_nanos()));\n'+old)
 else:body=body.replace(old,old+'\n        __fasen.push(("'+label+'", __begin.elapsed().as_nanos()));')
s=s[:a]+body+'\n        __fasen.push(("parts", __begin.elapsed().as_nanos()));\n        eprintln!("OOS_PLAN {}", serde_json::to_string(&__fasen).unwrap());'+s[end:];f.write_text(s)
p.joinpath('Cargo.toml').write_text('''[package]
name = "oos-planner-bronproef"
version = "0.0.0"
edition = "2024"
[workspace]
[dependencies]
docx-edit = { package = "betteroffice-docx-edit", path = "docx-edit", features = ["writer-bronjournaal"] }
serde_json = "1"
[patch.crates-io]
betteroffice-docx-parse = { path = "'''+str(r/'native/vendor/docx-parse')+'''" }
yrs = { path = "'''+str(r/'native/vendor/yrs')+'''" }
''')
