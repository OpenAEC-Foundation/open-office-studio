use docx_edit::{EditCtx, EditingDoc, FormatPolicy, Position, seed_from_docx};
use serde_json::json;
use std::{hint::black_box, time::Instant};
fn main() {
    let bytes = std::fs::read(std::env::args().nth(1).expect("Geef proefdocument")).unwrap();
    let mut runs = Vec::new();
    for (naam, wijzigingen, identiteiten) in [("ongewijzigd", 0, false), ("eerste-invoer", 1, false), ("twee-invoeren", 2, false), ("identiteiten-ongewijzigd", 0, true), ("identiteiten-eerste-invoer", 1, true), ("identiteiten-twee-invoeren", 2, true)] {
        for ronde in 0..3 {
            let doc = EditingDoc::new(71);
            doc.keep_deleted();
            let start = Instant::now();
            seed_from_docx(&doc, &bytes).unwrap();
            let openen = start.elapsed().as_nanos();
            let ctx = EditCtx::local("", "2026-11-28T00:00:00Z");
            for n in 0..wijzigingen {
                doc.insert_text(&ctx, Position::new("body", n), "x", FormatPolicy::Inherit).unwrap();
            }
            let identiteiten_ns = if identiteiten { let begin = Instant::now(); black_box(doc.paragraph_identities()); begin.elapsed().as_nanos() } else { 0 };
            let voor = doc.encode_state_as_update_v1();
            let vector = doc.encode_state_vector_v1();
            let mut plannen = Vec::new();
            let mut tijden = Vec::new();
            for stap in 0..3 {
                eprintln!("OOS_BEGIN {naam} {ronde} {stap}");
                let start = Instant::now();
                let plan = black_box(doc.paragraph_save_plan());
                tijden.push(start.elapsed().as_nanos());
                plannen.push(plan);
                assert_eq!(doc.encode_state_vector_v1(), vector);
                assert_eq!(doc.encode_state_as_update_v1(), voor);
            }
            assert_eq!(plannen[0], plannen[1]);
            assert_eq!(plannen[0], plannen[2]);
            runs.push(json!({"naam":naam,"ronde":ronde,"openen_ns":openen,"planner_ns":tijden,"plan":format!("{:?}", plannen.remove(0)),"identiteiten_ns":identiteiten_ns,"bron_en_vector_exact":true}));
        }
    }
    println!("{}", serde_json::to_string_pretty(&runs).unwrap());
}
