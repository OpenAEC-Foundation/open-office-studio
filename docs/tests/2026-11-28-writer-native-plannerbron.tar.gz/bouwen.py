from pathlib import Path
import os,subprocess,shutil,time,json
p=Path.cwd()/'.local/integratiecontrole/planner-bron';shutil.copytree(p.parent/'herstel-intern-verdiept/target-proef',p/'target',dirs_exist_ok=False)
env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(p/'target')};cmd=['cargo','build','--manifest-path',str(p/'Cargo.toml'),'--release','--offline'];begin=time.monotonic()
with(p/'bouwen.log').open('x')as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(p/'bouwen.json').write_text(json.dumps({'code':res.returncode,'opdracht':cmd,'duur_s':time.monotonic()-begin},indent=2)+'\n');print('BOUW',res.returncode,flush=True)
if res.returncode==0:
 shutil.copy2(p/'target/release/oos-planner-bronproef',p/'planner-profiel')
 with(p/'profiel.json').open('x')as out,(p/'profiel.log').open('x')as log:res=subprocess.run([str(p/'planner-profiel'),str(Path.cwd()/'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx')],stdout=out,stderr=log,timeout=180)
 print('PROEF',res.returncode,flush=True)
