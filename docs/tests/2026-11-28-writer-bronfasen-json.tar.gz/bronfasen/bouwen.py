from pathlib import Path
import subprocess,os,json,hashlib,shutil,time
r=Path.cwd();p=r/'.local/integratiecontrole/bronfasen';old=p.parent/'digest-spans';src=p/'docx-edit';shutil.copytree(r/'native/vendor/docx-edit',src)
f=src/'src/clipboard_batch.rs';s=f.read_text();before=s
needle='    let expected = StateVector::decode_v1(expected_vector)';s=s.replace(needle,'    let meetbegin = std::time::Instant::now();\n    let mut meetfasen = Vec::new();\n'+needle,1)
for label,needle in [('validatie','    let cached = cached.filter'),('cachebinding','    let reused = cached.is_some();'),('import','    if doc.holds_pending_update()'),('vector','    let snapshot = doc.encode_state_as_update_v1();'),('snapshot','    if snapshot.len() > max_source_bytes'),('mutatie','    let replica = PreparedClipboardReplica'),('replicahash','    Ok(ConfirmedClipboardBatchResult')]:
 assert s.count(needle)==1,needle;s=s.replace(needle,'    meetfasen.push(("'+label+'", meetbegin.elapsed().as_nanos() as u64));\n'+needle,1)
s=s.replace('    Ok(ConfirmedClipboardBatchResult','    eprintln!("WRITER_BRONFASEN {}", serde_json::json!({"hergebruikt":reused,"bronbytes":snapshot.len(),"fasen_ns":meetfasen}));\n    Ok(ConfirmedClipboardBatchResult',1);f.write_text(s);(p/'diagnose.patch').write_text(subprocess.run(['diff','-u',str(r/'native/vendor/docx-edit/src/clipboard_batch.rs'),str(f)],capture_output=True,text=True).stdout)
target=p/'native-target';shutil.copytree(old/'native-target',target);cfg={'build':{'frontendDist':str(old/'dist-kandidaat')}};env={**os.environ,'TAURI_CONFIG':json.dumps(cfg),'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']};cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal','--config','patch.crates-io.betteroffice-docx-edit.path='+json.dumps(str(src))];start=time.monotonic()
with(p/'bouwen.log').open('x')as log:
 proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while proc.poll()is None:
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:print('BOUW ACTIEF',round(time.monotonic()-start),flush=True)
assert proc.returncode==0
exe=p/'open-office-studio-bronfasen';shutil.copy2(target/'release/open-office-studio',exe);(p/'bouwen.json').write_text(json.dumps({'code':proc.returncode,'opdracht':cmd,'config':cfg,'seconden':time.monotonic()-start,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n');print('BOUW GEREED',flush=True)
