from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/bronfasen';tools=r/'.local/integratiecontrole/font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu')};exe=p/'open-office-studio-bronfasen';results=[]
for label in ['een','twee']:
 cmd=['/usr/bin/python3',str(p/'proef.py'),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/label)];print('START',label,flush=True);start=time.monotonic()
 with(p/(label+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print('ACTIEF',label,round(time.monotonic()-start),flush=True)
 report=json.loads((p/label/'rapport.json').read_text());row={'label':label,'code':proc.returncode,'geslaagd':report['geslaagd'],'seconden':time.monotonic()-start,'programma_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()};results.append(row);(p/'runs.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert proc.returncode==0 and report['geslaagd']
