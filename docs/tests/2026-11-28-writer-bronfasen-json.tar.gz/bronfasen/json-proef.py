from pathlib import Path
import json,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/bronfasen';s=(r/'native/vendor/docx-edit/src/deterministic.rs').read_text();s=s.replace('serde_json::to_string(&json_value(any))','serde_json::to_string(&Geleend(any))');s+='''
struct Geleend<'a>(&'a Any);
impl serde::Serialize for Geleend<'_> {
 fn serialize<S: serde::Serializer>(&self,s:S)->Result<S::Ok,S::Error>{
  use serde::ser::{SerializeMap,SerializeSeq};
  match self.0 {
   Any::Null|Any::Undefined=>s.serialize_unit(),
   Any::Bool(v)=>s.serialize_bool(*v),
   Any::Number(v) if *v as i64 as f64 == *v =>s.serialize_i64(*v as i64),
   Any::Number(v)=>Number::from_f64(*v).serialize(s),
   Any::BigInt(v)=>s.serialize_i64(*v),
   Any::String(v)=>s.serialize_str(v),
   Any::Buffer(v)=>{let mut a=s.serialize_seq(Some(v.len()))?;for b in v.iter(){a.serialize_element(b)?;}a.end()},
   Any::Array(v)=>{let mut a=s.serialize_seq(Some(v.len()))?;for x in v.iter(){a.serialize_element(&Geleend(x))?;}a.end()},
   Any::Map(v)=>{let sorted:BTreeMap<_,_>=v.iter().collect();let mut a=s.serialize_map(Some(v.len()))?;for(k,x)in sorted{a.serialize_entry(k,&Geleend(x))?;}a.end()},
  }
 }
}
pub(crate) fn controle_json(a:&Any){assert_eq!(serde_json::to_vec(&Geleend(a)).unwrap(),serde_json::to_vec(&json_value(a)).unwrap());}
''';(p/'deterministic-geleend.rs').write_text(s)
old=json.loads((p.parent/'invoer-groepering/bouw.json').read_text());cmd=old['opdracht'];cmd[cmd.index('-o')-1]=str(p/'json-proef.rs');cmd[cmd.index('-o')+1]=str(p/'json-proef')
# Gebruik exact dezelfde serde als de bestaande native libraries.
deps=Path(cmd[cmd.index('-L')+1].removeprefix('dependency='));serde=[deps/'libserde-450f0c2c242de8f7.rlib'];assert serde[0].exists();cmd+=['--extern','serde='+str(serde[0])];res=subprocess.run(cmd,capture_output=True,text=True);(p/'json-bouw.log').write_text(res.stdout+res.stderr);print('bouw',res.returncode,res.stderr[:1200]);assert res.returncode==0
with(p/'json-component.json').open('w')as f:res=subprocess.run([str(p/'json-proef'),str(p)],stdout=f,stderr=subprocess.PIPE,text=True)
print('proef',res.returncode,res.stderr[:1000]);assert res.returncode==0;(p/'json-bouw.json').write_text(json.dumps({'code':res.returncode,'opdracht':cmd},indent=2))
