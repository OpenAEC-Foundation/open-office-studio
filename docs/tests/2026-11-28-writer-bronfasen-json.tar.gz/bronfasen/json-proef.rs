use docx_edit::EditingDoc;
use serde_json::json;
use yrs::{Transact, StateVector,Any};
use std::{time::Instant,sync::Arc};
#[allow(dead_code)]mod geleend {include!("deterministic-geleend.rs");}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let p=std::path::PathBuf::from(std::env::args().nth(1).ok_or("Proefmap ontbreekt")?);let raw=p.join("../digest-spans/route-capture/raw");let d=EditingDoc::new(3525307561);d.keep_deleted();d.apply_update_v1(&std::fs::read(raw.join("initial.bin"))?)?;let mut rows=Vec::new();
 for step in 0..=58 {
  if step>0{d.apply_update_v1(&std::fs::read(raw.join("updates").join(format!("{:03}.bin",step-1)))?)?;}
  let expected=d.encode_state_as_update_v1();let vector=d.encode_state_vector_v1();
  for route in ["basis","geleend","geleend","basis"]{let t=Instant::now();let bytes=if route=="basis"{d.encode_state_as_update_v1()}else{geleend::encode_state_as_update_v1(&d.yrs_doc().transact(),&StateVector::default())};let ns=t.elapsed().as_nanos();assert_eq!(bytes,expected,"Stap {step}");rows.push(json!({"stap":step,"route":route,"ns":ns}));}
  assert_eq!(vector,d.encode_state_vector_v1());
 }
 let mut values=vec![Any::Undefined,Any::Null,Any::Bool(true),Any::BigInt(i64::MIN),Any::BigInt(i64::MAX),Any::String("a\n\"\\😀\u{0}".into()),Any::Buffer(Arc::from([0u8,127,255]))];
 for n in [f64::NAN,f64::INFINITY,f64::NEG_INFINITY,-0.,0.,f64::MIN_POSITIVE,f64::MAX,1.5,1e30,9007199254740992.,i64::MAX as f64,i64::MIN as f64]{values.push(Any::Number(n));}
 let mut count=0;for v in values{geleend::controle_json(&v);let nested=Any::Array(Arc::from([v]));geleend::controle_json(&nested);count+=2;}

 for i in 0..128 {
  let value=Any::from_json(&serde_json::to_string(&json!({"z":[i,"😀",null,true],"a":{"n":i as f64/7.0,"escape":"\n\t\"\\"},"é":"waarde","":-0.0}))?)?;
  let nested=Any::Array(Arc::from([value.clone(),value]));geleend::controle_json(&nested);count+=1;
 }
 let oracle=p.join("../digest-fasen");let cases:serde_json::Value=serde_json::from_slice(&std::fs::read(oracle.join("orakel.json"))?)?;let mut oracle_frames=0;
 for case in cases["cases"].as_array().unwrap(){let d=EditingDoc::new(case["client_id"].as_u64().unwrap());d.keep_deleted();for frame in case["frames"].as_array().unwrap(){d.apply_update_v1(&std::fs::read(oracle.join(frame["file"].as_str().unwrap()))?)?;let vector=d.encode_state_vector_v1();let expected=d.encode_state_as_update_v1();assert_eq!(geleend::encode_state_as_update_v1(&d.yrs_doc().transact(),&StateVector::default()),expected);assert_eq!(vector,d.encode_state_vector_v1());oracle_frames+=1;}}
 let pending=EditingDoc::new(999);pending.keep_deleted();pending.apply_update_v1(&std::fs::read(raw.join("initial.bin"))?)?;pending.apply_update_v1(&std::fs::read(raw.join("updates/001.bin"))?)?;assert!(pending.holds_pending_update());let before=pending.encode_state_as_update_v1();assert_eq!(geleend::encode_state_as_update_v1(&pending.yrs_doc().transact(),&StateVector::default()),before);pending.apply_update_v1(&std::fs::read(raw.join("updates/000.bin"))?)?;assert!(!pending.holds_pending_update());assert_eq!(geleend::encode_state_as_update_v1(&pending.yrs_doc().transact(),&StateVector::default()),pending.encode_state_as_update_v1());
 println!("{}",serde_json::to_string_pretty(&json!({"orakel_frames":oracle_frames,"pending_toestanden":2,"toestanden":59,"vergelijkingen":rows.len(),"json_randgevallen":count,"samples":rows,"bron_vector_exact":true}))?);Ok(())
}
