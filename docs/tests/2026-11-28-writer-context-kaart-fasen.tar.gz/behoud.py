from pathlib import Path
import json,hashlib,stat,ast
r=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();base=r/'.local/integratiecontrole/projectie-context/dist';asset='assets/editors-bODdYQ4o.js';s=(base/asset).read_text()
for x in json.loads((p/'bundelwijzigingen.json').read_text()):assert s.count(x['voor'])==1;s=s.replace(x['voor'],x['na'])
assert s==(p/'dist'/asset).read_text()
files=lambda root:{str(f.relative_to(root)):sha(f)for f in root.rglob('*')if f.is_file()};bf=files(base);cf=files(p/'dist');assert bf.keys()==cf.keys();assert set(n for n in bf if bf[n]!=cf[n])=={asset,'assets/index-DtZ2IWH9.js'}
idx='assets/index-DtZ2IWH9.js';q=(base/idx).read_text()
for x in json.loads((p/'indexwijzigingen.json').read_text()):assert q.count(x['voor'])==1;q=q.replace(x['voor'],x['na'])
assert q==(p/'dist'/idx).read_text()
refs=json.loads((r/'.local/integratiecontrole/selectie-projectie-fasen/referenties-nacontrole.json').read_text());assert len(refs)==37
for f,h in refs.items():assert sha(Path(f))==h
exe=p/'open-office-studio-context-kaart-fasen';build=json.loads((p/'desktop.json').read_text());assert build['code']==0 and sha(exe)==build['programma_sha256'];refs[str(exe)]=sha(exe);(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];assert len(pins)==15
for f,h in pins.items():assert sha(r/f)==h
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
for f in p.glob('*.py'):ast.parse(f.read_text())
result={'vorige_elf37_exact':True,'elfreferenties':38,'bronpinnen15_exact':True,'standaardbundel529_byte_mode_mtime_exact':True,'verschillende_assets':[asset,'assets/index-DtZ2IWH9.js'],'patchreplay_exact':True,'historisch_ontbrekende_autocorrectiereferentie':'Blijft reeds ontbreken; niet verwijderd.'};(p/'behoud.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
