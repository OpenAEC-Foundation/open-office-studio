from pathlib import Path
import os,subprocess,json,hashlib,time
r=Path.cwd();p=r/'.local/integratiecontrole/context-componentkosten';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();baseline=r/'.local/integratiecontrole/projectie-context/open-office-studio-projectie-context';candidate=baseline;assert sha(baseline)=='ee89c80e91be3a96fe47430b0e85d4093dde2bc160c0b10c872aa9733ce153bd';build={'programma_sha256':sha(candidate)};pins={'rijk':{'proef_sha256':sha(p/'native-proef.py')}};tools=r/'.local/integratiecontrole/font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu')};results=[]
for kind in ['rijk']:
 helper=p/'native-proef.py';assert sha(helper)==pins[kind]['proef_sha256']
 for label,exe in [('een',candidate),('twee',candidate)]:
  assert sha(helper)==pins[kind]['proef_sha256'];assert sha(candidate)==build['programma_sha256'];name='diagnose-'+label;assert not(p/name).exists();cmd=['/usr/bin/python3',str(helper),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/name)];print('START',name,flush=True);begin=time.monotonic()
  with(p/(name+'.log')).open('x')as log:
   try:code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450).returncode
   except subprocess.TimeoutExpired:code=124
  report=json.loads((p/name/'rapport.json').read_text())if(p/name/'rapport.json').exists()else{'geslaagd':False,'fout':'Geen eindrapport'};item={'naam':name,'code':code,'geslaagd':report['geslaagd'],'fout':report.get('fout'),'seconden':time.monotonic()-begin,'programma_sha256':sha(exe),'helper_sha256':sha(helper),'opdracht':cmd,'invoer':report.get('lange_invoer')};results.append(item);(p/'diagnoseronden.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print('EINDE',name,json.dumps(item),flush=True);assert code==0 and report['geslaagd'],name
assert len(results)==2
