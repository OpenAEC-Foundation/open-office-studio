from pathlib import Path
import json,hashlib,stat,ast
r=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();refs=json.loads((r/'.local/integratiecontrole/context-kaart-fasen/referenties-nacontrole.json').read_text());assert len(refs)==38
for f,h in refs.items():assert sha(Path(f))==h
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];assert len(pins)==15
for f,h in pins.items():assert sha(r/f)==h
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
for f,h in json.loads((p/'bronpinnen.json').read_text()).items():assert sha(r/f)==h
for f in p.glob('*.py'):ast.parse(f.read_text())
result={'referenties38_exact':True,'bronpinnen15_exact':True,'standaardbundel529_byte_mode_mtime_exact':True,'oude_componentmodules_exact':True,'nieuwe_native_bouw':False};(p/'behoud.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
