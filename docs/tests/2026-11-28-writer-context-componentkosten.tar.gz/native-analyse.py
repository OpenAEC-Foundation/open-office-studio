from pathlib import Path
import json,collections
p=Path(__file__).resolve().parent;result={}
for name in ['een','twee']:
 r=json.loads((p/('diagnose-'+name)/'rapport.json').read_text());assert r['geslaagd']and all(not v for v in r['fouten'].values());probe=r['bronlezer_eind'];assert probe['tag']=='reader-cache-v1'and not probe['overflow']and all(probe['restored']);assert len(probe['before'])==len(probe['after'])==1
 assert probe['before'][0]['bodyDigests']==897 and probe['after'][0]['bodyDigests']==897
 m=r['lange_invoer'];end=m['laatste_keyup_ms']+m['laatste_keyup_tot_frame_ms'];begin=end-m['begin_tot_frame_ms'];rows=[x for x in probe['records']if begin<=x['start']<=x['end']<=end];assert all(x['ok']for x in rows)
 def summary(selected):
  totals={}
  for method in ['storySegments','storySegmentUnitDigests','storySegmentUnits','paragraphSpans']:
   for body in [True,False]:
    values=[x['end']-x['start']for x in selected if x['method']==method and x['body']==body]
    if values:totals[method+(':body'if body else':overig')]={'aantal':len(values),'som_ms':sum(values),'maximum_ms':max(values)}
  return totals
 result[name]={'cache_voor':probe['before'],'cache_na':probe['after'],'venster_afgeleid':{'begin':begin,'eind':end},'in_invoervenster':summary(rows),'hele_opname':summary(probe['records']),'hersteld':probe['restored'],'overflow':probe['overflow'],'grens':'Venster afgeleid uit bestaande laatste-keyup en framevelden; geen nieuw exact beginanker. Hele opname bevat ook stand()-orakellezingen buiten invoer. Publieke methodevensters bevatten Wasm/JS/serialisatie/wachten, geen exclusieve Rust-CPU of directe At-nesting. Geen ABBA of prestatiewinst.'}
(p/'native-analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
