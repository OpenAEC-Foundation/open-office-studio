from pathlib import Path
import shutil,json,hashlib
p=Path('.local/integratiecontrole/context-componentkosten');base=Path('.local/integratiecontrole/projectie-context/modules')
for f in base.glob('*.mjs'):shutil.copy2(f,p/'modules'/f.name)
f=p/'modules/yrsPositionProjection.mjs';s=f.read_text();pairs=[]
def rep(a,b):
 global s
 assert s.count(a)==1;s=s.replace(a,b);pairs.append({'voor':a,'na':b})
rep('return this.nodes.get(position) ?? null;', 'let node = this.nodes.get(position);\n        if (typeof node === "function") { node = node(); this.nodes.set(position, node); }\n        return node ?? null;')
rep('const node = this.nodes.get(story.contentStart + paragraph.displayStart);','const node = this.nodeAt(story.contentStart + paragraph.displayStart);')
rep('const node = {\n                    kind: \'paragraph\',', 'const node = () => ({\n                    kind: \'paragraph\',')
rep('story: storyId,\n                };\n                this.nodes.set(start, node);\n                for (const block of blocks) {','story: storyId,\n                });\n                this.nodes.set(start, node);\n                for (const block of blocks) {')
(p/'modules/yrsPositionProjection-lazy.mjs').write_text(s);(p/'wijzigingen.json').write_text(json.dumps(pairs,indent=2)+'\n');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();(p/'bronpinnen.json').write_text(json.dumps({str(f):sha(f)for f in base.glob('*.mjs')},indent=2)+'\n')
