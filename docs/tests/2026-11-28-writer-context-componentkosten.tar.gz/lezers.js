(()=>{
 const session=sessie(),limit=8192,records=[],restores=[];let overflow=0,active=true;
 if(window._officeReaderProbe)throw Error('Bronlezerproef bestaat al');
 const snapshot=()=>{const seen=new Set(),found=new Set(),result=[];for(const el of document.querySelectorAll('*')){let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];for(;f&&!seen.has(f);f=f.return){seen.add(f);for(let h=f.memoizedState,n=0;h&&n++<500;h=h.next){const v=h.memoizedState?.current;if(v?.session!==session||!(v.stories instanceof Map)||!(v.units instanceof Map)||!(v.undigested instanceof Set)||found.has(v))continue;found.add(v);const body=v.stories.get('body'),stale=v.stale?.get('body');result.push({revision:v.revision,released:v.released,stories:v.stories.size,units:v.units.size,undigested:v.undigested.size,bodyDigests:body?.digests?.length??null,bodySegments:body?.segments?.length??null,staleBodyDigests:stale?.digests?.length??null,warming:v.warming?.size??null,cancelIdle:typeof v.cancelIdle==='function'})}}}return result};
 for(const method of ['storySegments','storySegmentUnitDigests','storySegmentUnits','paragraphSpans']){
  const original=session[method],descriptor=Object.getOwnPropertyDescriptor(session,method);
  if(typeof original!=='function'||descriptor&&!descriptor.configurable)throw Error('Bronlezer niet veilig te volgen: '+method);
  const wrapper=function(...args){if(!active)return Reflect.apply(original,this,args);const start=performance.now();let ok=false;try{const result=Reflect.apply(original,this,args);ok=true;return result}finally{if(records.length<limit)records.push({method,body:args[0]==='body',start,end:performance.now(),ok});else overflow++}};
  Object.defineProperty(session,method,{configurable:true,enumerable:descriptor?.enumerable??false,writable:true,value:wrapper});restores.push(()=>{if(session[method]!==wrapper)return false;if(descriptor)Object.defineProperty(session,method,descriptor);else delete session[method];return session[method]===original});
 }
 const before=snapshot();
 window._officeReaderProbe={stop(){const after=snapshot();active=false;const restored=restores.reverse().map(fn=>fn());delete window._officeReaderProbe;return {tag:'reader-cache-v1',before,after,records,overflow,restored,limit}}};
 return {tag:'reader-cache-v1',before,limit};
})()
