from pathlib import Path
import shutil,hashlib,json,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/digest-kern';src=r/'.local/integratiecontrole/font-hergebruik/bron';dst=p/'bron';assert not dst.exists();dst.mkdir()
for n in ['Cargo.toml','Cargo.lock','AGENTS.md','LICENSE','NOTICE']:shutil.copy2(src/n,dst/n)
shutil.copytree(src/'crates',dst/'crates');shutil.copytree(src/'target-wasm',dst/'target-wasm')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();manifest={str(f.relative_to(dst)):sha(f)for f in dst.rglob('*')if f.is_file()and'target-wasm'not in f.parts};(p/'bron-voor.json').write_text(json.dumps(manifest,indent=2)+'\n')
s=(r/'.local/integratiecontrole/digest-bewijs/cache.rs').read_text().replace('use docx_edit::{','use crate::{');(p/'digest_cache.rs').write_text(s);subprocess.run(['/home/aia01/.cargo/bin/rustfmt','--edition','2024',str(p/'digest_cache.rs')],check=True)
f=dst/'crates/docx-edit/src/wasm.rs';s=f.read_text();s=s.replace('    last_apply_profile_json: RefCell<String>,','    last_apply_profile_json: RefCell<String>,\n    unit_digest_cache: RefCell<crate::digest_cache::Cache>,');s=s.replace('            last_apply_profile_json: RefCell::new("{}".to_owned()),','            last_apply_profile_json: RefCell::new("{}".to_owned()),\n            unit_digest_cache: RefCell::new(crate::digest_cache::Cache::new(crate::segments_digest)),');old='''        self.engine
            .doc()
            .apply_local_update_v1(update)
            .map_err(js_err)''';new='''        self.unit_digest_cache
            .borrow_mut()
            .apply(self.engine.doc(), update)
            .map_err(js_err)''';assert s.count(old)==1;s=s.replace(old,new)
needle='''        let units = self
            .engine
            .doc()
            .story_segment_units(story)
            .map_err(js_err)?;
        let digests: Vec<String> = units
            .iter()
            .map(|unit| format!("{:032x}", crate::segments_digest(unit)))
            .collect();''';new='''        let values = if story == "body" {
            self.unit_digest_cache.borrow_mut().get(self.engine.doc()).map_err(js_err)?
        } else {
            self.engine.doc().story_segment_units(story).map_err(js_err)?
                .iter().map(|unit| crate::segments_digest(unit)).collect()
        };
        let digests: Vec<String> = values.iter().map(|value| format!("{value:032x}")).collect();''';assert s.count(needle)==1;s=s.replace(needle,new);(p/'wasm-kandidaat.rs').write_text(s)
f=dst/'crates/docx-edit/src/lib.rs';s=f.read_text();s+='\n#[cfg(feature = "wasm")]\nmod digest_cache;\n';(p/'lib-kandidaat.rs').write_text(s)
print('Eigen bron/targetkopie voorbereid; kandidaat nog niet toegepast')
