from pathlib import Path
import json,hashlib,stat,subprocess
r=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();refs=json.loads((r/'.local/integratiecontrole/context-kaart-fasen/referenties-nacontrole.json').read_text());assert len(refs)==38
for f,h in refs.items():assert sha(Path(f))==h
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];assert len(pins)==15
for f,h in pins.items():assert sha(r/f)==h
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
manifest=json.loads((p/'bron-voor.json').read_text());source=r/'.local/integratiecontrole/font-hergebruik/bron'
for f,h in manifest.items():assert sha(source/f)==h
changed=[f for f,h in manifest.items()if sha(p/'bron'/f)!=h];new=[str(f.relative_to(p/'bron'))for f in (p/'bron/crates').rglob('*')if f.is_file()and str(f.relative_to(p/'bron'))not in manifest];assert sorted(changed)==['crates/docx-edit/src/lib.rs','crates/docx-edit/src/wasm.rs'];assert new==['crates/docx-edit/src/digest_cache.rs']
assert sha(p/'bron/crates/docx-edit/src/digest_cache.rs')==sha(p/'digest_cache.rs')
for item in json.loads((p/'bouwen.json').read_text()):assert item['code']==0
for item in json.loads((p/'desktop.json').read_text()):
 assert item['code']==0;assert sha(Path(item['programma']))==item['sha256'];refs[item['programma']]=item['sha256']
assert len(refs)==40
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
result={'oude_desktopreferenties38_exact':True,'nieuwe_eigen_desktopreferenties2':True,'bronpinnen15_exact':True,'standaardbundel529_byte_mode_mtime_exact':True,'gekopieerde_canonieke_kernbestanden_exact':len(manifest),'eigen_sdk_delta':changed+new,'wasm_en_glue':{mode:{f.name:sha(f)for f in (p/mode).glob('*')if f.is_file()}for mode in ['basis','kandidaat']},'rustc':subprocess.check_output(['/home/aia01/.cargo/bin/rustc','--version'],text=True).strip(),'desktopreferenties40':True};(p/'behoud.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
