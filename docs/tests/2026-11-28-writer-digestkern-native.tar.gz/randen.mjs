import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const p=path.resolve('.local/integratiecontrole/digest-kern');
const root=path.resolve('.local/integratiecontrole/digest-fasen');
const oracle=JSON.parse(fs.readFileSync(path.join(root,'orakel.json')));
const c=oracle.cases.find(c=>c.name==='latin');
const base=fs.readFileSync(path.join(root,c.frames[0].file));
const fixture=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const mods=[];
for(const name of ['basis','kandidaat']) {
 const m=await import(pathToFileURL(path.join(p,name,'docx_edit.js')));
 await m.default({module_or_path:fs.readFileSync(path.join(p,name,'docx_edit_bg.wasm'))});
 mods.push(m);
}
function newSession(m,id) {
 const s=new m.EditSession(id);
 s.open_docx(fixture,false);
 s.load(base);
 s.track_undo();
 return s;
}
const source=newSession(mods[0],888),updates=[];
const para=JSON.parse(source.read_paragraphs_json('{"story":"body","view":"accepted"}')).paragraphs.at(-1);
let offset=para.text.length;
for(const text of ['a','b']) {
 const v=source.encode_state_vector();
 source.edit_text_resident('body',para.paraId,offset,para.paraId,offset,text);
 offset++;
 updates.push(source.encode_diff(v));
}
const resolvedState=sha(source.encode_state());
const resolvedDigests=source.story_segment_unit_digests('body');
const v=source.encode_state_vector();
source.edit_text_resident('body',para.paraId,offset,para.paraId,offset,'c');
const remote=source.encode_diff(v);
const rows=[];
for(let i=0;i<mods.length;i++) {
 const s=newSession(mods[i],c.client_id);
 try {
  const initial=s.story_segment_unit_digests('body'),before=sha(s.encode_state());
  assert.throws(()=>s.apply_local_update(new Uint8Array([255])));
  assert.equal(sha(s.encode_state()),before);
  assert.equal(s.story_segment_unit_digests('body'),initial);
  assert.throws(()=>s.story_segment_unit_digests('onbekend'));
  assert.equal(s.story_segment_unit_digests('body'),initial);
  s.apply_local_update(updates[1]);
  assert(s.has_pending_update());
  const pendingState=sha(s.encode_state());
  assert.equal(s.story_segment_unit_digests('body'),initial);
  assert.equal(sha(s.encode_state()),pendingState);
  s.apply_local_update(updates[0]);
  assert(!s.has_pending_update());
  assert.equal(sha(s.encode_state()),resolvedState);
  assert.equal(s.story_segment_unit_digests('body'),resolvedDigests);
  s.load(base);
  const mergedState=sha(s.encode_state());
  assert.equal(s.story_segment_unit_digests('body'),resolvedDigests);
  assert.equal(sha(s.encode_state()),mergedState);
  s.apply_update(remote);
  assert.equal(s.story_segment_unit_digests('body'),source.story_segment_unit_digests('body'));
  assert.equal(sha(s.encode_state()),sha(source.encode_state()));
  const fresh=new mods[0].EditSession(c.client_id),empty=new mods[i].EditSession(c.client_id);
  try {
   assert.throws(()=>empty.story_segment_unit_digests('body'));
   fresh.open_docx(fixture,true);
   empty.open_docx(fixture,true);
   assert.equal(empty.story_segment_unit_digests('body'),fresh.story_segment_unit_digests('body'));
  } finally {fresh.free();empty.free();}
  rows.push({variant:i?'kandidaat':'basis',ongeldige_update:true,onbekende_story:true,echte_pending:true,bron_exact:true,load_merge_na_warme_cache:true,echte_remote_update_na_warme_cache:true,seeden_na_ontbrekende_body:true});
 } finally {s.free();}
}
source.free();
fs.writeFileSync(path.join(p,'randen.json'),JSON.stringify({geslaagd:true,rows},null,2)+'\n');
console.log(JSON.stringify(rows));
