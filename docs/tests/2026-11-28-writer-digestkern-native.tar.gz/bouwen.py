from pathlib import Path
import os,subprocess,json,time,shutil,signal
r=Path.cwd();p=r/'.local/integratiecontrole/digest-kern';src=p/'bron';env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(src/'target-wasm'),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true');tools=r/'.local/integratiecontrole/font-hergebruik/gereedschap';results=[]
def run(cmd,name):
 start=time.monotonic()
 with (p/(name+'.log')).open('w')as log:
  proc=subprocess.Popen(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (p/'actief.json').write_text(json.dumps({'pid':proc.pid,'fase':name})+'\n')
  while proc.poll()is None:
   time.sleep(1)
   if time.monotonic()-start>720 or shutil.disk_usage(p).free<4*1024**3:
    os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=10);break
 result={'fase':name,'code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd};results.append(result);(p/'bouwen.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True);assert proc.returncode==0
for mode in ['basis','kandidaat']:
 if mode=='kandidaat':
  for name,target in [('lib-kandidaat.rs','lib.rs'),('wasm-kandidaat.rs','wasm.rs'),('digest_cache.rs','digest_cache.rs')]:shutil.copyfile(p/name,src/'crates/docx-edit/src'/target)
 run(['cargo','build','-p','betteroffice-docx-edit','--lib','--features','wasm,tiff,metafile,heap-stats','--target','wasm32-unknown-unknown','--release','--locked'],mode+'-cargo')
 out=p/mode;out.mkdir(exist_ok=False)
 run([str(tools/'bindgen/wasm-bindgen'),'--target','web','--out-name','docx_edit','--out-dir',str(out),str(src/'target-wasm/wasm32-unknown-unknown/release/docx_edit.wasm')],mode+'-bindgen')
 raw=out/'docx_edit_bg.wasm';shutil.copy2(raw,out/'docx_edit_bg-ongeoptimaliseerd.wasm')
 run([str(tools/'binaryen/bin/wasm-opt'),'-O3',str(raw),'-o',str(out/'docx_edit_bg-opt.wasm')],mode+'-opt');(out/'docx_edit_bg-opt.wasm').replace(raw)
(p/'actief.json').write_text('{"status":"klaar"}\n')
