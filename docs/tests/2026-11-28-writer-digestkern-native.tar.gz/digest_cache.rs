use crate::{EditingDoc, SegmentContent, StorySegment};
use std::{
    collections::BTreeSet,
    sync::{Arc, Mutex},
};
use yrs::{
    Any, BranchID, Out, ReadTxn, Transact,
    types::{DeepObservable, Delta, Event, PathSegment},
};
#[derive(Default)]
struct Observed {
    commits: usize,
    events: usize,
    inserts: usize,
    start: Option<u32>,
    len: u32,
    reasons: BTreeSet<&'static str>,
}
fn roots(doc: &EditingDoc) -> Option<Vec<String>> {
    let txn = doc.yrs_doc().transact();
    let mut names: Vec<_> = txn
        .root_refs()
        .take(33)
        .map(|(n, _)| n.to_string())
        .collect();
    if names.len() > 32 || names.iter().any(|x| x.len() > 256) {
        return None;
    }
    names.sort();
    Some(names)
}
#[derive(Clone)]
struct Bound {
    start: u32,
    end: u32,
    para: Option<String>,
}
struct Entry {
    epoch: u64,
    digests: Vec<u128>,
    bounds: Vec<Bound>,
    dirty: Option<(usize, u32)>,
}
pub struct Cache {
    doc: Option<yrs::Doc>,
    entry: Option<Entry>,
    hash: fn(&[StorySegment]) -> u128,
    pub promotions: usize,
    pub full: usize,
    pub hits: usize,
    pub rejected: Vec<Vec<String>>,
}
fn bounds(units: &[Vec<StorySegment>]) -> Option<Vec<Bound>> {
    if units.len() > 4096 {
        return None;
    }
    let mut result = Vec::new();
    let mut end = 0u32;
    for unit in units {
        let start = end;
        for s in unit {
            end = end.checked_add(match &s.content {
                SegmentContent::Text(t) => u32::try_from(t.encode_utf16().count()).ok()?,
                _ => 1,
            })?
        }
        let para = match unit.last().map(|s| &s.content) {
            Some(SegmentContent::Pilcrow(p)) if p.para_id.len() <= 128 => {
                Some(p.para_id.to_string())
            }
            _ => None,
        };
        result.push(Bound { start, end, para })
    }
    Some(result)
}
impl Cache {
    pub fn new(hash: fn(&[StorySegment]) -> u128) -> Self {
        Self {
            doc: None,
            entry: None,
            hash,
            promotions: 0,
            full: 0,
            hits: 0,
            rejected: Vec::new(),
        }
    }
    fn bind(&mut self, doc: &EditingDoc) {
        if !self
            .doc
            .as_ref()
            .is_some_and(|d| yrs::Doc::ptr_eq(d, doc.yrs_doc()))
        {
            self.entry = None;
            self.doc = Some(doc.yrs_doc().clone());
        }
    }
    pub fn get(&mut self, doc: &EditingDoc) -> Result<Vec<u128>, String> {
        self.bind(doc);
        let _pin = doc.yrs_doc().transact();
        let epoch = doc.committed_epoch();
        let old = self.entry.take().filter(|x| x.epoch == epoch);
        if let Some(entry) = old.as_ref() {
            if entry.dirty.is_none() {
                let result = entry.digests.clone();
                self.entry = old;
                self.hits += 1;
                return Ok(result);
            }
        }
        let units = doc.story_segment_units("body").map_err(|e| e.to_string())?;
        let new_bounds = bounds(&units);
        let mut promoted = false;
        let digests = if let (Some(mut entry), Some(b)) = (old, new_bounds.as_ref()) {
            if let Some((slot, len)) = entry.dirty {
                let valid = entry.bounds.len() == b.len()
                    && entry.bounds.iter().zip(b).enumerate().all(|(i, (a, n))| {
                        a.para == n.para
                            && Some(n.start) == a.start.checked_add(if i > slot { len } else { 0 })
                            && Some(n.end) == a.end.checked_add(if i >= slot { len } else { 0 })
                    });
                if valid && slot < units.len() {
                    entry.digests[slot] = (self.hash)(&units[slot]);
                    promoted = true;
                    entry.digests
                } else {
                    units.iter().map(|u| (self.hash)(u)).collect()
                }
            } else {
                unreachable!()
            }
        } else {
            units.iter().map(|u| (self.hash)(u)).collect()
        };
        if promoted {
            self.promotions += 1
        } else {
            self.full += 1
        }
        if let Some(b) = new_bounds {
            self.entry = Some(Entry {
                epoch,
                digests: digests.clone(),
                bounds: b,
                dirty: None,
            })
        }
        Ok(digests)
    }
    pub fn apply(&mut self, doc: &EditingDoc, bytes: &[u8]) -> Result<(), String> {
        self.bind(doc);
        let before = doc.committed_epoch();
        let old = self
            .entry
            .take()
            .filter(|e| e.epoch == before && e.dirty.is_none());
        if old.is_none() {
            return doc.apply_local_update_v1(bytes).map_err(|e| e.to_string());
        }
        let old = old.unwrap();
        let root_before = roots(doc);
        let pending = doc.holds_pending_update();
        let state = Arc::new(Mutex::new(Observed::default()));
        let recorded = state.clone();
        let deep = {
            let txn = doc.yrs_doc().transact();
            txn.get_map("stories").map(|m|m.observe_deep(move|txn,events|{let mut s=recorded.lock().unwrap();for e in events.iter(){let Event::Text(e)=e else{s.reasons.insert("non_text");continue};s.events=s.events.saturating_add(1);let path=e.path();if path.len()!=1||!matches!(path.front(),Some(PathSegment::Key(k))if k.as_ref()=="body"){s.reasons.insert("other_story");}let mut index=0u32;for delta in e.delta(txn){match delta{Delta::Retain(n,a)=>{if a.is_some(){s.reasons.insert("format");}index=index.saturating_add(*n)},Delta::Deleted(_)=>{s.reasons.insert("delete");},Delta::Inserted(Out::Any(Any::String(t)),attrs)=>{s.inserts=s.inserts.saturating_add(1);let len=t.encode_utf16().count();if len==0||len>4096||t.chars().any(|c|matches!(c,'\r'|'\n')){s.reasons.insert("text_boundary");}if s.inserts==1{s.start=Some(index);s.len=len as u32;}if let Some(a)=attrs{if a.len()>32||a.keys().any(|k|k.len()>128||matches!(k.as_ref(),"ins"|"del"|"rPrIns"|"rPrDel"|"moveFrom"|"moveTo")){s.reasons.insert("attributes");}}index=index.saturating_add(len as u32)},Delta::Inserted(_,_)=>{s.reasons.insert("embed");}}}}}))
        };
        let recorded = state.clone();
        let commit = doc
            .yrs_doc()
            .observe_after_transaction(move |txn| {
                if txn.before_state() == txn.after_state() && txn.delete_set().is_empty() {
                    return;
                }
                let mut s = recorded.lock().unwrap();
                s.commits = s.commits.saturating_add(1);
                let mut found = false;
                for branch in txn.changed_parent_types() {
                    if let BranchID::Root(n) = branch.id() {
                        found = true;
                        if n.as_ref() != "stories" {
                            s.reasons.insert("other_root");
                        }
                    }
                }
                if !found {
                    s.reasons.insert("no_root");
                }
            })
            .map_err(|e| e.to_string())?;
        let result = doc.apply_local_update_v1(bytes).map_err(|e| e.to_string());
        drop(deep);
        drop(commit);
        let after = doc.committed_epoch();
        let mut state = std::mem::take(&mut *state.lock().unwrap());
        if pending || doc.holds_pending_update() {
            state.reasons.insert("pending");
        }
        if root_before.is_none() || root_before != roots(doc) {
            state.reasons.insert("root_set");
        }
        if state.commits != 1 || before.checked_add(1) != Some(after) {
            state.reasons.insert("commits");
        }
        if state.events != 1 || state.inserts != 1 {
            state.reasons.insert("not_one_insert");
        }
        let slot = state.start.and_then(|start| {
            old.bounds
                .iter()
                .position(|b| b.start <= start && start < b.end && b.para.is_some())
        });
        if slot.is_none() {
            state.reasons.insert("unit_boundary");
        }
        if result.is_ok() && state.reasons.is_empty() {
            self.entry = Some(Entry {
                epoch: after,
                dirty: Some((slot.unwrap(), state.len)),
                ..old
            });
        } else {
            if self.rejected.len() < 4096 {
                self.rejected
                    .push(state.reasons.iter().map(|x| x.to_string()).collect());
            }
            if before == after {
                self.entry = Some(old);
            }
        }
        result
    }
}
