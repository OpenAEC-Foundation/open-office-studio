# Verworpen aanname over bronvervanging

Twee extra verkennende gevallen kwamen bovenop de 39 groene gerichte proeven.
Een tweede openDocx(..., true) in dezelfde reeds gezaaide sessie faalt met
`story body already exists`: die proef gebruikt geen geldige vervangingsroute.
De tweede proef eiste volle bronnen bij onbekende tokenvorm. Dat is geen
contract: versietokens zijn ondoorzichtig. Beide oorspronkelijke negatieve
gevallen en de broncode zijn behouden, maar gelden niet als productregressie.

De werkelijke publieke loadState-route integreert een Yrs-update en draait de
versietoken, met behoud van dezelfde CRDT-replica. Nieuwe sessie-objecten krijgen
al een volle bron via objectidentiteit. De tests zijn daarom vervangen door
geldige hydratie van dezelfde replica en een ondoorzichtige tokenvorm met
behoud van alle brontekst. Er is GEEN parsing van nonceprefixen toegevoegd en
GEEN native productsource gewijzigd op basis van deze verworpen aanname.
