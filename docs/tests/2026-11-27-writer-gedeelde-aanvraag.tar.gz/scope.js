function officePreparedRegionScope(raw, prepare, stamp) {
  let cached=false, key=null, value;
  const probe=globalThis.__OPENAEC_REGION_SCOPE_PROBE__,id=probe?.active?++probe.next:0;
  const note=event=>{if(!id||!probe.active)return;if(probe.rows.length<4096)probe.rows.push({scope:id,event});else probe.overgeslagen++};
  const same=(a,b)=>a.length===b.length&&a.every((v,i)=>Object.is(v,b[i]));
  return {read(){
    const before=stamp();
    if(cached&&same(key,before)){note("reuse");return value}
    note("prepare");
    const next=prepare(raw),after=stamp();
    value=next;key=after;cached=same(before,after);if(!cached)note("unstable");
    return next;
  }};
}
