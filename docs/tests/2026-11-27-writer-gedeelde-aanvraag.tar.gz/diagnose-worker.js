(()=>{
 'use strict';
 if(self._bewaarBinnen)throw Error('Binnenmeting bestaat al');
 const oud=Object.getOwnPropertyDescriptor(self,'postMessage'),fn=self.postMessage;
 if(typeof fn!=='function'||oud&&!oud.configurable)throw Error('Werkerantwoord niet veilig te volgen');
 const regels=[];let actief=true,overgeslagen=0;
 const waarde=(o,k)=>o&&Object.getOwnPropertyDescriptor(o,k)?.value;
 function noteer(richting,data){if(!actief)return;try{const type=waarde(data,'type'),id=waarde(data,'id'),saved=waarde(data,'saved');if(regels.length<4096)regels.push({richting,tijd:performance.now(),...(typeof type==='string'?{type:type.slice(0,80)}:{}),...(typeof id==='number'?{id}:{}),...(saved instanceof ArrayBuffer?{bewaarbytes:saved.byteLength}:{})});else overgeslagen++}catch{}}
 const luister=e=>noteer('ontvangst',e.data);
 const wrapper={postMessage(...args){noteer('verzending',args[0]);return Reflect.apply(fn,this,args)}}.postMessage;
 self.addEventListener('message',luister,true);
 Object.defineProperty(self,'postMessage',{value:wrapper,configurable:true,writable:true,enumerable:oud?.enumerable??false});
 self._bewaarBinnen={stop(){actief=false;self.removeEventListener('message',luister,true);const hersteld=self.postMessage===wrapper;if(hersteld){if(oud)Object.defineProperty(self,'postMessage',oud);else delete self.postMessage}return{regels,overgeslagen,hersteld,grens:4096}}};
 return {geplaatst:true};
})()

;(()=>{const previous=globalThis.__OPENAEC_WERKER_FASEN__;globalThis.__OPENAEC_WERKER_FASEN__={note(){},start(){globalThis.__OPENAEC_REGION_SCOPE_PROBE__={active:true,next:0,rows:[],overgeslagen:0};return true},stop(){const p=globalThis.__OPENAEC_REGION_SCOPE_PROBE__;p.active=false;const out={regels:p.rows,scopes:p.next,overgeslagen:p.overgeslagen,grens:4096};delete globalThis.__OPENAEC_REGION_SCOPE_PROBE__;if(previous===undefined)delete globalThis.__OPENAEC_WERKER_FASEN__;else globalThis.__OPENAEC_WERKER_FASEN__=previous;return out}};return true})()
