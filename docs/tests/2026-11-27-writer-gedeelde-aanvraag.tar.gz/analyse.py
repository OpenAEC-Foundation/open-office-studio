from pathlib import Path
import json,collections
p=Path(__file__).resolve().parent
r=json.loads((p/'diagnose/rapport.json').read_text());assert r['geslaagd']
f=r['fasen_eind'][0]['result']['result']['value'];rows=f['regels'];assert len(rows)==68
for i in range(34):assert rows[2*i:2*i+2]==[{'scope':i+1,'event':'prepare'},{'scope':i+1,'event':'reuse'}]
sends=[x for x in r['transport_eind']['regels'] if x.get('type')=='sync' and x['richting']=='verzending'];assert len(sends)==34
joined=[{'id':x['id'],'tijd':x['tijd'],'pending_native_transport':sum(y['fetchStartMs']<=x['tijd']<y['antwoordMs'] for y in r['native_opdrachten'] if 'antwoordMs'in y)}for x in sends]
assert sum(x['pending_native_transport']>0 for x in joined)==32
rounds=json.loads((p/'native-ronden.json').read_text());assert len(rounds)==8 and all(x['code']==0 and x['geslaagd']for x in rounds)
result={'ronden':[{'naam':x['naam'],'elf':x['programma_sha256'],'metingen':{k:v for k,v in x['invoer'].items() if k.endswith('_ms')}}for x in rounds],'voorbereidingen':34,'hergebruik':34,'syncs':34,'syncs_tijdens_native_transport':32,'overlap':joined,'grenzen':'Overlap gebruikt uitsluitend dezelfde main-klok, fetch tot antwoord; geen CPU-tijd, volledige mutatielevensduur of bewezen oorzaak. Diagnoseronde uitgesloten van ABBA. Renderlijst plus twee rAF is geen fysieke schermpaint.'}
(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['ronden','overlap']}))
