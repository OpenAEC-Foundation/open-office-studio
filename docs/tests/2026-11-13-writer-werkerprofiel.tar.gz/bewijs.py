from pathlib import Path
import hashlib,json,stat,tarfile
p=Path(__file__).resolve().parent;repo=p.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
refs=json.load(open(repo/'.local/integratiecontrole/bewaar-groepen/referenties-nacontrole.json'))
refs[str(repo/'.local/integratiecontrole/bewaar-groepen/open-office-studio-bewaar-groepen')]='b6162e59e9c2dfdfcb98eb85d1b731ba52d2d4ee97f3a6429b6106a6127c3421'
for f,h in refs.items():assert sha(Path(f))==h,f
bundel=json.load(open(repo/'.local/integratiecontrole/bewaar-groepen/standaardbundel.json'))
for f,v in bundel.items():
 q=repo/'dist'/f;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],f
assert len([x for x in (repo/'dist').rglob('*') if x.is_file()])==len(bundel)
sdk=repo/'node_modules/@betteroffice/docx-react/dist/index.mjs';assert sha(sdk)=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
(p/'behoud.json').write_text(json.dumps({'referenties':refs,'standaardbundel_exact':len(bundel),'sdk_sha256':sha(sdk),'geen_productwijziging':True},indent=2)+'\n')
for f in ['src/editors.tsx','src/tekst/info/opslaan.ts','src/tekst/info/docprops.ts','src/useHerstel.tsx']:
 (p/Path(f).name).write_bytes((repo/f).read_bytes())
(p/'wachtrij-probe.js').write_bytes((repo/'.local/integratiecontrole/adaptieve-invoer/wachtrij-probe.js').read_bytes())
import gzip
for naam,f in [('sdk-react.mjs.gz','node_modules/@betteroffice/docx-react/dist/index.mjs'),('sdk-client.mjs.gz','node_modules/@betteroffice/docx/dist/chunk-6ZKYZDSZ.mjs'),('sdk-werker.mjs.gz','node_modules/@betteroffice/docx/dist/yrs/docxWorker.mjs')]:
 with gzip.open(p/naam,'wb') as z:z.write((repo/f).read_bytes())
archive=repo/'docs/tests/2026-11-13-writer-werkerprofiel.tar.gz'
files=[f for f in p.rglob('*') if f.is_file() and f.suffix!='.pyc']
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(files):t.add(f,arcname=f.relative_to(p),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(files)
 for m in members:assert m.isfile() and sha(p/m.name)==hashlib.sha256(t.extractfile(m).read()).hexdigest()
anal=json.load(open(p/'analyse.json'))['opname'];profiel=json.load(open(p/'profielanalyse.json'));assert anal['geslaagd']
assert profiel['samples']==9629 and profiel['timestamp_nul']==6927
r={'datum':'2026-11-13','basis_integratie':'99b86e72','productbron':'41e7000198f89d992e1059e9715636a44b39d21a','programma_sha256':'acb77036935feed425b7c81a5dbd2ef796ffcb4307db96c9845aa6dd8b70c958','besluit':'Echte Worker-sampling wijst op veel herhaalde lettertypebepaling naast bewaarwerk. Geen productwijziging, volledige oorzaak- of snelheidsfixclaim.','native':anal,'werkerprofiel':profiel,'frameaanwezigheid_belangrijk':{'layout_font_requirements_json':6305,'saveResidentDocument_E':1853,'paragraph_save_plan':791},'bronbinding':{'lettertypefunctie':'gg in chunk-Q7OC7M5Q-BzppsI5m.js,regel10/kolom59926 roept layoutFontRequirementsJson; cache wordt op owner/version en onUpdate ongeldig gemaakt.','bewaarfunctie':'E in chunk-YTGFUEEE-BR8wyl1E.js,regel1/kolom175,export saveResidentDocument.','bronherkomst':'Worker-script-URLs/posities gekoppeld aan bewaarde lint-invoer/dist. Alle in deze native ronde werkelijk opgehaalde main-profielbronnen zijn bytegelijk aan die bundel. Workerbronnen niet opnieuw uit draaiende runtime opgehaald; geen sterkere herkomstclaim.','client':'fontRequirements deelt alleen een wachtend antwoord bij identieke layoutInput en dezelfde laatste request-id; bestaande versie-/fontbewaking niet gewijzigd.'},'validatie':{'native_volledig':True,'probe_controles':25,'collector_python_compilatie':True,'docx_onafhankelijk':anal['docx'],'beeld':'snel-getypt-bewaard.png bekeken: lint, tekst, tabellen en paginaovergang zichtbaar. Geen volledige65pagina-/pixelacceptatie.'},'grenzen':['Eén eigen rijke native Linux/schema2-ronde met gelijktijdige main-/Worker-profiler, geen onbeïnvloede ABBA-snelheidsvergelijking.','9629Worker-samples:6927tijdstempel0 en2702positief. Positieve tijden monotoon9.915893–13.978665, maar geen volledige aan savefasen gebonden tijdlijn. Geen nul-tijden geïmputeerd of CPU-ms/-percentages afgeleid.','Frameaantallen tellen aanwezigheid in samples over de volledige invoerperiode. Aanroepers overlappen;6305+1853+791niet als verdeling optellen. Geen hele3seconden-save aan fontbepaling toegeschreven.','Geen afzonderlijke klokmeting van interne taakstart/wachtrij/session.save/ZIP. Profiel geeft de volgende onderzoekslijn, geen volledige splitsing.','Worker-debugger na export uitgeschakeld; alle bewaar-/verwerp-/nieuw-document-/lateantwoordproeven slagen. Eerdere twee diagnose-timeouts blijven in vorig rapport afgekeurd.','ProbeJS bytegelijk aan vorige geteste meetopzet, alle25controles opnieuw uitgevoerd. Geen extra Worker-/engineverzoeken door de probes; profilering/Promise-observers kunnen uitvoering beïnvloeden.','Geen frontend/TS/Python-producttests/build/CI opnieuw: alleen private diagnose en bewijsdocs; normale eerdere3OS-CI afzonderlijk. Geheugenfouten/platform/releasevarianten niet opgelost of aanvaard.'],'behoud':json.load(open(p/'behoud.json')),'vervolg':'Maak een aparte bronexacte diagnostische Worker-kopie met alleen begrensde klokken bij queue-submit/taskstart, fontRequirements, session.save/saveDocument, pakketuitvoer en update-encoding; behoud echte return/Promises/versiegrenzen en standaardSDK/dist. Bind originele timings en workerbron vóór een fix. Onderzoek daarna of fontaanvragen veilig samengevoegd kunnen worden met actuele-versie/fallback-bewaking; geen blinde cache van fonts of geometrie. Na gerichte wijziging vaste korte/rijke ABBA en functionele/visuele bewijslast. Tien migratiegebieden/geheugenfouten open; Database laatst.','bewijs':{'pad':str(archive.relative_to(repo)),'sha256':sha(archive),'bytes':archive.stat().st_size,'reguliere_leden':len(files),'alle_leden_byteexact_gecontroleerd':True}}
(repo/'docs/tests/2026-11-13-writer-werkerprofiel.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r['bewijs']))
