from pathlib import Path
import json,collections,statistics
p=Path(__file__).resolve().parent

def union(intervals):
 merged=[]
 for a,b in sorted(intervals):
  if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
  else:merged.append([a,b])
 return sum(b-a for a,b in merged)

def distribution(values):
 return {'aantal':len(values),'som_ms':sum(values),'mediaan_ms':statistics.median(values)if values else None,'maximum_ms':max(values)if values else None}

results={}
for name in ['een','twee']:
 r=json.loads((p/('diagnose-'+name)/'rapport.json').read_text());assert r['geslaagd'];data=r['tijdlijn_eind'];assert data['tag']=='publicatie-tijdlijn-v1'and data['overflow']==0
 rows=data['rows'];assert len(rows)<=data['limit'];assert all(set(x)=={'kind','phase','id','session','t'}for x in rows);assert all(rows[i]['t']<=rows[i+1]['t']for i in range(len(rows)-1))
 opened={};spans=[]
 for x in rows:
  if x['kind']=='begin':assert x['id']not in opened;opened[x['id']]=x
  elif x['kind']=='end':
   a=opened.pop(x['id']);assert(a['phase'],a['session'])==(x['phase'],x['session']);assert x['t']>=a['t'];spans.append({'id':x['id'],'phase':x['phase'],'session':x['session'],'begin':a['t'],'eind':x['t']})
 assert not opened
 begin=r['invoer_begin_klok'];end=begin+r['lange_invoer']['begin_tot_frame_ms'];assert r['tijdlijn_begin']['begin']<=begin<end<=data['eind'];window=[x for x in spans if x['begin']>=begin and x['eind']<=end];phases=collections.defaultdict(list)
 for x in window:phases[x['phase']].append(x['eind']-x['begin'])
 callbacks=sorted([x for x in window if x['phase']=='tekst'],key=lambda x:x['begin']);assert callbacks
 gaps=[];publications=[]
 for index,x in enumerate(callbacks):
  next_begin=callbacks[index+1]['begin']if index+1<len(callbacks)else end
  assert next_begin>=x['eind'];gaps.append(next_begin-x['eind'])
  candidates=[y for y in window if y['phase']=='Ft'and y['session']==x['session']and x['eind']<=y['begin']<next_begin]
  publications.append({'callback':x['id'],'eind':x['eind'],'volgende_callback_of_venstereind':next_begin,'Ft_ids':[y['id']for y in candidates],'tot_eerste_Ft_ms':min(y['begin']for y in candidates)-x['eind']if candidates else None})
 events=collections.defaultdict(list)
 for x in rows:
  if x['kind']=='event'and begin<=x['t']<=end:events[x['phase']].append(x['t'])
 def gaps_of(values):return distribution([b-a for a,b in zip(values,values[1:])])
 coverage=union([(x['begin'],x['eind'])for x in window]);ft=union([(x['begin'],x['eind'])for x in window if x['phase']=='Ft']);native=union([(x['begin'],x['eind'])for x in callbacks]);last_keyup=r['lange_invoer']['laatste_keyup_ms']
 results[name]={'rows':len(rows),'venster':{'begin':begin,'eind':end,'duur_ms':end-begin,'laatste_keyup':last_keyup,'laatste_callback_eind':callbacks[-1]['eind'],'laatste_callback_tot_frame_ms':end-callbacks[-1]['eind']},'fasen':{k:distribution(v)for k,v in phases.items()},'dekking':{'unie_alle_spans_ms':coverage,'niet_door_spans_gedekt_ms':end-begin-coverage,'unie_tekst_ms':native,'unie_Ft_ms':ft},'tussen_callbacks_inclusief_laatste_staart':distribution(gaps),'tussen_callback_en_Ft':distribution([x['tot_eerste_Ft_ms']for x in publications if x['tot_eerste_Ft_ms']is not None]),'publicaties':publications,'events':{k:{'aantal':len(v),'eerste':min(v),'laatste':max(v),'tussenpozen':gaps_of(v)}for k,v in events.items()},'grenzen':'Eén main performance-klok. Vensters kunnen wachten bevatten; At zit vaak in Ft, fasen niet optellen. Onbedekte tijd is geen bewezen idle- of CPU-tijd. Callback→Ft-koppeling op sessie en tijdvolgorde, geen oorzakelijk parenttoken. Eén vaste rijke bron; meetoverhead niet afgetrokken. Laatste frame = renderlijst plus twee rAFs, geen fysieke paint.'}
(p/'analyse.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:{n:v for n,v in x.items()if n not in ['publicaties','events']}for k,x in results.items()},ensure_ascii=False))
