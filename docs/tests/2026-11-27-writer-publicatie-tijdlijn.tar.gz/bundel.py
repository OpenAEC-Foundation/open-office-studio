from pathlib import Path
import json,shutil,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/publicatie-tijdlijn';base=r/'.local/integratiecontrole/projectie-context/dist';shutil.copytree(base,p/'dist');asset='assets/editors-bODdYQ4o.js';s=(base/asset).read_text();pairs=[]
def replace(old,new):
 global s
 assert s.count(old)==1,old[:100];s=s.replace(old,new);pairs.append({'voor':old,'na':new})
replace('function LW(e){',(p/'meter.js').read_text()+'\nfunction LW(e){')
for start,end,phase in [('At=u.useCallback((ne,pe=!1,Te=!1,Je=!1,Ke=!1)=>{','},[Dn,I])','At'),('Ft=u.useCallback((ne=!1,pe=!1,Te)=>{','},[At,$,R,pn])','Ft')]:
 i=s.index(start);j=s.index(end,i);old=s[i:j+len(end)];body=s[i+len(start):j];replace(old,start[:-1]+'officeTimeline.span("'+phase+'",()=>{'+body+'},c)'+end[1:])
replace('value:s?.plak??null,children:i.jsx(r6,{value:l?.tekst??null','value:officeTimeline.wrap(s?.plak,"plak"),children:i.jsx(r6,{value:officeTimeline.wrap(l?.tekst,"tekst")')
replace('let dt=Du(t,o,At);V.current&&(dt.cachedPageTotals=!0);','let dt=officeTimeline.span("layoutInput",()=>Du(t,o,At),n);V.current&&(dt.cachedPageTotals=!0);')
replace('let Ue=JSON.parse(En??n.layoutFontRequirementsJson(Nt));Ft=s(Ue)','let Ue=officeTimeline.span("fontDecode",()=>JSON.parse(En??n.layoutFontRequirementsJson(Nt)),n);Ft=officeTimeline.span("fontConfig",()=>s(Ue),n)')
replace('U.current=!1,be.current=Nt,R(on);','U.current=!1,be.current=Nt,officeTimeline.span("framePublicatie",()=>R(on),n);')
(p/'dist'/asset).write_text(s);(p/'bundelwijzigingen.json').write_text(json.dumps(pairs,indent=2)+'\n');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();(p/'bundel.json').write_text(json.dumps({'asset':asset,'voor':sha(base/asset),'na':sha(p/'dist'/asset),'overige_assets_exact':all(sha(f)==sha(p/'dist'/f.relative_to(base))for f in base.rglob('*')if f.is_file()and str(f.relative_to(base))!=asset)},indent=2)+'\n')
s=(r/'.local/integratiecontrole/invoer-layout/bouwen.py').read_text().replace("p=r/'.local/integratiecontrole/invoer-layout'","p=r/'.local/integratiecontrole/publicatie-tijdlijn'").replace('gedeelde-aanvraag/referenties-nacontrole','invoer-layout/referenties-nacontrole').replace('len(present)==33','len(present)==34').replace('open-office-studio-invoer-layout','open-office-studio-publicatie-tijdlijn').replace('referenties33_exact','referenties34_exact');(p/'bouwen.py').write_text(s)
