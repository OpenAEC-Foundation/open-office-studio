from pathlib import Path
import subprocess,json,os
r=Path.cwd();p=r/'.local/integratiecontrole/herstel-observatie';env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];uit={}
for naam in ['probe-b','probe-c']:
 with (p/(naam+'.log')).open('x') as log:
  v=subprocess.run(['/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python',str(p/'proef.py'),'--programma',str(p/'open-office-studio-ci-afgekeurd'),'--versie','2026.45.52','--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken','--uitvoer',str(p/naam)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 d=json.loads((p/naam/'rapport.json').read_text());uit[naam]={'code':v.returncode,'geslaagd':d['geslaagd'],'fout':d.get('fout')};(p/'rondes.json').write_text(json.dumps(uit,indent=2)+'\n');print(naam,uit[naam],flush=True)
