from pathlib import Path
import hashlib,json,os,re,shutil,signal,subprocess,time
r=Path.cwd();u=r/'.local/integratiecontrole/tabelrust';root=r.parent/'Open-Office-Studio';target=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '2395 passed (2395)' in (u/'frontend.log').read_text();assert not (u/'typescript.log').read_text();assert 'built in' in (u/'vite.log').read_text()
bronbestanden=['src/tekst/liniaal/TabelGrepen.tsx','src/tekst/liniaal/tabelRust.ts','src/tekst/liniaal/tabelRust.test.ts'];pinnen={p:sha(r/p) for p in bronbestanden};status=subprocess.check_output(['git','status','--porcelain']);assert set(s[3:] for s in status.decode().splitlines())==set(bronbestanden)
(u/'bron.diff').write_bytes(subprocess.check_output(['git','diff','--binary']));(u/'bronpinnen.json').write_text(json.dumps(pinnen,indent=2)+'\n')
for n in bronbestanden:shutil.copy2(r/n,u/Path(n).name)
refs=json.loads((r/'.local/integratiecontrole/runtime-vergelijking/referenties.json').read_text())
for p,h in refs.items():assert sha(Path(p))==h
oud={str(p.relative_to(r/'dist')):{'sha256':sha(p),'mode':p.stat().st_mode&0o777,'mtime_ns':p.stat().st_mtime_ns} for p in (r/'dist').rglob('*') if p.is_file()};assert len(oud)==529
(u/'standaardbundel.json').write_text(json.dumps(oud,indent=2)+'\n')
# Alleen onveranderde bouwassets tijdelijk delen; geen verdere Vite-bouw tijdens
# de native bouw. De hele oude boom wordt voor en na byte/mode/mtime vergeleken.
links=[]
for n,b in oud.items():
 p=u/'dist'/n;q=r/'dist'/n
 if p.is_file() and sha(p)==b['sha256']:
  p.unlink();os.link(q,p);links.append(n)
(u/'gedeelde-assets.json').write_text(json.dumps(links)+'\n')
vrij=shutil.disk_usage(r).free;assert vrij>3.1*1024**3,('Te weinig ruimte voor uitsluitend gecachete eigen crates',vrij)
assert not (u/'standaarddist').exists();(r/'dist').rename(u/'standaarddist');(u/'dist').rename(r/'dist')
env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true')
cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];allow={'open-office-studio'};begin=time.monotonic();minimum=vrij;reden=None;result={};crates=set()
try:
 with (u/'desktop.log').open('x') as log:
  p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (u/'actief.json').write_text(json.dumps({'status':'native_bouw_actief','supervisor_pid':os.getpid(),'cargo_pid':p.pid,'standaarddist_tijdelijk':str(u/'standaarddist'),'stopvloer_gib':3,'max_crates':sorted(allow),'bronpinnen':pinnen},indent=2)+'\n')
  while p.poll() is None:
   time.sleep(1);minimum=min(minimum,shutil.disk_usage(r).free);tekst=(u/'desktop.log').read_text(errors='replace');crates=set(re.findall(r'^\s*Compiling ([^ ]+)',tekst,re.M))
   if crates-allow or minimum<3*1024**3 or time.monotonic()-begin>1200:
    reden='Onverwachte afhankelijkheid, minder dan3GiB of20min';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
 result={'code':p.returncode,'reden':reden,'seconden':time.monotonic()-begin,'minimum_vrije_bytes':minimum,'start_vrije_bytes':vrij,'gecompileerde_crates':sorted(crates),'opdracht':cmd,'startgrens_gib':3.1,'stopgrens_gib':3}
 if p.returncode==0:
  exe=target/'release/open-office-studio';st=exe.stat();aliases=[q for q in (target/'release/deps').glob('open_office_studio-*') if q.is_file() and q.stat().st_ino==st.st_ino and q.stat().st_dev==st.st_dev];assert len(aliases)+1==st.st_nlink==2
  h=sha(exe);doel=u/'open-office-studio-tabelrust';assert not doel.exists();exe.rename(doel)
  for q in aliases:assert sha(q)==h;q.unlink()
  assert doel.stat().st_nlink==1
  result.update(programma=str(doel),programma_sha256=h,cargo_cache_app_verplaatst_zonder_dubbele_ELF=True)
finally:
 (r/'dist').rename(u/'dist');(u/'standaarddist').rename(r/'dist')
 assert oud=={str(p.relative_to(r/'dist')):{'sha256':sha(p),'mode':p.stat().st_mode&0o777,'mtime_ns':p.stat().st_mtime_ns} for p in (r/'dist').rglob('*') if p.is_file()}
 assert status==subprocess.check_output(['git','status','--porcelain']) and pinnen=={p:sha(r/p) for p in bronbestanden}
 for p,h in refs.items():assert sha(Path(p))==h
 (u/'desktop.json').write_text(json.dumps(result,indent=2)+'\n');(u/'actief.json').write_text(json.dumps({'status':'native_bouw_klaar' if result.get('code')==0 else 'native_bouw_afgewezen','resultaat':result,'standaarddist_hersteld':True},indent=2)+'\n')
print(json.dumps(result));raise SystemExit(result['code'])
