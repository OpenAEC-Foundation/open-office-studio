import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { wachtOpTabelRust } from "./tabelRust";

beforeEach(() => vi.useFakeTimers());
afterEach(() => { vi.clearAllTimers(); vi.useRealTimers(); });

it("hervat na lege wachtrij zonder volgend indelingsbericht of flush", () => {
  const bron = { versie: "a", invoer: true }, hervat = vi.fn();
  const lees = vi.fn(() => bron), stop = wachtOpTabelRust("a", lees, hervat);
  vi.advanceTimersByTime(600);
  expect(hervat).not.toHaveBeenCalled();
  bron.invoer = false;
  vi.advanceTimersByTime(120);
  expect(hervat).toHaveBeenCalledExactlyOnceWith("a");
  expect(vi.getTimerCount()).toBe(0); stop();
});

it("wacht opnieuw bij gewijzigde bron, ook als de wachtrij tussendoor leeg is", () => {
  const bron = { versie: "a", invoer: false }, hervat = vi.fn();
  const stop = wachtOpTabelRust("a", () => bron, hervat);
  vi.advanceTimersByTime(100); bron.versie = "b";
  vi.advanceTimersByTime(120); expect(hervat).not.toHaveBeenCalled();
  bron.versie = "c"; vi.advanceTimersByTime(120); expect(hervat).not.toHaveBeenCalled();
  vi.advanceTimersByTime(120); expect(hervat).toHaveBeenCalledExactlyOnceWith("c"); stop();
});

it.each(["opruimen", "eigenaar vervangen", "lezen mislukt"])("hervat niet na %s en laat geen timer achter", (soort) => {
  let huidig = true;
  const hervat = vi.fn(), lees = vi.fn(() => {
    if (soort === "lezen mislukt") throw new Error("Bron gesloten");
    return huidig ? { versie: "a", invoer: true } : null;
  });
  const stop = wachtOpTabelRust("a", lees, hervat);
  vi.advanceTimersByTime(120);
  if (soort === "opruimen") stop(); else huidig = false;
  vi.advanceTimersByTime(1200);
  expect(hervat).not.toHaveBeenCalled(); expect(vi.getTimerCount()).toBe(0); stop();
});

it("laat een nieuwe eigenaar onafhankelijk hervatten nadat oud werk is opgeruimd", () => {
  const oud = vi.fn(), nieuw = vi.fn();
  const stop = wachtOpTabelRust("zelfde versie", () => ({ versie: "zelfde versie", invoer: true }), oud);
  vi.advanceTimersByTime(100); stop();
  const stopNieuw = wachtOpTabelRust("zelfde versie", () => ({ versie: "zelfde versie", invoer: false }), nieuw);
  vi.advanceTimersByTime(120);
  expect(oud).not.toHaveBeenCalled(); expect(nieuw).toHaveBeenCalledExactlyOnceWith("zelfde versie"); stopNieuw();
});
