/** Optionele tabellezingen wachten op een stabiele bron en lege invoerwachtrij. */
export function wachtOpTabelRust(
  versie: string,
  lees: () => { versie: string; invoer: boolean } | null,
  hervat: (versie: string) => void,
) {
  let actief = true;
  let timer: ReturnType<typeof setTimeout>;
  const plan = () => { timer = setTimeout(controleer, 120); };
  const controleer = () => {
    if (!actief) return;
    let bron;
    try { bron = lees(); } catch { return; }
    // Een verdwenen of vervangen eigenaar krijgt geen hertekening van oud werk.
    if (!bron || !actief) return;
    if (bron.versie !== versie) { versie = bron.versie; plan(); return; }
    if (bron.invoer) { plan(); return; }
    hervat(versie);
  };
  plan();
  return () => { actief = false; clearTimeout(timer); };
}
