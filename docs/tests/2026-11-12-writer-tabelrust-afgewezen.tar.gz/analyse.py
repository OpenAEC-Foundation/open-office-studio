from pathlib import Path
import collections,hashlib,json,zipfile,xml.etree.ElementTree as ET
u=Path(__file__).resolve().parent;plan=json.loads((u/'vergelijkplan.json').read_text());uitslagen=json.loads((u/'vergelijkuitslagen.json').read_text());assert len(uitslagen)==8 and all(x['code']==0 for x in uitslagen)
uit=[]
for soort,j,app in plan['vooraf_bepaalde_volgorde']:
 naam=f'{soort}-{j}-{app}';p=u/naam;r=json.loads((p/'rapport.json').read_text());assert r['geslaagd'] and r['schema']==2 and not any(r['fouten'].values())
 assert r['programma_sha256']==plan['programma_sha256'][app] and r['script_sha256']==plan['helpers'][soort]
 assert r['gewone_invoer_antwoordvertraging_ms']==0
 if soort=='rijk':assert r['uitlezingen']['hersteld'] and r['uitlezingen']['overgeslagen']==0
 marker=' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.' if soort=='rijk' else ' Een korte zin. EINDEPROEF.'
 prefix='';opdrachten=[]
 for m in r['native_opdrachten']:
  opdrachten.append(m)
  if m.get('caret'):prefix+=m['text']
  assert marker.startswith(prefix)
  if prefix==marker:break
 assert prefix==marker and all(m['bronbinding'] and m['gereed'] and not m.get('vertragingMs') and not m['wacht'] for m in opdrachten)
 docx=p/'Ontwerpnotitie.docx'
 with zipfile.ZipFile(docx) as z:
  assert z.testzip() is None
  doc=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tabellen=len(doc.findall('.//w:tbl',ns));assert tabellen==(128 if soort=='rijk' else 1)
 if soort=='rijk':assert r['bewaarde_tabellen_exact']==128
 uit.append({'naam':naam,'geslaagd':True,'invoer':r['lange_invoer'],'uitlezingen':dict(collections.Counter(x['naam'] for x in r['uitlezingen']['regels'])) if soort=='rijk' else None,'gewone_native_opdrachten':len(opdrachten),'undo_groepen':r['undo_groepen_lange_invoer'],'bewaarde_tabellen':tabellen,'docx_sha256':hashlib.sha256(docx.read_bytes()).hexdigest(),'fouten':r['fouten']})
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for v in uit:print(v['naam'],v['invoer']['wall_begin_tot_frame_ms'],round(v['invoer']['laatste_keyup_tot_frame_ms']),v['uitlezingen'].get('tablePayload',0) if v['uitlezingen'] else 'niet gemeten')
