from pathlib import Path
import collections,gzip,hashlib,json
u=Path(__file__).resolve().parent;p=u.parent/'actuele-invoerstaart/opname';r=json.loads((p/'rapport.json').read_text())
assert r['programma_sha256']=='8d67e9e495008f7dd7542082214410b0f5322c459bfcf297eccd8d31fa76f567' and r['stack_kalibratie']['leaf_eerst']
bronnen={}
for b in r['scriptbronnen']:
 data=gzip.decompress((p/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256'];bronnen[b['url']]=data.decode()
index=next(s for n,s in bronnen.items() if n.endswith('/index-DfZTET1E.js')).split('\n');editors=next(s for n,s in bronnen.items() if n.endswith('/editors-EW2ZgGN5.js')).split('\n')
assert 'function lY(' in index[222][9531:9961]
assert 'function iY(' in index[222][4199:4629]
assert 'new dH(oe)' in editors[11][143945:144375]
assert 'let pe=b(ne.anchor),Te=b(ne.head)' in editors[7][77356:77786]
ev=json.load(gzip.open(p/'profielen.json.gz','rt'));ms=next(e for e in ev if e.get('method')=='ScriptProfiler.trackingComplete')['params']['samples']['stackTraces'];c=collections.Counter()
for m in ms:
 fs=m['stackFrames'];ns=[f['name'] for f in fs]
 if 'buildStory' in ns:
  i=ns.index('buildStory');c[tuple((f['name'],f.get('url'),f.get('line'),f.get('column')) for f in fs[i:i+9])]+=1
(u/'projectie-aanroepers.json').write_text(json.dumps({'bronrapport':'docs/tests/2026-11-12-writer-actuele-invoerstaart.json','programma_sha256':r['programma_sha256'],'scriptbronnen':r['scriptbronnen'],'stackvensters':c.most_common(8),'grens':'Oudere baselineopname; overlappende stacklidmaatschappen, geen CPU-percentages of bewezen oorzaak van nieuwe kandidaat-eindlatency. Bronfragmenten koppelen de hoofdketen aan loc→displayselectieprojectie.'},ensure_ascii=False,indent=2)+'\n')
print('Exacte baselinebron bevestigt loc→displayselectieprojectie; geen nieuwe kandidaatprofilering.')
