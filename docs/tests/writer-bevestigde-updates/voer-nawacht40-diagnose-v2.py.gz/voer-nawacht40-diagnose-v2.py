from pathlib import Path
import os,subprocess,json,time
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer'
script=r/'meet-passief-nawacht-native-v2.py';tekst=json.loads((r/'doortypen-38-zonder-profiel/profiel.json').read_text())['invoertekst']
uitkomsten=[]
for naam,ms in [('nawacht2-40-controle-voor',-1),('nawacht2-40-yield-0',0),('nawacht2-40-yield-16',16),('nawacht2-40-yield-64',64),('nawacht2-40-controle-na',-1)]:
 env=os.environ.copy();env['OFFICE_PROEF_NA_RPC_MS']=str(ms);env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
 cmd=[str(repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'),str(script),'--zonder-profiel','--programma',str(r/'open-office-studio-45.40-journaal'),'--versie','2026.45.40','--bron',str(repo/'docs/tests/writer-doortypen/bron.docx'),'--paginas','129','--tekst',tekst,'--uitvoer',str(r/naam)]
 print('START',naam,flush=True);begin=time.monotonic()
 with (r/(naam+'.log')).open('w') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 uitkomsten.append({'naam':naam,'ms':ms,'code':p.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd});(r/'nawacht40-v2-uitkomsten.json').write_text(json.dumps(uitkomsten,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
