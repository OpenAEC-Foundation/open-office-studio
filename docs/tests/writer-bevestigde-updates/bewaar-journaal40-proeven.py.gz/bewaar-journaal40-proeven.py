from pathlib import Path
import gzip, hashlib, json, statistics, subprocess
from PIL import Image, ImageChops

repo=Path.cwd(); r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer'
uit=repo/'docs/tests/writer-bevestigde-updates'
sha='16cc2a57d1a283eedfc9ab008add1f18cef8345b205df8105259d8466b95eb7e'
oudsha='f25c6c3395781209f0d1760c035110c0e846f0b1e394d90860d5e8a526ccc75d'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='3ad2eb6fe9628d426213b4e75680c0c57ef88e1a'
app=json.loads((r/'journaal40-app-bronnen.json').read_text())
assert app['programma_sha256']==sha
for n,h in app['bronbestanden'].items(): assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
assert hashlib.sha256((r/'open-office-studio-45.40-journaal').read_bytes()).hexdigest()==sha
assert hashlib.sha256((r/'open-office-studio-45.39-begrensd').read_bytes()).hexdigest()==oudsha
fun=json.loads((r/'journaal40-proefuitkomsten.json').read_text()); assert len(fun)==10 and all(v['code']==0 for v in fun)
passief=json.loads((r/'journaal40-passieve-uitkomsten.json').read_text()); assert len(passief)==4 and all(v['code']==0 for v in passief)
rpc=json.loads((r/'journaal40-rpc-uitkomst.json').read_text()); assert rpc['code']==0
rust=json.loads((r/'journaal40-rustcontroles.json').read_text()); assert len(rust)==2 and all(v['code']==0 for v in rust)
for v in fun:
 d=json.loads((r/v['naam']/'rapport.json').read_text());assert d['geslaagd'] and d['programma_sha256']==sha
for v in passief:
 d=json.loads((r/v['naam']/'profiel.json').read_text());assert d['geslaagd'] and d['programma_sha256']==(sha if '-40-' in v['naam'] else oudsha)
 assert d['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True}
 assert not any(d['fouten_na'].values()) and not any(d['fouten_voor'].values())
d=json.loads((r/rpc['naam']/'profiel.json').read_text()); assert d['geslaagd'] and d['programma_sha256']==sha
assert not any(d['fouten_na'].values())
oud_docx=json.loads((r/'acht-39-begrensd/rapport.json').read_text())['onafhankelijk_docx']
nieuw_docx=json.loads((r/'acht-40-journaal/rapport.json').read_text())['onafhankelijk_docx']
assert oud_docx['exact'] and nieuw_docx['exact']
assert oud_docx['body_met_opmaak_sha256']==nieuw_docx['body_met_opmaak_sha256']=='0808d3dcf34c8251d371d9e4c6eda470ed2597acd850062b5b5f70169333a302'
assert subprocess.run(['git','diff','--quiet','HEAD','--','src','public','patches','vite.config.ts','pnpm-lock.yaml']).returncode==0
uit.mkdir(exist_ok=False)
p={'schema':1,'versie':'2026.45.40','rustwerkruimte':'2026.45.0-alpha.55','programma_sha256':sha,'referentie_sha256':oudsha,'applicatiebron':app,'bestanden':{},'functioneel':[],'passieve_metingen':[],'rust_prototype':[],'grenzen':['Eigen Linux-testomgeving met afzonderlijk profiel, DBus en Xvfb; geen algemeen platform-, FPS- of volledige suitebewijs.','64 MiB telt geserialiseerd checkpoint, bevestigde updates en onbevestigde delta; geen bovengrens voor totale heapkosten.','Geen issue of migratie-acceptatievlag gesloten. Volledige Rust-interface en suiteacceptatie blijven open.','Losse Rust-metingen zijn een afzonderlijk prototype op alpha54, vóór alleen exportregelopmaak en versieverhoging; geen definitieve desktopmeting.']}
def bewaar(bron,naam):
 data=bron.read_bytes();target=uit/naam;target.parent.mkdir(parents=True,exist_ok=True)
 if naam.endswith('.gz') and not bron.name.endswith('.gz'):data=gzip.compress(data,mtime=0)
 target.write_bytes(data);p['bestanden'][naam]=hashlib.sha256(data).hexdigest()
for v in fun:
 naam=v['naam'];d=json.loads((r/naam/'rapport.json').read_text());p['functioneel'].append({'naam':naam,'code':0,'seconden':v['seconden'],'script_sha256':d['script_sha256']})
for v in passief:
 naam=v['naam'];d=json.loads((r/naam/'profiel.json').read_text());p['passieve_metingen'].append({k:d[k] for k in ['getekende_tekst_ms','invoer_en_inspectie_ms','toetsen_verzonden_ms','broncontrole','programma_sha256','layout_na_opname'] }|{'naam':naam})
for v in [*fun,*passief,rpc]:
 naam=v['naam']
 for bron in (r/naam).rglob('*'):
  if bron.is_file() and bron.suffix in ['.json','.png','.log']:
   bewaar(bron,str(bron.relative_to(r))+('' if bron.suffix=='.png' else '.gz'))
 bewaar(r/(naam+'.log'),naam+'/proef.log.gz')
d=json.loads((r/rpc['naam']/'profiel.json').read_text());aanvragen=d['rpcmeting']['aanvragen'];p['rpc_meting']={'naam':rpc['naam'],'batches':len(aanvragen),'tekens':sum(a['tekens'] for a in aanvragen),'rust_totaal_ms':sum(a['rust_ms'] for a in aanvragen),'invoer_en_inspectie_ms':d['invoer_en_inspectie_ms'],'wachttijd_na_verzenden_ms':d['na_toetsen_verzenden_ms'],'exacte_bevestigingen':sum(a['vorig_voorstel_exact'] for a in aanvragen)}
ref=Image.open(r/passief[0]['naam']/'profiel.png').convert('RGB');raster={}
for v in passief:
 naam=v['naam'];im=Image.open(r/naam/'profiel.png').convert('RGB');assert im.size==ref.size
 diff=ImageChops.difference(ref,im);c=diff.split();mask=ImageChops.lighter(ImageChops.lighter(c[0],c[1]),c[2]);aantal=im.width*im.height-mask.histogram()[0]
 doc=mask.crop((320,208,1138,978));docpixels=doc.width*doc.height-doc.histogram()[0];zonder=mask.copy();zonder.paste(0,(491,347,496,366));dc=zonder.crop((320,208,1138,978));zonderpixels=dc.width*dc.height-dc.histogram()[0]
 raster[naam]={'pixels':aantal,'bbox':mask.getbbox(),'documentpixels':docpixels,'document_zonder_cursorpixels':zonderpixels,'sha256':hashlib.sha256((r/naam/'profiel.png').read_bytes()).hexdigest()}
p['rastervergelijking']=raster
for naam in ['journaal-oud-voor','journaal-nieuw-eerste','journaal-nieuw-tweede','journaal-oud-na','journaal-nieuw-checkpoints']:
 d=json.loads((r/(naam+'.json')).read_text());warm=d['voorbereidingen'][1:];p['rust_prototype'].append({'naam':naam,'ronden':len(d['voorbereidingen']),'warm_mediaan_ms':statistics.median(x['totaal_ns']/1e6 for x in warm),'warm_max_ms':max(x['totaal_ns']/1e6 for x in warm)});bewaar(r/(naam+'.json'),naam+'.json.gz');bewaar(r/(naam+'.log'),naam+'.log.gz')
for bron in (r/'bron-van-journaalmeetbouw').rglob('*'):
 if bron.is_file():bewaar(bron,'rust-prototype-bronnen/'+str(bron.relative_to(r/'bron-van-journaalmeetbouw'))+'.gz')
for naam in ['journaal40-app-bronnen.json','journaal40-applicatie.patch.gz','journaal40-confirmed_source.rs.gz','journaal40-proeven.json','journaal40-proefuitkomsten.json','journaal40-passieve-uitkomsten.json','journaal40-rpc-uitkomst.json','journaal40-rustcontroles.json','journaal40-rusttests.log','journaal40-clippy.log','journaal40-fmt.log','journaal40-desktopbouw.log','journaal40-weekversie.log','journaal-frontend.log','journaal-typescript.log','journaal-python.log','journaal-python-hoofd.log','journaal-bronkosten-uitkomsten.json','journaal-meetbouw.log','journaal-mengproef.log','journaal-eerste.log','journaal-tweede.log','journaal-derde.log','journaal-grenzen.log','journaal-oude-statische-cache-opruiming.json','journaal-incremental-opruiming.json','voer-journaal40-proeven.py','voer-journaal40-passieve-metingen.py','meet-passief-doortypen-native.py','meet-rpc-native.py','bewaar-journaal40-proeven.py']:
 bron=r/naam
 if bron.exists():bewaar(bron,naam+('' if naam.endswith('.gz') else '.gz'))
p['docx_behoud']={'referentie':'acht-39-begrensd','kandidaat':'acht-40-journaal','body_met_opmaak_sha256':nieuw_docx['body_met_opmaak_sha256'],'normalisatie':nieuw_docx['normalisatie'],'exact':True}
bewaar(r/'ci-39-zeven-afgesloten.json','referentie39-zeven-platformen.json.gz')
p['referentie39_zeven_edities']={'run':41881398377,'resultaat':'Linux, Windows en macOS slagen; publiceren overgeslagen. Dit betreft referentie39, geen platformacceptatie van kandidaat40.'}
p['acceptatie']='AFGEKEURD: zichtbaar typen is in beide nieuwe ronden langzamer dan de referentie; bovendien faalt een aanvullende warme revisieauteur-/celverhaalpariteitsproef. Geen geteste verbetering of vrijgegeven kandidaat.'
p['aanvullende_regressie']={'geslaagd':False,'log':'journaal40-warme-auteurs.log.gz','testbron':'warme-auteurs-regressie.rs.gz','fout':'Delta op stap 1: de warme replica gebruikt revisie-ID 21:1, de volledige reconstructie 21:0. Tellerherstel en revisie-identiteit vragen nader onderzoek; nog geen bewezen reparatie.'}
bewaar(r/'journaal40-warme-auteurs.log','journaal40-warme-auteurs.log.gz')
bewaar(repo/'native/crates/office-writer-plakken/tests/journaal.rs','warme-auteurs-regressie.rs.gz')
p['controles']={'rust_unit':30,'rust_integratie':2,'frontend':1819,'frontend_voor_uitsluitend_versieverhoging':True,'python_hoofd':77,'python_native':9,'native_functioneel':10,'passieve_rasterronden':4,'rpc_ronden':1,'clippy_writer_all_targets':True,'rustfmt_zes_ci_pakketten':True,'typescript_productiebouw':True,'productiebouw':True}
(repo/'docs/tests/2026-11-04-writer-bevestigde-updates.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
(r/'journaal40-rastervergelijking.json').write_text(json.dumps(raster,indent=2)+'\n')
print('Begrensde bevestigde updates:',len(p['bestanden']),'bewijsbestanden')
