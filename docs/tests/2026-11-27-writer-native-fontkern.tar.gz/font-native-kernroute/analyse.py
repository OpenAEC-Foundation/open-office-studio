from pathlib import Path
import json,collections,statistics
p=Path(__file__).resolve().parent;out={}
for name in ['native','herhaling']:
 d=json.loads((p/name/'rapport.json').read_text());assert d['geslaagd'];raw=d['fasen_eind'][0]['result']['result']['value'];assert raw['overgeslagen']==0
 regels=raw['regels'];kern=raw['kern'];fonts={e['id']:e for e in regels if e['soort']=='font.begin'};ends={e['id']:e for e in regels if e['soort']=='font.einde'}
 assert len(fonts)==len(ends)==len(kern) and len({x['id'] for x in kern})==len(kern);assert set(fonts)=={x['id']for x in kern}
 rows=[];totaal=collections.Counter();routes=collections.Counter()
 for x in kern:
  marks=x['marks'];assert marks[0][0]=='begin' and marks[-1][0]=='json';assert all(a[1]<=b[1] for a,b in zip(marks,marks[1:]));assert fonts[x['id']]['tijd']<=marks[0][1]<=marks[-1][1]<=ends[x['id']]['tijd']
  tijden=collections.Counter();rs=[]
  for a,b in zip(marks,marks[1:]):
   if a[0]=='story_begin':assert b[0]=='story_gereed';tijden['resident_ms']+=b[1]-a[1]
   if a[0].startswith('route_'):assert b[0]=='collect_gereed';tijden['collector_ms']+=b[1]-a[1];rs.append(a[0]);routes[a[0]]+=1
  tijden['rust_ms']=marks[-1][1]-marks[0][1];tijden['adapter_ms']=ends[x['id']]['tijd']-fonts[x['id']]['tijd'];tijden['overig_rust_ms']=tijden['rust_ms']-tijden['resident_ms']-tijden['collector_ms'];assert tijden['overig_rust_ms']>=0
  totaal.update(tijden);rows.append({'id':x['id'],'routes':rs,**tijden})
 out[name]={'fontaantal':len(kern),'routes':dict(routes),'sommen_ms':dict(totaal),'mediaan_resident_ms':statistics.median(x['resident_ms']for x in rows),'mediaan_collector_ms':statistics.median(x['collector_ms']for x in rows),'resident_aandeel_rust':totaal['resident_ms']/totaal['rust_ms'],'vensters':rows,'grens':'Verstreken geïnstrumenteerde tijd; geen CPU-cycli, gewone ABBA of fix. Cachemiss-route bewijst niet dat ieder blok intern volledig opnieuw wordt opgebouwd.'}
(p/'analyse.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({n:{k:v for k,v in x.items()if k!='vensters'}for n,x in out.items()},ensure_ascii=False))
