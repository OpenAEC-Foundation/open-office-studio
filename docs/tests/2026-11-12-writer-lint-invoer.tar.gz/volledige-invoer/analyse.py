from pathlib import Path
import collections,gzip,hashlib,json,statistics
u=Path(__file__).resolve().parent;p=u/'opname';r=json.loads((p/'rapport.json').read_text());assert r['geslaagd'] and not any(r['fouten'].values());assert r['schema']==2 and r['bewaarde_tabellen_exact']==128;assert r['programma_sha256']=='8d67e9e495008f7dd7542082214410b0f5322c459bfcf297eccd8d31fa76f567'
t=r['publicatietijdlijn'];assert t['hersteld'] and not t['overgeslagen'];rows=t['regels'];counts=collections.Counter(x['soort'] for x in rows);assert counts['applyLocalUpdate']==counts['onUpdate']==len(r['nativefasen']['monsters'])==115
final=r['lange_invoer']['laatste_keyup_ms']+r['lange_invoer']['laatste_keyup_tot_frame_ms'];start=final-r['lange_invoer']['begin_tot_frame_ms'];first=min(x['begin'] for x in rows if x['soort']=='keydown');assert r['profiel_begin_klok']<=start<=first
frames=[x['begin'] for x in rows if x['soort']=='rAF' and start<=x['begin']<=final];gaps=[b-a for a,b in zip(frames,frames[1:])]
durations={}
for naam in ['applyLocalUpdate','setSelection','tablePayload','readParagraphs','readStories']:
 a=[x['einde']-x['begin'] for x in rows if x['soort']==naam];durations[naam]={'aanroepen':len(a),'som_ms':sum(a),'mediaan_ms':statistics.median(a),'max_ms':max(a)}
ev=json.load(gzip.open(p/'profielen.json.gz','rt'));klaar=[e for e in ev if e.get('method')=='ScriptProfiler.trackingComplete'];assert len(klaar)==1;samples=klaar[0]['params']['samples']['stackTraces'];assert len(samples)==r['profiel_samples'];timestamps=collections.Counter(x.get('timestamp') for x in samples)
bronnen={}
for b in r['scriptbronnen']:
 data=gzip.decompress((p/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256'];bronnen[b['url']]=data.decode()
# Bind het echte pad uit dezelfde stack, zodat gelijknamige closures niet worden verward.
getrect=[s for s in samples if s['stackFrames'] and s['stackFrames'][0]['name']=='getClientRects'];assert getrect
pad=getrect[0]['stackFrames'];assert [f['name'] for f in pad[:4]]==['getClientRects','Bse','ee','ne'];lintframes=pad[1:4];context=[]
for f in lintframes:
 line=bronnen[f['url']].split('\n')[f['line']-1];i=f['column']-1;context.append({'frame':f,'bron':line[max(0,i-70):i+1100]})
assert 'function Bse(e)' in context[0]['bron'] and 'getClientRects' in context[0]['bron'];assert 'F10' in context[2]['bron'] and 'F1' in context[2]['bron'];assert 'te.defaultPrevented||!ee()' in context[2]['bron']
leden=collections.Counter()
for s in samples:
 namen={f['name'] for f in s['stackFrames']}
 for naam in ['buildStory','storySegmentUnitDigests','tablePayload','targetAt','wasm-stub']:
  if naam in namen:leden[naam]+=1
 if any(f['name']=='dee' and 'editors-' in f.get('url','') for f in s['stackFrames']):leden['TabelGrepen']+=1
 if s in getrect:leden['getClientRects_lintpad']+=1
uit={'basis_elf':r['programma_sha256'],'functionaliteit_geslaagd':True,'invoer':r['lange_invoer'],'profileert_voor_fysieke_dispatch':True,'profiel_begin_performance_ms':r['profiel_begin_klok'],'afgeleide_invoerbegin_ms':start,'eerste_keydown_ms':first,'profiel_eind_performance_ms':r['profiel_eind_klok'],'samples':len(samples),'sampletijdstempels':dict(timestamps),'geen_sampletijdlijn_koppelbaar':set(timestamps)=={0},'bronmutaties_en_lezingen':durations,'tijdlijnregels':len(rows),'telling':dict(counts),'raf_callbackpauzes_ms':{'aantal':len(gaps),'max':max(gaps),'mediaan':statistics.median(gaps)},'stacklidmaatschap':dict(leden),'lint_bronbinding':context,'scriptbronnen':r['scriptbronnen'],'grenzen':['Sampler-/probetiming is beïnvloed; deze ene ronde is geen prestatieacceptatie.','Samples hebben allemaal tijdstempel0. Geen fictieve millisecondenkoppeling of CPU-percentages; stacklidmaatschappen overlappen.','Probe-opruimen/exporteren en inspectie rond stoppen vallen deels binnen profielvenster, na het terminale frame.','rAF-callbackpauzes meten kansen op callbacks, niet fysieke paint/FPS.','De probe-observer leest alleen klokken en herkomst, geen extra engineversie/selectie/document.']}
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:uit[k] for k in ['samples','telling','bronmutaties_en_lezingen','raf_callbackpauzes_ms','stacklidmaatschap']},ensure_ascii=False,indent=2))
