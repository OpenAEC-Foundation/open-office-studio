from pathlib import Path
import json,os,subprocess,time
r=Path.cwd();u=r/'.local/integratiecontrole/lint-invoer';eind=time.monotonic()+1200
while not (u/'actief.json').exists():
 assert time.monotonic()<eind;time.sleep(1)
while True:
 a=json.loads((u/'actief.json').read_text())
 if a['status']=='native_bouw_klaar':break
 if a['status']=='native_bouw_afgewezen':raise RuntimeError('Eigen native bouw afgewezen')
 assert time.monotonic()<eind;time.sleep(1)
b=json.loads((u/'desktop.json').read_text());assert b['code']==0;env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];env['OFFICE_LINT_GEEN_METING']='1'
python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python';c=[python,str(u/'proef-lint.py'),'--programma',b['programma'],'--versie','2026.45.52','--uitvoer',str(u/'kandidaat-lint')]
with (u/'kandidaat-lint.log').open('x') as log:p=subprocess.run(c,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450)
d=json.loads((u/'kandidaat-lint/rapport.json').read_text());assert p.returncode==0 and d['geslaagd'] and d['lintmetingen_gewone_invoer']==0,(p.returncode,d.get('fout'));print('Lint native: nul gewone toetsmetingen; F10/Alt/CtrlF1/verborgen/modaal groen',flush=True)
env.pop('OFFICE_LINT_GEEN_METING');p=subprocess.run(['python3',str(u/'native-rondes.py')],env=env,timeout=1500);raise SystemExit(p.returncode)
