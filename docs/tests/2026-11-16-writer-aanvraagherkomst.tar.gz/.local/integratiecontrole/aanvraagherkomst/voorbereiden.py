from pathlib import Path
import hashlib,json,py_compile
r=Path.cwd();p=r/'.local/integratiecontrole/aanvraagherkomst';base=r/'.local/integratiecontrole/context-profiel/native-profiel.py';s=base.read_text()
a=s.index('    from gui.webkit_inspector import Inspector as BasisInspector');b=s.index('    a.uitvoer.mkdir',a);s=s[:a]+'    from gui.webkit_inspector import Inspector\n'+s[b:]
a=s.index("                r['worker_enable']");b=s.index("                invoer =",a);s=s[:a]+"                r['aanvraagprobe_begin'] = await p.ev((REPO / '.local/integratiecontrole/aanvraagherkomst/probe.js').read_text())\n"+s[b:]
a=s.index("                r['profiel_eind_klok']");b=s.index("                r['nativefasen']",a)
print('verwijderblok einde',s[b:b+100]);s=s[:a]+"                r['aanvraagprobe'] = await p.ev('_aanvraagProbe.stop()')\n                assert r['aanvraagprobe']['restored'] and not r['aanvraagprobe']['errors'] and r['aanvraagprobe']['overflow']==0\n"+s[b:]
assert 'ScriptProfiler.' not in s and 'Debugger.'not in s
(p/'native-aanvragen.py').write_text(s);py_compile.compile(str(p/'native-aanvragen.py'),doraise=True)
(p/'bronpinnen.json').write_text(json.dumps({'basis_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256(s.encode()).hexdigest(),'probe_sha256':hashlib.sha256((p/'probe.js').read_bytes()).hexdigest(),'grens':'Alleen bestaande Worker.postMessage omhuld tijdens lange invoer;geen nieuw programma,Debugger of profiler. Volledige gewone functieharnas blijft.'},indent=2)+'\n')
