from pathlib import Path
import hashlib,json,sys
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from PIL import Image,ImageChops
r=Path.cwd();p=Path(__file__).resolve().parent;naam=sys.argv[1]if len(sys.argv)>1 else 'native-twee';d=p/naam;report=json.loads((d/'rapport.json').read_text());f=d/'Ontwerpnotitie.docx';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert sha(f)==report['bewaring_sha256'];parts={}
with ZipFile(f)as z:
 assert z.testzip()is None
 for name in z.namelist():
  data=z.read(name)
  if name.endswith(('.xml','.rels')):ET.fromstring(data)
  parts[name]=hashlib.sha256(data).hexdigest()
 xml=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(xml.findall('.//w:tbl',ns));text=''.join(n.text or''for n in xml.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2
assert tables==128 and units==91423
old=r/'.local/integratiecontrole/projectie-context/native-rijk-b-twee';before={}
with ZipFile(old/'Ontwerpnotitie.docx')as z:
 before={n:hashlib.sha256(z.read(n)).hexdigest()for n in z.namelist()}
assert set(before)==set(parts);changed=[n for n in parts if before[n]!=parts[n]];assert set(changed)<={'docProps/core.xml'}
pixels=[]
for name in ['invoer-redo.png','snel-getypt-bewaard.png','nieuw-na-laat-antwoord.png']:
 a=Image.open(old/name).convert('RGB');b=Image.open(d/name).convert('RGB');assert a.size==b.size;diff=ImageChops.difference(a,b);bbox=diff.getbbox();count=0 if bbox is None else sum(any(c)for c in diff.crop(bbox).getdata());pixels.append({'bestand':name,'verschillende_pixels':count,'bbox':bbox})
result={'docx_sha256':sha(f),'tabellen':tables,'utf16':units,'zip_crc_xml_relaties_groen':True,'pakketverschil_met_eerdere_context_kandidaat':changed,'part_hashes':parts,'beelden':pixels,'grens':'Drie vaste beelden tegenover eerdere ongeinstrumenteerde contextkandidaat; geen volledige visuele/platformacceptatie.'};(p/f'documentcontrole-{naam}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['tabellen','utf16','pakketverschil_met_eerdere_context_kandidaat','beelden']}))
