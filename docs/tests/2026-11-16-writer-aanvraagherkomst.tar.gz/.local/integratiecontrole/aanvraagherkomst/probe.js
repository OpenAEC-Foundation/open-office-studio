(() => {
  const proto = Worker.prototype, descriptor = Object.getOwnPropertyDescriptor(proto, 'postMessage');
  if (!descriptor || typeof descriptor.value !== 'function') throw Error('Geen originele Worker.postMessage');
  const original = descriptor.value, workers = new Map(), events = [], strings = [], stringIds = new Map(), errors = [];
  let bytes = 0, overflow = 0, active = true, phase = 'lange-invoer';
  const intern = value => {
    if (stringIds.has(value)) return stringIds.get(value);
    if (bytes + value.length * 2 > 8 * 1024 * 1024) { overflow++; return null; }
    const id = strings.length; strings.push(value); stringIds.set(value, id); bytes += value.length * 2; return id;
  };
  const summary = (value, depth = 0) => {
    if (value == null || typeof value === 'number' || typeof value === 'boolean') return value;
    if (typeof value === 'string') return { string: intern(value), length: value.length };
    if (ArrayBuffer.isView(value) || value instanceof ArrayBuffer) return { binary: value.constructor.name, bytes: value.byteLength };
    if (depth > 3) return { keys: Object.keys(value).slice(0, 40) };
    if (Array.isArray(value)) return value.length <= 16 ? value.map(v => summary(v, depth + 1)) : { array: value.length };
    if (typeof value === 'object') return Object.fromEntries(Object.entries(value).slice(0, 60).map(([k,v]) => [k, summary(v, depth + 1)]));
    return typeof value;
  };
  const add = event => { if (events.length < 20000) events.push(event); else overflow++; };
  function tracked(...args) {
    if (active) try {
      let worker = workers.get(this);
      if (!worker) {
        worker = { id: workers.size + 1, listener: null };
        worker.listener = event => { if (active) try { const m = event.data; add({ direction: 'antwoord', worker: worker.id, phase, time: performance.now(), id: m?.id, type: m?.type, ok: m?.ok, keys: m && typeof m === 'object' ? Object.keys(m) : [], version: summary(m?.version) }); } catch(e) { errors.push(String(e)); } };
        this.addEventListener('message', worker.listener); workers.set(this, worker);
      }
      const m = args[0];
      add({ direction: 'aanvraag', worker: worker.id, phase, time: performance.now(), id: m?.id, type: m?.type, sourceVersion: typeof sessie === 'function' ? sessie()?.version() : null, stack: intern(new Error().stack ?? ''), message: summary(m) });
    } catch(e) { errors.push(String(e)); }
    return Reflect.apply(original, this, args);
  }
  Object.defineProperty(proto, 'postMessage', { ...descriptor, value: tracked });
  const apiRestores = [];
  const publicApi = typeof api === 'function' ? api() : null;
  for (const name of ['save', 'flushPendingInput']) {
    const desc = publicApi && Object.getOwnPropertyDescriptor(publicApi, name);
    if (!desc || typeof desc.value !== 'function' || !desc.configurable) continue;
    const value = desc.value;
    function observed(...args) {
      if (active) try { add({ direction: 'api', phase, time: performance.now(), type: name, stack: intern(new Error().stack ?? '') }); } catch(e) { errors.push(String(e)); }
      return Reflect.apply(value, this, args);
    }
    Object.defineProperty(publicApi, name, { ...desc, value: observed });
    apiRestores.push(() => { if(publicApi[name] !== observed) throw Error('API omhulling gewijzigd'); Object.defineProperty(publicApi, name, desc); });
  }
  window._aanvraagProbe = {
    phase: value => { phase = value; },
    stop: () => {
      active = false; const untouched = proto.postMessage === tracked;
      if (untouched) Object.defineProperty(proto, 'postMessage', descriptor);
      for (const restore of apiRestores) restore();
      for (const [worker, state] of workers) worker.removeEventListener('message', state.listener);
      return { events, strings, errors, overflow, bytes, workers: workers.size, api_wrappers: apiRestores.length, restored: untouched && proto.postMessage === original };
    }
  };
  return { installed: true };
})()
