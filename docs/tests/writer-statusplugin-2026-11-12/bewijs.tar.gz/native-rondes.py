from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/status-plugin';python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python';env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
limiet=time.monotonic()+1500
while not (u/'desktop.json').exists():
 assert time.monotonic()<limiet,'Bouw niet binnen begrensde tijd gereed';time.sleep(1)
b=json.loads((u/'desktop.json').read_text());assert b['code']==0,b
pinnen=json.loads((u/'bronpinnen.json').read_text());oud=r/'.local/integratiecontrole/status-telling/open-office-studio-status-telling';nieuw=Path(b['programma']);assert sha(oud)=='d9ae4803d2ae7085d6d530a35631277460b1c73df2232cd67fe65541907c9157' and sha(nieuw)==b['programma_sha256']
uit={}
for soort,helper in [('klein',r/'.local/integratiecontrole/adaptieve-invoer/kleine-invoer.py'),('rijk',r/'.local/integratiecontrole/status-telling/proef.py')]:
 for naam,exe in [('oud-a',oud),('nieuw-a',nieuw),('nieuw-b',nieuw),('oud-b',oud)]:
  assert pinnen=={p:sha(r/p) for p in pinnen};n=soort+'-'+naam
  with (u/(n+'.log')).open('x') as log:
   c=subprocess.run([python,str(helper),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(u/n)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450)
  rapport=json.loads((u/n/'rapport.json').read_text());assert c.returncode==0 and rapport['geslaagd'],(n,c.returncode,rapport.get('fout'))
  uit[n]={'geslaagd':True,'invoer':rapport['lange_invoer'],'programma_sha256':rapport['programma_sha256'],'uitlezingen':len(rapport.get('uitlezingen',{}).get('regels',[]))}
  (u/'rondes.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print(n,uit[n]['invoer']['wall_begin_tot_frame_ms'],uit[n]['invoer']['laatste_keyup_tot_frame_ms'],flush=True)
print('Acht volledige native scenario’s geslaagd; geen automatische snelheidsacceptatie.',flush=True)
