from pathlib import Path
import hashlib, io, json, tarfile
r = Path.cwd(); p = r / '.local/integratiecontrole/projectie-context-telling-herbouw'; out = r / 'docs/tests'
label = '2026-11-16-writer-projectietelling-native'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
assert read('desktop.json')['code'] == 0 and read('native/rapport.json')['geslaagd']
assert read('analyse.json')['nul_verlies_fouten'] and read('paarcontrole.json')['elk_een_bouw_en_een_hergebruik']
files = [f for f in sorted(p.rglob('*')) if f.is_file()
         and not set(f.relative_to(p).parts) & {'dist', '__pycache__', 'standaarddist'}
         and not f.name.startswith('open-office-studio')]
manifest = {str(f.relative_to(p)): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in files}
archive = out / (label + '.tar.gz')
with tarfile.open(archive, 'w:gz') as t:
    for f in files: t.add(f, arcname=str(f.relative_to(p)), recursive=False)
    b = (json.dumps(manifest, indent=2) + '\n').encode(); info = tarfile.TarInfo('manifest.json'); info.size = len(b)
    t.addfile(info, io.BytesIO(b))
with tarfile.open(archive) as t:
    assert set(t.getnames()) == set(manifest) | {'manifest.json'}
    for n, v in manifest.items():
        b = t.extractfile(n).read(); assert len(b) == v['bytes'] and hashlib.sha256(b).hexdigest() == v['sha256']
report = {
    'datum': '2026-11-16', 'basis_integratie': '9c0afc7d', 'basis_hoofdbranch': '207e4f00',
    'productbron': '41e7000198f89d992e1059e9715636a44b39d21a',
    'besluit': 'Native hergebruik op de gecorrigeerde private kandidaat bevestigd:80809huidigehits,67extra hergebruikshits,67bouwpaden. Alle67nieuwe bronversies krijgen precies één bouwpad en één hergebruikshit. Geen logverlies/fouten of onverklaarde afwijzingen. Een niet-gebruikte hergebruikroute verklaart de resterende vertraging niet; dit meet geen tijdwinst of volledige latencyoorzaak.',
    'herbouwbasis': read('herbouwbasis.json'), 'native_bouw': read('desktop.json'),
    'herstel': read('actief.json'), 'bundel': read('bundel.json'),
    'analyse': read('analyse.json'), 'bronparen': read('paarcontrole.json'),
    'native_functie': read('native/rapport.json'), 'document': read('documentcontrole.json'),
    'beeldbeoordeling': read('beeldbeoordeling.json'), 'behoud': read('behoud.json'),
    'grenzen': [
        'Zelfde meetbundel als bewaarde afgebroken poging,byteexact gecontroleerd;afzonderlijke nieuwe uitvoer/logmap. Start3446972416vrije bytes,minimum3337658368bytes;3GiBstopvloer niet bereikt. Alleen eigen appcrate gebouwd,vorige afbreking behouden.',
        'Drie normale JS-meetpunten in bestaande callback,geen hoofdthread-Debugger/ScriptProfiler. Telt geldige sessie/storyvragen na oorspronkelijke vroege afwijzing. Elke bouwmeting leest bronversie aanvullend;huidigehits/hergebruik niet. Voorbereidende collector/orakelproeven staan in vorige bewijsbundel.',
        '80943gemeten geldige vragen,269verliesloze groepen,nul errors/overflow. Bevestigde API-sessie en alle gemeten sessies dezelfde identiteit1,generatie1,rootbody,segmentbron3. Worker/gereed waar,opening/preview/disposed onwaar. Alle67bouwafwijzingen uitsluitend bronversiewijziging;geen sessie/generatie/segmentbron/gereedheidsafwijzing.',
        '68broncontexten:eerste al opgewarmd,67nieuwe versies met elk1bouw/1hergebruik. Geen aanvullende bronstaat/hash of volledige projectie per native tussenstap vastgelegd;bronversie en contextidentiteiten wel. Componentpariteit staat afzonderlijk vast.',
        'Eén instrumenteerde native Linux-functieronde inclusief lange fysieke invoer,Undo/Redo,selectie/bewaren/verwerpen en laat antwoord groen. Geen nieuwe normale ABBA of snelheidsacceptatie. Meetoverhead en aanvullende versielezingen beïnvloeden de ruwe klok;geen profiler-CPUtijden afgeleid.',
        'DOCX onafhankelijk SHA/ZIP/CRC/XML/relaties gecontroleerd:128tabellen/91423UTF16;tegenover eerdere ongeinstrumenteerde contextkandidaat uitsluitend core.xmlverschil. Drie beeldparen hebben28/30/36verschillende pixels;bewaarbeeld bekeken met verschil opcaret. Geen volledige visuele acceptatie.'
    ],
    'niet_gecontroleerd': ['Geen productwijziging,volledige frontend/TypeScript/Python-suite of product-CI.',
                           'Geen Windows/macOS/installer/andere editie/feature/schema/release/volledige IME/accessibility/documentdekking.',
                           'Geen geheugen-/RefCell-foutfix of issue-/migratievoltooiing.'],
    'vervolg': 'Gebruik de al bewaarde ongeinstrumenteerde ee89c80e-contextkandidaat voor één begrensd actueel hoofdthread-/documentworkerprofiel van de volledige rijke invoerperiode,zonder nieuwe ELF-bouw of hoofdthread-Debugger. Onderscheid segmentrefresh/volledige projectie/digestplanning,bronpublicatie/layout/tekenen en de staart;wijs geen CPUduur toe aan aantallen alleen. De native hergebruikroute is nu bevestigd,dus geen nieuwe cachevariant om een vermeende ongebruikte route te repareren. Bewaak schijfruimte en behoud27referenties/standaardbundel. Pas een gerichte wijziging ontwerpen na actueel kostbewijs;R(k) apart,Database laatst.',
    'afhankelijkheden': [{'pad': 'docs/tests/' + n, 'sha256': sha(out / n)} for n in [
        '2026-11-16-writer-projectieteller-bouwruimte.tar.gz', '2026-11-16-writer-projectie-context.tar.gz']],
    'bewijs': {'pad': str(archive.relative_to(r)), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
               'bestanden': len(files), 'alle_leden_byteexact_gecontroleerd': True,
               'uitsluiting': 'Geen ELF/Wasm/dist. Wel herbouw/bronpinnen,collector/native/analyse/document-scripts,verliesloze tellingen,functierapport,DOCX/PNG/logs en27referentiepinnen.'}
}
(out / (label + '.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['bewijs']))
