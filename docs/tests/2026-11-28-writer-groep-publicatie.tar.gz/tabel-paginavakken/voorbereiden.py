from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/tabel-paginavakken';shutil.copytree(p.parent/'greep-toestand/dist',p/'dist');rows=[]
changes={
'index-BtjjFW78.js':[
('let c=t(s.docStart);if(c==null)continue;let u=a.get(s.table.tableId);(!u||s.docStart<u.docStartSample)&&a.set(s.table.tableId,{tableKey:c,docStartSample:s.docStart})','let u=a.get(s.table.tableId);if(n.pageIndex!==undefined&&u&&s.docStart>=u.docStartSample)continue;let c=t(s.docStart);if(c==null)continue;(!u||s.docStart<u.docStartSample)&&a.set(s.table.tableId,{tableKey:c,docStartSample:s.docStart})'),
('let o=[],i=kE(e,n,r);for(let s of e.pages){let c=wE(s,r);','let o=[],i=kE(e,n,r);for(let s of e.pages){if(r.pageIndex!==undefined&&s.pageIndex!==r.pageIndex)continue;let c=wE(s,r);')],
'editors-hz_Qg-1B.js':[
('Dw(VJ(l,m.pageIndex),b,p).filter','Dw(VJ(l,m.pageIndex),b,p,globalThis.__OOS_PAGINAVAKKEN__?{kind:"body",pageIndex:m.pageIndex}:undefined).filter')]}
for name,pairs in changes.items():
 f=p/'dist/assets'/name;s=f.read_text();before=hashlib.sha256(f.read_bytes()).hexdigest()
 for old,new in pairs:
  assert s.count(old)==1,(name,old,s.count(old));s=s.replace(old,new)
 f.write_text(s);subprocess.run(['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--check',str(f)],check=True);rows.append({'bestand':name,'voor':before,'na':hashlib.sha256(f.read_bytes()).hexdigest(),'ankers':pairs})
(p/'bundel.json').write_text(json.dumps(rows,indent=2)+'\n')
