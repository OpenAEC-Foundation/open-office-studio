from pathlib import Path
import json,hashlib,tarfile,stat,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/tabel-paginavakken';dirs=['groep-publicatie','greep-toestand','tabel-ankerminimum','tabel-paginavakken'];base=p.parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
old=json.loads((base/'json-native/referenties-nacontrole.json').read_text());assert all(sha(Path(f))==v for f,v in old.items());refs=dict(old)
for d in dirs:
 for f in(base/d).glob('open-office-studio-*'):
  if f.is_file():refs[str(f)]=sha(f)
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
standard=json.loads((base/'projectie-context-telling-herbouw/standaardbundel.json').read_text());assert set(standard)=={str(f.relative_to(r/'dist'))for f in(r/'dist').rglob('*')if f.is_file()}
for name,expect in standard.items():
 f=r/'dist'/name;v={'sha256':sha(f),'mode':stat.S_IMODE(f.stat().st_mode),'mtime_ns':f.stat().st_mtime_ns};assert v==expect,(name,v,expect)
(p/'behoud.json').write_text(json.dumps({'bestaande_ELF_referenties':len(old),'alle_ELF_referenties':len(refs),'exact':True,'standaardbundel_bestanden':len(standard),'byte_mode_mtime_exact':True},indent=2)+'\n')
files=[]
for d in dirs:
 for f in(base/d).rglob('*'):
  rel=f.relative_to(base/d)
  if any(x in {'dist','sdk','__pycache__'}or x.startswith('target-')for x in rel.parts):continue
  if f.is_file()and f.suffix in {'.json','.py','.js','.mjs','.log','.gz','.png','.docx','.patch'}and f.name not in {'bewijs.py','manifest.json','archief.json'}:files.append(f)
for name in ['font-rij-native/proef-rijk.py','context-profiel/native-profiel.py']:
 files.append(base/name)
manifest=[{'pad':str(f.relative_to(base)),'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(set(files))];(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(p/'manifest.json');files.append(p/'bewijs.py')
out=r/'docs/tests/2026-11-28-writer-groep-publicatie.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz',compresslevel=6)as tar:
 for f in sorted(set(files)):tar.add(f,arcname=str(f.relative_to(base)),recursive=False)
print(json.dumps({'archief':str(out.relative_to(r)),'bytes':out.stat().st_size,'sha256':sha(out),'bestanden':len(set(files)),'referenties':len(refs),'standaardbundel':len(standard)},indent=2))
