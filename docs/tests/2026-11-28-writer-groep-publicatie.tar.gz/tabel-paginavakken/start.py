from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/tabel-paginavakken';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';exe=p/'open-office-studio-groep-proef';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};rows=[]
while not exe.exists():time.sleep(10)
for label,flag in [('a',False),('b',True)]:
 cmd=['/usr/bin/python3',str(p/'proef.py'),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/label)];start=time.monotonic();print('START',label,flush=True)
 with(p/(label+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env={**env,'OFFICE_TEST_PAGINAVAKKEN':'1'if flag else'0'},stdout=log,stderr=subprocess.STDOUT)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-start),flush=True)
 d=json.loads((p/label/'rapport.json').read_text());assert d['paginavakken']==flag
 renders=[x for x in d['groepmeting']['rows']if x['name']=='tabel_grepen_render'];row={'label':label,'flag':flag,'code':proc.returncode,'geslaagd':d['geslaagd'],'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'render_aantal':len(renders),'render_ms':sum(x['end']-x['start']for x in renders),'invoer':d['lange_invoer']};rows.append(row);(p/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',json.dumps(row),flush=True);assert proc.returncode==0 and d['geslaagd']
