from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/groep-publicatie';dist=p/'dist';source=p.parent/'digest-spans/dist-kandidaat';shutil.copytree(source,dist);f=dist/'assets/editors-hz_Qg-1B.js';s=f.read_text();original=s
assert '__oosGroepProbe'not in s
# Alleen eigen diagnostische kopie, met exacte ankers uit de geteste bundel.
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
replace('let Je=async(kt,Yt=[pe,pe])=>{let Mt=ct(),bn=Mt?h(Mt.anchor.story):null;', 'let Je=async(kt,Yt=[pe,pe])=>{const __oosGroup=__oosGroepProbe.group(kt.length,Yt);try{let Mt=__oosGroepProbe.sync("selectie",()=>ct()),bn=Mt?__oosGroepProbe.sync("projectie",()=>h(Mt.anchor.story)):null;')
replace('let vn=Kf(Mt,bn),Wn=', 'let vn=__oosGroepProbe.sync("bereik",()=>Kf(Mt,bn)),Wn=')
replace('const Rn=await W(c,Mt.head,kt,en(),()=>re(c),Yt);', '__oosGroepProbe.point("provider_begin",__oosGroup);const Rn=await W(c,Mt.head,kt,en(),()=>re(c),Yt);__oosGroepProbe.point("provider_einde",__oosGroup);')
replace('sn()};if(Te&&o){','sn()}finally{__oosGroepProbe.groupEnd(__oosGroup)}};if(Te&&o){')
# Synchrone publicatie en wachtrij-ingang; bestaande functiebody blijft heel.
for begin,end,name,extra in [('Ft=u.useCallback((ne=!1,pe=!1,Te)=>{', '},[At,$,R,pn]),In=u.useCallback', 'publicatie',''),('Fe=u.useCallback((ne,pe="selection",Te,Je,Ke=pe==="mutation")=>{','},[re,Vn,t,o,ue,zn,c,ke]),Ve=u.useCallback','wachtrij_ingang','__oosGroepProbe.queue(G.current);'),('ze=u.useCallback((ne,pe,Te=!1)=>{','},[W,T,se,Fe,ct,Ft,In,ae,h,re,f,t,o,c,en]),lt=u.useCallback','invoer_callback','')]:
 assert s.count(begin)==1 and s.count(end)==1
 a=s.index(begin)+len(begin);b=s.index(end,a);body=s[a:b];s=s[:a]+f'const __oosSync=__oosGroepProbe.begin("{name}");try{{'+extra+body+'}finally{__oosGroepProbe.end(__oosSync)}'+s[b:]
replace('R(Te),At(!0,ne,pe)', 'R(Te),__oosGroepProbe.sync("publicatie_notificatie",()=>At(!0,ne,pe))')
s=(p/'probe.js').read_text()+'\n'+s;f.write_text(s);(p/'frontend.patch').write_text(subprocess.run(['diff','-u',str(source/f.relative_to(dist)),str(f)],capture_output=True,text=True).stdout);node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';res=subprocess.run([node,'--check',str(f)],capture_output=True,text=True);(p/'syntax.log').write_text(res.stdout+res.stderr);print('SYNTAX',res.returncode,res.stderr[:800]);assert res.returncode==0
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();before={str(q.relative_to(source)):sha(q)for q in source.rglob('*')if q.is_file()};after={str(q.relative_to(dist)):sha(q)for q in dist.rglob('*')if q.is_file()};changed=[f for f in before if before[f]!=after[f]];assert changed==['assets/editors-hz_Qg-1B.js'];(p/'bundel.json').write_text(json.dumps({'bestanden':len(after),'gewijzigd':changed,'basis':before[changed[0]],'diagnose':after[changed[0]],'syntax_code':res.returncode},indent=2)+'\n')
