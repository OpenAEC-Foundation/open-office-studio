from pathlib import Path
import json,statistics
p=Path(__file__).resolve().parent;result=[]
for label in ['a','b']:
 d=json.loads((p/label/'rapport.json').read_text());m=d['groepmeting'];rows=m['rows'];assert not m['dropped']and not m['pendingSync']and not m['currentGroup']and all(m['restored']);assert len(rows)<m['limit'];starts={x['group']:x for x in rows if x['name']=='groep_begin'};ends={x['group']:x for x in rows if x['name']=='groep_einde'};pb={x['group']:x for x in rows if x['name']=='provider_begin'};pe={x['group']:x for x in rows if x['name']=='provider_einde'};assert set(starts)==set(ends)==set(pb)==set(pe);assert sum(x['size']for x in starts.values())==1052
 sync={x['id']:x for x in rows if 'start'in x and'end'in x};children={}
 for x in sync.values():
  if x['parent']in sync:children[x['parent']]=children.get(x['parent'],0)+(x['end']-x['start'])
 cats={}
 for x in sync.values():
  c=cats.setdefault(x['name'],{'aantal':0,'inclusief_ms':0,'exclusief_ms':0,'max_ms':0});dt=x['end']-x['start'];c['aantal']+=1;c['inclusief_ms']+=dt;c['exclusief_ms']+=dt-children.get(x['id'],0);c['max_ms']=max(c['max_ms'],dt)
 tasks={x['id']:{'start':x['at'],'queued':x['queued']}for x in rows if x['name']=='wachtrij_start'}
 for x in rows:
  if x['name']=='wachtrij_einde':tasks[x['id']]['end']=x['at'];assert x['ok']
 groups=[]
 for id,start in starts.items():
  a=start['at'];b=ends[id]['at'];matches=[(i,t)for i,t in tasks.items()if t['start']<=a+1e-8 and t.get('end',float('-inf'))>=b-1e-8];assert len(matches)==1,(label,id,matches);qid,t=matches[0];groups.append({'id':id,'tekens':start['size'],'begin':a,'einde':b,'voor_provider_ms':pb[id]['at']-a,'provider_ms':pe[id]['at']-pb[id]['at'],'na_provider_ms':b-pe[id]['at'],'wachtrij_id':qid,'voor_groep_in_taak_ms':a-t['start'],'na_groep_in_taak_ms':t['end']-b,'wachttijd_voor_taak_ms':t['start']-t['queued'],'invoer_ouderdom_ms':m['origin']+a-start['inputFirst']})
 groups.sort(key=lambda g:g['begin']);native=d['nativefasen']['monsters'];assert len(native)==len(groups);assert [len(x['text'])for x in d['native_opdrachten'][:len(native)]]==[x['tekens']for x in groups]
 phases={k:sum(x[k]for x in groups)for k in ['voor_provider_ms','provider_ms','na_provider_ms','voor_groep_in_taak_ms','na_groep_in_taak_ms']};frames=[x['at']for x in rows if x['name']=='frame'];gaps=[b-a for a,b in zip(frames,frames[1:])];row={'label':label,'geslaagd':d['geslaagd'],'programma_sha256':d['programma_sha256'],'records':len(rows),'herstel':m['restored'],'groepen':len(groups),'fasen_totaal_ms':phases,'synchrone_categorieen':cats,'invoer':d['lange_invoer'],'framegap_max_ms':max(gaps,default=0),'framegaps_boven_50ms':sum(x>50 for x in gaps),'groepsgegevens':groups};result.append(row)
(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for r in result:print(json.dumps({k:v for k,v in r.items()if k not in ['groepsgegevens','invoer']},ensure_ascii=False,indent=2))
