from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/groep-publicatie';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};rows=[]
while not(p/'open-office-studio-groep-b').exists():time.sleep(10)
for label in ['a','b']:
 exe=p/('open-office-studio-groep-'+label);cmd=['/usr/bin/python3',str(p/'proef-render.py'),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/('render-'+label))];start=time.monotonic();print('START',label,flush=True)
 with(p/('render-'+label+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-start),flush=True)
 d=json.loads((p/('render-'+label)/'rapport.json').read_text())if(p/('render-'+label)/'rapport.json').exists()else{};rows.append({'label':label,'code':proc.returncode,'geslaagd':d.get('geslaagd',False),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'seconden':time.monotonic()-start});(p/'render-runs.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',json.dumps(rows[-1]),flush=True);assert proc.returncode==0 and d['geslaagd']
