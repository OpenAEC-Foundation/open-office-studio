(()=>{
 const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)throw Error('Geen eigen editor');const targets=new Map,inventory=[];const session=sessie();
 for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return){
  let role=null;
  if(f.memoizedProps?.session===session&&typeof f.memoizedProps?.inputPositionMap==='function'&&typeof f.memoizedProps?.onStateChange==='function')role='invoer';
  for(let h=f.memoizedState,n=0;h&&n++<1500;h=h.next)for(const v of[h.memoizedState,h.memoizedState?.current])if(v?.displayList?.pages&&v?.queries?.sourceState)role='hoofd';
  if(!role)continue;const type=f.type;inventory.push({role,tag:f.tag,type:typeof type,keys:type&&Object.keys(type),render:typeof type?.render});if(type&&typeof type.render==='function')targets.set(type,role);
 }
 if(!targets.size)throw Error('Geen bestaande forwardRef-rendering gevonden');const restores=[];
 for(const[type,role]of targets){const original=type.render,descriptor=Object.getOwnPropertyDescriptor(type,'render');if(!descriptor?.writable)throw Error('Renderfunctie niet tijdelijk meetbaar');const wrapper=function(...args){const x=__OOS_GROEPMETING__.begin('react_render_'+role);try{return Reflect.apply(original,this,args)}finally{__OOS_GROEPMETING__.end(x)}};type.render=wrapper;restores.push(()=>{if(type.render!==wrapper)return false;Object.defineProperty(type,'render',descriptor);return type.render===original});}
 window._oosRenderStop=()=>{const result=restores.reverse().map(fn=>fn());delete window._oosRenderStop;return result};return {inventory,wrapped:targets.size};
})()
