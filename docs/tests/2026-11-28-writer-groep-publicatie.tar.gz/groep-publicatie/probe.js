const __oosGroepProbe=(()=>{
 let active=false,origin=0,sequence=0,currentGroup=0,dropped=0,frame=0;
 const limit=32768,rows=[],stack=[],restores=[],seen=new WeakSet();
 const now=()=>performance.now()-origin;
 const put=row=>{if(rows.length<limit)rows.push(row);else dropped++};
 const api={
  begin(name,size){if(!active)return null;const x={id:++sequence,name,size,group:currentGroup,parent:stack.at(-1)?.id??null,start:now()};stack.push(x);return x},
  end(x){if(!x)return;if(active)put({...x,end:now()});const index=stack.lastIndexOf(x);if(index>=0)stack.splice(index,1)},
  sync(name,fn){const x=api.begin(name);try{return fn()}finally{api.end(x)}},
  group(size,times){if(!active)return 0;const id=++sequence;currentGroup=id;put({id,name:'groep_begin',group:id,size,inputFirst:times?.[0],inputLast:times?.[1],at:now()});return id},
  groupEnd(id){if(!id)return;if(active)put({name:'groep_einde',group:id,at:now()});if(currentGroup===id)currentGroup=0},
  point(name,id){if(active)put({name,group:id,at:now()})},
  queue(q){if(!active||!q||seen.has(q))return;const original=q.enqueue,descriptor=Object.getOwnPropertyDescriptor(q,'enqueue');if(typeof original!=='function')throw Error('Geen invoerwachtrij');seen.add(q);
   const wrapper=function(fn,...args){if(!active)return Reflect.apply(original,this,[fn,...args]);const id=++sequence,queued=now();put({id,name:'wachtrij_aanbod',at:queued});const task=function(...parameters){const start=now();put({id,name:'wachtrij_start',at:start,queued});let result;try{result=Reflect.apply(fn,this,parameters)}catch(error){put({id,name:'wachtrij_einde',at:now(),ok:false});throw error}if(result&&typeof result.then==='function')result.then(()=>{if(active)put({id,name:'wachtrij_einde',at:now(),ok:true})},()=>{if(active)put({id,name:'wachtrij_einde',at:now(),ok:false})});else put({id,name:'wachtrij_einde',at:now(),ok:true});return result};return Reflect.apply(original,this,[task,...args])};
   Object.defineProperty(q,'enqueue',{value:wrapper,writable:true,configurable:true,enumerable:descriptor?.enumerable??false});restores.push(()=>{if(q.enqueue!==wrapper)return false;if(descriptor)Object.defineProperty(q,'enqueue',descriptor);else delete q.enqueue;return q.enqueue===original});
  },
  start(){if(active||restores.length)throw Error('Groepmeting reeds actief');origin=performance.now();active=true;sequence=0;currentGroup=0;dropped=0;rows.length=0;stack.length=0;const tick=t=>{if(!active)return;put({name:'frame',at:now(),stamp:t-origin});frame=requestAnimationFrame(tick)};frame=requestAnimationFrame(tick);return {origin,limit}},
  stop(){active=false;cancelAnimationFrame(frame);const restored=restores.splice(0).reverse().map(f=>f());return {rows,dropped,limit,restored,pendingSync:stack.length,currentGroup,origin}}
 };globalThis.__OOS_GROEPMETING__=api;return api;
})();
