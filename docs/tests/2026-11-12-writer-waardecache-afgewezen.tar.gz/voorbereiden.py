from pathlib import Path
import json,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/waardecache';p=r/'native/vendor/docx-edit/src/deterministic.rs';s=p.read_text();s=s[:s.index('\n#[cfg(test)]\nmod tests')];s=s.replace('mod sorteringproeven;','#[path="'+str(r/'native/vendor/docx-edit/src/deterministic/sorteringproeven.rs')+'"]\nmod sorteringproeven;')
s=s.replace('pub(crate) struct DeterministicEncoderV1(EncoderV1);',"pub(crate) struct DeterministicEncoderV1<'a>(EncoderV1, Option<&'a mut WaardeCache>);")
s=s.replace('impl DeterministicEncoderV1 {',"impl<'a> DeterministicEncoderV1<'a> {").replace('Self(EncoderV1::new())','Self(EncoderV1::new(), None)').replace('impl Write for DeterministicEncoderV1 {',"impl Write for DeterministicEncoderV1<'_> {").replace('impl Encoder for DeterministicEncoderV1 {',"impl Encoder for DeterministicEncoderV1<'_> {")
a='''    fn write_any(&mut self, any: &Any) {
        encode_any(any, self);
    }

    fn write_json(&mut self, any: &Any) {
        self.write_string(&serde_json::to_string(&json_value(any)).unwrap());
    }''';b='''    fn write_any(&mut self, any: &Any) {
        if let Some(cache) = self.1.as_deref_mut() {
            if let Some(bytes) = cache.lees(any, false) { self.0.write_all(&bytes); return; }
        }
        encode_any(any, self);
    }

    fn write_json(&mut self, any: &Any) {
        if let Some(cache) = self.1.as_deref_mut() {
            if let Some(bytes) = cache.lees(any, true) { self.0.write_all(&bytes); return; }
        }
        self.write_string(&serde_json::to_string(&json_value(any)).unwrap());
    }''';assert s.count(a)==1;s=s.replace(a,b)
s+='''
/// Alleen canonieke waarde-encoderingen. De sterke Any houdt de onveranderlijke
/// Arc levend; pointerhergebruik of copy-on-write kan geen andere inhoud raken.
/// Begrensde gecodeerde bytes/regels zijn geen grens voor de gehele native heap.
#[derive(Default)]
pub(crate) struct WaardeCache {
    regels: std::collections::HashMap<(u8, usize), (Any, std::sync::Arc<[u8]>)>,
    pub bytes: usize,
    pub raak: usize,
    pub mis: usize,
    pub vol: usize,
}
impl WaardeCache {
    fn lees(&mut self, any: &Any, json: bool) -> Option<std::sync::Arc<[u8]>> {
        use std::sync::Arc;
        let (soort, ptr) = match any {
            Any::Map(v) => (0, Arc::as_ptr(v) as *const () as usize),
            Any::Array(v) => (1, Arc::as_ptr(v) as *const () as usize),
            Any::Buffer(v) => (2, Arc::as_ptr(v) as *const () as usize),
            _ => return None,
        };
        let sleutel = (soort + if json { 4 } else { 0 }, ptr);
        if let Some((_, bytes)) = self.regels.get(&sleutel) {
            self.raak += 1; return Some(bytes.clone());
        }
        self.mis += 1;
        let mut e = EncoderV1::new();
        if json { e.write_string(&serde_json::to_string(&json_value(any)).unwrap()); }
        else { encode_any(any, &mut e); }
        let bytes: Arc<[u8]> = e.to_vec().into();
        if self.regels.len() < 4096 && bytes.len() <= 8 * 1024 * 1024 - self.bytes {
            self.bytes += bytes.len();
            self.regels.insert(sleutel, (any.clone(), bytes.clone()));
        } else { self.vol += 1; }
        Some(bytes)
    }
}
pub(crate) fn encode_state_cached<T: ReadTxn>(txn: &T, cache: &mut WaardeCache) -> Vec<u8> {
    if txn.store().pending_update().is_some() || txn.store().pending_ds().is_some() {
        return encode_state_as_update_v1(txn, &StateVector::default());
    }
    let mut e = DeterministicEncoderV1(EncoderV1::new(), Some(cache));
    txn.encode_state_as_update(&StateVector::default(), &mut e);
    e.to_vec()
}
'''
(u/'deterministic-cache.rs').write_text(s);(u/'deterministic-origineel.rs').write_bytes(p.read_bytes());(u/'pinnen.json').write_text(json.dumps({'basis':__import__('subprocess').check_output(['git','rev-parse','HEAD'],text=True).strip(),'bron':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'kandidaat_sha256':hashlib.sha256(s.encode()).hexdigest()},indent=2))
