from pathlib import Path
import json,hashlib,collections,subprocess
from zipfile import ZipFile
from xml.etree import ElementTree as E
from PIL import Image,ImageChops
r=Path.cwd();u=r/'.local/integratiecontrole/waardecache';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=json.loads((u/'native-rondes.json').read_text());out={};ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
for n,v in cases.items():
 p=u/n;d=json.loads((p/'rapport.json').read_text());doc=p/'Ontwerpnotitie.docx'
 with ZipFile(doc) as z:
  assert z.testzip() is None;x=E.fromstring(z.read('word/document.xml'))
 text=''.join(e.text or '' for e in x.findall('.//w:t',ns));tables=len(x.findall('.//w:tbl',ns));assert tables==(128 if n.startswith('rijk') else 1)
 assert sha(doc)==d['bewaring_sha256'];a={'docx_sha256':sha(doc),'tabellen':tables,'tekens_utf16':len(text.encode('utf-16-le'))//2,'invoer':v['invoer'],'geheugen':v['geheugen'],'geslaagd':True,'stappen':d['stappen']}
 if 'nativefasen' in d:
  m=d['nativefasen']['monsters'];assert not d['nativefasen']['overgeslagen'];a.update(groepen=len(m),rust_binnen_ms=sum(x['rustBinnenMs'] for x in m),duursom_ms=sum(x['duurMs'] for x in m),fasen_ms={k:sum(x['stappen'].get(k,0) for x in m) for k in ['bron','hash','transport','mutatie','selectie']})
 if 'uitlezingen' in d:a['lezingen']=dict(collections.Counter(x['naam'] for x in d['uitlezingen']['regels']));assert d['uitlezingen']['hersteld'] and not d['uitlezingen']['overgeslagen']
 out[n]=a
pixels=[];packages=[]
for soort in ['klein','rijk']:
 for suffix in ['a','b']:
  ref=u/(soort+'-referentie-'+suffix);cand=u/(soort+'-kandidaat-'+suffix)
  for p in cand.glob('*.png'):
   a=Image.open(ref/p.name).convert('RGB');b=Image.open(p).convert('RGB');assert a.size==b.size;diff=ImageChops.difference(a,b);pixels.append({'soort':soort,'paar':suffix,'beeld':p.name,'afwijkende_pixels':sum(px!=(0,0,0) for px in diff.getdata()),'bbox':diff.getbbox()})
  with ZipFile(ref/'Ontwerpnotitie.docx') as a,ZipFile(cand/'Ontwerpnotitie.docx') as b:
   assert set(a.namelist())==set(b.namelist());anders=[n for n in a.namelist() if a.read(n)!=b.read(n)];packages.append({'soort':soort,'paar':suffix,'onderdelen':len(a.namelist()),'verschillen':anders})
# Oude referenties en alle eerdere afwijzingen blijven bestaan.
refs=json.loads((r/'.local/integratiecontrole/hostfasen/referenties-nacontrole.json').read_text())
for n,h in refs.items():assert sha(Path(n))==h
assert sha(Path(json.loads((u/'desktop.json').read_text())['programma']))==json.loads((u/'desktop.json').read_text())['programma_sha256']
std=json.loads((u/'standaardbundel.json').read_text());assert std=={str(p.relative_to(r/'dist')):{'sha256':sha(p),'mode':p.stat().st_mode&0o777,'mtime_ns':p.stat().st_mtime_ns} for p in (r/'dist').rglob('*') if p.is_file()}
idx=r/'node_modules/@betteroffice/docx-react/dist/index.mjs';sdk=sha(idx)
assert sdk=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
result={'native':out,'beelden':pixels,'docx_vergelijking':packages,'referenties_exact':len(refs),'prototype_elf_exact':True,'standaarddist_exact':len(std),'sdk_index_sha256':sdk,'productboom_schoon':not subprocess.check_output(['git','status','--porcelain'])};(u/'nacontrole.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'native':{n:{k:v.get(k) for k in ['groepen','rust_binnen_ms','lezingen','tekens_utf16']} for n,v in out.items()},'docx':packages,'pixels':pixels},ensure_ascii=False,indent=2))
