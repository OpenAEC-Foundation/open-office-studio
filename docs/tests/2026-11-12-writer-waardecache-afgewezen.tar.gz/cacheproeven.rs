use super::*;
use std::{collections::HashMap, sync::Arc};
fn waarde(v: &str) -> Any {
    Any::Map(Arc::new(HashMap::from([("tekst".into(), Any::from(v))])))
}
fn bytes(v: &Any, json: bool) -> Vec<u8> {
    let mut e = DeterministicEncoderV1::new();
    if json {
        e.write_json(v)
    } else {
        e.write_any(v)
    };
    e.to_vec()
}
#[test]
fn sterke_eigenaar_voorkomt_pointerhergebruik_en_copy_on_write_treft_nieuwe_bytes() {
    let mut cache = WaardeCache::default();
    let mut oud = waarde("oud");
    let clone = oud.clone();
    for json in [false, true] {
        assert_eq!(&*cache.lees(&oud, json).unwrap(), bytes(&oud, json));
        assert_eq!(&*cache.lees(&clone, json).unwrap(), bytes(&clone, json));
    }
    assert_eq!(cache.raak, 2);
    assert_eq!(cache.mis, 2);
    let oude_ptr = match &oud {
        Any::Map(v) => Arc::as_ptr(v),
        _ => unreachable!(),
    };
    if let Any::Map(v) = &mut oud {
        Arc::make_mut(v).insert("tekst".into(), Any::from("nieuw 😀"));
        assert_ne!(Arc::as_ptr(v), oude_ptr)
    }
    for json in [false, true] {
        assert_ne!(bytes(&oud, json), bytes(&clone, json));
        assert_eq!(&*cache.lees(&oud, json).unwrap(), bytes(&oud, json));
        assert_eq!(&*cache.lees(&clone, json).unwrap(), bytes(&clone, json));
    }
    assert_eq!(cache.raak, 4);
    assert_eq!(cache.mis, 4);
}
#[test]
fn gelijke_inhoud_op_andere_arc_is_een_misser_en_verhalen_delen_geen_cache() {
    let a = waarde("zelfde");
    let b = waarde("zelfde");
    let mut cache = WaardeCache::default();
    assert_eq!(
        cache.lees(&a, false).unwrap(),
        cache.lees(&b, false).unwrap()
    );
    assert_eq!(cache.mis, 2);
    assert_eq!(cache.raak, 0);
    let mut ander = WaardeCache::default();
    ander.lees(&a, false);
    assert_eq!(ander.mis, 1);
    assert_eq!(ander.raak, 0);
}
#[test]
fn oude_waarde_komt_vrij_bij_einde_cache() {
    let Any::Map(arc) = waarde("tijdelijk") else {
        unreachable!()
    };
    let zwak = Arc::downgrade(&arc);
    let mut cache = WaardeCache::default();
    cache.lees(&Any::Map(arc), false);
    assert!(zwak.upgrade().is_some());
    drop(cache);
    assert!(zwak.upgrade().is_none());
}
#[test]
fn volle_regelgrens_codeert_correct_zonder_onbegrensd_te_bewaren() {
    let mut cache = WaardeCache::default();
    for i in 0..16400 {
        let a = waarde(&i.to_string());
        assert_eq!(&*cache.lees(&a, false).unwrap(), bytes(&a, false));
    }
    assert_eq!(cache.regels.len(), 16384);
    assert_eq!(cache.vol, 16);
    assert!(cache.bytes <= 8 * 1024 * 1024);
}
#[test]
fn te_grote_waarde_en_scalair_blijven_correct_zonder_cacheopname() {
    let mut cache = WaardeCache::default();
    let a = Any::Buffer(Arc::from(vec![1u8; 8 * 1024 * 1024]));
    assert_eq!(&*cache.lees(&a, false).unwrap(), bytes(&a, false));
    assert_eq!(cache.bytes, 0);
    assert!(cache.regels.is_empty());
    assert_eq!(cache.vol, 1);
    assert!(cache.lees(&Any::from("los"), false).is_none());
}
#[test]
fn pending_bron_gebruikt_ongewijzigde_oude_codec() {
    use yrs::{Transact, updates::decoder::Decode};
    let doc = docx_edit::EditingDoc::new(7);
    doc.create_story("body", "abc", "Normal", "left").unwrap();
    let vector = doc.encode_state_vector_v1();
    doc.insert_text(
        &docx_edit::EditCtx::local("", ""),
        docx_edit::Position::new("body", 1),
        "X",
        docx_edit::FormatPolicy::Inherit,
    )
    .unwrap();
    let pending = docx_edit::EditingDoc::new(8);
    let delta = doc.encode_diff_v1(&vector).unwrap();
    pending
        .yrs_doc()
        .transact_mut()
        .apply_update(yrs::Update::decode_v1(&delta).unwrap())
        .unwrap();
    assert!(pending.holds_pending_update());
    let mut cache = WaardeCache::default();
    assert_eq!(
        encode_state_cached(&pending.yrs_doc().transact(), &mut cache),
        pending.encode_state_as_update_v1()
    );
    assert!(cache.regels.is_empty());
}
