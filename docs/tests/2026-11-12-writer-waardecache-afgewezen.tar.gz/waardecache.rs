use super::{DeterministicEncoderV1, encode_any, encode_state_as_update_v1, json_value};
use yrs::encoding::write::Write;
use yrs::{
    Any, ReadTxn, StateVector,
    updates::encoder::{Encoder, EncoderV1},
};

/// Alleen canonieke waarde-encoderingen. De sterke Any houdt de onveranderlijke
/// Arc levend; pointerhergebruik of copy-on-write kan geen andere inhoud raken.
/// Begrensde gecodeerde bytes/regels zijn geen grens voor de gehele native heap.
#[derive(Default)]
pub(crate) struct WaardeCache {
    regels: std::collections::HashMap<(u8, usize, usize), (Any, std::sync::Arc<[u8]>)>,
    bytes: usize,
    #[cfg(test)]
    raak: usize,
    #[cfg(test)]
    mis: usize,
    #[cfg(test)]
    vol: usize,
}
impl WaardeCache {
    pub(super) fn lees(&mut self, any: &Any, json: bool) -> Option<std::sync::Arc<[u8]>> {
        use std::sync::Arc;
        let (soort, ptr, lengte) = match any {
            Any::Map(v) => (0, Arc::as_ptr(v) as *const () as usize, v.len()),
            Any::Array(v) => (1, Arc::as_ptr(v) as *const () as usize, v.len()),
            Any::Buffer(v) => (2, Arc::as_ptr(v) as *const () as usize, v.len()),
            _ => return None,
        };
        let sleutel = (soort + if json { 4 } else { 0 }, ptr, lengte);
        if let Some((_, bytes)) = self.regels.get(&sleutel) {
            #[cfg(test)]
            {
                self.raak += 1;
            }
            return Some(bytes.clone());
        }
        #[cfg(test)]
        {
            self.mis += 1;
        }
        let mut e = EncoderV1::new();
        if json {
            e.write_string(&serde_json::to_string(&json_value(any)).unwrap());
        } else {
            encode_any(any, &mut e);
        }
        let bytes: Arc<[u8]> = e.to_vec().into();
        if self.regels.len() < 16384 && bytes.len() <= 8 * 1024 * 1024 - self.bytes {
            self.bytes += bytes.len();
            self.regels.insert(sleutel, (any.clone(), bytes.clone()));
        } else {
            #[cfg(test)]
            {
                self.vol += 1;
            }
        }
        Some(bytes)
    }
}
pub(crate) fn encode_state_cached<T: ReadTxn>(txn: &T, cache: &mut WaardeCache) -> Vec<u8> {
    if txn.store().pending_update().is_some() || txn.store().pending_ds().is_some() {
        return encode_state_as_update_v1(txn, &StateVector::default());
    }
    let mut e = DeterministicEncoderV1(EncoderV1::new(), Some(cache));
    txn.encode_state_as_update(&StateVector::default(), &mut e);
    e.to_vec()
}

#[cfg(test)]
#[path = "cached_gouden.rs"]
mod cached_gouden;
#[cfg(test)]
#[path = "cacheproeven.rs"]
mod cacheproeven;
