//! Bevestigde bronbytes en een strikt daarvan gescheiden, nog onbevestigd voorstel.
use office_writer_plakken::{Antwoord, MAX_SNAPSHOT_BYTES, snapshot_sha256};
use base64::{Engine as _, engine::general_purpose::STANDARD};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct IncrementeleTekstAanvraag {
    /// Schema 2: snapshot is volledig zonder basis, anders een delta tegen die basis.
    pub schema: u8,
    pub basis: Option<String>,
    pub request_id: String,
    pub document_id: String,
    pub source_version: String,
    pub source_vector: String,
    pub snapshot_sha256: String,
    pub snapshot: String,
    pub client_id: u64,
    pub position: office_writer_plakken::Cursor,
    pub text: String,
    pub author: Option<office_writer_plakken::Auteur>,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct IncrementeelAntwoord {
    pub resultaat: Antwoord,
    /// Identificeert uitsluitend de geïmporteerde bron, vóór het voorstel.
    pub basis: String,
    pub bronvector: String,
}

/// Deze spiegel leeft uitsluitend op zijn eigen documentwerker. De nog
/// onbevestigde replica vervangt nooit de bewaarde bevestigde bronbytes.
#[derive(Default)]
pub struct BronSpiegel {
    bron: Option<BevestigdeBron>,
    voorstel: Option<docx_edit::PreparedClipboardReplica>,
    voorstel_bytes: usize,
    #[cfg(test)]
    hergebruikt: bool,
}

struct BevestigdeBron {
    document_id: String,
    client_id: u64,
    basis: String,
    snapshot: Vec<u8>,
}

impl BronSpiegel {
    pub fn bytes(&self) -> usize {
        self.bron
            .as_ref()
            .map_or(0, |b| b.snapshot.len())
            .saturating_add(if self.voorstel.is_some() {
                self.voorstel_bytes
            } else {
                0
            })
    }

    /// None vraagt expliciet om een volledige bron. Ongeldige of onvolledige
    /// gegevens en mislukte bewerkingen veranderen de bevestigde spiegel niet.
    pub fn bereid_voor(
        &mut self,
        a: IncrementeleTekstAanvraag,
    ) -> Result<Option<IncrementeelAntwoord>, String> {
        crate::markeer("start");
        if a.schema != 2 {
            return Err("Onbekend schema voor incrementele Writer-invoer".into());
        }
        let p = a;
        if p.text.is_empty() || p.text.contains(['\r', '\n']) {
            return Err(
                "Gewone Writer-tekst moet niet leeg zijn en mag geen alineagrens bevatten".into(),
            );
        }
        if p.request_id.is_empty()
            || p.document_id.is_empty()
            || p.source_version.is_empty()
            || p.client_id > 9_007_199_254_740_991
        {
            return Err("De document- of bronbinding van de Writer-invoer ontbreekt".into());
        }
        if p.snapshot.len() > MAX_SNAPSHOT_BYTES.div_ceil(3) * 4 {
            return Err("De incrementele Writer-bron is te groot".into());
        }
        let bytes = STANDARD
            .decode(&p.snapshot)
            .map_err(|_| "De Writer-bron is geen geldige base64")?;
        if bytes.is_empty()
            || bytes.len() > MAX_SNAPSHOT_BYTES
            || snapshot_sha256(&bytes) != p.snapshot_sha256
        {
            return Err("De incrementele Writer-bron wijkt af van de opgegeven gegevens".into());
        }
        crate::markeer("decode_hash");
        let oud = if let Some(basis) = p.basis {
            let Some(oud) = self.bron.as_ref().filter(|b| {
                b.basis == basis && b.document_id == p.document_id && b.client_id == p.client_id
            }) else {
                return Ok(None);
            };
            Some(oud.snapshot.as_slice())
        } else {
            None
        };
        let vector = STANDARD
            .decode(&p.source_vector)
            .map_err(|_| "De Writer-bronvector is geen geldige base64")?;
        let ctx = if let Some(auteur) = &p.author {
            docx_edit::EditCtx::local(&auteur.name, &auteur.date).suggesting()
        } else {
            docx_edit::EditCtx::local("", "")
        };
        crate::markeer("binding");
        let begin = std::time::Instant::now();
        let loc = docx_edit::Loc::new(&p.position.story, &p.position.para_id, p.position.offset);
        let r = docx_edit::prepare_confirmed_clipboard_fragment_cached(
            self.voorstel.take(),
            oud,
            &bytes,
            p.client_id,
            &vector,
            &docx_edit::LocRange {
                start: loc.clone(),
                end: loc,
            },
            &serde_json::json!({"paragraphs":[{"text":p.text}]}),
            &ctx,
            MAX_SNAPSHOT_BYTES,
        )
        .map_err(|e| e.to_string())?;
        #[cfg(test)]
        {
            self.hergebruikt = r.reused;
        }
        crate::markeer("kern");
        self.voorstel_bytes = r.batch.update.len();
        self.voorstel = Some(r.replica);
        let snapshot = r.snapshot;
        let basis = snapshot_sha256(&snapshot);
        crate::markeer("bevestigingshash");
        let bronvector = p.source_vector;
        let resultaat = Antwoord {
            schema: 1,
            request_id: p.request_id,
            document_id: p.document_id.clone(),
            source_version: p.source_version,
            snapshot_sha256: p.snapshot_sha256,
            client_id: p.client_id,
            delta: STANDARD.encode(r.batch.update),
            caret: office_writer_plakken::Cursor {
                story: r.batch.caret.story,
                para_id: r.batch.caret.para,
                offset: r.batch.caret.offset,
            },
            preparation_ms: begin.elapsed().as_millis().try_into().unwrap_or(u64::MAX),
        };
        self.bron = Some(BevestigdeBron {
            document_id: p.document_id,
            client_id: p.client_id,
            basis: basis.clone(),
            snapshot,
        });
        crate::markeer("antwoord");
        Ok(Some(IncrementeelAntwoord {
            resultaat,
            basis,
            bronvector,
        }))
    }
}
