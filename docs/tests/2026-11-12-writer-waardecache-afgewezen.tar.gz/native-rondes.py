from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/waardecache';python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python';env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
eind=time.monotonic()+1200
while True:
 a=json.loads((u/'actief.json').read_text())
 if a['status']=='native_bouw_klaar':break
 if a['status']=='native_bouw_afgewezen':raise RuntimeError('Eigen native bouw afgewezen')
 assert time.monotonic()<eind,'Eigen bouw niet binnen20min gereed'
 time.sleep(1)
b=json.loads((u/'desktop.json').read_text());assert b['code']==0;bestaand=r/'.local/integratiecontrole/bewaarprojectie-ci/open-office-studio-ci-statusfout';nieuw=Path(b['programma']);assert sha(bestaand)=='8d67e9e495008f7dd7542082214410b0f5322c459bfcf297eccd8d31fa76f567' and sha(nieuw)==b['programma_sha256'];pinnen=json.loads((u/'bronpinnen.json').read_text());uit={}
for soort in ['klein','rijk']:
 for naam,exe in [('referentie-a',bestaand),('kandidaat-a',nieuw),('kandidaat-b',nieuw),('referentie-b',bestaand)]:
  assert pinnen=={p:sha(r/p) for p in pinnen};n=soort+'-'+naam;c=[python,str(u/('proef-'+soort+'.py')),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(u/n)]
  print('START',n,flush=True)
  with (u/(n+'.log')).open('x') as log:p=subprocess.run(c,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450)
  rapport=json.loads((u/n/'rapport.json').read_text());uit[n]={'code':p.returncode,'geslaagd':rapport['geslaagd'],'invoer':rapport.get('lange_invoer'),'geheugen':rapport.get('nativegeheugen'),'programma_sha256':rapport['programma_sha256'],'opdracht':c,'helper_sha256':sha(u/('proef-'+soort+'.py'))};(u/'native-rondes.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print('EINDE',n,json.dumps(uit[n]['invoer']),flush=True)
  assert p.returncode==0 and rapport['geslaagd'],(n,p.returncode,rapport.get('fout'))
