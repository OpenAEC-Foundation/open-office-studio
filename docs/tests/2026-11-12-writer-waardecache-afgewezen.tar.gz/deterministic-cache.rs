use std::collections::BTreeMap;

use serde_json::{Map, Number, Value};
use yrs::any::{F64_MAX_SAFE_INTEGER, F64_MIN_SAFE_INTEGER};
use yrs::block::{BLOCK_GC_REF_NUMBER, BLOCK_ITEM_DELETED_REF_NUMBER, HAS_PARENT_SUB};
use yrs::encoding::write::Write;
use yrs::updates::decoder::Decode;
use yrs::updates::encoder::{Encode, Encoder, EncoderV1};
use yrs::{Any, ClientID, ID, ReadTxn, StateVector, Update};

pub(crate) struct DeterministicEncoderV1<'a>(EncoderV1, Option<&'a mut WaardeCache>);

impl<'a> DeterministicEncoderV1<'a> {
    fn new() -> Self {
        Self(EncoderV1::new(), None)
    }
}

impl Write for DeterministicEncoderV1<'_> {
    fn write_all(&mut self, buf: &[u8]) {
        self.0.write_all(buf);
    }

    fn write_u8(&mut self, value: u8) {
        self.0.write_u8(value);
    }
}

impl Encoder for DeterministicEncoderV1<'_> {
    fn to_vec(self) -> Vec<u8> {
        self.0.to_vec()
    }

    fn reset_ds_cur_val(&mut self) {
        self.0.reset_ds_cur_val();
    }

    fn write_ds_clock(&mut self, clock: u32) {
        self.0.write_ds_clock(clock);
    }

    fn write_ds_len(&mut self, len: u32) {
        self.0.write_ds_len(len);
    }

    fn write_left_id(&mut self, id: &ID) {
        self.0.write_left_id(id);
    }

    fn write_right_id(&mut self, id: &ID) {
        self.0.write_right_id(id);
    }

    fn write_client(&mut self, client: ClientID) {
        self.0.write_client(client);
    }

    fn write_info(&mut self, info: u8) {
        self.0.write_info(info);
    }

    fn write_parent_info(&mut self, is_y_key: bool) {
        self.0.write_parent_info(is_y_key);
    }

    fn write_type_ref(&mut self, info: u8) {
        self.0.write_type_ref(info);
    }

    fn write_len(&mut self, len: u32) {
        self.0.write_len(len);
    }

    fn write_any(&mut self, any: &Any) {
        if let Some(cache) = self.1.as_deref_mut() {
            if let Some(bytes) = cache.lees(any, false) { self.0.write_all(&bytes); return; }
        }
        encode_any(any, self);
    }

    fn write_json(&mut self, any: &Any) {
        if let Some(cache) = self.1.as_deref_mut() {
            if let Some(bytes) = cache.lees(any, true) { self.0.write_all(&bytes); return; }
        }
        self.write_string(&serde_json::to_string(&json_value(any)).unwrap());
    }

    fn write_key(&mut self, string: &str) {
        self.0.write_key(string);
    }
}

#[derive(Default)]
struct CountingEncoderV1 {
    len: usize,
    info: u8,
    unstable_json: bool,
    root_sequence: bool,
    tombstone_len: u64,
    deleted_len: u64,
}

impl Write for CountingEncoderV1 {
    fn write_all(&mut self, buf: &[u8]) {
        self.len += buf.len();
    }

    fn write_u8(&mut self, _: u8) {
        self.len += 1;
    }
}

impl Encoder for CountingEncoderV1 {
    fn to_vec(self) -> Vec<u8> {
        unreachable!("a counting encoder has no byte buffer")
    }

    fn reset_ds_cur_val(&mut self) {}

    fn write_ds_clock(&mut self, clock: u32) {
        self.write_var(clock);
    }

    fn write_ds_len(&mut self, len: u32) {
        self.deleted_len += u64::from(len);
        self.write_var(len);
    }

    fn write_left_id(&mut self, id: &ID) {
        self.write_var(id.client.get());
        self.write_var(id.clock);
    }

    fn write_right_id(&mut self, id: &ID) {
        self.write_left_id(id);
    }

    fn write_client(&mut self, client: ClientID) {
        self.write_var(client.get());
    }

    fn write_info(&mut self, info: u8) {
        self.info = info;
        self.write_u8(info);
    }

    fn write_parent_info(&mut self, is_y_key: bool) {
        self.root_sequence |= is_y_key && self.info & HAS_PARENT_SUB == 0;
        self.write_var(u32::from(is_y_key));
    }

    fn write_type_ref(&mut self, info: u8) {
        self.write_u8(info);
    }

    fn write_len(&mut self, len: u32) {
        if self.info == BLOCK_GC_REF_NUMBER || self.info & 0x1F == BLOCK_ITEM_DELETED_REF_NUMBER {
            self.tombstone_len += u64::from(len);
        }
        self.write_var(len);
    }

    fn write_any(&mut self, any: &Any) {
        encode_any(any, self);
    }

    fn write_json(&mut self, any: &Any) {
        let json = serde_json::to_string(&json_value(any)).unwrap();
        self.write_string(&json);
        if !self.unstable_json && !json_stable_fast(any) && !json_stable(any, &json) {
            self.unstable_json = true;
        }
    }

    fn write_key(&mut self, key: &str) {
        self.write_string(key);
    }
}

/// Returns None for pending data, unstable JSON values, root sequence content, or deleted content
/// a fork would collect; a fork that `keeps_deleted`, as one of a replica with an undo history
/// does, collects none.
pub(crate) fn fork_state_len_v1<T: ReadTxn>(txn: &T, keeps_deleted: bool) -> Option<usize> {
    let store = txn.store();
    if store.pending_update().is_some() || store.pending_ds().is_some() {
        return None;
    }
    let mut encoder = CountingEncoderV1::default();
    txn.encode_state_as_update(&StateVector::default(), &mut encoder);
    (!encoder.unstable_json
        && !encoder.root_sequence
        && (keeps_deleted || encoder.tombstone_len == encoder.deleted_len))
        .then_some(encoder.len)
}

pub(crate) fn encode_state_as_update_v1<T: ReadTxn>(
    txn: &T,
    state_vector: &StateVector,
) -> Vec<u8> {
    let integrated = encode_state(txn, state_vector);
    let store = txn.store();
    if store.pending_update().is_none() && store.pending_ds().is_none() {
        return integrated;
    }

    let mut updates = vec![Update::decode_v1(&integrated).unwrap()];
    if let Some(pending) = store.pending_update() {
        let mut encoder = DeterministicEncoderV1::new();
        pending.update.encode(&mut encoder);
        updates.push(Update::decode_v1(&encoder.to_vec()).unwrap());
    }
    if let Some(pending) = store.pending_ds() {
        let mut encoder = DeterministicEncoderV1::new();
        encoder.write_var(0_u32);
        pending.encode(&mut encoder);
        updates.push(Update::decode_v1(&encoder.to_vec()).unwrap());
    }

    let merged = Update::merge_updates(updates);
    let mut encoder = DeterministicEncoderV1::new();
    merged.encode(&mut encoder);
    encoder.to_vec()
}

pub(crate) fn encode_diff_v1<T: ReadTxn>(txn: &T, state_vector: &StateVector) -> Vec<u8> {
    let mut encoder = DeterministicEncoderV1::new();
    txn.encode_diff(state_vector, &mut encoder);
    encoder.to_vec()
}

fn encode_state<T: ReadTxn>(txn: &T, state_vector: &StateVector) -> Vec<u8> {
    let mut encoder = DeterministicEncoderV1::new();
    txn.encode_state_as_update(state_vector, &mut encoder);
    encoder.to_vec()
}

fn encode_any<W: Write>(any: &Any, encoder: &mut W) {
    match any {
        Any::Undefined => encoder.write_u8(127),
        Any::Null => encoder.write_u8(126),
        Any::Bool(value) => encoder.write_u8(if *value { 120 } else { 121 }),
        Any::String(value) => {
            encoder.write_u8(119);
            encoder.write_string(value);
        }
        Any::Number(value) => {
            let truncated = value.trunc();
            if truncated == *value
                && (F64_MIN_SAFE_INTEGER..=F64_MAX_SAFE_INTEGER).contains(&truncated)
            {
                encoder.write_u8(125);
                encoder.write_var(truncated as i64);
            } else if ((*value as f32) as f64) == *value {
                encoder.write_u8(124);
                encoder.write_f32(*value as f32);
            } else {
                encoder.write_u8(123);
                encoder.write_f64(*value);
            }
        }
        Any::BigInt(value) => {
            encoder.write_u8(122);
            encoder.write_i64(*value);
        }
        Any::Array(values) => {
            encoder.write_u8(117);
            encoder.write_var(values.len() as u64);
            for value in values.iter() {
                encode_any(value, encoder);
            }
        }
        Any::Map(values) => {
            encoder.write_u8(118);
            encoder.write_var(values.len() as u64);
            let sorted: BTreeMap<_, _> = values.iter().collect();
            for (key, value) in sorted {
                encoder.write_string(key);
                encode_any(value, encoder);
            }
        }
        Any::Buffer(value) => {
            encoder.write_u8(116);
            encoder.write_buf(value);
        }
    }
}

fn json_stable_fast(any: &Any) -> bool {
    json_stable_fast_at(any, 0)
}

fn json_stable_fast_at(any: &Any, depth: usize) -> bool {
    match any {
        Any::Null | Any::Bool(_) => true,
        Any::String(value) => value
            .chars()
            .all(|ch| !ch.is_control() && ch != '"' && ch != '\\'),
        Any::Number(value) => {
            value.abs() < 2_147_483_648.0
                && value.trunc() == *value
                && (*value != 0.0 || !value.is_sign_negative())
        }
        Any::Array(values) => {
            depth < 32 && values.iter().all(|v| json_stable_fast_at(v, depth + 1))
        }
        Any::Map(values) => {
            depth < 32 && values.values().all(|v| json_stable_fast_at(v, depth + 1))
        }
        _ => false,
    }
}

fn json_stable(any: &Any, json: &str) -> bool {
    let Ok(round_trip) = Any::from_json(json) else {
        return false;
    };
    let mut original = Vec::new();
    let mut decoded = Vec::new();
    encode_any(any, &mut original);
    encode_any(&round_trip, &mut decoded);
    original == decoded
}

fn json_value(any: &Any) -> Value {
    match any {
        Any::Null | Any::Undefined => Value::Null,
        Any::Bool(value) => Value::Bool(*value),
        Any::Number(value) if *value as i64 as f64 == *value => {
            Value::Number(Number::from(*value as i64))
        }
        Any::Number(value) => Number::from_f64(*value)
            .map(Value::Number)
            .unwrap_or(Value::Null),
        Any::BigInt(value) => Value::Number(Number::from(*value)),
        Any::String(value) => Value::String(value.to_string()),
        Any::Buffer(value) => Value::Array(
            value
                .iter()
                .map(|byte| Value::Number(Number::from(*byte)))
                .collect(),
        ),
        Any::Array(values) => Value::Array(values.iter().map(json_value).collect()),
        Any::Map(values) => {
            let sorted: BTreeMap<_, _> = values
                .iter()
                .map(|(key, value)| (key.clone(), json_value(value)))
                .collect();
            Value::Object(sorted.into_iter().collect::<Map<_, _>>())
        }
    }
}

#[cfg(test)]
#[path="/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/native/vendor/docx-edit/src/deterministic/sorteringproeven.rs"]
mod sorteringproeven;

/// Alleen canonieke waarde-encoderingen. De sterke Any houdt de onveranderlijke
/// Arc levend; pointerhergebruik of copy-on-write kan geen andere inhoud raken.
/// Begrensde gecodeerde bytes/regels zijn geen grens voor de gehele native heap.
#[derive(Default)]
pub(crate) struct WaardeCache {
    regels: std::collections::HashMap<(u8, usize), (Any, std::sync::Arc<[u8]>)>,
    pub bytes: usize,
    pub raak: usize,
    pub mis: usize,
    pub vol: usize,
}
impl WaardeCache {
    fn lees(&mut self, any: &Any, json: bool) -> Option<std::sync::Arc<[u8]>> {
        use std::sync::Arc;
        let (soort, ptr) = match any {
            Any::Map(v) => (0, Arc::as_ptr(v) as *const () as usize),
            Any::Array(v) => (1, Arc::as_ptr(v) as *const () as usize),
            Any::Buffer(v) => (2, Arc::as_ptr(v) as *const () as usize),
            _ => return None,
        };
        let sleutel = (soort + if json { 4 } else { 0 }, ptr);
        if let Some((_, bytes)) = self.regels.get(&sleutel) {
            self.raak += 1; return Some(bytes.clone());
        }
        self.mis += 1;
        let mut e = EncoderV1::new();
        if json { e.write_string(&serde_json::to_string(&json_value(any)).unwrap()); }
        else { encode_any(any, &mut e); }
        let bytes: Arc<[u8]> = e.to_vec().into();
        if self.regels.len() < 4096 && bytes.len() <= 8 * 1024 * 1024 - self.bytes {
            self.bytes += bytes.len();
            self.regels.insert(sleutel, (any.clone(), bytes.clone()));
        } else { self.vol += 1; }
        Some(bytes)
    }
}
pub(crate) fn encode_state_cached<T: ReadTxn>(txn: &T, cache: &mut WaardeCache) -> Vec<u8> {
    if txn.store().pending_update().is_some() || txn.store().pending_ds().is_some() {
        return encode_state_as_update_v1(txn, &StateVector::default());
    }
    let mut e = DeterministicEncoderV1(EncoderV1::new(), Some(cache));
    txn.encode_state_as_update(&StateVector::default(), &mut e);
    e.to_vec()
}
