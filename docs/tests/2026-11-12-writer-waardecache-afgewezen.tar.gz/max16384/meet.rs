mod codec { include!("deterministic-cache.rs"); }
use base64::{Engine as _,engine::general_purpose::STANDARD};
use yrs::{Transact,ReadTxn,StateVector,Update,updates::decoder::Decode};
use serde_json::{Value,json};
use std::time::Instant;
fn main()->Result<(),Box<dyn std::error::Error>> {
 let data=std::fs::read(std::env::args().nth(1).ok_or("Eigen aanvragen ontbreken")?)?;
 let regels:Vec<Value>=serde_json::from_slice(&data)?;let mut uit=Vec::new();
 for ronde in 0..4 {
  let doc=docx_edit::EditingDoc::new(regels[0]["aanvraag"]["clientId"].as_u64().unwrap());doc.keep_deleted();
  let mut cache=codec::WaardeCache::default();
  for (i,r) in regels.iter().enumerate() {
   let a=&r["aanvraag"];let bytes=STANDARD.decode(a["snapshot"].as_str().unwrap())?;
   doc.yrs_doc().transact_mut().apply_update(Update::decode_v1(&bytes)?)?;
   let txn=doc.yrs_doc().transact();assert_eq!(txn.state_vector(),StateVector::decode_v1(&STANDARD.decode(a["sourceVector"].as_str().unwrap())?)?);
   let (verwacht,ref_ns,gemeten,cache_ns)=if ronde==0||ronde==3 {
    let begin=Instant::now();let a=doc.encode_state_as_update_v1();let at=begin.elapsed().as_nanos() as u64;
    let begin=Instant::now();let b=codec::encode_state_cached(&txn,&mut cache);let bt=begin.elapsed().as_nanos() as u64;(a,at,b,bt)
   }else{
    let begin=Instant::now();let b=codec::encode_state_cached(&txn,&mut cache);let bt=begin.elapsed().as_nanos() as u64;
    let begin=Instant::now();let a=doc.encode_state_as_update_v1();let at=begin.elapsed().as_nanos() as u64;(a,at,b,bt)
   };
   assert_eq!(gemeten,verwacht,"Andere bytes bij {ronde}/{i}");
   assert_eq!(office_writer_plakken::snapshot_sha256(&gemeten),r["antwoord"]["basis"].as_str().unwrap());
   uit.push(json!({"ronde":ronde,"aanvraag":i,"ref_ns":ref_ns,"cache_ns":cache_ns,"bytes":gemeten.len(),"raak":cache.raak,"mis":cache.mis,"cachebytes":cache.bytes,"vol":cache.vol}));
  }
 }
 println!("{}",serde_json::to_string_pretty(&json!({"alle_bytes_exact":true,"metingen":uit}))?);Ok(())
}
