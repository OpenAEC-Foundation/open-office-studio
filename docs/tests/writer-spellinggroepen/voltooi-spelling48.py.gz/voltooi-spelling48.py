from pathlib import Path
import os,select,json,subprocess,hashlib,time
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';verwacht=b'python3\x00.local/doorwerk-2026-11-04/incrementele-invoer/voer-spelling48-vervolgproeven.py\x00';gevonden=[]
for p in Path('/proc').glob('[0-9]*/cmdline'):
 try:
  if p.read_bytes()==verwacht:gevonden.append(int(p.parent.name))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert len(gevonden)==1,gevonden
fd=os.pidfd_open(gevonden[0]);(r/'spelling48-slotstatus.json').write_text(json.dumps({'fase':'Wacht op nu levende vervolgproeven','pid':gevonden[0]},indent=2)+'\n');select.select([fd],[],[]);os.close(fd)
uit=json.loads((r/'spelling48-vervolgproefuitkomsten.json').read_text());assert len(uit)==5 and all(p['code']==0 for p in uit),uit[-1]
m=json.loads((r/'spelling48-bronnen.json').read_text());resultaten=[]
for n,h in {**m['bronbestanden'],**m['aanvullende_tests_na_bouw']}.items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
assert hashlib.sha256((repo/m['programma']).read_bytes()).hexdigest()==m['programma_sha256']
env=os.environ.copy();env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH'];python=repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'
def voer(naam,cmd,cwd=repo):
 print('START',naam,flush=True);begin=time.monotonic();(r/'spelling48-slotstatus.json').write_text(json.dumps({'fase':naam,'opdracht':cmd},indent=2)+'\n')
 with (r/(naam+'.log')).open('w')as log:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 resultaten.append({'naam':naam,'code':p.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd});(r/'spelling48-slotuitkomsten.json').write_text(json.dumps(resultaten,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
voer('spelling48-meethulp-op47',[str(python),'scripts/test-writer-rijk-plakken-native.py','--programma',str(r/'open-office-studio-45.47-observer'),'--versie','2026.45.47','--uitvoer',str(r/'spelling48-meethulp-op47'),'--bron','128-tabellen','--rondes','1','--maxduur','180','--vereis-rust-plakken','--vervolginvoer','--vereis-onderbreekbare-spelling'])
context=r/'ci47-foutcontext/writer-foutcontext';script=context/'scripts/test-writer-lijsten-native.py'
voer('spelling48-oorspronkelijke-lijstproef',[str(python),str(script),'--programma',str(repo/m['programma']),'--versie','2026.45.48','--uitvoer',str(r/'spelling48-oorspronkelijke-lijstproef')],context)
voer('spelling48-fysieke-vergelijking',['python3',str(r/'voer-spelling48-passieve-metingen.py')])
voer('spelling48-werkelijke-spelling',['python3',str(r/'voer-spelling48-werkelijke-spelling.py')])
(r/'spelling48-slotstatus.json').write_text(json.dumps({'fase':'Alle slotproeven afgerond','geslaagd':True},indent=2)+'\n')
