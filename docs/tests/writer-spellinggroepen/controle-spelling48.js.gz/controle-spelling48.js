const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');let spelling=null;
for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return){
 for(let slot=f.memoizedState,n=0;slot&&n<1500;n++,slot=slot.next){
  const waarde=slot.memoizedState,vs=[waarde,waarde?.current,...(Array.isArray(waarde)?waarde:[])];
  for(const v of vs)if(v&&typeof v.controleer==='function'&&typeof v.herbegin==='function'&&typeof v.zichtbareFouten==='function'&&v.editor?.()?.getEditorRef()===api().getEditorRef())spelling=v;
 }
}
if(!spelling)throw Error('Werkelijke spellingsessie niet gevonden');
const s=api().getEditorRef().getYrsSession(),d=Object.getOwnPropertyDescriptor(s,'readStories'),origineel=s.readStories;
let groepen=0;Object.defineProperty(s,'readStories',{...d,value:function(...args){groepen++;return Reflect.apply(origineel,this,args)}});
const voor=Array.from(s.encodeStateVector());
try{
 spelling.herbegin();let klaar=false;const eind=performance.now()+30000;
 do{await spelling.controleer();klaar=spelling.aantal!==null&&spelling.alineas?.length===3329&&!spelling.bezig&&!spelling.opnieuw;if(!klaar)await new Promise(r=>setTimeout(r,50))}while(!klaar&&performance.now()<eind);
 if(!klaar||spelling.probleem)throw Error('Spellingcontrole niet volledig: '+JSON.stringify({aantal:spelling.aantal,alineas:spelling.alineas?.length,probleem:spelling.probleem,groepen}));
 const controle=s.readStories({stories:'all',view:'accepted'});if(!controle.ok||controle.truncated||controle.stories.some(v=>!v.ok))throw Error('Onafhankelijke leescontrole onvolledig');
 const sorteer=a=>a.sort((a,b)=>a[0].localeCompare(b[0])||a[1].localeCompare(b[1]));
 const verwacht=sorteer(controle.stories.flatMap(v=>v.paragraphs.map(p=>[p.story,p.paraId,p.text])));
 const werkelijk=sorteer(spelling.alineas.map(p=>[p.story,p.paraId,p.tekst]));
 if(JSON.stringify(verwacht)!==JSON.stringify(werkelijk))throw Error('Spelling mist of wijzigt geaccepteerde verhaaltekst');
 if(JSON.stringify(voor)!==JSON.stringify(Array.from(s.encodeStateVector())))throw Error('Spelling wijzigt bronvector');
 if(groepen<2)throw Error('Geen echte groepslezing vanuit spelling aangetoond');
 return {geslaagd:true,groepen,verhalen:controle.stories.length,alineas:werkelijk.length,aantal_fouten:spelling.aantal,bronvector_gewijzigd:false,grens:'Werkelijke spellingsessie en echte plug-in in eigen native testvenster; één bron, geen algemene spelling- of prestatieacceptatie.'};
}finally{if(d)Object.defineProperty(s,'readStories',d);else delete s.readStories}
