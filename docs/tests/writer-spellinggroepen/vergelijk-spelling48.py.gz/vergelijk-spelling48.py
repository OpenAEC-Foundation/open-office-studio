from pathlib import Path
import json,hashlib
from PIL import Image,ImageChops
r=Path('.local/doorwerk-2026-11-04/incrementele-invoer');namen=['passief-spelling-47-voor','passief-spelling-48-eerste','passief-spelling-48-tweede','passief-spelling-47-na'];roi=(320,210,1140,950);cursor=(491,347,496,366);referentie=None;uit=[]
for n in namen:
 d=json.loads((r/n/'profiel.json').read_text());assert d['geslaagd']and d['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True}
 verwacht='335173aeb33cc483a753d9812db6b6f16a90320b6ee78ef09322b6eb7e5f6c04'if'-47-'in n else'f4a601f74375afe406750166010c809774225a44912288e866354f580478a784';assert d['programma_sha256']==verwacht
 im=Image.open(r/n/'profiel.png').convert('RGB').crop(roi);im.paste((0,0,0),(cursor[0]-roi[0],cursor[1]-roi[1],cursor[2]-roi[0],cursor[3]-roi[1]));referentie=referentie if referentie is not None else im.copy();diff=ImageChops.difference(referentie,im);aantal=sum(p!=(0,0,0)for p in diff.getdata());uit.append({'naam':n,'ms':d['getekende_tekst_ms'],'programma_sha256':verwacht,'broncontrole':d['broncontrole'],'documentpixels':{'roi':roi,'uitgesloten_cursor':cursor,'verschillende_pixels':aantal,'bbox':diff.getbbox()}})
oud=(uit[0]['ms']+uit[3]['ms'])/2;nieuw=(uit[1]['ms']+uit[2]['ms'])/2
rapport={'metingen':uit,'gemiddeld_oud_ms':oud,'gemiddeld_nieuw_ms':nieuw,'verhouding_nieuw_oud':nieuw/oud,'verschil_procent':100*(nieuw/oud-1),'grens':'Eén zware bron/pc, vier ronden; geen algemene responsiviteits- of volledige UI-/suiteacceptatie.'};(r/'spelling48-vergelijking.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rapport,ensure_ascii=False))
