from pathlib import Path
import os,subprocess,json,hashlib,shutil,time
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';m=json.loads((r/'spelling48-bronnen.json').read_text());resultaten=[]
env=os.environ.copy();env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/home/aia01/.cargo/bin:'+env['PATH'];python=repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'
def controleer():
 for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
def voer(fase,cmd,werkmap=repo):
 print('START',fase,flush=True);begin=time.monotonic()
 with (r/(fase+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=werkmap,env=env,stdout=log,stderr=subprocess.STDOUT)
  (r/'spelling48-levende-fase.json').write_text(json.dumps({'fase':fase,'pid':p.pid,'opdracht':cmd},indent=2)+'\n');code=p.wait()
 resultaten.append({'fase':fase,'code':code,'seconden':time.monotonic()-begin,'opdracht':cmd});(r/'spelling48-uitkomsten.json').write_text(json.dumps(resultaten,indent=2)+'\n');print('EINDE',fase,code,flush=True)
 if code:raise SystemExit(code)
controleer()
# Bewaar en hertest het exacte oorspronkelijke negatieve pakket, zonder de afkeuring te sluiten.
context=r/'ci47-foutcontext/writer-foutcontext';script=context/'scripts/test-writer-lijsten-native.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='77da7bfbc3c6679965e2e55d0341106bc6c02429fd4269b97614e8a78976db13'
voer('ci47-lijsten-exacte-hertest',[str(python),str(script),'--programma',str(context/'open-office-studio'),'--versie','2026.45.47','--uitvoer',str(r/'ci47-lijsten-exacte-hertest')],context)
for fase,cmd in [('spelling48-frontend',['node_modules/.bin/vitest','run']),('spelling48-typescript',['node_modules/.bin/tsc','--noEmit']),('spelling48-python',['python3','-m','unittest','discover','-s','tests','-v']),('spelling48-engines',['node','scripts/test-kantoor-engines.mjs']),('spelling48-opdrachten',['node','scripts/test-opdrachten.mjs']),('spelling48-week',['node','scripts/controleer-weekversie.mjs']),('spelling48-bouw',['node_modules/.bin/tauri','build','--no-bundle'])]:voer(fase,cmd)
controleer();p=repo/'src-tauri/target/release/open-office-studio';doel=r/'open-office-studio-45.48-spelling';assert not doel.exists();shutil.copy2(p,doel);m.update(programma=str(doel.relative_to(repo)),programma_sha256=hashlib.sha256(doel.read_bytes()).hexdigest());(r/'spelling48-bronnen.json').write_text(json.dumps(m,indent=2)+'\n')
voer('spelling48-native',['python3',str(r/'voer-spelling48-proeven.py')])
voer('spelling48-oorspronkelijke-lijstproef',[str(python),str(script),'--programma',str(doel),'--versie','2026.45.48','--uitvoer',str(r/'spelling48-oorspronkelijke-lijstproef')],context)
voer('spelling48-fysieke-vergelijking',['python3',str(r/'voer-spelling48-passieve-metingen.py')])
