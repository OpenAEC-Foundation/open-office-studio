from pathlib import Path
p=Path.cwd()/'.local/integratiecontrole/basistoestand-wasm';s=(p.parent/'groep-poort/proef-herstel-bestand.py').read_text()
s=s.replace("    app = subprocess.Popen", "    openen_begin = time.monotonic()\n    app = subprocess.Popen",1)
s=s.replace('        await asyncio.sleep(12)','''        inspectie_eind = time.monotonic()+40
        while True:
            try:
                from urllib.request import urlopen
                with urlopen('http://127.0.0.1:'+os.environ['OFFICE_PROEF_HTTP']+'/',timeout=.5) as antwoord:
                    if '/socket/' in antwoord.read().decode(): break
            except Exception:
                pass
            assert time.monotonic()<inspectie_eind, 'Eigen inspectie niet gereed'
            await asyncio.sleep(.05)''',1)
needle='                assert await p.run("return await window.__TAURI_INTERNALS__.invoke(\'plugin:app|version\');")'
i=s.index(needle)
frame='''window.__eersteLijst=async()=>{await document.fonts.ready;const eind=performance.now()+60000;let resultaat;while(!resultaat){const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(el){const gedaan=new Set;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let h=f.memoizedState,n=0;h&&n++<1500;h=h.next)for(const v of[h.memoizedState,h.memoizedState?.current]){if(!v?.displayList?.pages||!v.queries?.sourceState||gedaan.has(v))continue;gedaan.add(v);if(v.queries.sourceState().status==='error')throw Error('Fout in eerste renderbron');const tekst=v.displayList.pages.slice(0,1).flatMap(p=>p.primitives??[]).filter(p=>typeof p.text==='string').map(p=>p.text).join('');if(tekst.includes('Ruimte')&&tekst.includes('idee')&&api().getTotalPages()===65&&!document.querySelector('.office-melding')){resultaat={paginaHint:65,eersteTekst:tekst.slice(0,180),renderlijstMs:performance.now()};break}}}if(!resultaat){if(performance.now()>eind)throw Error('Geen eerste rijke tekstlijst');await new Promise(r=>setTimeout(r,20))}}await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return{...resultaat,tweeRafMs:performance.now()}};return await __eersteLijst();'''
s=s[:i]+"                r['openen'] = {'eerste_frame':await p.run("+repr(frame)+"), 'proces_tot_eerste_lijst_en_twee_raf_ms':(time.monotonic()-openen_begin)*1000}\n"+s[i:]
needle='                tweede = subprocess.run';i=s.index(needle);s=s[:i]+'                heropen_begin = time.monotonic()\n'+s[i:]
needle="                r['schema'] = schema";i=s.index(needle);s=s[:i]+"                r['openen']['heropen_frame'] = await p.run('return await __eersteLijst();')\n                r['openen']['heropen_tot_eerste_lijst_en_twee_raf_ms'] = (time.monotonic()-heropen_begin)*1000\n"+s[i:]
needle="                r['geval'] = 'rustig'";s=s.replace(needle,"                r['uitlijning'] = await p.run('const begin=performance.now();while(performance.now()<23000)await new Promise(r=>setTimeout(r,20));return{begin,einde:performance.now(),doel:23000}')\n"+needle)
(p/'proef-openen-herstel.py').write_text(s)
s=(p.parent/'herstel-serialisatie/native-ronden.py').read_text().replace("p=r/'.local/integratiecontrole/herstel-serialisatie'","p=r/'.local/integratiecontrole/basistoestand-wasm'").replace("helper=p.parent/'groep-poort/proef-herstel-bestand.py'","helper=p/'proef-openen-herstel.py'").replace("basis=p.parent/'tabel-paginavakken-productie/open-office-studio-paginavakken-proef'","basis=p.parent/'herstel-serialisatie/open-office-studio-herstel-proef'").replace("kandidaat=p/'open-office-studio-herstel-proef'","kandidaat=p/'open-office-studio-basistoestand-proef'")
s=s.replace("'herstel_tekst':d.get('herstel_tekst')","'herstel_tekst':d.get('herstel_tekst'),'openen':d.get('openen'),'uitlijning':d.get('uitlijning')")
(p/'native-ronden.py').write_text(s)
