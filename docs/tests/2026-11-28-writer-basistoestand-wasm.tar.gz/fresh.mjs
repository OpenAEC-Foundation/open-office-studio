import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {pathToFileURL}from'node:url';
const p=path.resolve('.local/integratiecontrole/basistoestand-wasm'),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),modules=[];
for(const mode of ['basis','kandidaat']){const m=await import(pathToFileURL(path.join(p,mode,'docx_edit.js')));await m.default({module_or_path:fs.readFileSync(path.join(p,mode,'docx_edit_bg.wasm'))});modules.push(m)}
const fixtures=[['nieuw','public/templates/nieuw.docx'],['rijk','docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'],['noten','docs/tests/nootomzetting-2026-11-06/bron.docx'],['voetnoten','docs/tests/nootomzetting-2026-11-06/alle-voetnoten.docx'],['eindnoten','docs/tests/nootomzetting-2026-11-06/alle-eindnoten.docx'],['gemengd','docs/tests/nootomzetting-2026-11-06/een-eindnoot.docx']];
const rows=[];let teller=0;
for(const[name,file]of fixtures)for(const route of (name==='rijk'?['ongewijzigd','invoer','cel','andere-digest']:['ongewijzigd','invoer'])){
 const bytes=fs.readFileSync(file),digest=route==='andere-digest'?sha(Buffer.from('eigen andere digest')):sha(bytes),sessions=[],open=[];
 console.log('PROEF',name,route);
 try{
  for(let i=0;i<modules.length;i++){const start=performance.now(),s=new modules[i].EditSession(97000+teller);s.open_docx(bytes,true,'eigen-basistoestand-'+teller,digest);open.push(performance.now()-start);sessions.push(s)}
  const ids=sessions[0].story_ids().sort();assert.deepEqual(sessions[1].story_ids().sort(),ids);
  let story=route==='cel'?ids.find(id=>id!=='body'&&id.includes(':r')):'body';assert(story,'Geen celstory');
  if(route==='invoer'||route==='cel'||route==='andere-digest')for(const s of sessions)s.apply_raw_ops(story,JSON.stringify([{op:'insert',index:0,text:'X😀'}]));
  const first=sessions.map(s=>sha(s.encode_state())),vectors=sessions.map(s=>sha(s.encode_state_vector()));assert.equal(first[0],first[1],'verse bronnen verschillen');assert.equal(vectors[0],vectors[1]);
  const plans=[],planMs=[];
  for(let n=0;n<2;n++){const pair=[];for(let i=0;i<sessions.length;i++){const t=performance.now();const plan=JSON.parse(sessions[i].paragraph_save_plan());if(n===0)planMs.push(performance.now()-t);pair.push(plan);assert.equal(sha(sessions[i].encode_state()),first[i]);assert.equal(sha(sessions[i].encode_state_vector()),vectors[i])}assert.deepEqual(pair[1],pair[0],'volledige plannen verschillen');plans.push(pair)}
  assert.deepEqual(plans[0],plans[1],'herhaald plan verschilt');
  for(const id of ids)assert.deepEqual(JSON.parse(sessions[1].story_segments(id)),JSON.parse(sessions[0].story_segments(id)),id);
  for(const fn of ['paragraph_identities','part_metadata_json','document_properties_json','section_margins_json','list_comments'])assert.deepEqual(JSON.parse(sessions[1][fn]()),JSON.parse(sessions[0][fn]()),fn);
  for(let i=0;i<sessions.length;i++){assert.equal(sha(sessions[i].encode_state()),first[i]);assert.equal(sha(sessions[i].encode_state_vector()),vectors[i]);}
  rows.push({naam:name,route,fixture:file,fixture_sha256:sha(bytes),storys:ids.length,open_ms:open,eerste_plan_ms:planMs,bron_en_vector_exact:true,bron_onderling_exact:true,volledige_plannen_en_herhaling_gelijk:true,storys_en_metadata_gelijk:true});
 }finally{for(const s of sessions)s.free()}
 teller++;
}
fs.writeFileSync(path.join(p,'fresh.json'),JSON.stringify({geslaagd:true,rows,grens:'Echte Wasm, verse seeding met vaste generatie/digest, ongewijzigd/body/cel/andere digest. Vergelijkt volledige plannen, alle story-segmenten en vijf metadata-APIs; geen DOCX-export of desktoplatentie.'},null,2)+'\n');console.log('GROEN',rows.length);
