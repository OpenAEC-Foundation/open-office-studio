from pathlib import Path
import shutil,hashlib,json
r=Path.cwd();p=r/'.local/integratiecontrole/basistoestand-wasm';old=p.parent/'digest-spans';native=p.parent/'basistoestand-bewaren/docx-kandidaat/src/identity.rs'
shutil.copytree(old/'bron',p/'bron',ignore=shutil.ignore_patterns('target','target-wasm','node_modules','.git','dist'))
for f in ['identity.rs','wasm.rs','lib.rs']:
 assert hashlib.sha256((old/'bron/crates/docx-edit/src'/f).read_bytes()).hexdigest()==hashlib.sha256((r/'native/vendor/docx-edit/src'/f).read_bytes()).hexdigest(),f
f=p/'bron/crates/docx-edit/src/identity.rs';s=f.read_text();n=native.read_text();a=n.index('    /// Alleen na voltooide, oorspronkelijke seeding');e=n.index('    /// Uitsluitend voor de eigen bronproef',a);helper=n[a:e];assert 'Instant'not in helper;at=s.index('    pub fn paragraph_save_plan(&self)');s=s[:at]+helper+s[at:];f.write_text(s)
f=p/'bron/crates/docx-edit/src/wasm.rs';s=f.read_text();oldline='        if fresh_seed {\n            self.engine.doc().mark_seeded();\n        }';assert s.count(oldline)==1;s=s.replace(oldline,'        if fresh_seed {\n            self.engine.doc().mark_seeded();\n            self.engine.doc().prepare_seeded_save_baseline();\n        }');f.write_text(s)
shutil.copytree(old/'wasm-target',p/'wasm-target')
(p/'bronpinnen.json').write_text(json.dumps({f:hashlib.sha256((p/'bron/crates/docx-edit/src'/f).read_bytes()).hexdigest()for f in ['identity.rs','wasm.rs','lib.rs']},indent=2)+'\n')
s=(old/'bouwen-veilig.py').read_text().replace("p=r/'.local/integratiecontrole/digest-spans'","p=r/'.local/integratiecontrole/basistoestand-wasm'")
s=s.replace("assert sha(p/'basis/docx_edit_bg.wasm')==json.loads((r/'patches/tekstengine-digestcache.json').read_text())['wasmSha256'];", "assert sha(r/'vendor/tekstengine/docx_edit_bg.wasm')=='03ff0e87c3804c89ba89d67d7a796f0ec0b6e71851f63b18caa296b50b16ebbf';")
(p/'bouwen.py').write_text(s)
