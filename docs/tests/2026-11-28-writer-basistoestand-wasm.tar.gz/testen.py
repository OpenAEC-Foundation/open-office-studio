from pathlib import Path
import subprocess,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/basistoestand-wasm';node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';rows=[]
a=(p/'basis/docx_edit.js').read_bytes();b=(p/'kandidaat/docx_edit.js').read_bytes();print('BINDING_JS_IDENTIEK',a==b,flush=True)
(p/'binding-js.json').write_text(json.dumps({'bytegelijk':a==b,'basis_sha256':hashlib.sha256(a).hexdigest(),'kandidaat_sha256':hashlib.sha256(b).hexdigest()},indent=2)+'\n');assert a==b,'Nieuwe binding verschilt: niet alleen Wasm vervangen'
for name in ['contract','fresh','spans-randen','pariteit']:
 begin=time.monotonic();cmd=[node,str(p/(name+'.mjs'))]
 with(p/('test-'+name+'.log')).open('x')as log:res=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append({'test':name,'code':res.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd});(p/'testen.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,res.returncode,flush=True)
 if res.returncode:break
