from pathlib import Path
import json,statistics
p=Path(__file__).resolve().parent;rows=json.loads((p/'native-ronden-herzien.json').read_text());assert len(rows)==4 and all(r['code']==0 and r['geslaagd']for r in rows)
result={'runs':rows,'groepen':{}}
for variant,labels in [('basis',['a-herzien','a2-herzien']),('kandidaat',['b-herzien','b2-herzien'])]:
 rs=[r for r in rows if r['label']in labels];assert len(rs)==2
 for r in rs:
  d=json.loads((p/r['label']/'rapport.json').read_text());assert len(d['letters'])==8 and all(x['bronExact']for x in d['letters'])and not any(d['fouten'].values())
 cold=[r['openen']['proces_tot_eerste_lijst_en_twee_raf_ms']for r in rs];warm=[r['openen']['heropen_tot_eerste_lijst_en_twee_raf_ms']for r in rs];recovery=[r['herstel_bestand_ms']-r['herstel_begin_ms']for r in rs]
 result['groepen'][variant]={'cold_ms':cold,'cold_mediaan_ms':statistics.median(cold),'heropen_ms':warm,'heropen_mediaan_ms':statistics.median(warm),'herstel_ms':recovery,'herstel_mediaan_ms':statistics.median(recovery),'som_cold_en_herstel_mediaan_ms':statistics.median([c+s for c,s in zip(cold,recovery)]),'piek_invoer_frame_ms':[max(r['frame_ms'])for r in rs],'eerste_toets_frame_ms':[r['frame_ms'][0]for r in rs]}
a=result['groepen']['basis'];b=result['groepen']['kandidaat'];result['verschil']={'cold_mediaan_ms':b['cold_mediaan_ms']-a['cold_mediaan_ms'],'herstel_daling_mediaan_ms':a['herstel_mediaan_ms']-b['herstel_mediaan_ms'],'herstel_daling_procent':100*(1-b['herstel_mediaan_ms']/a['herstel_mediaan_ms']),'som_daling_mediaan_ms':a['som_cold_en_herstel_mediaan_ms']-b['som_cold_en_herstel_mediaan_ms'],'som_daling_procent':100*(1-b['som_cold_en_herstel_mediaan_ms']/a['som_cold_en_herstel_mediaan_ms'])};result['definitie']='Eigen Xvfb, API/sessie/65-paginahint/eerste tekstlijst/font-ready + twee rAFs, geen fysieke paint. Openpoll/Inspector-kosten inbegrepen. Vóór invoer alleen testmatig tot performance.now 23 s uitgelijnd, zodat gewone herstelronde tijdens toetsen valt. Som is gemeten cold-open + herstelduur, geen totale tijd inclusief uitlijning/invoer of algemene reactietijd.'
(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'groepen':result['groepen'],'verschil':result['verschil']},indent=2))
