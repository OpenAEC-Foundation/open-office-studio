import fs from'node:fs';import path from'node:path';import assert from'node:assert/strict';import crypto from'node:crypto';import{pathToFileURL}from'node:url';
const p=path.resolve('.local/integratiecontrole/basistoestand-wasm'),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),mods=[];for(const mode of['basis','kandidaat']){const m=await import(pathToFileURL(path.join(p,mode,'docx_edit.js')));await m.default({module_or_path:fs.readFileSync(path.join(p,mode,'docx_edit_bg.wasm'))});mods.push(m)}
const bytes=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'),dg=sha(bytes),rows=[];
const donor=new mods[0].EditSession(99001);donor.open_docx(bytes,true,'eigen-donor',dg);donor.apply_raw_ops('body',JSON.stringify([{op:'insert',index:0,text:'nieuwe bron '} ]));const snapshot=donor.encode_state();donor.free();
for(const route of['laden-in-verse-cache','laden-na-eerste-plan','import-zonder-seeding']){
 const ss=mods.map(m=>new m.EditSession(99000));
 try{
  for(const s of ss){s.open_docx(bytes,route!=='import-zonder-seeding','eigen-oud',dg);if(route==='laden-na-eerste-plan')s.paragraph_save_plan();s.load(snapshot);s.track_undo()}
  const inspect=label=>{const before=ss.map(s=>sha(s.encode_state())),vectors=ss.map(s=>sha(s.encode_state_vector())),ids=ss[0].story_ids().sort();assert.deepEqual(ss[1].story_ids().sort(),ids);const plans=ss.map(s=>JSON.parse(s.paragraph_save_plan()));assert.deepEqual(plans[1],plans[0]);for(const id of ids)assert.deepEqual(JSON.parse(ss[1].story_segments(id)),JSON.parse(ss[0].story_segments(id)));for(let i=0;i<ss.length;i++){assert.equal(sha(ss[i].encode_state()),before[i]);assert.equal(sha(ss[i].encode_state_vector()),vectors[i])}assert.equal(before[0],before[1]);assert.equal(vectors[0],vectors[1]);rows.push({route,fase:label,stories:ids.length,plannen_gelijk:true,bron_en_vector_exact:true})};
  inspect('geladen');for(const s of ss){s.add_undo_boundary();s.apply_raw_ops('body',JSON.stringify([{op:'insert',index:0,text:'X'}]))}inspect('nieuwe-invoer');
 }finally{for(const s of ss)s.free()}
}
fs.writeFileSync(path.join(p,'levensduur.json'),JSON.stringify({geslaagd:true,rows,grens:'Werkelijke load van andere generatie na verse of gevulde cache en zonder seeding; daarna nieuwe invoer, plannen en alle stories. Geen thread-race of alle pakketherbindingen.'},null,2)+'\n');console.log('GROEN',rows.length);
