from pathlib import Path
import shutil,hashlib,json
r=Path.cwd();p=r/'.local/integratiecontrole/basistoestand-wasm';old=p.parent/'herstel-serialisatie';shutil.copytree(old/'dist',p/'dist',dirs_exist_ok=False)
changed=[]
for f in (p/'dist').rglob('*.wasm'):
 if hashlib.sha256(f.read_bytes()).hexdigest()=='03ff0e87c3804c89ba89d67d7a796f0ec0b6e71851f63b18caa296b50b16ebbf':
  f.write_bytes((p/'kandidaat/docx_edit_bg.wasm').read_bytes());changed.append(str(f.relative_to(p/'dist')))
assert len(changed)==1;changes=[]
for f in(p/'dist').rglob('*'):
 if f.is_file():
  rel=f.relative_to(p/'dist');a=hashlib.sha256(f.read_bytes()).hexdigest();b=hashlib.sha256((old/'dist'/rel).read_bytes()).hexdigest()
  if a!=b:changes.append({'bestand':str(rel),'basis':b,'kandidaat':a})
assert [x['bestand']for x in changes]==changed;(p/'desktop-bundel.json').write_text(json.dumps({'bestanden':len([f for f in(p/'dist').rglob('*')if f.is_file()]),'verschillen':changes,'opmerking':'Uitsluitend eigen testbundel; bestaande assetnaam behouden, JS/bindingen bytegelijk. Geen normale product-Vite-bouw.'},indent=2)+'\n')
s=(old/'bouwen-native.py').read_text().replace("p=r/'.local/integratiecontrole/herstel-serialisatie'","p=r/'.local/integratiecontrole/basistoestand-wasm'").replace("[('proef','groep-publicatie',None)]","[('proef','herstel-serialisatie',None)]").replace("p.parent/old/'target-a'","p.parent/old/'target-proef'").replace('open-office-studio-herstel-','open-office-studio-basistoestand-').replace("p/'bouwen.json'","p/'bouwen-native.json'");(p/'bouwen-native.py').write_text(s)
