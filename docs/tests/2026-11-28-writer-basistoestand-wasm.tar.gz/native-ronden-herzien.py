from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/basistoestand-wasm';helper=p/'proef-openen-herstel-herzien.py';basis=p.parent/'herstel-serialisatie/open-office-studio-herstel-proef';kandidaat=p/'open-office-studio-basistoestand-proef';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0','OFFICE_TEST_GROEPYIELD':'0','OFFICE_TEST_HERSTELFASE':'normaal'};rows=[]
for label,exe in [('a-herzien',basis),('b-herzien',kandidaat),('b2-herzien',kandidaat),('a2-herzien',basis)]:
 cmd=['/usr/bin/python3',str(helper),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/label)];t=time.monotonic();print('START',label,flush=True)
 with(p/(label+'.log')).open('x')as log:
  child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  while child.poll()is None:
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-t),flush=True)
 d=json.loads((p/label/'rapport.json').read_text());row={'label':label,'code':child.returncode,'geslaagd':d['geslaagd'],'fout':d.get('fout'),'programma_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'frame_ms':[round(x['eersteTotFrame'])for x in d.get('letters',[])],'herstel_begin_ms':d.get('herstel_begin_ms'),'herstel_bestand_ms':d.get('herstel_bestand_ms'),'herstel_tekst':d.get('herstel_tekst'),'openen':d.get('openen'),'uitlijning':d.get('uitlijning'),'seconden':time.monotonic()-t};rows.append(row);(p/'native-ronden-herzien.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',json.dumps(row),flush=True)
