from pathlib import Path
import subprocess,json,time
p=Path.cwd()/'.local/integratiecontrole/basistoestand-wasm';rows=[]
for script in ['start-metadata.py','start-functie.py','start-heropen.py']:
 begin=time.monotonic();print('START',script,flush=True)
 with(p/('stap-'+script+'.log')).open('x')as log:res=subprocess.run(['/usr/bin/python3',str(p/script)],stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append({'script':script,'code':res.returncode,'duur_s':time.monotonic()-begin});(p/'functies.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',script,res.returncode,flush=True)
 if res.returncode:break
