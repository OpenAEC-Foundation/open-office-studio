from pathlib import Path
import json,subprocess,hashlib,time,shutil,os,signal
u=Path(__file__).resolve().parent;r=json.loads((u/'bibliotheken.json').read_text());cache=Path(next(iter(r['pinnen'].values()))).parent
for p,h in r['sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
assert shutil.disk_usage(u).free>1536*1024**2
cmd=['/home/aia01/.cargo/bin/rustc','--edition=2024','-C','opt-level=3','-L','dependency='+str(cache),str(u/'meet-controle.rs'),'-o',str(u/'meet-controle')]
for n,p in r['pinnen'].items():cmd+=['--extern',n+'='+p]
begin=time.monotonic()
with (u/'bouw-controle.log').open('x') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  if shutil.disk_usage(u).free<1024**3 or time.monotonic()-begin>120:os.killpg(p.pid,signal.SIGTERM);p.wait();raise SystemExit('Eigen kleine bouw afgebroken bij ruimte-/tijdgrens')
  time.sleep(.2)
assert p.returncode==0,p.returncode
r.update(opdracht=cmd,code=p.returncode,duur_s=time.monotonic()-begin,programma_sha256=hashlib.sha256((u/'meet-controle').read_bytes()).hexdigest(),bronpinnen={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in u.glob('*.rs')})
(u/'bouw-controle.json').write_text(json.dumps(r,indent=2)+'\n');print('Eigen diagnosehulpmiddel gebouwd',r['duur_s'])
