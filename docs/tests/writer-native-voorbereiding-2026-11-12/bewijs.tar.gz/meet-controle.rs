//! Losse CPU-diagnose met echte eigen bronbytes; geen IPC- of rendereracceptatie.
#[allow(dead_code)] #[path="deterministic-oud-controle.rs"] mod oud;
#[allow(dead_code)] #[path="deterministic-vector-beide-controle.rs"] mod vector;
use base64::{Engine as _,engine::general_purpose::STANDARD};
use docx_edit::EditingDoc;
use office_writer_plakken::{BronSpiegel,IncrementeleTekstAanvraag,snapshot_sha256};
use serde_json::json;
use sha2::{Digest,Sha256};
use yrs::{StateVector,Transact};
use std::{time::Instant,hint::black_box};
fn main()->Result<(),Box<dyn std::error::Error>> {
 let mut gevallen=0;
 for n in [0,1,2,3,4,7,8,16,32,64,128] {for zaad in 0..32 {
  let mut waarden=std::collections::HashMap::new();
  for k in (0..n).rev() {
   let waarde=match (k+zaad)%13 {
    0=>yrs::Any::Undefined,1=>yrs::Any::Null,2=>yrs::Any::Bool(k%2==0),3=>yrs::Any::Number(f64::NAN),4=>yrs::Any::Number(-0.0),5=>yrs::Any::Number(f64::INFINITY),6=>yrs::Any::Number((k as f64)+0.25),7=>yrs::Any::BigInt(i64::MIN+k as i64),8=>yrs::Any::Buffer(std::sync::Arc::from([0u8,127,255])),9=>yrs::Any::from("\\\"\n😀"),_=>yrs::Any::Number(k as f64)};
   waarden.insert(format!("{}-{k:03}",if k%2==0{"😀"}else{"é"}),waarde);
  }
  let map=yrs::Any::Map(std::sync::Arc::new(waarden));
  for v in [map.clone(),yrs::Any::Array(std::sync::Arc::from([map.clone(),yrs::Any::Null,map]))] {
   assert_eq!(oud::proef_any(&v),vector::proef_any(&v));assert_eq!(oud::proef_json(&v),vector::proef_json(&v));gevallen+=1;
  }
 }}
 eprintln!("Bytegelijke Any/JSON-gevallen: {gevallen}; daarna twintig bronvervolgen");
 let pad=std::env::args().nth(1).ok_or("Geef eigen opname")?;
 let bestand=std::fs::read(pad)?;let mut a:IncrementeleTekstAanvraag=serde_json::from_slice(&bestand)?;
 assert!(a.basis.is_none());let bytes=STANDARD.decode(&a.snapshot)?;assert_eq!(snapshot_sha256(&bytes),a.snapshot_sha256);
 let doc=EditingDoc::new(a.client_id);doc.keep_deleted();doc.apply_update_v1(&bytes)?;
 assert!(!doc.holds_pending_update());let origineel=doc.encode_state_as_update_v1();
 let mut tijden=Vec::new();
 for n in 0..24 {
  let txn=doc.yrs_doc().transact();let sv=StateVector::default();let mut paar=Vec::new();
  for nieuw in if n%2==0 {[false,true]} else {[true,false]} {
   let begin=Instant::now();let b=if nieuw {vector::encode_state_as_update_v1(&txn,&sv)}else{oud::encode_state_as_update_v1(&txn,&sv)};let ns=begin.elapsed().as_nanos();
   assert_eq!(b,origineel,"Encoder geeft andere bronbytes");black_box(&b);paar.push(json!({"vector":nieuw,"ns":ns}));
  }
  let begin=Instant::now();black_box(Sha256::digest(&origineel));let sha_ns=begin.elapsed().as_nanos();
  let begin=Instant::now();black_box(snapshot_sha256(&origineel));let sha_hex_ns=begin.elapsed().as_nanos();
  tijden.push(json!({"ronde":n,"paar":paar,"sha_ns":sha_ns,"sha_hex_ns":sha_hex_ns}));
 }
 let mut spiegel=BronSpiegel::default();let mut stappen=Vec::new();
 for n in 0..20 {
  let begin=Instant::now();let r=spiegel.bereid_voor(a.clone())?.ok_or("Geen bron")?;let ns=begin.elapsed().as_nanos();
  let delta=STANDARD.decode(&r.resultaat.delta)?;doc.apply_update_v1(&delta)?;
  {let txn=doc.yrs_doc().transact();let sv=StateVector::default();let verwacht=doc.encode_state_as_update_v1();assert_eq!(oud::encode_state_as_update_v1(&txn,&sv),verwacht);assert_eq!(vector::encode_state_as_update_v1(&txn,&sv),verwacht);}
  let nieuw=doc.encode_diff_v1(&STANDARD.decode(&r.bronvector)?)?;assert_eq!(nieuw,delta);
  stappen.push(json!({"ronde":n,"ns":ns,"binnen_ms":r.resultaat.preparation_ms,"aanvraag_bytes":STANDARD.decode(&a.snapshot)?.len(),"bewaard_bytes":spiegel.bytes()}));
  a.request_id=format!("meting-{n}");a.source_version=format!("bron-{n}");a.basis=Some(r.basis);a.source_vector=STANDARD.encode(doc.encode_state_vector_v1());a.snapshot_sha256=snapshot_sha256(&nieuw);a.snapshot=STANDARD.encode(nieuw);a.position=r.resultaat.caret;a.text="x".into();
 }
 println!("{}",serde_json::to_string_pretty(&json!({"schema":1,"bronbytes":bytes.len(),"canonieke_bytes":origineel.len(),"aanvraag_sha256":snapshot_sha256(&bestand),"ronden":tijden,"voorbereidingen":stappen,"grens":"Native componentdiagnose. Iedere oude en vectorencoderuitvoer exact gelijk aan productiecodec. Losse heen/weer-volgorde, geen UI-/FPS-/platformacceptatie."}))?);Ok(())
}
