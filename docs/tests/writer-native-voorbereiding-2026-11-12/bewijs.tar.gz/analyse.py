from pathlib import Path
import json,statistics,math,hashlib
u=Path(__file__).resolve().parent
def stats(v):
 v=sorted(v);return {'aantal':len(v),'min_ms':v[0],'mediaan_ms':statistics.median(v),'p95_ms':v[max(0,math.ceil(.95*len(v))-1)],'max_ms':v[-1]}
uit={}
for name in ['rijk-meting','rijk-beide','groot-beide','rijk-controle','groot-controle']:
 r=json.loads((u/(name+'.json')).read_text());d={'bronbytes':r['bronbytes'],'canonieke_bytes':r['canonieke_bytes'],'aanvraag_sha256':r['aanvraag_sha256']}
 for b in [False,True]:d['vector' if b else 'bestaand']=stats([q['ns']/1e6 for n in r['ronden'] for q in n['paar'] if q['vector']==b])
 for k in ['sha_ns','sha_hex_ns']:d[k]=stats([n[k]/1e6 for n in r['ronden']])
 d['voorbereiding_volledige_aanvraag_ms']=r['voorbereidingen'][0]['ns']/1e6
 d['voorbereiding_vervolgen']=stats([n['ns']/1e6 for n in r['voorbereidingen'][1:]])
 d['geencodeerde_mediaanwinst_pct']=100*(1-d['vector']['mediaan_ms']/d['bestaand']['mediaan_ms'])
 d['grens']='Alleen encoderafzondering; de twintig voorbereidingen gebruiken de bestaande productbibliotheek. Hun tijden zijn GEEN meting van de vectorvariant.'
 uit[name]=d
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for n,r in uit.items():print(n,'oud',r['bestaand']['mediaan_ms'],'vector',r['vector']['mediaan_ms'],'voorbereiding-bestaand',r['voorbereiding_vervolgen']['mediaan_ms'])
