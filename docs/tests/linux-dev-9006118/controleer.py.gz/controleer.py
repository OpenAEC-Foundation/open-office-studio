from pathlib import Path
import zipfile,tarfile,hashlib,json,tempfile,runpy,shutil,stat
r=Path('.local/dev-linux-45.47-download');sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();zpad=r/'pakket.zip';gpad=Path('.local/dev-linux-45.47-gui.zip')
assert sha(zpad)=='7c4ac4aef1e6bbbc07d17db121aaaa65a30aadb2fb8a9c05e796903117c7ff13';assert sha(gpad)=='add88818c05cf62c620b9aa729a0953c1d8d2ec42ba1f8e8fe4d44d23f9a5375'
with zipfile.ZipFile(gpad)as z:
 assert z.testzip()is None;gui=json.loads(z.read('rapport.json'))
assert gui['geslaagd'] and not gui['gui_fouten'] and not gui['console_fouten'] and not gui['engine_fouten']
assert gui['versie']=='2026.45.47' and gui['profiel']=='org.openaec.office-studio.dev'
with zipfile.ZipFile(zpad)as z,tempfile.TemporaryDirectory(prefix='controle-',dir=r)as tmp:
 assert z.testzip()is None
 metadata=json.loads(z.read('bouw.json'));assert metadata['bronrevisie']=='9006118c1269333d5ab2576d9025dd5c855409f1';assert metadata['versie']=='2026.45.47';assert metadata['profiel']==gui['profiel'];assert metadata['native_gui']['geslaagd']
 tarnaam=next(n for n in z.namelist()if n.endswith('.tar.gz'));tarhash=z.read('SHA256SUMS').decode().split()[0]
 with z.open(tarnaam)as f:assert hashlib.file_digest(f,'sha256').hexdigest()==tarhash
 pakket=None;uit=Path(tmp);start=None;binnen=None;checks=None
 with z.open(tarnaam)as f,tarfile.open(fileobj=f,mode='r|gz')as t:
  for lid in t:
   p=Path(lid.name);assert not p.is_absolute() and '..'not in p.parts and (lid.isdir()or lid.isfile())
   if not lid.isfile():continue
   with t.extractfile(lid)as src:
    if p.suffix=='.AppImage':
     assert pakket is None and lid.mode&stat.S_IXUSR;pakket=uit/p.name
     with pakket.open('wb')as out:shutil.copyfileobj(src,out,1024*1024)
    elif p.name=='bouw.json':binnen=json.load(src)
    elif p.name=='SHA256SUMS':checks=src.read().decode()
    elif p.name=='start-dev.sh':assert lid.mode&stat.S_IXUSR;start=src.read().decode()
 assert binnen==metadata and sha(pakket)==metadata['sha256']==checks.split()[0]
 assert start=='#!/bin/sh\nset -eu\ncd -- "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"\n'+f'exec "./{pakket.name}" "$@"\n'
 # De controlebron is in deze kandidaat niet veranderd; uitpakken start de app niet.
 controle=runpy.run_path('scripts/controleer-installers.py')['appimage'](pakket,uit/'app')
 elfhash=sha(uit/'app/usr/bin/open-office-studio');launcherhash=sha(uit/'app/AppRun')
 assert elfhash==gui['programma_sha256']==metadata['native_gui']['programma_sha256'];assert launcherhash==gui['startprogramma_sha256']==metadata['native_gui']['startprogramma_sha256']
 rapport={'schema':1,'geslaagd':True,'versie':'2026.45.47','bronrevisie':metadata['bronrevisie'],'run':41951349430,'run_conclusie':'success','artifact':13382150485,'download':'https://github.com/OpenAEC-Foundation/open-office-studio/actions/runs/41951349430/artifacts/13382150485','zip_sha256':sha(zpad),'gui_zip_sha256':sha(gpad),'tar_sha256':tarhash,'appimage_sha256':metadata['sha256'],'metadata':metadata,'controles':controle+['ZIP-CRC en GitHub-digests','Tar-digest, metadata en uitvoerrechten','AppRun en ELF exact gelijk aan apart CI-GUI-rapport; alle foutlijsten leeg'],'grenzen':['Geen lokale GUI-uitvoering van deze gedownloade AppImage','FUSE-mount, ARM en andere distributies niet gevalideerd','Writer-invoervertraging en oorspronkelijke Wasm-afkeuringen, ook aparte Linux-lijstafkeuring op dezelfde bronrevisie, blijven open']}
(r/'controle.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');(r/'gui-rapport.json').write_text(json.dumps(gui,ensure_ascii=False,indent=2)+'\n');print('Download47, volledig SquashFS, AppRun/ELF en apart GUI-rapport exact gecontroleerd.')
