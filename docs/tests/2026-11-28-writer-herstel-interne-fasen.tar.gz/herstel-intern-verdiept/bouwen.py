from pathlib import Path
import subprocess,shutil,os,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/herstel-intern-verdiept';rows=[];env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','TAURI_CONFIG':json.dumps({'build':{'frontendDist':str(p/'dist')}})}
for label,old,override in [('proef','herstel-intern',None)]:
 target=p/('target-'+label);shutil.copytree(p.parent/old/'target-proef',target,dirs_exist_ok=True);cmd=['cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal']
 if override:cmd+=['--config','patch.crates-io.betteroffice-docx-edit.path='+json.dumps(str(override))]
 start=time.monotonic()
 with(p/('bouw-'+label+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env={**env,'CARGO_TARGET_DIR':str(target)},stdout=log,stderr=subprocess.STDOUT)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print('BOUW',label,round(time.monotonic()-start),flush=True)
 assert proc.returncode==0
 exe=p/('open-office-studio-herstel-intern-verdiept-'+label);shutil.copy2(target/'release/open-office-studio',exe);rows.append({'label':label,'code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd,'programma':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()});(p/'bouwen.json').write_text(json.dumps(rows,indent=2)+'\n');print('GEREED',label,flush=True)
