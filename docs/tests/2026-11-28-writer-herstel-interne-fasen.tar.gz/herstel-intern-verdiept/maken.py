from pathlib import Path
import shutil,hashlib,json
r=Path.cwd();p=r/'.local/integratiecontrole/herstel-intern-verdiept';b=p.parent/'herstel-intern';shutil.copytree(b/'dist',p/'dist',dirs_exist_ok=False);rows=[]
f=p/'dist/assets/chunk-Q7OC7M5Q-CYo4lz-m.js';s=f.read_text();helper=s.split('function bg(',1)[0]
old='let{saveResidentDocument:we}=await import("./chunk-YTGFUEEE-CWz7SArg.js"),'
new='let{saveResidentDocument:we}=await __oosAsync("residentImport",()=>import("./chunk-YTGFUEEE-CWz7SArg.js")),'
assert s.count(old)==1;before=hashlib.sha256(f.read_bytes()).hexdigest();s=s.replace(old,new);f.write_text(s);rows.append({'bestand':str(f.relative_to(p/'dist')),'voor':before,'na':hashlib.sha256(f.read_bytes()).hexdigest()})
f=p/'dist/assets/chunk-YTGFUEEE-CWz7SArg.js';s=f.read_text();before=hashlib.sha256(f.read_bytes()).hexdigest()
for old,new in [
 ('let e=b(c,f,l,m),s=o.base??e.session.materializeDocx();','let e=__oosSync("residentSession",()=>b(c,f,l,m)),s=o.base??__oosSync("materializeDocx",()=>e.session.materializeDocx());'),
 ('let r=u.capture(),a=new v;', 'let r=__oosSync("residentDirtyCapture",()=>u.capture()),a=new v;'),
 ('let t=x(e.session,h(s,p??e.host.document),a.projectionOptions());', 'let t=__oosSync("residentYrsToDocument",()=>x(e.session,__oosSync("residentHostMetadata",()=>h(s,p??e.host.document)),a.projectionOptions()));'),
 ('let n=await D(e.session,t,d,o);','let n=await __oosAsync("residentSaveEditorDocument",()=>D(e.session,t,d,o));')]:
 assert s.count(old)==1,old;s=s.replace(old,new)
f.write_text(helper+s);rows.append({'bestand':str(f.relative_to(p/'dist')),'voor':before,'na':hashlib.sha256(f.read_bytes()).hexdigest()});(p/'wijzigingen.json').write_text(json.dumps(rows,indent=2)+'\n')
s=(b/'bouwen.py').read_text().replace("p=r/'.local/integratiecontrole/herstel-intern'","p=r/'.local/integratiecontrole/herstel-intern-verdiept'").replace("[('proef','herstel-serialisatie',None)]","[('proef','herstel-intern',None)]").replace('open-office-studio-herstel-intern-','open-office-studio-herstel-intern-verdiept-');(p/'bouwen.py').write_text(s)
