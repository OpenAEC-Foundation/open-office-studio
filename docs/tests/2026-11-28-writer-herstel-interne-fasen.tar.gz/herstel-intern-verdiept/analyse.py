from pathlib import Path
import json
b=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/.local/integratiecontrole');rows=[]
for dirname,labels in [('herstel-intern',['intern-1','intern-2']),('herstel-intern-verdiept',['verdiept-1','verdiept-2'])]:
 for label in labels:
  f=b/dirname/label/'rapport.json'
  if not f.exists():continue
  d=json.loads(f.read_text());assert d['geslaagd'];assert all(d['fasen_hersteld']);assert len(d['herhaalde_sdk_exports'])==2
  profiles=[];msgs=d['fasen']['werker']
  for m in msgs:
   p=m['vorm'].get('__oosSaveProfile')
   if not p:continue
   req=next(a for a in msgs if a['richting']=='verzoek'and a['werker']==m['werker']and a['vorm'].get('type')=='save'and a['vorm'].get('id')==p['id'])
   ans=next(a for a in msgs if a['richting']=='antwoord'and a['werker']==m['werker']and a['vorm'].get('id')==p['id']and a['vorm'].get('ok')and 'saved'in a['vorm'])
   phases=[{'naam':a['naam'],'duur_ms':a['einde']-a['start'],'start_werker_ms':a['start'],'eind_werker_ms':a['einde']}for a in p['fasen']]
   assert not any(a.get('fout')for a in p['fasen'])
   profiles.append({'request_id':p['id'],'route':'herstel'if not profiles else 'herhaalde SDK-export','vector':p['vector'],'werkerhandler_ms':p['einde']-p['start'],'hoofdthread_verzoek_antwoord_ms':ans['ms']-req['ms'],'fasen':phases})
  assert len(profiles)==3
  rows.append({'map':dirname,'label':label,'programma_sha256':d['programma_sha256'],'schema':d['schema'],'profielen':profiles,'herstel':d['herstel_tekst'],'sdk_exports':d['herhaalde_sdk_exports'],'fouten':d['fouten'],'bronexacte_toetsen':len(d['letters'])})
(b/'herstel-intern-verdiept/analyse.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{**{k:r[k]for k in ['label','programma_sha256']},'profielen':[{'id':p['request_id'],'handler_ms':round(p['werkerhandler_ms']),'fasen':[(a['naam'],round(a['duur_ms']))for a in p['fasen']if a['duur_ms']>100]}for p in r['profielen']]}for r in rows],indent=2))
