from pathlib import Path
import shutil,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/herstel-intern';base=p.parent/'herstel-serialisatie/dist';shutil.copytree(base,p/'dist',dirs_exist_ok=False)
helper='''function __oosSync(naam,fn){const p=globalThis.__OOS_SAVE_PROFILE;if(!p)return fn();const m={naam,start:performance.now()};p.fasen.push(m);try{return fn()}catch(e){m.fout=String(e);throw e}finally{m.einde=performance.now()}}async function __oosAsync(naam,fn){const p=globalThis.__OOS_SAVE_PROFILE;if(!p)return fn();const m={naam,start:performance.now()};p.fasen.push(m);try{return await fn()}catch(e){m.fout=String(e);throw e}finally{m.einde=performance.now()}}\n'''
changes=[]
def wijzig(f,pairs):
 s=f.read_text();before=hashlib.sha256(f.read_bytes()).hexdigest()
 for old,new in pairs:
  assert s.count(old)==1,(f.name,old,s.count(old));s=s.replace(old,new)
 s=helper+s;f.write_text(s);changes.append({'bestand':str(f.relative_to(p/'dist')),'voor':before,'na':hashlib.sha256(f.read_bytes()).hexdigest(),'vervangingen':[a for a,b in pairs]})
f=p/'dist/assets/chunk-Q7OC7M5Q-CYo4lz-m.js'
wijzig(f,[
 ('if(e.type==="save"){if(Vt)', 'if(e.type==="save"){globalThis.__OOS_SAVE_PROFILE={id:e.id,start:performance.now(),vector:e.stateVector?Array.from(e.stateVector):null,fasen:[]};if(Vt)'),
 ('no?await N.saveDocument(e.host,a,Tn):await N.save(new Uint8Array(Qt.bytes),Qt.hostJson,e.host,a,Tn,e.stories)', 'no?await __oosAsync("N.saveDocument",()=>N.saveDocument(e.host,a,Tn)):await __oosAsync("N.save",()=>N.save(new Uint8Array(Qt.bytes),Qt.hostJson,e.host,a,Tn,e.stories))'),
 ('}finally{We=r}return}if(e.type==="revisionCount")', '}finally{We=r;const p=globalThis.__OOS_SAVE_PROFILE;if(p){p.einde=performance.now();self.postMessage({id:0,ok:true,__oosSaveProfile:p});globalThis.__OOS_SAVE_PROFILE=null}}return}if(e.type==="revisionCount")'),
 ('let z=we(g,fe(C.base??n,w??v())),le=await U(g,z,x,C);', 'let z=__oosSync("yrsToDocument",()=>we(g,__oosSync("hostMetadata",()=>fe(C.base??n,w??v())))),le=await __oosAsync("saveEditorDocument",()=>U(g,z,x,C));'),
 ('_=q.capture(),P=G(m);he(g,[..._.stories,...P.stories]);', '_=__oosSync("dirtyCapture",()=>q.capture()),P=__oosSync("storiesChangedSince",()=>G(m));__oosSync("noteDirty",()=>he(g,[..._.stories,...P.stories]));')
])
f=p/'dist/assets/chunk-YEDZERHF-pQnI8XH_.js'
pairs=[]
for name,async_ in [('Dt',False),('Vt',False),('Nt',True),('Te',True),('Le',True),('Xt',True)]:
 old=('async 'if async_ else '')+'function '+name+'('
 new=('async 'if async_ else '')+'function __oosOrig_'+name+'('
 pairs.append((old,new))
# Fasegrenzen in de bestaande opslagfuncties, zonder gewijzigde argumenten.
pairs += [
 ('let t=e.paragraphIdentities();P();let n=e.paragraphSavePlan();', 'let t=__oosSync("paragraphIdentities",()=>e.paragraphIdentities());P();let n=__oosSync("paragraphSavePlan",()=>e.paragraphSavePlan());'),
 ('await Promise.all([je(),Ge()]);for(let u of i?.splicedParts', 'await __oosAsync("wasmReady",()=>Promise.all([je(),Ge()]));for(let u of i?.splicedParts'),
 ('seed:await xt(new Uint8Array(t))','seed:await __oosAsync("determinismHash",()=>xt(new Uint8Array(t)))'),
 ('P(),ge(f,"save"),P();let m=Ye(f,()=>JSON.stringify(f));P();let{bytes:p,warnings:h}=Ke(m,new Uint8Array(t));P();let w=At(p);return!c&&Pt(e,t,w)', 'P(),__oosSync("validateSave",()=>ge(f,"save")),P();let m=__oosSync("saveJSON",()=>Ye(f,()=>JSON.stringify(f)));P();let{bytes:p,warnings:h}=__oosSync("wasmRepack",()=>Ke(m,new Uint8Array(t)));P();let w=__oosSync("copyBuffer",()=>At(p));return!c&&__oosSync("roundtripCheck",()=>Pt(e,t,w))'),
 ('let B=e.writtenParagraphIds(K);', 'let B=__oosSync("writtenParagraphIds",()=>e.writtenParagraphIds(K));')
]
wijzig(f,pairs)
s=f.read_text()
for name,async_ in [('Dt',False),('Vt',False),('Nt',True),('Te',True),('Le',True),('Xt',True)]:
 s+='\n'+('async 'if async_ else '')+'function '+name+'(...args){return '+('__oosAsync'if async_ else '__oosSync')+'('+json.dumps('pakket.'+name)+',()=>__oosOrig_'+name+'(...args))}\n'
f.write_text(s);changes[-1]['na']=hashlib.sha256(f.read_bytes()).hexdigest()
(p/'wijzigingen.json').write_text(json.dumps(changes,indent=2)+'\n')
