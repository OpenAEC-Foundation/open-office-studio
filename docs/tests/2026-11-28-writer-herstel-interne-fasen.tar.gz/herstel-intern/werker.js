(() => {
 const g=__fasen;g.werker=[];g.frames=[];
 const proto=Worker.prototype,desc=Object.getOwnPropertyDescriptor(proto,'postMessage'),oud=proto.postMessage,gekend=new Map();let volgend=0,actief=true,raf;
 const vorm=v=>{if(v?.__oosSaveProfile)return{__oosSaveProfile:v.__oosSaveProfile};if(!v||typeof v!=='object')return{type:typeof v};const r={sleutels:Object.keys(v)};for(const k of Object.keys(v)){const x=v[k];if(typeof x==='string'&&['type','kind','id','requestId','method','command'].includes(k))r[k]=x;else if(typeof x==='number'||typeof x==='boolean')r[k]=x;else if(x?.byteLength!==undefined)r[k]={bytes:x.byteLength};else if(x&&typeof x==='object')r[k]={sleutels:Object.keys(x).slice(0,25)}}return r};
 const wrapper=function(v,...rest){let entry=gekend.get(this);if(!entry){const id=++volgend,luister=e=>g.werker.push({richting:'antwoord',werker:id,ms:performance.now(),vorm:vorm(e.data)});entry={id,luister};gekend.set(this,entry);this.addEventListener('message',luister)}g.werker.push({richting:'verzoek',werker:entry.id,ms:performance.now(),vorm:vorm(v),stack:new Error().stack.slice(0,600)});return oud.call(this,v,...rest)};
 proto.postMessage=wrapper;if(proto.postMessage!==wrapper)throw Error('Worker-monitor niet actief');
 const tick=ms=>{if(!actief)return;g.frames.push(ms);raf=requestAnimationFrame(tick)};raf=requestAnimationFrame(tick);
 g.herstel.push(()=>{actief=false;cancelAnimationFrame(raf);for(const[w,e]of gekend)w.removeEventListener('message',e.luister);Object.defineProperty(proto,'postMessage',desc);return proto.postMessage===oud});return true;
})()
