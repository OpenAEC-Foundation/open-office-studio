const fn = (input) => {
    if (!partsTouched && !marginsTouched && !sectionsTouched && session.part_metadata_json() === '{}' &&
        session.document_properties_json() === '{}' && session.section_margins_json() === '{}')
        return input;
    const document = hostDocument();
    const request = JSON.parse(input);
    const sections = document.package.document.sections?.map(section => ({ sectionId: section.id ?? section.properties.sectionId, properties: section.properties })) ?? [];
    if (!sectionsTouched)
        sections.push({ sectionId: sections.at(-1)?.sectionId, properties: document.package.document.finalSectionProperties ?? {} });
    const variants = sections.flatMap((section, sectionIndex) => ['header', 'footer'].flatMap(kind => (section.properties[kind === 'header' ? 'headerReferences' : 'footerReferences'] ?? []).map(ref => ({ kind, type: ref.type, rId: ref.rId, sectionIndex }))));
    const contents = [...(document.package.footnotes ?? []).map(note => ({ id: note.id, noteKind: 'footnote', height: 0 })),
        ...(document.package.endnotes ?? []).map(note => ({ id: note.id, noteKind: 'endnote', height: 0 }))];
    const watermark = getDocumentWatermark(document);
    return JSON.stringify({ ...request, regions: { ...request.regions, sections, watermark,
            headersFooters: request.regions?.headersFooters ? { ...request.regions.headersFooters, watermark } : undefined }, notes: { ...request.notes, contents },
        ...(request.workerOwned ? { workerHeadersFooters: { ...request.workerHeadersFooters, variants } } : {}) });
};
