(()=>{
 'use strict';
 if(self._officeJsonProbe)throw Error('JSON-proef bestaat al');
 const desc=Object.getOwnPropertyDescriptor(JSON,'stringify'),original=JSON.stringify,entries=[],ids=new Map();let active=true,bytes=0,overflow=0,calls=0;
 if(typeof original!=='function'||!desc?.configurable)throw Error('JSON-methode niet veilig te volgen');
 function stringify(...args){
  const result=Reflect.apply(original,this,args);
  if(active){try{const v=args[0];if(v&&Object.prototype.hasOwnProperty.call(v,'bodyStory')&&Object.prototype.hasOwnProperty.call(v,'renderEnv')&&Object.prototype.hasOwnProperty.call(v,'regions')&&typeof result==='string'){calls++;const entry=ids.get(result);if(entry!==undefined)entries[entry].calls++;else if(result.length<=262144&&entries.length<32&&bytes+result.length<=2097152){ids.set(result,entries.length);entries.push({json:result,calls:1,stack:new Error().stack});bytes+=result.length}else overflow++;}}catch{overflow++;}}
  return result;
 }
 Object.defineProperty(JSON,'stringify',{...desc,value:stringify});
 self._officeJsonProbe={stop(){active=false;const restored=JSON.stringify===stringify;if(restored)Object.defineProperty(JSON,'stringify',desc);return {entries,calls,bytes,overflow,restored,grens:2097152};}};
 return {grens:2097152};
})()
