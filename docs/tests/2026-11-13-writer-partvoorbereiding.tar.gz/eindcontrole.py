from pathlib import Path
import json,hashlib,gzip,subprocess,ast,tarfile
from zipfile import ZipFile
from xml.etree import ElementTree as ET
r=Path.cwd();p=r/'.local/integratiecontrole/warm-part-input';old=r/'.local/integratiecontrole/warm-layout-request';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();native=json.loads((p/'native-functie/rapport.json').read_text());assert native['geslaagd'];observed=[]
for x in native['werkers_binnen_eind']:
 value=x['antwoord']['result']['result']['value'];d=value['json'];assert d['restored'] and d['overflow']==0;observed.append({'werker':x['werker'],'json':d})
(p/'json-waarnemingen.json').write_text(json.dumps({'werkers':observed,'gefilterde_stringify_calls':sum(x['json']['calls']for x in observed),'grens':'Alleen tijdens ingevoerde lange tekst binnen twee geïnstrumenteerde Workers. Nul gefilterde stringify-aanroepen bewijst geen nul partLayoutInput-aanroepen;fastpath/ander traject blijven mogelijk. Geen timingclaim.'},ensure_ascii=False,indent=2)+'\n')
patch=json.loads((p/'adapterwijziging.json').read_text());a=gzip.decompress((p/'werker-voor.js.gz').read_bytes());b=gzip.decompress((p/'werker-na.js.gz').read_bytes());assert a==gzip.decompress((old/'werker-na.js.gz').read_bytes());assert a.decode().count(patch['voor'])==1 and a.decode().replace(patch['voor'],patch['na'],1).encode()==b
node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';z=subprocess.run([node,'--check','--input-type=module'],input=b,capture_output=True);assert z.returncode==0,z.stderr;(p/'jscontrole.json').write_text(json.dumps({'code':z.returncode,'voor_sha256':hashlib.sha256(a).hexdigest(),'na_sha256':hashlib.sha256(b).hexdigest(),'een_aanroep_gewijzigd':True},indent=2)+'\n')
refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==23
for f,h in refs.items():assert sha(Path(f))==h
expected=json.loads((old/'standaardbundel.json').read_text());actual={str(f.relative_to(r/'dist')):{'sha256':sha(f),'mode':f.stat().st_mode&0o777,'mtime_ns':f.stat().st_mtime_ns}for f in(r/'dist').rglob('*')if f.is_file()};assert actual==expected and len(actual)==529
pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_npm_exact']
for f,h in pins.items():assert sha(r/f)==h
source=json.loads((old/'bron-hersteld.json').read_text())['bestanden']
for f,h in source.items():assert sha(r/f)==h
checks=[]
for f in p.glob('*.py'):ast.parse(f.read_text());checks.append({'pad':f.name,'controle':'Python AST','code':0})
for f in list(p.glob('*.mjs'))+list(p.glob('*.js')):
 z=subprocess.run([node,'--check',str(f)],capture_output=True);assert z.returncode==0,(f,z.stderr);checks.append({'pad':f.name,'controle':'node --check','code':0})
f=p/'native-functie/Ontwerpnotitie.docx';assert sha(f)==native['bewaring_sha256'];parts={}
with ZipFile(f)as z:
 assert z.testzip()is None
 for n in z.namelist():
  data=z.read(n)
  if n.endswith(('.xml','.rels')):ET.fromstring(data)
  parts[n]=hashlib.sha256(data).hexdigest()
 root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(x.text or''for x in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128 and units==91423
with ZipFile(old/'native-functie/Ontwerpnotitie.docx')as z:previous={n:hashlib.sha256(z.read(n)).hexdigest()for n in z.namelist()}
assert set(parts)==set(previous);diff=[n for n in parts if parts[n]!=previous[n]];assert set(diff)<={'docProps/core.xml'}
(p/'documentcontrole.json').write_text(json.dumps({'sha256':sha(f),'zip_crc_xml':True,'tabellen':tables,'utf16':units,'verschil_met_vorige_zelfde_ELF':diff},indent=2)+'\n');(p/'behoud.json').write_text(json.dumps({'elf_referenties_exact':refs,'standaarddist_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':pins,'canonieke_bron_exact':source,'scripts':checks,'wasm_ongewijzigd':sha(old/'kern/docx_edit_bg.wasm')},indent=2)+'\n');print('BEHOUD23/529/6;DOCX128/91423;JSONcalls',sum(x['json']['calls']for x in observed))
