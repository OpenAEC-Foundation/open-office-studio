from pathlib import Path
import os,subprocess,json,time,hashlib
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';script=r/'meet-queryafstemming44-diagnose-native.py';tekst=json.loads((repo/'docs/tests/writer-doortypen/doortypen-38-zonder-profiel/profiel.json.gz').read_bytes()) if False else json.loads((r/'doortypen-38-zonder-profiel/profiel.json').read_text())['invoertekst']
omgeving=os.environ.copy();omgeving['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+omgeving['PATH']
uitkomsten=[]
for naam,versie in [('passief-query-44-diagnose',44)]:
 cmd=[str(repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'),str(script),'--zonder-profiel','--programma',str(r/(f'open-office-studio-45.{versie}'+('-revisies' if versie==43 else '-queryafstemming'))),'--versie',f'2026.45.{versie}','--bron',str(repo/'docs/tests/writer-doortypen/bron.docx'),'--paginas','129','--tekst',tekst,'--uitvoer',str(r/naam)]
 print('START',naam,flush=True);begin=time.monotonic()
 with (r/(naam+'.log')).open('w') as log:p=subprocess.run(cmd,env=omgeving,stdout=log,stderr=subprocess.STDOUT)
 uitkomsten.append({'naam':naam,'code':p.returncode,'seconden':round(time.monotonic()-begin,2),'opdracht':cmd,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()});(r/'queryafstemming44-diagnose-uitkomst.json').write_text(json.dumps(uitkomsten,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
