/** Toets de echte SDK-queryresolver en haar echte bronmetadata, zonder renderimitatie. */
import { readFileSync } from "node:fs";
import { afterEach, describe, expect, it, vi } from "vitest";
const bron = readFileSync("node_modules/@betteroffice/docx-react/dist/index.mjs", "utf8");
const metadata = readFileSync("node_modules/@betteroffice/docx-react/dist/chunk-LZ2DPBZ6.mjs", "utf8");
const start = bron.indexOf("var Ta=class"), eind = bron.indexOf(";function Ea(", start);
const ms = metadata.indexOf("var wi=new WeakMap;function QE("), me = metadata.indexOf("function qy(", ms);
const fs = bron.indexOf("function Fm("), fe = bron.indexOf("var Ta=class", fs);
if ([start, eind, ms, me, fs, fe].some(x => x < 0)) throw Error("Controleer de vastgezette queryresolver na een SDK-update");
const meta = new Function(`${metadata.slice(ms, me)};return {schrijf:QE,lees:e8}`)() as {
  schrijf(q: Query, versie: string): void; lees(q: Query): string | null;
};
type Query = { frameEpoch: number; isReady(): boolean };
type Resultaat = { status: string; queries: Query | null };
type Resolver = { current: Query | null; waiters: unknown[]; publish(q: Query): void; clear(): void;
  resolve(epoch?: number): Promise<Query | null>;
  resolveVersion(o: { version(): string | null; signal?: AbortSignal; maximumWaitMs?: number }): Promise<Resultaat> };
const Klass = new Function("b$1", "e", `${bron.slice(fs, fe)};${bron.slice(start, eind)};return Ta`)(
  (o: Record<string, unknown>, k: string, v: unknown) => { o[k] = v; }, meta.lees,
) as new () => Resolver;
function query(versie: string, epoch = 1, gereed = true) {
  const q = { frameEpoch: epoch, isReady: () => gereed }; meta.schrijf(q, versie); return q;
}
afterEach(() => { vi.useRealTimers(); });
describe("brongebonden afstemming van native invoer", () => {
  it("breekt af bij een andere sessie, scope of uitgeschakelde editor", () => {
    const begin = bron.indexOf("let Ke=useRef({session:u,enabled:t,mounted:true,nativeQuery:null"), einde = bron.indexOf("let _=useRef", begin);
    expect(begin).toBeGreaterThan(0);
    const voerUit = new Function("useRef", "u", "t", "r", `${bron.slice(begin, einde)};return Ke.current`);
    const sessie = {}, scope = {};
    for (const [u, t, r, verwacht] of [[sessie,true,scope,false],[{},true,scope,true],[sessie,false,scope,true],[sessie,true,{},true]] as const) {
      const c = new AbortController(), vorige = {session:sessie,enabled:true,mounted:true,nativeQuery:c,queryScope:scope};
      voerUit(() => ({current:vorige}), u, t, r); expect(c.signal.aborted).toBe(verwacht);
    }
  });

  it("activeert de nieuwe route alleen voor de eigen gemarkeerde oproep", async () => {
    const begin = bron.indexOf("se=useCallback((l=null,V)=>"), einde = bron.indexOf(";", begin);
    expect(begin).toBeGreaterThan(0); const r = new Klass(), q = query("oud"); r.publish(q);
    const lees = new Function("useCallback", "A", `return ${bron.slice(begin + 3, einde)}`)((f: unknown) => f, r);
    await expect(lees(null, {version: () => "nieuw"})).resolves.toBe(q);
    const c = new AbortController(); const p = lees(null, {openaec: true, version: () => "nieuw", signal:c.signal});
    c.abort(); await expect(p).resolves.toEqual({status:"cancelled",queries:null});
  });

  it("geeft een oude versie met een hogere frame-epoch nooit als gereed terug", async () => {
    vi.useFakeTimers(); const r = new Klass(); r.publish(query("oud", 999));
    const klaar = vi.fn(); const p = r.resolveVersion({ version: () => "nieuw" }).then(klaar);
    await Promise.resolve(); expect(klaar).not.toHaveBeenCalled();
    r.publish(query("oud", 1000)); await Promise.resolve(); expect(klaar).not.toHaveBeenCalled();
    const nieuw = query("nieuw", 1001); r.publish(nieuw); await p;
    expect(klaar).toHaveBeenCalledWith({ status: "ready", queries: nieuw }); expect(r.waiters).toHaveLength(0);
  });
  it("meldt bij een deadline geen oude querybron als succes", async () => {
    vi.useFakeTimers(); const r = new Klass(); r.publish(query("oud"));
    const p = r.resolveVersion({ version: () => "nieuw", maximumWaitMs: 25 });
    await vi.advanceTimersByTimeAsync(25); await expect(p).resolves.toEqual({ status: "timeout", queries: null });
    expect(r.waiters).toHaveLength(0);
  });
  it("ruimt wachten bij een volgende bronwijziging op", async () => {
    const r = new Klass(), c = new AbortController();
    const p = r.resolveVersion({ version: () => "nieuw", signal: c.signal }); c.abort();
    await expect(p).resolves.toEqual({ status: "cancelled", queries: null }); expect(r.waiters).toHaveLength(0);
  });
  it("annuleert als de eigenaar verdwijnt en houdt een nieuwe bron vrij", async () => {
    const r = new Klass(); let versie: string | null = "nieuw";
    const p = r.resolveVersion({ version: () => versie }); versie = null; r.publish(query("ander"));
    await expect(p).resolves.toEqual({ status: "cancelled", queries: null }); expect(r.waiters).toHaveLength(0);
  });
  it("geeft een onbeschikbare renderer vrij zonder een gereed frame te verzinnen", async () => {
    const r = new Klass(); const a = r.resolveVersion({ version: () => "a" }), b = r.resolveVersion({ version: () => "b" });
    r.clear(); await expect(a).resolves.toEqual({ status: "unavailable", queries: null });
    await expect(b).resolves.toEqual({ status: "unavailable", queries: null }); expect(r.waiters).toHaveLength(0);
  });
  it("behoudt de bestaande niet-brongebonden resolverroute", async () => {
    vi.useFakeTimers(); const r = new Klass(), oud = query("oud", 1); r.publish(oud);
    const p = r.resolve(2); await vi.advanceTimersByTimeAsync(250); await expect(p).resolves.toBe(oud);
  });
  it("wacht ook bij passende metadata tot de querybron gereed is", async () => {
    const r = new Klass(); r.publish(query("nieuw", 1, false));
    const p = r.resolveVersion({ version: () => "nieuw" }); expect(r.waiters).toHaveLength(1);
    const q = query("nieuw", 2); r.publish(q); await expect(p).resolves.toEqual({ status: "ready", queries: q });
  });
});
