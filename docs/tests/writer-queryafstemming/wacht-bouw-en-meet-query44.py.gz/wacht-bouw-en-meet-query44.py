from pathlib import Path
import time,hashlib,json,subprocess,shutil,os
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer'
pid=1502333
stat=Path(f'/proc/{pid}/stat')
start=stat.read_text().split(') ',1)[1].split()[19] if stat.exists() else None
print('Bestaande bouw observeren',pid,flush=True)
einde=time.monotonic()+2400
while stat.exists() and stat.read_text().split(') ',1)[1].split()[19]==start:
    if time.monotonic()>einde:raise TimeoutError('Bouw blijft actief; niet gestopt of opnieuw gestart')
    time.sleep(2)
log=(r/'queryafstemming44-bouw.log').read_text()
assert 'Built application at:' in log and 'Finished `release` profile' in log, 'Geen geslaagde bouw vastgesteld'
m=json.loads((r/'queryafstemming44-bronnen.json').read_text())
for p,h in m['bronbestanden'].items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==h,p
bron=repo/'src-tauri/target/release/open-office-studio';doel=r/'open-office-studio-45.44-queryafstemming'
assert not doel.exists();digest=hashlib.sha256(bron.read_bytes()).hexdigest()
assert digest!='3ea2fb22c4e938395e6e9a99b3d5d80f10772faaf9d29275621b9249d5df29af'
shutil.copy2(bron,doel);assert hashlib.sha256(doel.read_bytes()).hexdigest()==digest
m.update(programma=str(doel.relative_to(repo)),programma_sha256=digest,fase='Bouw geslaagd; fysieke vergelijkingsproef gestart')
(r/'queryafstemming44-bronnen.json').write_text(json.dumps(m,indent=2)+'\n')
compilers=[]
for p in Path('/proc').glob('[0-9]*/comm'):
    try:
        naam=p.read_text().strip()
        if naam in ['rustc','cargo','rust-lld','ld.lld','cc']:compilers.append((str(p.parent),naam))
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not compilers,compilers
print('Eigen ELF bevroren',digest,'; fysieke vergelijking starten',flush=True)
uit=subprocess.run(['python3',str(r/'voer-queryafstemming44-passieve-metingen.py')],cwd=repo)
print('Fysieke vergelijkingsproef beëindigd',uit.returncode,flush=True)
raise SystemExit(uit.returncode)
