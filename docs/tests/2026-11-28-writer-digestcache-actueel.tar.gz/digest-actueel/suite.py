from pathlib import Path
import subprocess,os,time,json
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';(p/'office-tests.log').rename(p/'office-tests-sigterm.log');cmd=['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','node_modules/vitest/vitest.mjs','run','--maxWorkers=2'];start=time.monotonic()
with(p/'office-tests.log').open('x')as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=proc.wait(timeout=480)
 except subprocess.TimeoutExpired:
  import signal
  os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=30);code=124
out={'procescode':code,'seconden':time.monotonic()-start,'opdracht':cmd,'default_vendor_kern':True,'eerste_run':{'procescode':143,'volledig_eindrapport':False,'reden_SIGTERM':'Niet vastgesteld; niet als geslaagd geteld.'}};(p/'suite-uitkomst.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));assert code==0
