import standaard from '../../../vite.config';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import type {Plugin} from 'vite';
const kandidaat=process.env.OOS_PROEF_VARIANT==='kandidaat';
function proefkern():Plugin{return {name:'eigen-digestkernproef',enforce:'pre',transform(code,id){
 if(!kandidaat||!id.endsWith('/src/tekst/gedeeld/nootKern.ts'))return;
 const oud='../../../vendor/tekstengine/docx_edit_bg.wasm';
 const nieuw='../../../.local/integratiecontrole/digest-productie/kandidaat/docx_edit_bg.wasm';
 if(code.split(oud).length!==2)throw Error('Kernbron niet herkenbaar');
 const bytes=readFileSync(new URL('../digest-productie/kandidaat/docx_edit_bg.wasm',import.meta.url));
 if(createHash('sha256').update(bytes).digest('hex')!=='6fec97d3c650a625c085e0a0bf52e59ecd0802bc0070c42f706b4e03b4ff91c4')throw Error('Proefkern wijkt af');
 console.log('Gecontroleerde eigen proefkern in',id);
 return {code:code.replace(oud,nieuw),map:null};
}}}
export default {...standaard,plugins:[proefkern(),...(standaard.plugins??[])],worker:{...standaard.worker,plugins:()=>[proefkern(),...(standaard.worker?.plugins?.()??[])]}};
