from pathlib import Path
import os,subprocess,json,hashlib,shutil
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';prev=r/'.local/integratiecontrole/digest-productie';tools=r/'.local/integratiecontrole/font-hergebruik/gereedschap';env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']};script=r/'scripts/bouw-tekstkern.py';archive=r/'.local/integratiecontrole/font-hergebruik/bron.tar.gz';rows=[];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();before=json.loads((prev/'bron-voor.json').read_text())
for mode,flags in [('standaard',[]),('expliciet',['--digestcache']),('zonder',['--zonder-digestcache'])]:
 src=p/('recept-'+mode);out=p/('recept-uit-'+mode);cmd=['python3',str(script),'--bronmap',str(src),'--uitvoer',str(out),'--bronarchief',str(archive),'--wasm-bindgen',str(tools/'bindgen/wasm-bindgen'),'--wasm-opt',str(tools/'binaryen/bin/wasm-opt'),'--alleen-voorbereiden']+flags
 res=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=120);(p/('recept-'+mode+'.log')).write_text(res.stdout+res.stderr);assert res.returncode==0,res.stderr
 expected={f:(sha(prev/'bron'/f)if mode!='zonder'else h)for f,h in before.items()}
 if mode!='zonder':expected['crates/docx-edit/src/digest_cache.rs']=sha(prev/'bron/crates/docx-edit/src/digest_cache.rs')
 actual={str(f.relative_to(src)):sha(f)for f in src.rglob('*')if f.is_file()};assert actual==expected
 again=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=10);assert again.returncode!=0 and 'bronmap bestaat al'in again.stderr+again.stdout
 assert {str(f.relative_to(src)):sha(f)for f in src.rglob('*')if f.is_file()}==expected
 rows.append({'variant':mode,'flags':flags,'procescode':0,'bronbestanden_exact':len(actual),'bronhergebruik_geweigerd':True,'voorbereid':json.loads((out/'voorbereid.json').read_text())})
for flags in [['--digestcache','--zonder-digestcache'],['--controle','--alleen-voorbereiden']]:
 res=subprocess.run(['python3',str(script),'--bronmap',str(p/'verboden-bron'),'--uitvoer',str(p/'verboden-uit')]+flags,env=env,capture_output=True,text=True);assert res.returncode==2 and not(p/'verboden-bron').exists()
mini=p/'verkeerde-basis';(mini/'scripts').mkdir(parents=True);(mini/'patches').mkdir();shutil.copyfile(script,mini/'scripts/bouw-tekstkern.py')
for f in ['tekstengine-nootnummering.json','tekstengine-nootnummering.patch','tekstengine-digestcache.json','tekstengine-digestcache.patch']:shutil.copyfile(r/'patches'/f,mini/'patches'/f)
meta=json.loads((mini/'patches/tekstengine-digestcache.json').read_text());meta['basisWasmSha256']='ongelijke-basis';(mini/'patches/tekstengine-digestcache.json').write_text(json.dumps(meta));res=subprocess.run(['python3',str(mini/'scripts/bouw-tekstkern.py'),'--bronmap',str(p/'verboden-bron'),'--uitvoer',str(p/'verboden-uit'),'--alleen-voorbereiden'],env=env,capture_output=True,text=True);assert res.returncode!=0 and 'andere basisbron'in res.stderr+res.stdout and not(p/'verboden-bron').exists()
report={'geslaagd':True,'bronvoorbereiding':rows,'conflicterende_vlaggen_geweigerd':True,'verkeerde_actieve_basis_geweigerd':True,'grens':'Default/expliciete bron bytegelijk aan reeds volledig tweemaal gebouwde cachekernbron. Deze beurt geen derde volledige Cargo/bindgen/opt-herbouw; variantkeuze en validatie gewijzigd, compilatiepad ongewijzigd.'};(p/'recept-test.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
