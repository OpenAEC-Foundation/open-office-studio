from pathlib import Path
import json,hashlib,stat
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();old=r/'.local/integratiecontrole/digest-productie'
refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==42
for row in json.loads((p/'desktop.json').read_text()):refs[row['programma']]=row['sha256']
assert len(refs)==44
for f,h in refs.items():assert sha(Path(f))==h,f
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
pins=json.loads((r/'.local/integratiecontrole/projectie-context-telling-herbouw/behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];meta=json.loads((r/'patches/tekstengine-digestcache.json').read_text());changed=[]
for f,h in pins.items():
 if sha(r/f)!=h:changed.append(f)
assert changed==['vendor/tekstengine/docx_edit_bg.wasm'];assert sha(r/changed[0])==meta['wasmSha256'];assert sha(old/'basis/docx_edit_bg.wasm')==meta['basisWasmSha256']==pins[changed[0]]
bundle=json.loads((r/'.local/integratiecontrole/projectie-context-telling-herbouw/standaardbundel.json').read_text())
for f,v in bundle.items():
 q=r/'dist'/f;s=q.stat();assert sha(q)==v['sha256']and stat.S_IMODE(s.st_mode)==v['mode']and s.st_mtime_ns==v['mtime_ns'],f
out={'referentiepaden44_sha256_exact':True,'standaarddist529_byte_mode_mtime_exact':len(bundle)==529,'canonieke_pinnen14_exact':len(pins)-len(changed)==14,'bewuste_productovergang':{'bestand':changed[0],'oud_sha256':meta['basisWasmSha256'],'nieuw_sha256':meta['wasmSha256'],'oude_kern_exact_bewaard':str(old/'basis/docx_edit_bg.wasm')},'grens':'Vendor-editkern is bewust vervangen; niet beweren dat alle 15 eerdere bronpinnen onveranderd zijn. Referentie-ELFs en oude voorraadkern behouden; eigen nieuwe bundels/ELFs toegevoegd. Rootcheckout alleen bewijsdocumentatie, bestaande .claude/ ongemoeid.'};(p/'behoud.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
