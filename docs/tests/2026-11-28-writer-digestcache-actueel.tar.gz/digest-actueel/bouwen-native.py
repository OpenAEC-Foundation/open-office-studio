from pathlib import Path
import subprocess,os,json,hashlib,shutil,time,signal
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();results=[]
refs=json.loads((r/'.local/integratiecontrole/digest-productie/referenties-nacontrole.json').read_text());assert len(refs)==42
for f,h in refs.items():assert sha(Path(f))==h
assert subprocess.check_output(['git','status','--porcelain'])==b''
front=json.loads((p/'frontend-bouw.json').read_text());assert len(front)==2 and all(x['procescode']==0 for x in front)
target=p/'native-target';assert not target.exists();shutil.copytree(r/'.local/integratiecontrole/digest-productie/native-target',target)
for mode in ['basis','kandidaat']:
 config={'build':{'frontendDist':str(p/('dist-'+mode))}};env={**os.environ,'TAURI_CONFIG':json.dumps(config),'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']};cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];start=time.monotonic()
 with(p/('native-bouw-'+mode+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   while proc.poll()is None:
    time.sleep(1)
    if time.monotonic()-start>1200 or shutil.disk_usage(p).free<10*1024**3:raise RuntimeError('Bouwgrens bereikt')
  finally:
   if proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=30)
 row={'variant':mode,'code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd,'TAURI_CONFIG':config};assert proc.returncode==0
 out=p/('open-office-studio-actueel-'+mode);shutil.copy2(target/'release/open-office-studio',out);row.update(programma=str(out),sha256=sha(out));results.append(row);(p/'desktop.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
for f,h in refs.items():assert sha(Path(f))==h
