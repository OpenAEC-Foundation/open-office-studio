from pathlib import Path
import json,collections
p=Path(__file__).resolve().parent;d=json.loads((p/'route-een/rapport.json').read_text());m=d['lange_invoer'];end=m['laatste_keyup_ms']+m['laatste_keyup_tot_frame_ms'];start=end-m['begin_tot_frame_ms'];groups=[];current=[]
for v in d['bronlezer_eind']['records']:
 if not(start<=v['start']<=v['end']<=end)or not(v['body']or v['method']=='applyLocalUpdate'):continue
 if v['method']=='applyLocalUpdate':
  if current:groups.append(current)
  current=[v['method']]
 else:current.append(v['method'])
if current:groups.append(current)
c=collections.Counter(tuple(g)for g in groups);out={'bronrapport':'route-een/rapport.json','programma_sha256':d['programma_sha256'],'venster_afgeleid':{'begin':start,'eind':end},'groepen':[{'volgorde':list(k),'aantal':v}for k,v in c.items()],'grens':'Actuele kandidaatfrontend, extra diagnostische opname; geen gewone ABBA, exclusieve Rust-CPU of bewijs van cachepromoties.'};(p/'spans-volgorde.json').write_text(json.dumps(out,indent=2)+'\n')
f=p/'volgende-stap.json';next=json.loads(f.read_text());next['volgorde_actuele_native_proef']=out['groepen'];next['vervolg']='Actuele volgorde bevestigt paragraphSpans vóór digests. Toets gedeelde unitmaterialisatie vóór de digestlezing alleen met bewezen warme promotie, exact hetzelfde Doc/epoch en volledige grenzencontrole. Koude of onzekere cache en ontbrekende/te lange para-id/trailing unit moeten volledig terugvallen. Corpus en echte pending-/Undo-/metadata-/foutproeven herhalen vóór Wasm/native proef; geen onveilige unitpointercache.';f.write_text(json.dumps(next,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out))
