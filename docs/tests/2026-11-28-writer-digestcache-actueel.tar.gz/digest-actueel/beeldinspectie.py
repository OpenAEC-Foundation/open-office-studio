from pathlib import Path
from PIL import Image,ImageChops,ImageDraw
import json
p=Path(__file__).resolve().parent;regions=[('venstericoon',(0,0,40,36)),('zoomschuif',(1100,980,1150,1000)),('cursor',(540,315,570,355)),('invoercursor',(1030,935,1045,960))];rows=[];sheet=Image.new('RGB',(1000,340),'white');draw=ImageDraw.Draw(sheet);y=0
for label,name in [('b-twee','invoer-redo.png'),('schema3-a','invoer-redo.png'),('b-een','nieuw-na-laat-antwoord.png')]:
 a=Image.open(p/'native-a-een'/name).convert('RGB');b=Image.open(p/('native-'+label)/name).convert('RGB');draw.text((4,y),label+' '+name,fill='black');x=10
 for title,box in regions:
  draw.text((x,y+15),title,fill='black');aa=a.crop(box).resize(((box[2]-box[0])*2,(box[3]-box[1])*2));bb=b.crop(box).resize(aa.size);sheet.paste(aa,(x,y+30));sheet.paste(bb,(x+aa.width+5,y+30));x+=aa.width*2+25
 y+=110
sheet.save(p/'beeldinspectie.png')
for row in json.loads((p/'documenten-beelden.json').read_text())['beelden']:
 a=Image.open(p/'native-a-een'/row['beeld']).convert('RGB');b=Image.open(p/('native-'+row['label'])/row['beeld']).convert('RGB');diff=ImageChops.difference(a,b);outside=0
 red,green,blue=diff.split();mask=ImageChops.lighter(ImageChops.lighter(red,green),blue)
 for index,value in enumerate(mask.getdata()):
  if value:
   xx=index%diff.width;yy=index//diff.width
   if not any(box[0]<=xx<box[2]and box[1]<=yy<box[3]for _,box in regions):outside+=1
 assert outside==0,row;rows.append({**row,'verschillen_buiten_vier_onderzochte_UI_regios':outside})
(p/'beeldinspectie.json').write_text(json.dumps({'beeldparen':rows,'regios':regions,'grens':'Volledige onbewerkte beelden eerder pixelgewijs vergeleken. Uitsneden alleen voor inspectie; nulmaskers of gewijzigde acceptatiebeelden.'},indent=2)+'\n')
