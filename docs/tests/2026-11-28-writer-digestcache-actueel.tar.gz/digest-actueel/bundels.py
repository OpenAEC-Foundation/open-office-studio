from pathlib import Path
from collections import Counter
import hashlib,json,re
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda f:json.loads((p/f).read_text());a=read('bundel-basis.json');b=read('bundel-kandidaat.json')
pattern=rb'-[A-Za-z0-9_-]{8}(?=\.(?:js|wasm|css)(?:["\x27?#/\s]|$))'
def normalize(data):return re.sub(pattern,b'-HASH',data)
def signatures(mode,files):
 rows=[]
 for f,h in files.items():
  data=(p/('dist-'+mode)/f).read_bytes();assert sha(data)==h
  if 'docx_edit_bg' in f and f.endswith('.wasm'):rows.append(('editkern','apart getoetst'));continue
  if f.endswith(('.js','.html','.css')):data=normalize(data)
  rows.append((normalize(f.encode()).decode(),sha(data)))
 return Counter(rows)
assert signatures('basis',a)==signatures('kandidaat',b),'Meer dan kern of hashverwijzingen veranderd'
expected={'basis':'737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9','kandidaat':'6fec97d3c650a625c085e0a0bf52e59ecd0802bc0070c42f706b4e03b4ff91c4'}
for mode in expected:
 files=read('bundel-'+mode+'.json');edit=[h for f,h in files.items()if 'docx_edit_bg' in f];assert edit==[expected[mode]]
standard=json.loads((r/'.local/integratiecontrole/projectie-context-telling-herbouw/standaardbundel.json').read_text());different=[f for f,v in standard.items()if a.get(f)!=v['sha256']]
changed={mode:[{'pad':f,'sha256':h}for f,h in files.items()if other.get(f)!=h]for mode,files,other in [('basis',a,b),('kandidaat',b,a)]}
result={'geslaagd':True,'bestanden_per_variant':len(a),'gewijzigde_paden':changed,'standaarddist_verschillende_paden':different,'grens':'Actuele Vite-bronnen zonder private projectie-contextpatch. Multisets van pad plus bytes exact na normalisatie van achttekens inhoudshash in js/wasm/css-assetverwijzingen. Alleen editkern afzonderlijk vergeleken. Bestaande standaarddist niet vervangen.'}
(p/'bundelvergelijking.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'bestanden':len(a),'gewijzigde_paden':{k:len(v)for k,v in changed.items()},'standaarddist_verschillende_paden':len(different)}))
