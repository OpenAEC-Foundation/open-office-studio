from pathlib import Path
import os,subprocess,json,hashlib,time
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();old=r/'.local/integratiecontrole/font-rij-native';helper=old/'proef-rijk.py';pins=json.loads((old/'harnas.json').read_text());assert sha(helper)==pins['rijk']['proef_sha256'];build=json.loads((p/'desktop.json').read_text());assert len(build)==2 and all(x['code']==0 for x in build)
tools=old/'gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu')};results=[]
for label,mode,schema in [('a-een','basis',2),('b-een','kandidaat',2),('b-twee','kandidaat',2),('a-twee','basis',2),('schema3-a','basis',3),('schema3-b','kandidaat',3)]:
 exe=p/('open-office-studio-actueel-'+mode);assert sha(exe)==next(v['sha256']for v in build if v['variant']==mode);out=p/('native-'+label);assert not out.exists();cmd=['/usr/bin/python3',str(helper),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(out)];print('START',label,flush=True);start=time.monotonic()
 with(p/('native-'+label+'.log')).open('x')as log:
  try:code=subprocess.run(cmd,env={**env,'OFFICE_TEST_JOURNAAL':'1' if schema==3 else '0'},stdout=log,stderr=subprocess.STDOUT,timeout=450).returncode
  except subprocess.TimeoutExpired:code=124
 report=json.loads((out/'rapport.json').read_text())if(out/'rapport.json').exists()else{'geslaagd':False,'fout':'Geen eindrapport'};item={'label':label,'variant':mode,'schema':schema,'code':code,'geslaagd':report['geslaagd'],'fout':report.get('fout'),'seconden':time.monotonic()-start,'programma_sha256':sha(exe),'helper_sha256':sha(helper),'invoer':report.get('lange_invoer'),'opdracht':cmd};results.append(item);(p/'native-ronden.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print('EINDE',json.dumps(item),flush=True);assert code==0 and report['geslaagd'],label
