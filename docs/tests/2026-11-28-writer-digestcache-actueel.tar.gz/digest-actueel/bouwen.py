from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/digest-actueel';node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';results=[]
assert subprocess.check_output(['git','status','--porcelain'])==b''
for mode in ['basis','kandidaat']:
 out=p/('dist-'+mode);assert not out.exists();cmd=[node,'node_modules/vite/bin/vite.js','build','--config',str(p/'vite.config.ts'),'--outDir',str(out)];start=time.monotonic()
 with(p/('vite-'+mode+'.log')).open('x')as log:
  proc=subprocess.run(cmd,env={**os.environ,'OOS_PROEF_VARIANT':mode},stdout=log,stderr=subprocess.STDOUT,timeout=600)
 row={'variant':mode,'procescode':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd};results.append(row);(p/'frontend-bouw.json').write_text(json.dumps(results,indent=2)+'\n');assert proc.returncode==0
 files={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest()for f in out.rglob('*')if f.is_file()};(p/('bundel-'+mode+'.json')).write_text(json.dumps(files,indent=2)+'\n');print(mode,len(files),flush=True)
