function officeCreateInputActivity(schedule, report) {
  const states = new WeakMap(), wrappers = new WeakMap();
  const state = session => {
    let s = states.get(session);
    if (!s) { s = { count: 0, queued: false, listeners: new Set() }; states.set(session, s); }
    return s;
  };
  const wake = s => {
    if (s.count || s.queued || !s.listeners.size) return;
    s.queued = true;
    schedule(() => {
      s.queued = false;
      if (s.count) return;
      for (const callback of [...s.listeners]) {
        if (!s.listeners.has(callback)) continue;
        try { callback(); } catch (error) { report(error); }
      }
    });
  };
  const begin = session => {
    const s = state(session); s.count++;
    let closed = false;
    return () => { if (closed) return; closed = true; s.count--; wake(s); };
  };
  return {
    busy: session => !!session && (states.get(session)?.count ?? 0) > 0,
    subscribe(session, callback) {
      if (!session) return () => {};
      const s = state(session); s.listeners.add(callback);
      return () => s.listeners.delete(callback);
    },
    wrap(fn) {
      if (!fn) return null;
      let wrapper = wrappers.get(fn);
      if (!wrapper) {
        wrapper = function(...args) {
          const end = begin(args[0]);
          try {
            return Promise.resolve(fn.apply(this, args)).then(value => { end(); return value; }, error => { end(); throw error; });
          } catch (error) { end(); throw error; }
        };
        wrappers.set(fn, wrapper);
      }
      return wrapper;
    }
  };
}
// Eén taakwissel na de volledige callback, inclusief bronmutatie en selectie.
function officeInputTask(callback) {
  const channel = new MessageChannel();
  channel.port1.onmessage = () => { channel.port1.close(); channel.port2.close(); callback(); };
  channel.port2.postMessage(null);
}
const officeInputActivity = officeCreateInputActivity(officeInputTask, error => console.error('[Writer invoer-layout]', error));
