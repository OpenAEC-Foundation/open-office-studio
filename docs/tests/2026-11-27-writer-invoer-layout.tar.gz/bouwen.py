from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,signal,stat,fcntl,re
r=Path.cwd();p=r/'.local/integratiecontrole/invoer-layout';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();lock=(p/'bouwslot').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert subprocess.check_output(['git','status','--porcelain'])==b''
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';refs=json.loads((r/'.local/integratiecontrole/gedeelde-aanvraag/referenties-nacontrole.json').read_text());pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];bundle=json.loads((old/'standaardbundel.json').read_text());present={f:h for f,h in refs.items()if Path(f).exists()};assert len(present)==33
for f,h in present.items():assert sha(Path(f))==h
for f,h in pins.items():assert sha(r/f)==h
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
(p/'referenties-voor.json').write_text(json.dumps(present,indent=2)+'\n');head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();target=r/'.local/integratiecontrole/font-rij-native/target';assert target.exists();assert not(p/'standaarddist').exists();free=shutil.disk_usage(r).free;assert free>20*1024**3
cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];env={**os.environ,'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']};(r/'dist').rename(p/'standaarddist');(p/'dist').rename(r/'dist');start=time.monotonic();minimum=free;proc=None;result={};reason=None
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in()).throw(KeyboardInterrupt()))
try:
 with(p/'desktop.log').open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (p/'actief.json').write_text(json.dumps({'status':'bouw_actief','supervisor_pid':os.getpid(),'cargo_pid':proc.pid,'target':str(target),'standaarddist_tijdelijk':str(p/'standaarddist'),'start_vrije_bytes':free,'stopvloer_gib':10,'max_seconden':900},indent=2)+'\n')
  while proc.poll()is None:
   time.sleep(1);minimum=min(minimum,shutil.disk_usage(r).free)
   if set(re.findall(r'^\s*Compiling ([^ ]+)',(p/'desktop.log').read_text(),re.M)) - {'open-office-studio'} or minimum<10*1024**3 or time.monotonic()-start>900:reason='Onverwachte dependencyherbouw, schijfvloer of bouwtijd overschreden';break
  if reason:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=20)
 result={'code':proc.returncode,'reden':reason,'seconden':time.monotonic()-start,'minimum_vrije_bytes':minimum,'start_vrije_bytes':free,'opdracht':cmd,'basis_head':head,'bestaande_eigen_bouwcache':True,'target':str(target)}
 if proc.returncode==0:
  exe=target/'release/open-office-studio';out=p/'open-office-studio-invoer-layout';assert not out.exists();shutil.copy2(exe,out);result.update(programma=str(out),programma_sha256=sha(out))
except BaseException as e:
 result.update(code=-1,fout=repr(e),seconden=time.monotonic()-start)
 raise
finally:
 if proc is not None and proc.poll()is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 (r/'dist').rename(p/'dist');(p/'standaarddist').rename(r/'dist')
 for f,v in bundle.items():
  q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
 for f,h in present.items():assert sha(Path(f))==h
 for f,h in pins.items():assert sha(r/f)==h
 assert subprocess.check_output(['git','status','--porcelain'])==b'';assert head==subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
 result.update(standaarddist529_byte_mode_mtime_hersteld=True,referenties33_exact=True,bronpinnen15_exact=True)
 (p/'desktop.json').write_text(json.dumps(result,indent=2)+'\n');(p/'actief.json').write_text(json.dumps({'status':'bouw_klaar'if result.get('code')==0 else 'bouw_afgekeurd','resultaat':result},indent=2)+'\n')
print(json.dumps(result));raise SystemExit(result['code'])
