import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import ts from 'typescript';
const p='.local/integratiecontrole/fragmentafnemers/';
const bronnen=[];
function functies(pad,namen,omgeving={}) {
 const bron=fs.readFileSync(pad,'utf8');const ast=ts.createSourceFile(pad,bron,ts.ScriptTarget.Latest,true,pad.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 const nodes=ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&namen.includes(n.name?.text));assert.equal(nodes.length,namen.length);
 const text=nodes.map(n=>n.getText(ast).replace(/^export /,'')).join('\n');
 bronnen.push({pad,sha256:crypto.createHash('sha256').update(bron).digest('hex'),functies:namen,uitgevoerd:text});
 const js=ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
 return Function(...Object.keys(omgeving),js+';return {'+namen.join(',')+'};')(...Object.values(omgeving));
}
const metaApi=functies('.local/integratiecontrole/font-hergebruik/bron/packages/docx/src/yrs/layoutMeta.ts',['layoutMetaSummary']);
const liniaal=functies('src/tekst/liniaal/geometrie.ts',['paginaMetPositie']);
const tabel=functies('src/tekst/tabel/logica.ts',['tekstbreedteOpPagina'],{TWIPS_PER_PX:15});
const selectie=functies('src/tekst/paginabereik.ts',['paginaSelectie','zichtbarePaginaElementen'],{getComputedStyle:()=>({visibility:'visible'})});
const spelling=functies('src/spelling/tekst/Golflijnen.tsx',['zichtbaarBereik','bereikInBeeld'],{SCROLLVLAK:'.vlak',MARGE:400,window:{innerHeight:900},getComputedStyle:()=>({visibility:'visible'}),...selectie});
let layout;const acties=[];const ref={focus:()=>acties.push('focus'),scrollToPage:n=>acties.push(['pagina',n])};
const engine=()=>({weergave:{getLayout:()=>layout,setSelection:n=>acties.push(['selectie',n]),scrollToPosition:n=>acties.push(['positie',n])}});
const navigatie=functies('src/tekst/zoeken/ganaar.ts',['paginas','naarPositie','gaNaarPagina','regelDoelen'],{engine,i18next:{t:(_k,{n})=>String(n)}});
const rect={top:0,bottom:800,width:600};const pageElement={parentElement:null,getBoundingClientRect:()=>rect};const vlak={getBoundingClientRect:()=>rect,querySelectorAll:()=>[pageElement]};const laag={closest:()=>vlak};
const sessie={editor:()=>({getEditorRef:()=>({getLayout:()=>layout})})};
const full={pages:[{
 number:1,size:{w:600,h:800},margins:{left:50,right:50},
 fragments:[{kind:'paragraph',pmStart:10,pmEnd:30,
 resolvedLines:[{segments:[{run:{pmStart:12}}]}]}]
}],partial:false};
const shell={...full,pages:full.pages.map(x=>({...x,fragments:[]}))};
const summary=metaApi.layoutMetaSummary({layoutShell:JSON.stringify(shell)});
const checks=[
 ['liniaal-pagina',()=>liniaal.paginaMetPositie(layout.pages,15),0,-1],
 ['tabel-sectiebreedte',()=>tabel.tekstbreedteOpPagina(layout.pages,15),7500,null],
 ['paginanavigatie',()=>{acties.length=0;navigatie.gaNaarPagina(ref,1);return structuredClone(acties)},[['selectie',12],'focus',['pagina',1]],[['pagina',1]]],
 ['regelnavigatie',()=>navigatie.regelDoelen(ref).length,1,0],
 ['zichtbaar-spellingsbereik',()=>spelling.bereikInBeeld(sessie,laag),[10,30],null],
];
const resultaten=[];
for(const [naam,run,goed,leeg]of checks){layout=full;assert.deepEqual(run(),goed);layout=summary;assert.throws(run,/fragments.*worker/);layout=shell;assert.deepEqual(run(),leeg);resultaten.push({naam,volledige_layout:goed,compact:'werpt fragmentfout',lege_fragmenten:leeg});}
layout=full;assert.equal(liniaal.paginaMetPositie(layout.pages,null),-1);assert.equal(tabel.tekstbreedteOpPagina(layout.pages,null),null);layout=summary;assert.equal(liniaal.paginaMetPositie(layout.pages,null),-1);assert.equal(tabel.tekstbreedteOpPagina(layout.pages,null),null);
fs.writeFileSync(p+'contract-proef.json',JSON.stringify({geslaagd:true,resultaten,bronfuncties:bronnen,grenzen:['Werkelijke ongewijzigde functies via TypeScript AST geëxtraheerd;één gecontroleerde pagina,editor/DOM-referenties gecontroleerd.','Geen volledige SDK/React/native/GUI/beeld/snelheidsproef;geen nieuwe productvariant.','Lege fragmenten veroorzaken stille functieverliezen en zijn geen terugval.']},null,2)+'\n');
console.log('Vijf volledige-layoutreferenties exact;vijf compacte fragmentfouten;vijf stille lege-fragmentafwijkingen bevestigd.');
