(()=>{
const s=api().getEditorRef().getYrsSession(),t=window.__TAURI_INTERNALS__,herstel=[],aanvragen=[],mutaties=[];
if(!t||typeof t.invoke!=='function')throw Error('Native transport ontbreekt');
const oorsprong=performance.now();let lopend=0;
function vervang(o,n,f){const d=Object.getOwnPropertyDescriptor(o,n);if(!d||typeof d.value!=='function'||(!d.writable&&!d.configurable))throw Error('Niet meetbaar: '+n);Object.defineProperty(o,n,{...d,value:f(d.value)});herstel.push(()=>Object.defineProperty(o,n,d));}
for(const n of ['applyLocalUpdate','encodeStateAsUpdate','setSelection','resolveStickyPosition','encodeStickyPosition'])vervang(s,n,orig=>function(...args){const begin=performance.now();try{return Reflect.apply(orig,this,args)}finally{if(mutaties.length<4000)mutaties.push({naam:n,start:begin-oorsprong,ms:performance.now()-begin})}});
window._stopLezers=()=>{for(const f of herstel.reverse())f();delete window._stopLezers;if(lopend)throw Error('Native aanvragen nog niet voltooid');return {aanvragen,mutaties,hersteld:true,grens:'Alleen synchrone bronmutatie, momentopname, selectie en cursorbinding; native transport is in deze runtime niet overschrijfbaar en wordt niet gemeten. Inclusieve tijden, geen volledige CPU- of stille snelheidsvergelijking.'}};return true;
})()
