from pathlib import Path
import gzip,json,hashlib
p=Path(__file__).resolve().parent;before=gzip.decompress((p/'werker-voor.js.gz').read_bytes()).decode();after=gzip.decompress((p/'werker-na.js.gz').read_bytes()).decode();a=before.index('function Ea(');b=before.index('function hg()',a);part=before[a:b];pairs=json.load(open(p/'wijzigingen.json'))
for x in pairs:assert part.count(x['voor'])==1;part=part.replace(x['voor'],x['na'],1)
assert before[:a]+part+before[b:]==after==(p/'dist/assets/chunk-Q7OC7M5Q-BzppsI5m.js').read_text();bad=p/'mislukte-voorbereiding/dist/assets/chunk-Q7OC7M5Q-BzppsI5m.js';assert bad.read_text()==before;r={'exacte_vervangingen':len(pairs),'uitsluitend_binnen_Ea':True,'voor_sha256':hashlib.sha256(before.encode()).hexdigest(),'na_sha256':hashlib.sha256(after.encode()).hexdigest(),'afgekeurde_voorbereiding_heeft_geen_JS_gewijzigd':True};(p/'wijzigingscontrole.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
