(() => {
  "use strict";
  const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');
  if(!el)throw Error('Geen eigen actieve teksteditor');
  const begin=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))],gevonden=new Set(),bezocht=new Set(),stapel=[begin];
  for(let f=begin?.return;f;f=f.return)stapel.push(f);
  while(stapel.length){
    const f=stapel.pop();if(!f||bezocht.has(f))continue;bezocht.add(f);
    if(bezocht.size>12000)throw Error('Te grote eigen editorboom');
    if(f.child)for(let c=f.child;c;c=c.sibling)stapel.push(c);
    for(let h=f.memoizedState,n=0;h&&n<1500;n++,h=h.next)
      for(const v of [h.memoizedState,h.memoizedState?.current])
        if(v&&typeof v.admit==='function'&&typeof v.flush==='function'&&typeof v.captureInteractionEpoch==='function'&&Number.isSafeInteger(v.depth)&&Array.isArray(v.recentFailures))gevonden.add(v);
  }
  if(gevonden.size!==1)throw Error('Verwacht precies één eigen invoerwachtrij, gevonden: '+gevonden.size);
  const q=[...gevonden][0],oud=q.admit,trace=[];
  q.admit=function(taak,...rest){
    if(trace.length>=10000)throw Error('Eigen wachtrijprobe overschrijdt grens');
    const m={id:trace.length,toelatingMs:performance.now(),diepte:this.depth,rapportage:rest[0]};trace.push(m);
    const ingepakt=function(...args){m.startMs=performance.now();try{return taak.apply(this,args)}finally{m.synchroneTerugkeerMs=performance.now()}};
    return oud.call(this,ingepakt,...rest);
  };
  window._wachtrijProbe={trace,stop(){q.admit=oud;return trace},referentie:q};
  return {gevonden:gevonden.size,diepte:q.depth,bezochteFibers:bezocht.size};
})()
