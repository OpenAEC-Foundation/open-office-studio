(()=>{
 'use strict';
 if(window._werkerProbe)throw Error('Werkermeting bestaat al');
 const proto=Worker.prototype,oud=Object.getOwnPropertyDescriptor(proto,'postMessage'),fn=proto.postMessage;
 if(typeof fn!=='function'||!oud?.configurable)throw Error('Werkermethode niet veilig te volgen');
 const regels=[],werkers=new Map();let actief=true,overgeslagen=0;
 const waarde=(o,k)=>o&&Object.getOwnPropertyDescriptor(o,k)?.value;
 function voeg(r){if(!actief)return;if(regels.length<4096)regels.push(r);else overgeslagen++}
 function meta(o){
  const r={};for(const k of ['id','type','ok']){const v=waarde(o,k);if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')r[k]=typeof v==='string'?v.slice(0,80):v}
  const saved=waarde(o,'saved'),updates=waarde(o,'updates');
  if(saved instanceof ArrayBuffer)r.bewaarbytes=saved.byteLength;
  if(Array.isArray(updates))r.updates=updates.length;
  for(const k of ['commandFrame','caret','collabUpdates'])if(waarde(o,k))r[k]=true;
  return r;
 }
 const wrapper={postMessage(...args){
  if(!actief)return Reflect.apply(fn,this,args);
  let nr=werkers.get(this)?.nr;
  if(!nr&&werkers.size<8){nr=werkers.size+1;const luister=e=>{try{voeg({richting:'ontvangst',werker:nr,tijd:performance.now(),...meta(e.data)})}catch{}};this.addEventListener('message',luister,true);werkers.set(this,{nr,luister})}
  try{voeg({richting:'verzending',werker:nr??null,tijd:performance.now(),...meta(args[0])})}catch{}
  return Reflect.apply(fn,this,args);
 }}.postMessage;
 Object.defineProperty(proto,'postMessage',{...oud,value:wrapper});
 window._werkerProbe={stop(){actief=false;for(const [w,x]of werkers)w.removeEventListener('message',x.luister,true);const hersteld=proto.postMessage===wrapper;if(hersteld)Object.defineProperty(proto,'postMessage',oud);return {regels,overgeslagen,hersteld,werkers:werkers.size,grens:4096,werkergrens:8,geen_extra_aanvragen:true}}};
 return {grens:4096,werkergrens:8};
})()
