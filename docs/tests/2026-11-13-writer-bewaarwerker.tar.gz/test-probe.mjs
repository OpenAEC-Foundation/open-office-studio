import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const bron=fs.readFileSync(new URL('probe.js',import.meta.url),'utf8');let proeven=0;
function maak(groepsantwoord, extra={}){let klok=0,rafId=0,cancel,off=0,observer,aanroepen=0;const events=new Map(),ontvangen=[],antwoord={},promise=Promise.resolve(antwoord),fout=new Error('eigen fout');
 const proto={readParagraphs(...args){aanroepen++;ontvangen.push([this,args]);if(args[0]==='fout')throw fout;return antwoord}};
 const doel=Object.assign(Object.create(proto),{applyLocalUpdate(){aanroepen++;return antwoord},setSelection(){aanroepen++},tablePayload(){aanroepen++;return antwoord},readStories(){aanroepen++;return groepsantwoord??promise},onUpdate(fn){observer=fn;return()=>{off++}}});
 const publiek={save(...args){ontvangen.push([this,args]);if(args[0]==='fout')throw fout;return promise},flushPendingInput(){return promise},readParagraphs(...args){ontvangen.push([this,args]);if(args[0]==='fout')throw fout;return promise}};const publiekOrigineel=Object.getOwnPropertyDescriptors(publiek);let actueelPubliek=publiek;const oude=Object.getOwnPropertyDescriptors(doel);const w={addEventListener(n,fn){events.set(n,fn)},removeEventListener(n,fn){assert.equal(events.get(n),fn);events.delete(n)}};
 Object.assign(w,extra);const c=vm.createContext({window:w,sessie:()=>doel,api:()=>actueelPubliek,performance:{now:()=>++klok},requestAnimationFrame:fn=>{c.frame=fn;return ++rafId},cancelAnimationFrame:id=>{cancel=id},Reflect,Error,Promise});vm.runInContext(bron,c);
 return {wisselApi:p=>{actueelPubliek=p},doel,publiek,publiekOrigineel,w,oude,antwoord,promise,fout,events,ontvangen,observer:()=>observer(),get off(){return off},get calls(){return aanroepen},frame:()=>c.frame(),get cancel(){return cancel}};
}
{
 const m=maak(),args=['tekst',{eigen:true}];assert.equal(m.doel.readParagraphs(...args),m.antwoord);assert.equal(m.ontvangen[0][0],m.doel);assert.equal(m.ontvangen[0][1][1],args[1]);proeven++;
 assert.equal(m.doel.readStories(),m.promise);proeven++;
 assert.throws(()=>m.doel.readParagraphs('fout'),e=>e===m.fout);proeven++;
 const n=m.calls;m.observer();assert.equal(m.calls,n);proeven++;
 m.events.get('keyup')({type:'keyup',key:'A',timeStamp:12});m.frame();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(m.off,1);assert.equal(m.events.size,0);assert.equal(m.doel.readParagraphs,Object.getPrototypeOf(m.doel).readParagraphs);assert.equal(Object.hasOwn(m.doel,'readParagraphs'),false);for(const [k,d]of Object.entries(m.oude))assert.deepEqual(Object.getOwnPropertyDescriptor(m.doel,k),d);proeven++;
 assert(r.regels.some(x=>x.soort==='onUpdate'));assert(r.regels.some(x=>x.soort==='keyup'));assert(r.regels.some(x=>x.soort==='rAF'));proeven++;
}
{const m=maak(),eigen=()=>7;m.doel.tablePayload=eigen;const r=m.w._publicatieProbe.stop();assert.equal(r.hersteld,false);assert.equal(m.doel.tablePayload,eigen);proeven++;}
{const m=maak();for(let i=0;i<8300;i++)assert.equal(m.doel.applyLocalUpdate(),m.antwoord);const r=m.w._publicatieProbe.stop();assert.equal(r.regels.length,8192);assert.equal(r.overgeslagen,108);assert(r.hersteld);proeven++;}
{ const m=maak(),oud=m.publiek.readParagraphs; assert.equal(m.publiek.readParagraphs('eigen'),m.promise);assert.equal(m.ontvangen[0][0],m.publiek);assert.throws(()=>m.publiek.readParagraphs('fout'),e=>e===m.fout);for(let i=0;i<20;i++)m.publiek.readParagraphs();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(r.aanroepers.filter(x=>x.label==='openbaar.readParagraphs').length,4);assert.notEqual(m.publiek.readParagraphs,oud);assert.deepEqual(Object.getOwnPropertyDescriptors(m.publiek),m.publiekOrigineel);proeven++; }

{const m=maak(),vreemd=()=>m.antwoord;m.publiek.readParagraphs=vreemd;const r=m.w._publicatieProbe.stop();assert.equal(r.hersteld,false);assert.equal(m.publiek.readParagraphs,vreemd);proeven++;}


{const antwoord={ok:true,truncated:false,stories:[{story:'body'}]},m=maak(antwoord),req={stories:['body']};for(let i=0;i<70;i++)assert.equal(m.doel.readStories(req),antwoord);const r=m.w._publicatieProbe.stop();assert.equal(r.leesgroepen.length,64);assert.equal(r.leesgroepen[0].gevraagd,1);assert.equal(r.leesgroepen[0].ontvangen,1);assert.equal(r.leesgroepen[0].truncated,false);proeven++;}
{let getters=0;const req={get stories(){getters++;return ['body']}},m=maak({ok:true,truncated:true,stories:[]});m.doel.readStories(req);assert.equal(getters,0);const r=m.w._publicatieProbe.stop();assert.equal(r.leesgroepen[0].gevraagd,null);assert.equal(r.leesgroepen[0].truncated,true);proeven++;}

{const m=maak(),p={readParagraphs(){return m.promise}},d=Object.getOwnPropertyDescriptors(p);m.wisselApi(p);m.frame();assert.equal(p.readParagraphs(),m.promise);const r=m.w._publicatieProbe.stop();assert.equal(r.oorspronkelijke_ref_nog_actueel,false);assert.equal(r.aantal_nieuwe_refs,1);assert.equal(r.aanroepers.filter(x=>x.label==='actueel.readParagraphs').length,1);assert.deepEqual(Object.getOwnPropertyDescriptors(p),d);proeven++;}
{
 const m=maak(),args=[{eigen:true}],fn=m.publiek.save;
 assert.equal(m.publiek.save(...args),m.promise);assert.equal(m.ontvangen[0][0],m.publiek);assert.equal(m.ontvangen[0][1][0],args[0]);
 assert.throws(()=>m.publiek.save('fout'),e=>e===m.fout);await m.promise;await Promise.resolve();
 const r=m.w._publicatieProbe.stop(),e=r.regels.filter(x=>x.soort==='api.save.einde');assert.equal(e.length,2);assert(e.some(x=>x.fout&&x.synchroon));assert(e.some(x=>!x.fout));assert(r.hersteld);assert.deepEqual(Object.getOwnPropertyDescriptors(m.publiek),m.publiekOrigineel);proeven++;
}
{
 const waarde={},fout=new Error('eigen afwijzing'),afgewezen=Promise.reject(fout);afgewezen.catch(()=>{});
 const fn=Object.assign(function(...args){assert.equal(this,kaart);assert.equal(args[0],waarde);return afgewezen},{bereidVoor:()=>waarde}),kaart=new Map([[1,fn]]);
 const m=maak(undefined,{_serialiseerMeetdoelen:[{map:kaart,key:1}]});assert.equal(kaart.get(1).bereidVoor,fn.bereidVoor);assert.equal(kaart.get(1).call(kaart,waarde),afgewezen);
 await assert.rejects(afgewezen,e=>e===fout);await Promise.resolve();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(kaart.get(1),fn);assert.equal(r.bewaarfuncties,1);assert(r.regels.some(x=>x.soort==='geregistreerd.bewaren.einde'&&x.fout));proeven++;
}
{
 const m=maak(),antwoord={},p={save(){return antwoord},flushPendingInput(){return m.promise},readParagraphs(){return m.promise}},d=Object.getOwnPropertyDescriptors(p);m.wisselApi(p);m.frame();assert.equal(p.save(),antwoord);assert.equal(p.flushPendingInput(),m.promise);await m.promise;await Promise.resolve();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.deepEqual(Object.getOwnPropertyDescriptors(p),d);assert(r.regels.some(x=>x.soort==='api.save.einde'&&x.synchroon));assert(r.regels.some(x=>x.soort==='api.flushPendingInput.einde'));proeven++;
}
{const fn=()=>3,kaart=new Map([[1,fn]]),m=maak(undefined,{_serialiseerMeetdoelen:[{map:kaart,key:1}]}),vreemd=()=>4;m.publiek.save=vreemd;kaart.set(1,vreemd);const r=m.w._publicatieProbe.stop();assert.equal(r.hersteld,false);assert.equal(m.publiek.save,vreemd);assert.equal(kaart.get(1),vreemd);proeven++;}
{const antwoord={},ref={save(){return antwoord},flushPendingInput(){return Promise.resolve(antwoord)}},oud=Object.getOwnPropertyDescriptors(ref),m=maak(undefined,{_extraBewaarRefs:()=>[ref]});assert.equal(ref.save(),antwoord);const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(r.faserefs,2);assert.deepEqual(Object.getOwnPropertyDescriptors(ref),oud);assert(r.regels.some(x=>x.soort==='api.save.einde'));proeven++;}
console.log(`${proeven} transparantie-/opruim-/grenscontroles geslaagd`);
