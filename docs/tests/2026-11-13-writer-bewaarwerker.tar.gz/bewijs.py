from pathlib import Path
import hashlib,json,stat,tarfile
p=Path(__file__).resolve().parent;repo=p.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
refs=json.load(open(repo/'.local/integratiecontrole/bewaar-groepen/referenties-nacontrole.json'))
refs[str(repo/'.local/integratiecontrole/bewaar-groepen/open-office-studio-bewaar-groepen')]='b6162e59e9c2dfdfcb98eb85d1b731ba52d2d4ee97f3a6429b6106a6127c3421'
for f,h in refs.items():assert sha(Path(f))==h,f
bundel=json.load(open(repo/'.local/integratiecontrole/bewaar-groepen/standaardbundel.json'))
for f,v in bundel.items():
 q=repo/'dist'/f;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],f
assert len([x for x in (repo/'dist').rglob('*') if x.is_file()])==len(bundel)
sdk=repo/'node_modules/@betteroffice/docx-react/dist/index.mjs';assert sha(sdk)=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
(p/'behoud.json').write_text(json.dumps({'referenties':refs,'standaardbundel_exact':len(bundel),'sdk_sha256':sha(sdk),'geen_productwijziging':True},indent=2)+'\n')
for f in ['src/editors.tsx','src/tekst/info/opslaan.ts','src/tekst/info/docprops.ts','src/useHerstel.tsx']:
 (p/Path(f).name).write_bytes((repo/f).read_bytes())
(p/'wachtrij-probe.js').write_bytes((repo/'.local/integratiecontrole/adaptieve-invoer/wachtrij-probe.js').read_bytes())
import gzip
for naam,f in [('sdk-react.mjs.gz','node_modules/@betteroffice/docx-react/dist/index.mjs'),('sdk-client.mjs.gz','node_modules/@betteroffice/docx/dist/chunk-6ZKYZDSZ.mjs'),('sdk-werker.mjs.gz','node_modules/@betteroffice/docx/dist/yrs/docxWorker.mjs')]:
 with gzip.open(p/naam,'wb') as z:z.write((repo/f).read_bytes())
archive=repo/'docs/tests/2026-11-13-writer-bewaarwerker.tar.gz'
files=[f for f in p.rglob('*') if f.is_file()]
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(files):t.add(f,arcname=f.relative_to(p),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(files)
 for m in members:assert m.isfile() and sha(p/m.name)==hashlib.sha256(t.extractfile(m).read()).hexdigest()
anal=json.load(open(p/'analyse.json'))
assert len(anal)==4 and sum(v['geslaagd'] for v in anal.values())==2
from zipfile import ZipFile
basis=None;verschillen={}
for naam in anal:
 with ZipFile(p/naam/'Ontwerpnotitie.docx') as z:delen={n:z.read(n) for n in z.namelist()}
 if basis is None:basis=delen
 verschillen[naam]=[n for n in sorted(set(basis)|set(delen)) if basis.get(n)!=delen.get(n)]
assert all(set(v)<= {'docProps/core.xml'} for v in verschillen.values())
laatste=json.load(open(p/'opname-binnen-afgemeld/rapport.json'));assert not laatste['worker_disable'].get('error')
r={'datum':'2026-11-13','basis_integratie':'3badc83e','productbron':'41e7000198f89d992e1059e9715636a44b39d21a','programma_sha256':'acb77036935feed425b7c81a5dbd2ef796ffcb4307db96c9845aa6dd8b70c958','besluit':'Diagnose: het lange save-venster ligt voornamelijk binnen de Worker, niet tussen SDK-call en berichtverzending of bij antwoordadoptie. Geen productwijziging of oplossing van de invoervertraging.','metingen':anal,'laatste_uitsplitsing_ms':{'geregistreerd_totaal':4431,'sdk_save':3263,'sdk_begin_tot_worker_verzending':167,'worker_rondgang':3094,'worker_ontvangst_tot_verzending':3082,'rondgang_min_binnen':12,'antwoordontvangst_tot_sdk_einde':2,'sdk_einde_tot_geregistreerd_einde':798,'eerste_flush':188,'test_flush_overlapt_sdk':277,'worker_sync_na_bewaren':357},'tests':{'faseprobe':18,'transportprobe':4,'binnenprobe':3,'alle_groen':True},'native':{'volledig_geslaagd':['opname','opname-binnen-afgemeld'],'afgekeurd':['opname-binnen','opname-binnen-herhaling'],'afkeuring':'Beide oorspronkelijke binnenmetingen slagen op invoer/UndoRedo/selectie/bewaren maar falen daarna op dezelfde30sec nieuw-documentgrens; consoleleeg. Worker-debugger bleef actief. Alleen diagnose aangepast: Worker.disable na export en vóór nieuwe werkers. Daarna volledige ronde groen. Dit ondersteunt meetverstoring, maar is geen onafhankelijke interne protocoloorzaak- of appstabiliteitsfix. Geen timeout of functionele assertie versoepeld.'},'docx_verschillen':verschillen,'behoud':json.load(open(p/'behoud.json')),'grenzen':['Vier eigen rijke schema-2-Linuxdiagnoses op dezelfdeELF, geen onbeïnvloede ABBA-snelheidsvergelijking en geen platform/releaseacceptatie.','De binnenmeting begint bij ontvangen message-event en eindigt vóór postMessage. Zij omvat interne wachtrij, verwerking en async-wachten; geen exclusieve CPU- of uitsluitend ZIP/serialisatietijd.','Binnen- en hoofdthread hebben verschillende klokorigines; alleen afzonderlijke duurverschillen vergeleken, geen absolute tijdstempels direct afgetrokken.','Eerste transportmeting: Worker2869ms binnen SDK2994ms. Drie binnenmetingen:3025/3065/3082ms; eerste twee functioneel afgekeurd blijven apart zichtbaar.','Geen extra enginelezingen of Worker-verzoeken. Alleen bestaande verzendingen/ontvangsten met type/id/byteaantal geklokt, geen tekst/bytes gekopieerd door probes. Begrensd4096regels/8werkers; alle wrappers/luisteraars hersteld, geen overschrijding.','De faseprobe volgt refs perrAF; een kortlevende eerste flush kan ontbreken. SDK-save en geregistreerd save zijn wel begrensd gemeten. Extra Promise-observers/debugger kunnen uitvoering beïnvloeden.','Alle vier opgeslagen DOCX onafhankelijk SHA/ZIP/CRC/XML:128tabellen/91423UTF16. Pakketverschillen uitsluitendcore.xml. Laatste bewaarbeeld bekeken, geen volledige65pagina-/pixelacceptatie.','Geen frontend/TS/Python/build/CI opnieuw voor private diagnose en bewijsdocs. Productbron ongewijzigd; eerdere normale3OS-CI blijft afzonderlijk gelden. Bestaande geheugenfouten niet opgelost.'],'vervolg':'Op acb770 de interne Worker-save verder splitsen: eventwachtrij→taakstart, session.save/saveDocument, pakket-/ZIP-uitvoer en update-encoding. Gebruik begrensde Worker-profielen of een aparte bronexacte diagnostische kopie; SDK-hardlinks/productbundel niet in-place wijzigen. Worker-debugger na export uitschakelen vóór nieuw-documentproeven. Behoud herstelkopieën en bewaking; pas na oorzaakbewijs een gerichte wijziging met vaste korte/rijke ABBA-ronden. Tien migratiegebieden open; Database laatst.','bewijs':{'pad':str(archive.relative_to(repo)),'sha256':sha(archive),'bytes':archive.stat().st_size,'reguliere_leden':len(files),'alle_leden_byteexact_gecontroleerd':True}}
(repo/'docs/tests/2026-11-13-writer-bewaarwerker.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r['bewijs']))
