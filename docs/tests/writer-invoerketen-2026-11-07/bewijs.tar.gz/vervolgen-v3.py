from pathlib import Path
import os,time,json,subprocess,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/invoerketen';root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');pid=[]
for f in Path('/proc').glob('[0-9]*/cmdline'):
 try:a=f.read_bytes().split(b'\0')
 except OSError:continue
 if len(a)>1 and a[1]==b'.local/integratiecontrole/invoerketen/vervolgen.py':pid.append(int(f.parent.name))
assert len(pid)<=1,pid
start=time.monotonic()
while pid and Path('/proc/'+str(pid[0])).exists():
 assert time.monotonic()-start<600
 time.sleep(2)
cmd=json.loads((root/'.local/doorwerk-2026-11-06/positie-integratie56/diagnose-opdracht.json').read_text());cmd[1]=str(u/'proef-v3.py');cmd[cmd.index('--programma')+1]=str(r/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding');env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];result=[]
for n in [1]:
 cmd[-1]=str(u/('v3-ronde-'+str(n)));begin=time.monotonic()
 with(u/('v3-ronde-'+str(n)+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 result.append({'ronde':n,'code':p.returncode,'duur_s':time.monotonic()-begin,'script_sha256':hashlib.sha256((u/'proef-v3.py').read_bytes()).hexdigest(),'opdracht':cmd.copy()});(u/'v3-resultaten.json').write_text(json.dumps(result,indent=2)+'\n');print('v2',n,p.returncode,flush=True)
