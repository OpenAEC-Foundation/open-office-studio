// Alleen begrensde gebeurtenistijden; geen invoertekst of bronlezingen.
function startWaarnemer(doel, klok, microtaak, frame, annuleerFrame, grens = 1024) {
  let actief = true, id = 0, gemist = 0, vorig = klok(), begin = vorig;
  const regels = [], totalen = Object.create(null);
  const voeg = regel => { if (regels.length < grens) regels.push(regel); else gemist++; };
  const luister = e => {
    if (!actief) return;
    const nu = klok();
    totalen[e.type] = (totalen[e.type] || 0) + 1;
    const regel = { soort: e.type, ms: nu - begin, vertrouwd: e.isTrusted === true };
    if (e.type === 'beforeinput') {
      regel.invoertype = e.inputType;
      regel.tekens = typeof e.data === 'string' ? e.data.length : null;
      microtaak(() => {
        if (!actief) return;
        regel.tot_microtaak_ms = klok() - nu;
        regel.geannuleerd = e.defaultPrevented;
      });
    }
    voeg(regel);
  };
  for (const soort of ['beforeinput', 'input', 'keyup']) doel.addEventListener(soort, luister, true);
  const teken = () => {
    if (!actief) return;
    const nu = klok();
    if (nu - vorig > 100) voeg({ soort: 'framepauze', ms: nu - begin, duur_ms: nu - vorig });
    vorig = nu;
    id = frame(teken);
  };
  id = frame(teken);
  return { stop() {
    if (actief) {
      actief = false;
      for (const soort of ['beforeinput', 'input', 'keyup']) doel.removeEventListener(soort, luister, true);
      annuleerFrame(id);
    }
    return { regels, totalen, gemist, duur_ms: klok() - begin };
  } };
}
module.exports = { startWaarnemer };
