from pathlib import Path
import json,subprocess,os,hashlib,time
r=Path.cwd();u=r/'.local/integratiecontrole/invoerketen';root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');ref=r/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding'
assert hashlib.sha256(ref.read_bytes()).hexdigest()=='c88c5d82f1b0b44bf1279645a6b3e930dc8f302e5e3f7bec57605b8d2df42c59'
env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];cmd=json.loads((root/'.local/doorwerk-2026-11-06/positie-integratie56/diagnose-opdracht.json').read_text());cmd[1]=str(u/'proef.py');cmd[cmd.index('--programma')+1]=str(ref)
result=[]
for n in [1,2]:
 cmd[-1]=str(u/('ronde-'+str(n)));begin=time.monotonic()
 with(u/('ronde-'+str(n)+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 result.append({'ronde':n,'code':p.returncode,'duur_s':time.monotonic()-begin,'opdracht':cmd.copy()});(u/'resultaten.json').write_text(json.dumps(result,indent=2)+'\n');print(n,p.returncode,flush=True)
