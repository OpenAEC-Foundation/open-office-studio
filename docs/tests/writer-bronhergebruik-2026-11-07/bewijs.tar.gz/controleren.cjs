const assert = require('node:assert/strict');
const { startOpname } = require('./opnemen.cjs');
(async () => {
 let calls = 0, ontvang;
 const antwoord = { json: async function(a) { assert.equal(this, antwoord); return { schema: 2, delta: 'xyz', a }; } };
 const origJson = antwoord.json;
 const w = { __TAURI_INTERNALS__: { convertFileSrc: () => 'doel' }, fetch: async function(...args) { calls++; ontvang=args; assert.equal(this,w); return antwoord; } };
 const orig = w.fetch;
 const opname = startOpname(w);
 await w.fetch('anders',{body:'geen json'});assert.equal(opname.stop().regels.length,0);assert.equal(w.fetch,orig);
 const tweede = startOpname(w,1);
 const args={body:JSON.stringify({aanvraag:{schema:2,snapshot:'abc'}})};
 const r=await w.fetch('doel',args,3);assert.equal(ontvang[1],args);assert.equal(ontvang[2],3);const j=await r.json(4);assert.equal(j.a,4);
 await w.fetch('doel',args);const d=tweede.stop();assert.equal(d.regels.length,1);assert.equal(d.overgeslagen,1);assert.equal(d.regels[0].aanvraag.snapshot,'abc');assert.equal(d.regels[0].antwoord.delta,'xyz');assert.equal(w.fetch,orig);assert.equal(antwoord.json,origJson);
 const derde=startOpname(w,2,2);await w.fetch('doel',args);assert.equal(derde.stop().regels.length,0);
 const vierde=startOpname(w);await w.fetch('doel',{body:'fout'});assert.deepEqual(vierde.stop().fouten,['SyntaxError']);assert.equal(w.fetch,orig);
 console.log('Doelselectie, doorgifte, binding, antwoord, grens, bytegrens, parsefout en herstel groen.');
})().catch(e=>{console.error(e);process.exitCode=1});
