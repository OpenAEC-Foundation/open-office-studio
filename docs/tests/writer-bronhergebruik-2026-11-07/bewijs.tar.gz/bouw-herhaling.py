from pathlib import Path
import os,subprocess,time,hashlib,json,signal,shutil
u=Path.cwd()/'.local/integratiecontrole/bronhergebruik';cache=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio/native/target/release');j=json.loads((cache/'.fingerprint/office-writer-plakken-adeaf5a58d506384/example-meet_bronkosten.json').read_text());cmd=['/home/aia01/.cargo/bin/rustc','--edition=2024','-C','opt-level=3','-L','dependency='+str(cache/'deps'),str(u/'herhaal.rs'),'-o',str(u/'herhaal')];libs={}
for naam in ['office_writer_plakken','serde_json']:
 getal=next(x[3]for x in j['deps']if x[1]==naam);pinnen=[]
 for p in (cache/'.fingerprint').glob(naam.replace('_','-')+'-*/lib-'+naam)if naam!='serde_json'else(cache/'.fingerprint').glob('serde_json-*/lib-serde_json'):
  if int.from_bytes(bytes.fromhex(p.read_text().strip()),'little')==getal:pinnen.append(p)
 assert len(pinnen)==1,pinnen
 lib=cache/'deps'/('lib'+naam+'-'+pinnen[0].parent.name.rsplit('-',1)[1]+'.rlib');assert lib.exists();libs[str(lib)]=hashlib.sha256(lib.read_bytes()).hexdigest();cmd+=['--extern',naam+'='+str(lib)]
assert shutil.disk_usage(u).free>1536*1024**2,'Geen kleine hulpprogrammabouw onder1.5GiBvrij'
begin=time.monotonic()
with(u/'bouw.log').open('x')as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  if shutil.disk_usage(u).free<1024**3 or time.monotonic()-begin>120:
   os.killpg(p.pid,signal.SIGTERM);p.wait();raise SystemExit('Eigen kleine bouw afgebroken bij ruimte-/tijdgrens')
  time.sleep(.2)
assert p.returncode==0,p.returncode
assert (u/'herhaal').stat().st_size<32*1024**2
(u/'bouw.json').write_text(json.dumps({'opdracht':cmd,'code':p.returncode,'duur_s':time.monotonic()-begin,'bibliotheken':libs,'binary_sha256':hashlib.sha256((u/'herhaal').read_bytes()).hexdigest(),'grens':'Alleen één klein onderzoekshulpprogramma met vastgelegde reeds gebouwde Cargo-artefacten; geen desktopbouw of nieuwe afhankelijkheden.'},indent=2)+'\n')
d=json.loads((u/'opname/profiel.json').read_text());r=d['invoerketen']['aanvragen']['regels'];(u/'aanvraagreeks.json').write_text(json.dumps(r)+'\n')
with(u/'herhaling.json').open('x')as out,(u/'herhaling.log').open('x')as log:p=subprocess.run([str(u/'herhaal'),str(u/'aanvraagreeks.json')],stdout=out,stderr=log,timeout=120)
print('Exacte herhaling:',p.returncode,flush=True)
(u/'herhaling-uitkomst.json').write_text(json.dumps({'code':p.returncode})+'\n')
