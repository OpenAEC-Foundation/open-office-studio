//! Speel uitsluitend de begrensde aanvraagreeks van de eigen proefkopie opnieuw af.
use std::{fs, time::Instant};
use office_writer_plakken::{BronSpiegel, IncrementeleTekstAanvraag};
use serde_json::{Value, json};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let pad=std::env::args().nth(1).ok_or("Geef de eigen aanvraagreeks")?;
    let bytes=fs::read(pad)?;
    assert!(bytes.len()<16*1024*1024);
    let regels:Vec<Value>=serde_json::from_slice(&bytes)?;
    assert!(!regels.is_empty() && regels.len()<=64);
    let mut spiegel=BronSpiegel::default();let mut uit=Vec::new();
    for (nr,regel) in regels.iter().enumerate() {
        let aanvraag:IncrementeleTekstAanvraag=serde_json::from_value(regel["aanvraag"].clone())?;
        let begin=Instant::now();
        let r=spiegel.bereid_voor(aanvraag)?.ok_or("Onverwachte vraag om een volledige bron")?;
        let duur=begin.elapsed().as_secs_f64()*1000.;
        let prep=r.resultaat.preparation_ms;
        let mut echt=serde_json::to_value(r.resultaat)?;
        echt["schema"]=json!(2);echt["basis"]=json!(r.basis);echt["bronvector"]=json!(r.bronvector);
        let mut verwacht=regel["antwoord"].clone();
        echt.as_object_mut().unwrap().remove("preparationMs");
        verwacht.as_object_mut().unwrap().remove("preparationMs");
        uit.push(json!({"groep":nr,"totaal_ms":duur,"voorbereiding_ms":prep,"antwoord_exact_zonder_tijd":echt==verwacht,"bronvoorraad_bytes":spiegel.bytes()}));
        assert_eq!(echt,verwacht,"Groep {nr}: herhaald antwoord wijkt af");
    }
    println!("{}",serde_json::to_string_pretty(&json!({"groepen":uit,"grens":"Losse Rust-herhaling met vastgelegde bibliotheekartefacten; geen desktop-/IPC-/render-/snelheidsacceptatie."}))?);
    Ok(())
}
