from pathlib import Path
import json,subprocess,hashlib,time,shutil,os,signal
u=Path.cwd()/'.local/integratiecontrole/bronhergebruik';root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');cache=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release';j=json.loads(Path(json.loads((u/'bouw-desktop.json').read_text())['desktop_fingerprint']).read_text());pin={}
def vind(naam,waarde):
 gevonden=[p for p in(cache/'.fingerprint').glob('*/lib-'+naam)if int.from_bytes(bytes.fromhex(p.read_text().strip()),'little')==waarde];assert len(gevonden)==1,(naam,len(gevonden));p=gevonden[0];h=p.parent.name.rsplit('-',1)[1];lib=cache/'deps'/('lib'+naam+'-'+h+'.rlib');lib=lib if lib.exists() else cache/'deps'/('lib'+naam+'.rlib');assert lib.exists();pin[naam]=lib;return json.loads(p.with_suffix('.json').read_text())
def dep(j,naam):
 return vind(naam,next(x[3]for x in j['deps']if x[1]==naam))
o=dep(j,'office_writer_plakken');d=dep(o,'docx_edit');dep(d,'yrs')
for naam in ['serde','serde_json','base64','sha2']:dep(o,naam)
bron=Path.cwd()/'native/crates/office-writer-plakken/examples/meet_bronkosten.rs';kopie=u/'huidige-bronkosten.rs';kopie.write_bytes(bron.read_bytes());cmd=['/home/aia01/.cargo/bin/rustc','--edition=2024','-C','opt-level=3','-L','dependency='+str(cache/'deps'),str(kopie),'-o',str(u/'huidige-bronkosten')]
for naam,lib in pin.items():cmd+=['--extern',naam+'='+str(lib)]
assert shutil.disk_usage(u).free>1536*1024**2
begin=time.monotonic()
with(u/'bouw-huidige-bronkosten.log').open('x')as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  if shutil.disk_usage(u).free<1024**3 or time.monotonic()-begin>120:os.killpg(p.pid,signal.SIGTERM);p.wait();raise SystemExit('Kleine bouw afgebroken bij ruimte-/tijdgrens')
  time.sleep(.2)
assert p.returncode==0,p.returncode
(u/'bouw-huidige-bronkosten.json').write_text(json.dumps({'opdracht':cmd,'code':p.returncode,'bron_sha256':hashlib.sha256(bron.read_bytes()).hexdigest(),'bibliotheken':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in pin.values()},'programma_sha256':hashlib.sha256((u/'huidige-bronkosten').read_bytes()).hexdigest()},indent=2)+'\n')
with(u/'huidige-bronkosten.json').open('x')as out,(u/'huidige-bronkosten.log').open('x')as log:p=subprocess.run([str(u/'huidige-bronkosten'),str(u/'eerste-aanvraag.json')],stdout=out,stderr=log,timeout=120)
print('Huidige losse bronkosten:',p.returncode,flush=True)
