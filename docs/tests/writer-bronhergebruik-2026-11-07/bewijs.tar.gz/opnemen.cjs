// Uitsluitend voor een eigen geïsoleerde test-WebView met een openbare proefkopie.
function startOpname(w, grens = 64, bytegrens = 8 * 1024 * 1024) {
  const origineel = w.fetch;
  const doel = w.__TAURI_INTERNALS__.convertFileSrc('writer_tekst_voorbereiden', 'ipc');
  const regels = [], herstel = [], fouten = [];
  let actief = true, bytes = 0, overgeslagen = 0;
  const kopie = waarde => {
    const tekst = JSON.stringify(waarde);
    if (bytes + tekst.length > bytegrens) { overgeslagen++; return null; }
    bytes += tekst.length;
    return JSON.parse(tekst);
  };
  const fetch = async function(url, args, ...rest) {
    if (!actief || String(url) !== doel) return origineel.call(this, url, args, ...rest);
    let regel;
    try {
      if (regels.length < grens) {
        const aanvraag = kopie(JSON.parse(args.body).aanvraag);
        if (aanvraag) { regel = { aanvraag }; regels.push(regel); }
      } else overgeslagen++;
    } catch (e) { fouten.push(e.name); }
    const antwoord = await origineel.call(this, url, args, ...rest);
    if (regel && actief) {
      const oud = antwoord.json;
      const json = async function(...params) {
        const resultaat = await oud.apply(this, params);
        if (actief) try { regel.antwoord = kopie(resultaat); } catch (e) { fouten.push(e.name); }
        return resultaat;
      };
      antwoord.json = json;
      herstel.push(() => { if (antwoord.json === json) antwoord.json = oud; });
    }
    return antwoord;
  };
  w.fetch = fetch;
  return { stop() {
    actief = false;
    if (w.fetch === fetch) w.fetch = origineel;
    for (const fn of herstel) fn();
    return { regels, bytes, overgeslagen, fouten };
  } };
}
module.exports = { startOpname };
