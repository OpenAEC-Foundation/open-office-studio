from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent;repo=p.parents[2];env={**os.environ,'PATH':'/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']};hash=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
gevallen=[('zonder-beeld',{}),('beeld-laatste',{'BEELD':'1'}),('beeld-voorlaatste',{'BEELD':'1','ALINEA':'-2'}),('beeld-geen-lokaal',{'BEELD':'1','ALINEA':'-2','LOKAAL':'0'})];r=[]
for naam,opzet in gevallen:
 runs=[]
 for kern,wasm in [('basis',repo/'vendor/tekstengine/docx_edit_bg.wasm'),('klok',p/'route/docx_edit_bg.wasm')]:
  label=f'route-{naam}-{kern}'
  with (p/f'{label}.log').open('x') as log:subprocess.run(['node',str(p/'vergelijk-route.mjs'),str(wasm),label,hash(wasm)],cwd=repo,env={**env,**opzet},stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
  runs.append(json.load(open(p/f'{label}.json')))
 assert all(v['geslaagd'] for v in runs)
 velden=['stap','tekst','alinea_sha256','bronvector_sha256','font_sha256','font_bytes','update_bytes']
 for a,b in zip(runs[0]['metingen'],runs[1]['metingen'],strict=True):
  for k in velden:assert a[k]==b[k],(naam,k,a[k],b[k])
 routes={kant:[next(z[0] for z in x[f'font_trace_{kant}'] if z[0].startswith('route_')) for x in runs[1]['metingen']] for kant in ['a','b']}
 herhaald=[next(z[0] for z in x['font_trace'] if z[0].startswith('route_')) for x in runs[1]['herhaalde_lezingen']]
 r.append({'opzet':naam,'kernvergelijking_acht_stappen_exact':True,'routes':routes,'herhaalde_routes':herhaald})
(p/'route-ronden.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r))
