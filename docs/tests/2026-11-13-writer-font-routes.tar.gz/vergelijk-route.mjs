import fs from 'node:fs';import path from 'node:path';import{pathToFileURL}from'node:url';import assert from'node:assert/strict';import{performance}from'node:perf_hooks';import crypto from'node:crypto';
const dir=path.resolve('.local/integratiecontrole/font-hergebruik'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const wasm=fs.readFileSync(process.argv[2]);assert.match(process.argv[3],/^[a-z-]+$/);assert.equal(hash(wasm),process.argv[4]);const{preloadEditWasm,createEditSession}=await import(pathToFileURL(path.resolve('node_modules/@betteroffice/docx/dist/wasm-edit.mjs')).href);await preloadEditWasm(wasm);
const bytes=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'),a=createEditSession(901),b=createEditSession(902);let r={geslaagd:false,wasm_sha256:hash(wasm),bron_sha256:hash(bytes),opzet:{beeld:process.env.BEELD === '1',alinea:Number(process.env.ALINEA ?? -1),lokaal:process.env.LOKAAL !== '0',opwarmen:process.env.OPWARMEN !== '0'},metingen:[]};
try{
 a.open_docx(bytes,true);b.open_docx(bytes,false);b.load(a.encode_state());a.set_local_lowering(process.env.LOKAAL !== '0');b.set_local_lowering(process.env.LOKAAL !== '0');
 const req=JSON.stringify({bodyStory:'body',renderEnv:{}}),body=()=>JSON.parse(a.read_paragraphs_json(JSON.stringify({story:'body',view:'accepted'})));
 const init=body();assert(init.ok&&init.paragraphs.length>0);const p=init.paragraphs.at(Number(process.env.ALINEA ?? -1));let offset=p.text.length;assert.equal(typeof p.paraId,'string');
 if(process.env.OPWARMEN !== '0'){a.layout_document_with_regions_retained(req);b.layout_document_with_regions_retained(req);}if(process.env.BEELD === '1'){a.build_display_list_frame('{}',0);b.build_display_list_frame('{}',0);}const initA=a.layout_font_requirements_json(req),initB=b.layout_font_requirements_json(req);assert.equal(initA,initB);
 for(const [i,tekst]of [' Een proef',' met woorden',' en spaties.',' Ω',' العربية',' 漢字',' 🙂',' extra'].entries()){
  const vector=b.encode_state_vector(),voor=performance.now();a.edit_text_resident('body',p.paraId,offset,p.paraId,offset,tekst);const lokaalBewerken=performance.now()-voor;
  const update=a.encode_diff(vector),v=performance.now();b.apply_update(update);const updateMs=performance.now()-v;
  const t=performance.now(),fontsA=a.layout_font_requirements_json(req),lokaalMs=performance.now()-t;
  const u=performance.now(),fontsB=b.layout_font_requirements_json(req),replicaMs=performance.now()-u;
  assert.equal(fontsA,fontsB,`fontresultaat ${i}`);const pa=JSON.parse(a.read_paragraphs_json(JSON.stringify({story:'body',view:'accepted'}))),pb=JSON.parse(b.read_paragraphs_json(JSON.stringify({story:'body',view:'accepted'})));assert.deepEqual(pa.paragraphs,pb.paragraphs,`alinearesultaat ${i}`);assert.deepEqual(a.encode_state_vector(),b.encode_state_vector(),`bronvector ${i}`);
  r.metingen.push({stap:i,tekst,alinea_sha256:hash(JSON.stringify(pa.paragraphs)),bronvector_sha256:hash(a.encode_state_vector()),font_trace_a:JSON.parse(a.apply_input_profile_json()),font_trace_b:JSON.parse(b.apply_input_profile_json()),lokaal_bewerken_ms:lokaalBewerken,replica_update_ms:updateMs,lokaal_font_ms:lokaalMs,replica_font_ms:replicaMs,update_bytes:update.length,font_sha256:hash(fontsA),font_bytes:Buffer.byteLength(fontsA),fontresultaat_exact:true,alinearesultaat_exact:true,bronvector_exact:true});offset+=tekst.length;
 }
 r.herhaalde_lezingen=[];for(let i=0;i<5;i++){const t=performance.now();const x=a.layout_font_requirements_json(req);r.herhaalde_lezingen.push({ms:performance.now()-t,font_sha256:hash(x),font_trace:JSON.parse(a.apply_input_profile_json())})}r.geslaagd=true;
}catch(e){r.fout=String(e);throw e}finally{a.free();b.free();fs.writeFileSync(path.join(dir,process.argv[3]+'.json'),JSON.stringify(r,null,2)+'\n')}
console.log(JSON.stringify(r));
