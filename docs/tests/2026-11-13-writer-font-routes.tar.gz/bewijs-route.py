from pathlib import Path
import hashlib,json,gzip,tarfile,stat,statistics
p=Path(__file__).resolve().parent;repo=p.parents[2];sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
meta=json.load(open(repo/'patches/tekstengine-nootnummering.json'));bouw=json.load(open(p/'route/bouw.json'));assert bouw['interface_exact'];assert sha(p/'route/docx_edit_bg.wasm')==bouw['sha256']
for naam,key in [('docx_edit','wasmSha256'),('docx_layout','layoutWasmSha256')]:assert sha(repo/'vendor/tekstengine'/f'{naam}_bg.wasm')==meta[key]
refs=json.load(open(repo/'.local/integratiecontrole/werker-fasekopie/referenties-nacontrole.json'));assert len(refs)==16
for q,h in refs.items():assert sha(Path(q))==h
oud=json.load(open(repo/'.local/integratiecontrole/werker-fasekopie/standaardbundel.json'))
for n,v in oud.items():
 q=repo/'dist'/n;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],n
assert len([q for q in (repo/'dist').rglob('*') if q.is_file()])==len(oud)==529
assert sha(repo/'node_modules/@betteroffice/docx-react/dist/index.mjs')=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
assert sha(repo/'node_modules/@betteroffice/docx/dist/generated/edit/docx_edit_bg.wasm')==meta['oorspronkelijkWasmSha256']
ronden=json.load(open(p/'route-ronden.json'));assert len(ronden)==4 and all(x['kernvergelijking_acht_stappen_exact'] for x in ronden)
(p/'route-behoud.json').write_text(json.dumps({'ELFs_exact':16,'standaardbundel_byte_mode_mtime_exact':529,'sdk_en_vendor_exact':True},indent=2)+'\n')
(p/'route-bouwgegevens.json').write_bytes((p/'route/bouw.json').read_bytes())
for n in ['engine-route-voor.rs','engine-route-na.rs']:(p/(n+'.gz')).write_bytes(gzip.compress((p/n).read_bytes(),mtime=0))
files=sorted([q for q in p.iterdir() if q.is_file() and (q.name.startswith(('route-','bouw-route','vergelijk-route','engine-route','bewijs-route')) or q.name=='route.diff') and q.suffix not in ['.rs','.wasm']])
arch=repo/'docs/tests/2026-11-13-writer-font-routes.tar.gz'
with tarfile.open(arch,'x:gz') as t:
 for q in files:t.add(q,arcname=q.name,recursive=False)
with tarfile.open(arch) as t:
 leden=t.getmembers();assert len(leden)==len(files)
 for m in leden:assert m.isfile() and t.extractfile(m).read()==(p/m.name).read_bytes()
tijden={}
for geval in ronden:
 naam=geval['opzet'];v=json.load(open(p/f'route-{naam}-klok.json'));tijden[naam]={}
 for kant,veld in [('a','lokaal_font_ms'),('b','replica_font_ms')]:
  xs=[x[veld] for x in v['metingen']];tijden[naam][kant]={'alle_acht_ms':xs,'mediaan_ms':statistics.median(xs),'min_ms':min(xs),'max_ms':max(xs)}
r={'datum':'2026-11-13','basis_integratie':'5fbe7f8c','basis_productbron':'41e7000198f89d992e1059e9715636a44b39d21a','besluit':'Cache-/patch-/volledige-loweringroute afzonderlijk vastgesteld in private klok-Wasm. Opzet met beeldframe corrigeert ontbrekende voorwaarde van eerdere componentproef; geen productfix.','bronbinding':meta,'route_bouw':bouw,'bouw':json.load(open(p/'bouw-route.json')),'bronpinnen':json.load(open(p/'route-bronpinnen.json')),'ronden':ronden,'tijden':tijden,'controles':['Vier opzetten, elk acht lokale bewerkingen en acht replica-updates; tekst, fontJSON en bronvector lokaal/replica exact.','Elk van de vier opzetten ook acht stappen meegeleverde kern versus klokmodule exact op zeven velden.','Elke opzet vijf herhaalde lezingen zonder mutatie vastgelegd.','JavaScript-syntax en Python-compilatie van de nieuwe proefscripts groen; volledige JS/Wasm-import/exportinterface identiek.','Zestien eerdere ELF-referenties, 529 standaardbundelbestanden inclusief mode/mtime, SDK-index, npm-Wasm en beide vendor-Wasms intact.'],'grenzen':['Node/V8-componentmetingen op eigen rijke bron; geen nieuwe desktop-, IME-, pixel-, platform- of releaseacceptatie.','Vaste volgorde, lokale bewerking voor replica; geen ABBA of snelheidsacceptatie. Klokpunten en tellerlezingen kunnen verstoren.','route_volledig_loweren betekent toename van render.cache_misses door lower_story_into_cache; die functie kan intern previeweenheden hergebruiken. Geen bewijs dat ieder blok opnieuw is opgebouwd.','route_overige_patch betekent geen cachehit/miss/previewpatch-tellerverschil. Dit past bij patch_lowered_body in de bronroute; het individuele patchsucces en de pending-update-foutterugval zijn niet rechtstreeks gemarkeerd. Geen sterkere branchclaim uitsluitend op grond van tijdwinst.','De eerdere opzet miste build_display_list_frame; can_apply_input vereist display.extras_json. Daarom was eerder uitblijven van winst geen valide vergelijking van de snelle route.','Geen productbronwijziging, frontend/TypeScript/Python-productsuite, appbouw of CI in deze stap. De bestaande geheugenfouten blijven open.','De private bestaande apply_input_profile_json-getter bevat fontklokken; module ongeschikt voor productie.','Body/leeg renderEnv en acht invoerstukken met Grieks, Arabisch, CJK en emoji; geen volledige stijl-/kop-/noot-/previewdekking.'],'behoud':json.load(open(p/'route-behoud.json')),'vervolg':'Onderzoek hoe de werkelijke Worker-update veilig dezelfde paragraafpatch kan behouden. Stel eerst de herkomst en exacte mutatiegrenzen van de Worker-update vast; typing-caretinference bewijst geen uitsluitend tekstuele update. Geen cacheguard versoepelen. Daarna prototype en vaste native korte/rijke ABBA plus functioneel/visueel bewijs.','bewijs':{'pad':str(arch.relative_to(repo)),'sha256':sha(arch),'bytes':arch.stat().st_size,'reguliere_leden':len(files),'byteexact_gecontroleerd':True}}
(repo/'docs/tests/2026-11-13-writer-font-routes.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r['bewijs']))
