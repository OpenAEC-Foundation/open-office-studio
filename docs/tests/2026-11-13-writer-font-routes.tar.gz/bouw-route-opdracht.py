from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent;repo=p.parents[2];bron=p/'bron';uit=p/'route';uit.mkdir(exist_ok=False);env={**os.environ,'CARGO_TARGET_DIR':str(bron/'target-wasm')}
subprocess.run(['cargo','build','-p','betteroffice-docx-edit','--lib','--features','wasm,tiff,metafile,heap-stats','--target','wasm32-unknown-unknown','--release','--locked','--offline'],cwd=bron,env=env,check=True)
subprocess.run([str(p/'gereedschap/bindgen/wasm-bindgen'),'--target','web','--out-name','docx_edit','--out-dir',str(uit),str(bron/'target-wasm/wasm32-unknown-unknown/release/docx_edit.wasm')],check=True)
wasm=uit/'docx_edit_bg.wasm';opt=uit/'opt.wasm';subprocess.run([str(p/'gereedschap/binaryen/bin/wasm-opt'),'-O3',str(wasm),'-o',str(opt)],check=True);opt.replace(wasm)
code="""import{readFileSync}from'node:fs';const f=p=>{const m=new WebAssembly.Module(readFileSync(p));return JSON.stringify({i:WebAssembly.Module.imports(m).map(r=>`${r.module}:${r.name}:${r.kind}`).sort(),e:WebAssembly.Module.exports(m).map(r=>`${r.name}:${r.kind}`).sort()})};if(f(process.argv[1])!==f(process.argv[2]))throw Error('JS/Wasm-interface verschilt')"""
subprocess.run(['node','--input-type=module','--eval',code,str(wasm),str(repo/'vendor/tekstengine/docx_edit_bg.wasm')],check=True)
(uit/'bouw.json').write_text(json.dumps({'sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'bytes':wasm.stat().st_size,'interface_exact':True,'doel':'uitsluitend font-klokken via bestaande profielgetter, geen productievariant'},indent=2)+'\n')
