from pathlib import Path
import json,hashlib,shutil,difflib
r=Path.cwd();p=r/'.local/integratiecontrole/warm-layout-request';old=r/'.local/integratiecontrole/warm-layout-env';src=r/'.local/integratiecontrole/font-hergebruik/bron';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();pins=json.loads((old/'bron-hersteld.json').read_text())['bestanden']
for n,h in pins.items():assert sha(r/n)==h,n
for n in ['engine.rs','wasm.rs','mutation_proof.rs','lib.rs']:
 f=src/'crates/docx-edit/src'/n;shutil.copyfile(f,p/(n+'.voor'));s=(old/(n+'.na')).read_text()
 if n=='engine.rs':
  parse='''        let mut parsed_render_env = if render_env.is_null() {
            None
        } else {
            Some({
                let json = serde_json::to_string(&render_env)
                    .map_err(|error| format!("serialize render environment: {error}"))?;
                serde_json::from_str::<RenderEnv>(&json)
                    .map_err(|error| format!("parse render environment: {error}"))?
            })
        };'''
  resolve='''        if regions.sections.len() <= 1
            && let Some(env) = &mut parsed_render_env
        {
            let line_px = regions.paragraph_spacing_line_px(0);
            env.paragraph_spacing_line_px = (line_px != 16.0).then_some(line_px);
            env.doc_grid_pitch_px = regions.doc_grid_snap_pitch_px(0);
        }'''
  assert s.count(parse)==1 and s.count(resolve)==1
  s=s.replace(parse,'        let mut parsed_render_env = parse_region_render_env(&render_env)?;').replace(resolve,'        resolve_region_render_env(&mut parsed_render_env, &regions);')
  anchor='    pub fn warm_story(&self, story: &str, env: &RenderEnv) -> Result<(), BridgeError> {';assert s.count(anchor)==1
  method='''    pub fn warm_story_for_region_layout(&self, story: &str, input_json: &str) -> Result<(), String> {
        let request: RegionLayoutInput =
            serde_json::from_str(input_json).map_err(|error| format!("parse: {error}"))?;
        let (_, regions, _, _, render_env, body_story) = request.split();
        if body_story.as_deref() != Some(story) {
            return Err("warm region layout requires a matching body story".into());
        }
        let mut env = parse_region_render_env(&render_env)?;
        resolve_region_render_env(&mut env, &regions);
        let env = env.ok_or("warm region layout requires a render environment")?;
        self.with_resident_story(story, &env, |_| ())
            .map_err(|error| error.to_string())
    }

'''
  s=s.replace(anchor,method+anchor)
  # Beide routes gebruiken dezelfde helpers;de bestaande volgorde rond revision_preview_key blijft intact.
  helper='''
fn parse_region_render_env(render_env: &serde_json::Value) -> Result<Option<RenderEnv>, String> {
    if render_env.is_null() {
        return Ok(None);
    }
    let json = serde_json::to_string(render_env)
        .map_err(|error| format!("serialize render environment: {error}"))?;
    serde_json::from_str::<RenderEnv>(&json)
        .map(Some)
        .map_err(|error| format!("parse render environment: {error}"))
}

fn resolve_region_render_env(env: &mut Option<RenderEnv>, regions: &DocumentRegions) {
    if regions.sections.len() <= 1
        && let Some(env) = env
    {
        let line_px = regions.paragraph_spacing_line_px(0);
        env.paragraph_spacing_line_px = (line_px != 16.0).then_some(line_px);
        env.doc_grid_pitch_px = regions.doc_grid_snap_pitch_px(0);
    }
}
'''
  s+=helper
 if n=='wasm.rs':
  anchor='    /// Warms with the complete render environment.';assert s.count(anchor)==1
  s=s.replace(anchor,'''    /// Warms the resident body under a region layout request.
    pub fn warm_story_for_region_layout(&self, story: &str, input: &str) -> Result<(), JsValue> {
        let _fonts = self.fonts.enter();
        self.engine
            .warm_story_for_region_layout(story, input)
            .map_err(js_err)
    }

'''+anchor)
 (p/(n+'.na')).write_text(s);(p/(n+'.request.diff')).write_text(''.join(difflib.unified_diff((old/(n+'.na')).read_text().splitlines(True),s.splitlines(True),fromfile=n+'.warm-layout-env',tofile=n+'.na')));f.write_text(s)
for n in ['docx_edit.d.ts','docx_edit_bg.wasm.d.ts']:shutil.copyfile(src/'packages/docx/src/wasm/generated/edit'/n,p/(n+'.voor'))
(p/'bronpinnen.json').write_text(json.dumps({'voor':pins,'na':{n:sha(p/(n+'.na'))for n in ['engine.rs','wasm.rs','mutation_proof.rs','lib.rs']},'basis':'warm-layout-env/*.rs.na;extra request-API en gedeelde helpers voor bestaande regionlayout'},indent=2)+'\n')
for n in ['bouw.py','bouw-opdracht.py']:
 s=(old/n).read_text().replace("['editsession_warm_story:function','editsession_warm_story_with_render_env:function']","['editsession_warm_story:function','editsession_warm_story_for_region_layout:function','editsession_warm_story_with_render_env:function']").replace('Private complete RenderEnv-warm-API boven bestaande warm/cachemeetmodule','Private requestbewuste warm-API boven volledige RenderEnv/warm/cachemeetmodule');(p/n).write_text(s)
