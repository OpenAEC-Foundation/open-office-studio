from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent;repo=p.parents[2];bron=repo/'.local/integratiecontrole/font-hergebruik/bron';gereedschap=repo/'.local/integratiecontrole/font-hergebruik/gereedschap';uit=p/'kern';uit.mkdir(exist_ok=False);env={**os.environ,'CARGO_TARGET_DIR':str(bron/'target-wasm')}
subprocess.run(['cargo','build','-p','betteroffice-docx-edit','--lib','--features','wasm,tiff,metafile,heap-stats','--target','wasm32-unknown-unknown','--release','--locked','--offline'],cwd=bron,env=env,check=True)
subprocess.run([str(gereedschap/'bindgen/wasm-bindgen'),'--target','web','--out-name','docx_edit','--out-dir',str(uit),str(bron/'target-wasm/wasm32-unknown-unknown/release/docx_edit.wasm')],check=True)
wasm=uit/'docx_edit_bg.wasm';opt=uit/'opt.wasm';subprocess.run([str(gereedschap/'binaryen/bin/wasm-opt'),'-O3',str(wasm),'-o',str(opt)],check=True);opt.replace(wasm)
code="""import{readFileSync}from'node:fs';const m=p=>new WebAssembly.Module(readFileSync(p)),a=m(process.argv[1]),b=m(process.argv[2]),i=m=>JSON.stringify(WebAssembly.Module.imports(m).map(r=>`${r.module}:${r.name}:${r.kind}`).sort()),e=m=>WebAssembly.Module.exports(m).map(r=>`${r.name}:${r.kind}`).sort();if(i(a)!==i(b))throw Error('Importinterface verschilt');const x=e(a),y=e(b);if(y.some(n=>!x.includes(n)))throw Error('Oude export ontbreekt');const extra=x.filter(n=>!y.includes(n));if(JSON.stringify(extra)!==JSON.stringify(['editsession_warm_story:function','editsession_warm_story_for_region_layout:function','editsession_warm_story_with_render_env:function']))throw Error('Onverwachte extra exports '+JSON.stringify(extra));console.log(JSON.stringify({imports_exact:true,oude_exports_behouden:true,extra}))"""
with (uit/'interface.json').open('x')as f:subprocess.run(['node','--input-type=module','--eval',code,str(wasm),str(repo/'vendor/tekstengine/docx_edit_bg.wasm')],stdout=f,check=True)
for n in ['docx_edit.d.ts','docx_edit_bg.wasm.d.ts']:
 import shutil
 shutil.copyfile(uit/n,bron/'packages/docx/src/wasm/generated/edit'/n)
(uit/'bouw.json').write_text(json.dumps({'sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'bytes':wasm.stat().st_size,'interface':json.load(open(uit/'interface.json')),'doel':'Private requestbewuste warm-API boven volledige RenderEnv/warm/cachemeetmodule;geen productievariant'},indent=2)+'\n')
