from pathlib import Path
import os,subprocess,json
r=Path.cwd();p=r/'.local/integratiecontrole/warm-layout-request';env={**os.environ,'PATH':'/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+os.environ['PATH']};python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python';assert json.loads((p/'desktop.json').read_text())['code']==0
# Alle bouw- en componentproeven zijn vooraf afgerond;geen parallel werk tijdens ABBA.
subprocess.run(['python3',str(p/'native-ronden.py')],env=env,check=True)
cmd=[python,str(p/'native-proef.py'),'--programma',str(p/'open-office-studio-warm-layout-request'),'--versie','2026.45.52','--uitvoer',str(p/'native-functie')]
with(p/'native-functie.log').open('x')as log:z=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=500)
(p/'native-functie-opdracht.json').write_text(json.dumps({'code':z.returncode,'opdracht':cmd,'grens':'Geïnstrumenteerde functie-/runtimecontrole na de normale ABBA;geen snelheidsbenchmark.'},indent=2)+'\n');assert z.returncode==0
subprocess.run([python,str(p/'documenten-beelden.py')],env=env,check=True)
