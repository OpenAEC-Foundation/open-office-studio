from pathlib import Path
import json,hashlib,ast,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/warm-layout-request';old=r/'.local/integratiecontrole/warm-story';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==22; build=json.loads((p/'desktop.json').read_text());refs[build['programma']]=build['programma_sha256'];(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
for f,h in refs.items():assert sha(Path(f))==h,f
expected=json.loads((old/'standaardbundel.json').read_text());actual={str(f.relative_to(r/'dist')):{'sha256':sha(f),'mode':f.stat().st_mode&0o777,'mtime_ns':f.stat().st_mtime_ns}for f in(r/'dist').rglob('*')if f.is_file()};assert len(actual)==529 and actual==expected
pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_npm_exact']
for f,h in pins.items():assert sha(r/f)==h
source=json.loads((p/'bron-hersteld.json').read_text())['bestanden']
for f,h in source.items():assert sha(r/f)==h
checks=[]
for f in sorted(p.glob('*.py')):ast.parse(f.read_text());checks.append({'pad':f.name,'controle':'Python AST','code':0})
for f in sorted(list(p.glob('*.mjs'))+list(p.glob('*.js'))):
 z=subprocess.run(['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--check',str(f)],capture_output=True,text=True);assert z.returncode==0,(f,z.stderr);checks.append({'pad':f.name,'controle':'node --check','code':0})
(p/'behoud.json').write_text(json.dumps({'elf_referenties_exact':refs,'standaarddist_byte_mode_mtime_exact':len(actual),'sdk_vendor_npm_exact':pins,'bron_hersteld':source,'scriptcontroles':checks},indent=2)+'\n');print('BEHOUD23ELF/529dist/6bron',len(checks))
