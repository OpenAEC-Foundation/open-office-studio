function officeRegionWarmInput(snapshot, story, env, layout) {
  try {
    if (layout !== true || snapshot.layoutWithRegions !== true || !env || Object.getPrototypeOf(env) !== Object.prototype || Object.keys(env).length !== 0) return null;
    const request = JSON.parse(snapshot.layoutInput);
    if (!request || typeof request !== 'object' || Array.isArray(request) || request.bodyStory !== story || !request.renderEnv || typeof request.renderEnv !== 'object' || Array.isArray(request.renderEnv)) return null;
    return snapshot.layoutInput;
  } catch {
    return null;
  }
}
