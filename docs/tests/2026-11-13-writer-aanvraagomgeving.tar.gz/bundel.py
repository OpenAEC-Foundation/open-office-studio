from pathlib import Path
import re,hashlib,json,shutil,os,gzip
r=Path.cwd();p=r/'.local/integratiecontrole/warm-layout-request';base=r/'.local/integratiecontrole/lint-invoer/dist';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();gen=(p/'kern/docx_edit.js').read_text()
def method(name):
 i=gen.index('    '+name+'(');j=gen.index('\n    }',i)+6;return gen[i:j]
assert method('apply_raw_ops').replace('apply_raw_ops','warm_story_for_region_layout').replace('ops_json','input')==method('warm_story_for_region_layout')
assert not(p/'dist').exists();shutil.copytree(base,p/'dist',copy_function=os.link);f=p/'dist/assets/chunk-Q7OC7M5Q-BzppsI5m.js';before=f.read_text();s=before;pairs=[]
def replace(a,b):
 global s
 assert s.count(a)==1,(a[:70],s.count(a));s=s.replace(a,b,1);pairs.append({'voor':a,'na':b})
m=re.search(r'apply_raw_ops\([^)]*\)\{[^}]*\}',s);assert m;old=m.group(0);assert old.startswith('apply_raw_ops(e,t){');binding=old.replace('apply_raw_ops','warm_story_for_region_layout');cap='supports_region_layout_warm(){return typeof p.editsession_warm_story_for_region_layout==="function"}';replace(old,cap+binding+old)
a='yrsBlocksForStory:(_,P={})=>{let z=e.yrs_blocks_for_story(_,JSON.stringify(P)),le=JSON.parse(z);return m.set(_,structuredClone(P)),le}'
b='warmStoryForRegionLayout:(_,P,k)=>{typeof e.supports_region_layout_warm==="function"&&e.supports_region_layout_warm()?e.warm_story_for_region_layout(_,k):JSON.parse(e.yrs_blocks_for_story(_,JSON.stringify(P)));m.set(_,structuredClone(P))},'+a;replace(a,b)
a='yrsBlocksForStory:(w,x={})=>JSON.parse(r.yrs_blocks_for_story(w,JSON.stringify(x)))';b='warmStoryForRegionLayout:(w,x,k)=>{typeof r.supports_region_layout_warm==="function"&&r.supports_region_layout_warm()?r.warm_story_for_region_layout(w,k):JSON.parse(r.yrs_blocks_for_story(w,JSON.stringify(x)))},'+a;replace(a,b)
a='function Ea(e,t,r=!0,n=!0,i,a,o,s=!0){';replace(a,(p/'keuze.js').read_text()+'\n'+a)
a='for(let{story:f,env:h}of e.renderInputs)N.yrsBlocksForStory(f,h);';b='for(let{story:f,env:h}of e.renderInputs){let _warmRegionInput=officeRegionWarmInput(e,f,h,s);_warmRegionInput!==null&&typeof N.warmStoryForRegionLayout==="function"?N.warmStoryForRegionLayout(f,h,_warmRegionInput):N.yrsBlocksForStory(f,h);}';replace(a,b)
f.unlink();f.write_text(s);gzip.open(p/'werker-voor.js.gz','wb').write(before.encode());gzip.open(p/'werker-na.js.gz','wb').write(s.encode());(p/'bundelwijzigingen.json').write_text(json.dumps(pairs,indent=2)+'\n')
f=p/'dist/assets/docx_edit_bg-ONvZFP_n.wasm';assert sha(f)=='737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9';f.unlink();shutil.copy2(p/'kern/docx_edit_bg.wasm',f);beforeMap={str(f.relative_to(base)):sha(f)for f in base.rglob('*')if f.is_file()};afterMap={str(f.relative_to(p/'dist')):sha(f)for f in(p/'dist').rglob('*')if f.is_file()};changed=[n for n in beforeMap if beforeMap[n]!=afterMap[n]];assert sorted(changed)==sorted(['assets/chunk-Q7OC7M5Q-BzppsI5m.js','assets/docx_edit_bg-ONvZFP_n.wasm']);(p/'bundel.json').write_text(json.dumps({'basis':'lint-invoer/dist','voor':beforeMap,'na':afterMap,'uitsluitend_vervangen':changed,'bindgen_tweestring_void_body_exact':True,'binding':binding,'capaciteit':cap,'warm_api':method('warm_story_for_region_layout'),'fallback':'Oude rawkern zonder export:gewone JSON-API met oorspronkelijke renderInputs.env en dezelfde JS-envregistratie;alle andere stories/nonemptyenv/plainlayout/layoutfalse behouden oorspronkelijke aanroep.','grens':'Private kandidaat;geen productvariant.'},ensure_ascii=False,indent=2)+'\n')
