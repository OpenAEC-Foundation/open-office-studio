use base64::{Engine as _,engine::general_purpose::STANDARD};
use office_writer_plakken::{TekstAanvraag,bereid_tekst_voor};
use docx_edit::EditingDoc;
fn main(){
 let pad=std::env::args().nth(1).expect("Eigen aanvraagpad ontbreekt");
 let a:TekstAanvraag=serde_json::from_slice(&std::fs::read(pad).unwrap()).unwrap();
 let doc=EditingDoc::new(71);doc.apply_update_v1(&STANDARD.decode(&a.snapshot).unwrap()).unwrap();
 let voor=doc.paragraphs("body").unwrap().last().unwrap().text.clone();
 let tekst=a.text.clone();let punt=a.position.clone();
 let antwoord=bereid_tekst_voor(a).unwrap();
 doc.apply_update_v1(&STANDARD.decode(&antwoord.delta).unwrap()).unwrap();
 let na=doc.paragraphs("body").unwrap().last().unwrap().text.clone();
 let goed=na==format!("{voor}{tekst}");
 println!("{}",serde_json::json!({"positie":punt,"voor":voor,"na":na,"caret":antwoord.caret,"exact":goed}));
 assert!(goed,"Native bibliotheek plaatst de tekst niet aan het opgegeven alineaeinde");
}
