from pathlib import Path
import subprocess,os,json
r=Path.cwd();u=r/'.local/integratiecontrole/herstel-paniek';env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];uit={}
for naam,exe in [('nieuw-a',r/'.local/integratiecontrole/status-plugin/open-office-studio-status-plugin'),('oud-a',r/'.local/integratiecontrole/status-telling/open-office-studio-status-telling')]:
 with (u/(naam+'.log')).open('x') as log:
  p=subprocess.run(['/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python','scripts/test-writer-rijk-plakken-native.py','--programma',str(exe),'--versie','2026.45.52','--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken','--uitvoer',str(u/naam)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 d=json.loads((u/naam/'rapport.json').read_text());uit[naam]={'code':p.returncode,'geslaagd':d['geslaagd'],'fout':d.get('fout'),'gui_fouten':d.get('gui_fouten'),'console_fouten':d.get('console_fouten'),'programma_sha256':d['programma_sha256']};(u/'rondes.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print(naam,p.returncode,d['geslaagd'],flush=True)
