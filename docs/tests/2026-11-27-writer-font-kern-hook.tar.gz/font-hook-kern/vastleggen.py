from pathlib import Path
import hashlib,json,tarfile,stat,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/font-hook-kern';out=r/'docs/tests/2026-11-27-writer-font-kern-hook';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
rich=json.loads((p/'rapport.json').read_text());corpus=json.loads((p/'corpusrapport.json').read_text());transfer=json.loads((p/'transfer-rapport.json').read_text());assert rich['geslaagd'] and corpus['geslaagd'] and not transfer['geslaagd']
assert len(corpus['gevallen'])==30 and sum(len(x['stappen'])for x in corpus['gevallen'])==43
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';refs=json.loads((old/'referenties-nacontrole.json').read_text());pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];bundle=json.loads((old/'standaardbundel.json').read_text())
behoud={'referenties':{f:('exact' if Path(f).exists() and sha(Path(f))==h else 'ontbreekt' if not Path(f).exists() else 'gewijzigd') for f,h in refs.items()},'bronpinnen':{f:sha(r/f)==h for f,h in pins.items()},'standaardbestanden':{f:sha(r/'dist'/f)==v['sha256'] and stat.S_IMODE((r/'dist'/f).stat().st_mode)==v['mode'] and (r/'dist'/f).stat().st_mtime_ns==v['mtime_ns'] for f,v in bundle.items()}}
assert all(behoud['bronpinnen'].values()) and all(behoud['standaardbestanden'].values());assert list(behoud['referenties'].values()).count('exact')==26
(p/'behoud-27nov.json').write_text(json.dumps(behoud,indent=2)+'\n')
inputs={}
for report in [rich['kern'],transfer['kern']]:
 for x in report['invoer']:
  f=r/x['file'];assert sha(f)==x['sha256'];inputs[x['file']]=x['sha256']
for f,h in corpus['inputs'].items():assert sha(Path(f))==h;inputs[f]=h
(p/'invoermanifest.json').write_text(json.dumps(inputs,indent=2)+'\n')
with tarfile.open(str(out)+'.tar.gz','w:gz')as tar:
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:tar.add(f,arcname='font-hook-kern/'+str(f.relative_to(p)),recursive=False)
 for i,(f,h)in enumerate(corpus['inputs'].items()):tar.add(f,arcname='corpus-invoer/'+str(i)+'-'+Path(f).name)
 for name in ['browser/wachtrij.mjs','bronpinnen.json','hook-voor.js','hook-na.js']:
  f=p.parent/'font-voorvlucht-hook'/name;tar.add(f,arcname='hook-afhankelijkheden/'+name)
with tarfile.open(str(out)+'.tar.gz')as tar:
 for m in tar.getmembers():
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert len(tar.extractfile(m).read())==m.size
report={'datum':'2026-11-27','basis_integratie':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'besluit':'Private kernpariteit groen; sessieoverdracht afgekeurd op byteongelijke encode_state. Geen productintegratie of native snelheidsacceptatie.','rijke_hook':rich,'corpus':corpus,'sessieoverdracht':transfer,'overdracht_snapshots':json.loads((p/'transfer-snapshots.json').read_text()),'grenzen':['Werkelijke volledige SDK-hook in React StrictMode met Node-Wasm via HTTP-RPC; geen echte WebWorker-protocoloverdracht of volledige editor.','Rijke fixture: 128 tabellen, twaalf gedeelde updates, Undo/Redo en splitsing; één geregistreerd regulier font voor alle gevraagde families/stijlen. Geen volledige fontfallbackdekking.','document=null gebruikt standaardregio’s; gelijke 68 pagina’s bewijzen geen oorspronkelijke documentlay-out.','Alleen opaque bovenste version-envelop verwijderd bij paragraaf/storyvergelijking; volledige staat/vector apart exact tussen gepaarde replica’s.','eigen:1-preview in rijke proef is geen bestaande revisie; twee echte accepted/rejected-previews afzonderlijk in corpus.','Overdracht stopt bij byteongelijkheid; font/layout na overdracht niet bereikt. Inhoudsverlies niet bewezen.','Ruwe byteassertie duurde meer dan 40 seconden; begrensde poging exit124. Hashassertie meldt direct dezelfde toetscategorie.','Geen native invoer/selectie/bewaren/DOCX/beelden, ABBA, productbuild, CI, andere platforms of releasevarianten deze ronde.','Een historische ELF ontbreekt reeds bij hervatting; overige26 en alle15 bronpinnen/529 standaardbestanden gecontroleerd. Niet door deze stap verwijderd.'],'behoud':behoud,'archief':{'pad':out.name+'.tar.gz','sha256':sha(Path(str(out)+'.tar.gz'))},'vervolg':'Isoleer sessieoverdracht: vergelijk werkelijke inhoud, projecties en vector naast serializeerbytes; verklaar verschil vóór aanpassing van oracle. Behoud beide staten en originele font/lay-outaanvraag. Pas daarna native kandidaat op ee89c80e-basis met positiecontextcorrectie, aparte korte/rijke ABBA en functie-/beeldbewijs. Automatisch herstel behouden; Database laatst.'}
Path(str(out)+'.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archief_sha256':report['archief']['sha256'],'referenties_exact':26,'corpus':30,'updates':43,'rijk':rich['geslaagd'],'overdracht':transfer['geslaagd']}))
