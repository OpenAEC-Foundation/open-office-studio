import React,{act,StrictMode}from'react';import{createRoot}from'react-dom/client';import{LayoutSelectionGate}from'@betteroffice/docx/layout';
import{proefHook as baseline}from'/@fs/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/.local/integratiecontrole/font-voorvlucht-hook/browser/sdk/baseline.mjs';
import{proefHook as kandidaat}from'/@fs/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/.local/integratiecontrole/font-voorvlucht-hook/browser/sdk/kandidaat.mjs';
window.IS_REACT_ACT_ENVIRONMENT=true;const root=createRoot(document.getElementById('root'));let result,key=0;const ok=(v,m)=>{if(!v)throw Error(m)},tick=async()=>act(async()=>{for(let i=0;i<20;i++)await Promise.resolve()});
function App({hook,props}){result=hook(props);return null}
async function rpc(q){const r=await fetch('/kern',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(q)}),x=await r.json();if(!r.ok)throw Error(x.fout);return x}
window.run=async(candidate,overdracht=true)=>{
 const slot=candidate?'kandidaat':'baseline',init=await rpc({slot,method:'init'}),fonts=[],layouts=[],errors=[];let version=init.version;
 const session={version:()=>version,getProposals:()=>({version,proposals:[],previewVersion:0}),residentWorkerProbe:()=>({layoutRevision:1})};
 const worker=Object.assign((s,request)=>rpc({slot,method:'layout',input:request}).then(x=>{layouts.push({sha256:x.sha256,request,pages:JSON.parse(x.value).layout?.pages?.length});return JSON.parse(x.value)}),{ownsDocument:()=>true,canSyncHostUpdates:()=>true,isViewerSession:()=>false});
 const fontRead=(s,input)=>{const ready=rpc({slot,method:'fonts',input});let resolve,reject;const wait=new Promise((a,b)=>{resolve=a;reject=b});fonts.push({input,ready,resolve,reject});return wait};
 let props={document:null,session,renderEnv:{},pageGap:24,zoom:1,residentMeasurementConfig:requirements=>({fontChains:Object.fromEntries(requirements.map(r=>[r.key,[init.fontId]])),defaults:{fontSize:11,fontFamily:'Liberation Sans'},compat:{},authoritativeShaping:true}),deferLayoutPass:()=>false,pagesContainerRef:{current:null},viewportLayoutRef:{current:null},syncCoordinator:new LayoutSelectionGate(),getScrollContainer:()=>null,onError:e=>errors.push(String(e)),experimentalWorkerOpen:true,layoutInWorker:worker,fontRequirementsInWorker:fontRead};
 const render=async()=>act(async()=>root.render(<StrictMode><App key={key} hook={candidate?kandidaat:baseline} props={props}/></StrictMode>));++key;await render();
 const run=async()=>{await act(async()=>result.runLayoutPipeline());await Promise.all(fonts.map(f=>f.ready))};
 await run();
 for(const text of [' eigen',' Ω',' العربية',' 漢字',' 🙂',' a\u0301',' einde']){const x=await rpc({slot,method:'edit',text});version=x.version;await run()}
 for(const method of ['undo','redo','split','undo','redo']){const x=await rpc({slot,method});version=x.version;await run()}
 props={...props,renderEnv:{showHiddenText:true,revisionPreview:{'eigen:1':'accepted'},themeColors:{accent1:'123456'}}};await render();await run();
 const requestedBeforeRelease=fonts.length;
 // Laat steeds één echt berekend antwoord door; een nieuwe wachtende dispatch wordt ook afgehandeld.
 for(let i=0;i<fonts.length;i++){const value=await fonts[i].ready;await act(async()=>fonts[i].resolve(value.value));await tick()}
 await act(async()=>{for(let i=0;i<100&&layouts.length===0;i++)await new Promise(r=>setTimeout(r,50))});await tick();ok(layouts.length===1,'Niet precies één echte eindlayout');ok(errors.length===0,'Hook meldt fout: '+errors.join('|'));
 const independent=result.readLayoutRequest();await tick();const last=fonts.at(-1);const value=await last.ready;await act(async()=>last.resolve(value.value));const read=await independent;ok(read!==null,'Afzonderlijke fontlezer ontbreekt');
 const transfer=overdracht?await rpc({slot,method:'transfer',input:read}):null;const snapshot=await rpc({slot,method:'snapshot'});await act(async()=>root.render(null));return{geslaagd:true,requestedBeforeRelease,fontaanvragen:fonts.length,layouts,errors,snapshot,transfer,independent:read};
};window.ready=true;
