from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/tabel-paginavakken-productie';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';exe=p/'open-office-studio-paginavakken-proef';cmd=['/usr/bin/python3',str(r/'scripts/test-writer-tabelgrepen-native.py'),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/'grepen')];env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};t=time.monotonic()
with(p/'grepen.log').open('x')as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while child.poll()is None:
  try:child.wait(timeout=20)
  except subprocess.TimeoutExpired:print('GREPEN ACTIEF',round(time.monotonic()-t),flush=True)
d=json.loads((p/'grepen/rapport.json').read_text());row={'opdracht':cmd,'code':child.returncode,'geslaagd':d['geslaagd'],'programma_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'seconden':time.monotonic()-t};(p/'grepen-run.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);assert child.returncode==0 and d['geslaagd']
