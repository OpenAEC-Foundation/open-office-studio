from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/tabel-paginavakken-productie';exe=p/'open-office-studio-paginavakken-proef';helper=p.parent/'font-rij-native/proef-rijk.py';old=p.parent/'font-rij-native';tools=old/'gereedschap/uitgepakt/usr';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();pins=json.loads((old/'harnas.json').read_text());assert sha(helper)==pins['rijk']['proef_sha256'];env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};rows=[]
while not exe.exists():time.sleep(10)
for label,variant in [('a-een','basis'),('b-een','kandidaat'),('b-twee','kandidaat'),('a-twee','basis')]:
 binary=p.parent/'digest-spans/open-office-studio-spans-veilig'if variant=='basis'else exe
 if variant=='basis':assert sha(binary)=='061b19f15628f803bf772ece68f3a4bb2d2b09e34012b04524d220500c00e849'
 cmd=['/usr/bin/python3',str(helper),'--programma',str(binary),'--versie','2026.45.52','--uitvoer',str(p/label)];print('START',label,flush=True);begin=time.monotonic()
 with(p/(label+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-begin),flush=True)
 d=json.loads((p/label/'rapport.json').read_text());rows.append({'label':label,'variant':variant,'code':proc.returncode,'geslaagd':d['geslaagd'],'programma_sha256':sha(binary),'helper_sha256':sha(helper),'invoer':d.get('lange_invoer'),'seconden':time.monotonic()-begin});(p/'native-ronden.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('GEREED',json.dumps(rows[-1]),flush=True);assert proc.returncode==0 and d['geslaagd']
