from pathlib import Path
import hashlib,json,stat,tarfile,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/tabel-paginavakken-productie';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
old=read(p.parent/'tabel-paginavakken/referenties-nacontrole.json');assert all(sha(Path(f))==v for f,v in old.items());refs=dict(old);exe=p/'open-office-studio-paginavakken-proef';refs[str(exe)]=sha(exe);(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
standard=read(p.parent/'projectie-context-telling-herbouw/standaardbundel.json');assert set(standard)=={str(f.relative_to(r/'dist'))for f in(r/'dist').rglob('*')if f.is_file()}
for name,expected in standard.items():
 f=r/'dist'/name;assert {'sha256':sha(f),'mode':stat.S_IMODE(f.stat().st_mode),'mtime_ns':f.stat().st_mtime_ns}==expected,name
(p/'behoud.json').write_text(json.dumps({'oudere_ELF_paden':len(old),'alle_ELF_paden':len(refs),'SHA_exact':True,'standaardbestanden':len(standard),'byte_mode_mtime_exact':True},indent=2)+'\n')
assets={str(f.relative_to(p/'dist')):sha(f)for f in(p/'dist').rglob('*')if f.is_file()};assert len(assets)==529
for f in(p/'dist/assets').glob('*.js'):
 s=f.read_text();assert '__OOS_GROEPMETING__'not in s and '__OOS_PAGINAVAKKEN__'not in s and '__OOS_NOOP_GREEP__'not in s
(p/'frontend-sha256.json').write_text(json.dumps(assets,indent=2)+'\n')
runs=read(p/'native-ronden.json');assert len(runs)==4 and all(x['code']==0 and x['geslaagd']for x in runs)
for row in runs:
 d=read(p/row['label']/'rapport.json');assert d['geslaagd']and not any(d['fouten'].values())
assert read(p/'grepen-run.json')['geslaagd'];assert read(p/'typescript.json')['code']==0 and read(p/'gericht-definitief.json')['code']==0
assert '2394 passed | 4 skipped'in(p/'suite.log').read_text()
# Bewaar ook de definitieve productbron en vaste regressie bij het bewijs.
for name in ['scripts/tekstengine-compatibiliteit.ts','src/tekst/liniaal/geometrie.ts','src/tekst/liniaal/tabelpaginavakken.test.ts','scripts/test-writer-tabelgrepen-native.py']:
 target=p/'productbron'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((r/name).read_bytes())
files=[]
for f in p.rglob('*'):
 rel=f.relative_to(p)
 if any(x in {'dist','__pycache__'}or x.startswith('target-')for x in rel.parts):continue
 if f.is_file()and f.suffix in {'.json','.py','.ts','.mjs','.log','.png','.docx','.patch'}and f.name not in {'manifest.json','archief.json'}:files.append(f)
helper=p.parent/'font-rij-native/proef-rijk.py';files.append(helper)
manifest=[{'pad':str(f.relative_to(p.parent)),'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(set(files))];(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(p/'manifest.json')
out=r/'docs/tests/2026-11-28-writer-tabelpaginavakken.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz',compresslevel=6)as tar:
 for f in sorted(set(files)):tar.add(f,arcname=str(f.relative_to(p.parent)),recursive=False)
with tarfile.open(out)as tar:
 for x in manifest:
  data=tar.extractfile(x['pad']).read();assert len(data)==x['bytes']and hashlib.sha256(data).hexdigest()==x['sha256']
print(json.dumps({'archief':str(out.relative_to(r)),'sha256':sha(out),'bytes':out.stat().st_size,'bestanden':len(set(files)),'manifest_groen':True},indent=2))
