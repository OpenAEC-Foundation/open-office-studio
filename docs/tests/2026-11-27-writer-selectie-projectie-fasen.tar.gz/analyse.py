from pathlib import Path
import json,collections,statistics
p=Path(__file__).resolve().parent

def stats(v):return {'aantal':len(v),'som_ms':sum(v),'mediaan_ms':statistics.median(v)if v else None,'maximum_ms':max(v)if v else None}
results={}
for name in ['een','twee']:
 r=json.loads((p/('diagnose-'+name)/'rapport.json').read_text());assert r['geslaagd']and all(not x for x in r['fouten'].values());d=r['tijdlijn_eind'];assert d['tag']=='selectie-projectie-fasen-v1'and not d['overflow'];rows=d['rows'];assert len(rows)<=d['limit'];assert all(set(x)=={'kind','phase','id','session','t'}for x in rows);assert all(a['t']<=b['t']for a,b in zip(rows,rows[1:]));opened={};spans=[]
 for ix,x in enumerate(rows):
  if x['kind']=='begin':assert x['id']not in opened;opened[x['id']]={**x,'row':ix}
  elif x['kind']=='end':
   a=opened.pop(x['id']);assert(a['phase'],a['session'])==(x['phase'],x['session']);assert x['t']>=a['t'];spans.append({'id':x['id'],'phase':x['phase'],'session':x['session'],'begin':a['t'],'eind':x['t'],'begin_row':a['row'],'eind_row':ix})
 assert not opened
 begin=r['invoer_begin_klok'];end=begin+r['lange_invoer']['begin_tot_frame_ms'];window=[x for x in spans if begin<=x['begin']<=x['eind']<=end];phases=collections.defaultdict(list)
 for x in window:phases[x['phase']].append(x['eind']-x['begin'])
 awaited=sorted([x for x in window if x['phase']=='nativeAwait'],key=lambda x:x['begin']);assert awaited
 causal=[]
 for index,a in enumerate(awaited):
  nested=[x for x in window if x['phase']=='tekst'and x['session']==a['session']and a['begin_row']<x['begin_row']<x['eind_row']<a['eind_row']];assert len(nested)==1
  token=nested[0];following=awaited[index+1]['begin']if index+1<len(awaited)else end
  resumes=[x for x in rows if x['phase']=='nativeResume'and x['session']==a['session']and a['eind']<=x['t']<following];assert len(resumes)==1
  publications=[x for x in window if x['phase']=='Ft'and x['session']==a['session']and resumes[0]['t']<=x['begin']<following];assert len(publications)==1
  pub=publications[0];causal.append({'await_id':a['id'],'callback_id':token['id'],'Ft_id':pub['id'],'callback_eind':token['eind'],'await_eind':a['eind'],'resume':resumes[0]['t'],'Ft_begin':pub['begin'],'callback_tot_await_ms':a['eind']-token['eind'],'resume_tot_Ft_ms':pub['begin']-resumes[0]['t']})
 at_parts=[]
 for a in [x for x in window if x['phase']=='At']:
  parts=[x for x in window if x['phase'].startswith('At.')and x['session']==a['session']and a['begin_row']<x['begin_row']<x['eind_row']<a['eind_row']];at_parts.append({'At_id':a['id'],'duur_ms':a['eind']-a['begin'],'delen':{x['phase']:x['eind']-x['begin']for x in parts},'deel_ids':[x['id']for x in parts]})
 dn=[x for x in window if x['phase']=='At.Dn'];dn_phases=collections.defaultdict(list)
 for parent in dn:
  for x in window:
   if (x['phase'].startswith('Dn.')or x['phase'].startswith('n6'))and parent['begin_row']<x['begin_row']<x['eind_row']<parent['eind_row']:
    dn_phases[x['phase']].append(x['eind']-x['begin'])
 results[name]={'rows':len(rows),'venster':{'begin':begin,'eind':end,'duur_ms':end-begin,'wall_begin_tot_frame_ms':r['lange_invoer']['wall_begin_tot_frame_ms']},'fasen':{k:stats(v)for k,v in phases.items()},'callback_tot_await_hervatting':stats([x['callback_tot_await_ms']for x in causal]),'resume_tot_Ft':stats([x['resume_tot_Ft_ms']for x in causal]),'causale_vensters':causal,'Dn_deelfasen_binnen_At':{k:stats(v)for k,v in dn_phases.items()},'At_delen':at_parts,'grenzen':'Echte nativeAwait-spans bevatten elk één tekstcallback; nativeResume en Ft op sessie/tijdvolgorde. Eén main-klok, geen exclusieve CPU-meting. At-delen en callbacks genest, niet optellen. Meetoverhead niet afgetrokken; andere microtaken/React/GC niet oorzakelijk toegewezen. Twee vaste rijke Linux-ronden; geen prestatiewinst of fysieke paintmeting.'}
(p/'analyse.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:{n:v for n,v in x.items()if n not in ['causale_vensters','At_delen']}for k,x in results.items()},ensure_ascii=False))
