from pathlib import Path
import os,subprocess,json,hashlib,shutil
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';m=json.loads((r/'bronversie45-bronnen.json').read_text())
for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
for fase,cmd,lognaam in [('frontend',['node_modules/.bin/vitest','run'],'bronversie45-volledig.log'),('desktop',['node_modules/.bin/tauri','build','--no-bundle'],'bronversie45-bouw.log')]:
    print('START',fase,flush=True)
    with (r/lognaam).open('w') as log:
        p=subprocess.Popen(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
        (r/'bronversie45-levende-fase.json').write_text(json.dumps({'fase':fase,'pid':p.pid,'opdracht':cmd},indent=2)+'\n')
        code=p.wait()
    print('EINDE',fase,code,flush=True)
    if code:raise SystemExit(code)
for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
bron=repo/'src-tauri/target/release/open-office-studio';doel=r/'open-office-studio-45.45-bronversie';assert not doel.exists()
digest=hashlib.sha256(bron.read_bytes()).hexdigest();assert digest!='b376f2d0e17923512e16dfd6058a093cfb420f7d9949b9f3c5d3f4f234195222'
shutil.copy2(bron,doel);assert hashlib.sha256(doel.read_bytes()).hexdigest()==digest
m.update(programma=str(doel.relative_to(repo)),programma_sha256=digest)
(r/'bronversie45-bronnen.json').write_text(json.dumps(m,indent=2)+'\n')
compilers=[]
for p in Path('/proc').glob('[0-9]*/comm'):
    try:
        naam=p.read_text().strip()
        if naam in ['rustc','cargo','rust-lld','ld.lld','cc']:compilers.append((str(p.parent),naam))
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not compilers,compilers
print('Eigen ELF bevroren',digest,'; fysieke vergelijking starten',flush=True)
p=subprocess.run(['python3',str(r/'voer-bronversie45-passieve-metingen.py')],cwd=repo)
print('EINDE fysieke vergelijking',p.returncode,flush=True)
raise SystemExit(p.returncode)
