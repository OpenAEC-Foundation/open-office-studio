from pathlib import Path
import json,hashlib,tarfile,subprocess,datetime,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-grote-bron';s=r/'native/onderzoek/writer-bronjournaal'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
uit=json.loads((u/'uitkomst.json').read_text());assert len(uit)==5 and all(v['code']==0 and v['stopreden'] is None for v in uit)
assert len(set(v['binary_sha256'] for v in uit))==1
logs={}
for v in uit:
 naam=str(v['payload_mib']) if v['vervolgstappen']==0 else f"{v['payload_mib']}-{v['vervolgstappen']}";logs[naam]=json.loads((u/f'{naam}.log').read_text())
assert logs['63-1028']['sessie']['vervolgen']==1028 and logs['63-1028']['sessie']['volledige_herstarts']==4 and logs['63-1028']['sessie']['volledige_broncontroles']==17
for naam in ['journaal.rs','proef.rs','geschiedenis.rs','unicode.rs','grenzen.rs','middelen.rs','grote_bron.rs']:assert (s/naam).read_bytes()==(u/'voorbereid'/naam).read_bytes()
p=subprocess.run(['python3',str(s/'voorbereiden.py'),'--uitvoer',str(u/'voorbereid')],capture_output=True,text=True);assert p.returncode!=0 and 'niets overschreven' in p.stderr;(u/'bestaande-uitvoer.log').write_text(p.stdout+p.stderr)
libs={}
for a in json.loads((u/'bouw.json').read_text())['opdracht']:
 if '.rlib' in a:
  naam,pad=a.split('=',1);libs[naam]={'pad':pad,'sha256':sha(Path(pad))}
(u/'bibliotheken.json').write_text(json.dumps(libs,indent=2))
keuze=[p for p in u.iterdir() if p.suffix in ['.json','.log','.py','.txt']]+[p for p in s.iterdir() if p.suffix in ['.rs','.py','.json','.md']];manifest={str(p.relative_to(r)):sha(p) for p in keuze}
map=r/'docs/tests/writer-grote-bron-2026-11-11';map.mkdir(exist_ok=True);a=map/'bewijs.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for p in keuze:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(a) as t:
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]
j={'datum_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Grote bronbytes en begrensde vervolgreeks in onderzoeksprototype getest; geen productintegratie.','bronbasis':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'bronbestanden':{str(p.relative_to(r)):sha(p) for p in s.iterdir() if p.is_file()},'fixture':'Eigen kleine alinea met opaque binaire metadatabuffer. Geen grote tekst-/paginafixture of DOCX-gebruikersbestand. Werkelijke gecodeerde CRDT-bronomvang wordt getoetst; geen grote bronbestanden op schijf.','uitkomsten':uit,'inhoud':logs,'geheugen':'time_maxrss_kib is Linux maximale RSS van het volledige proefproces, inclusief fixture, orakel en kopieën. De afzonderlijke RSS-bemonstering kan kortstondige pieken missen en omvat procesobservatie; geen appgeheugen of algemene heapgrens.','begrenzing':{'adresruimte_gib':3,'bemonsterde_rss_stop_gib':1.5,'looptijd_max_seconden_per_proef':120,'beschikbaar_geheugen_stop_gib':2,'vrije_schijf_stop_gib':1,'alleen_eigen_procesgroep':True},'voorbereiding':{'zeven_bronnen_bytegelijk':True,'vendorpinnen_gevalideerd':True,'bestaande_uitvoer_geweigerd':True,'rustfmt_en_diffcheck':True},'archief':{'pad':str(a.relative_to(r)),'bytes':a.stat().st_size,'sha256':sha(a),'bestandsbytes_teruggelezen':True,'manifest':manifest},'niet_getest':['Geen desktopadapter, appbuild, visuele/GUI-pariteit of appversnelling','Geen grote tekstpagina’s, rijke tabellen, echte Unicode/IME-GUI of revisie-GUI op nieuwe route','Geen urenlange lektest; 1028 vervolgstappen duren slechts enkele seconden','Geen nieuwe platform- of zeveneditieacceptatie'],'product':'Appcode, journaalkern, SDK, versies, gebruikersgegevens en referentiebinaries blijven gelijk. Alleen nieuwe onderzoekstest/voorbereider/documentatie.','vervolg':'Ontwerp een afzonderlijk opt-in desktopadaptercontract voor schema 3 met zelfstandige volledige schema-2-validatie bij capaciteit en volledige bronreset bij verlopen binding. Behoud standaardroute. Test fout-/levensduur-/wachtrij-/selectiegedrag voordat kandidaatbouw en echte GUI-pariteit worden uitgevoerd. Rijke grote tekst/heap en urenlange lektests blijven daarnaast open.','vrije_gib':round(shutil.disk_usage(r).free/1024**3,2)}
(r/'docs/tests/2026-11-11-writer-grote-bron.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'archief_bytes':a.stat().st_size,'sha256':sha(a),'vrije_gib':j['vrije_gib']},indent=2))
