from pathlib import Path
import subprocess,resource,os,signal,time,json,shutil,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-grote-bron';assert shutil.disk_usage(r).free>1.5*1024**3
assert Path('/usr/bin/time').exists()
def beperk():resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
bouw=json.loads((u/"bouw.json").read_text()); b=subprocess.run(bouw["opdracht"],capture_output=True,text=True,timeout=60); (u/"bouw.log").write_text(b.stdout+b.stderr); bouw["code"]=b.returncode; (u/"bouw.json").write_text(json.dumps(bouw,indent=2)); assert b.returncode==0,b.stderr
uit=[]
for n,stappen in [(63,0),(65,0),(99,0),(101,0),(63,1028)]:
 naam=str(n) if stappen==0 else f"{n}-{stappen}"
 with (u/f'{naam}.log').open('w') as f:
  cmd=['/usr/bin/time','-f','%M','-o',str(u/f'{naam}-piek-kib.txt'),str(u/'grote_bron'),str(n),str(stappen)];p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=beperk);t=time.monotonic();reden=None;hoog=0
  while p.poll() is None:
   status=Path(f'/proc/{p.pid}/task/{p.pid}/children')
   for pid in ([p.pid]+[int(x) for x in status.read_text().split()] if status.exists() else []):
    try:
     s=Path(f'/proc/{pid}/status').read_text();rss=int(next((x.split()[1] for x in s.splitlines() if x.startswith('VmRSS:')),'0'));hoog=max(hoog,rss)
    except FileNotFoundError:pass
   mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
   if time.monotonic()-t>120 or hoog>1572864 or mem<2*1024**2 or shutil.disk_usage(r).free<1024**3:
    reden='Eigen begrensde proef gestopt wegens tijd/geheugen/schijfgrens';os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5);break
   time.sleep(.1)
  code=p.wait();v={'payload_mib':n,'vervolgstappen':stappen,'code':code,'seconden':time.monotonic()-t,'stopreden':reden,'rss_kib_bemonsterd':hoog,'time_maxrss_kib':int((u/f'{naam}-piek-kib.txt').read_text().strip()) if code==0 else None,'opdracht':cmd,'binary_sha256':hashlib.sha256((u/'grote_bron').read_bytes()).hexdigest()};uit.append(v);(u/'uitkomst.json').write_text(json.dumps(uit,indent=2));print(v,flush=True);assert code==0,(u/f'{naam}.log').read_text()
