window._geenMelding={typen:0,aanroepen:0};
const typen=new Set();
for(const el of document.querySelectorAll('.office-tabpaneel:not([hidden]) .office-tekst'))
 for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return){
  const p=f.memoizedProps,t=f.type;
  if(!p?.documentBuffer||typeof p.onChange!=='function'||typeof t?.render!=='function'||typen.has(t))continue;
  typen.add(t);const origineel=t.render;
  t.render=function(p,ref){_geenMelding.aanroepen++;return origineel.call(this,{...p,onChange:undefined},ref)};
 }
_geenMelding.typen=typen.size;
if(!typen.size)throw Error('Geen eigen editor met documentcallback gevonden');
document.querySelector('.office-themaknop').click();
await new Promise(r=>setTimeout(r,150));
document.querySelector('.office-themaknop').click();
await new Promise(r=>setTimeout(r,500));
if(!_geenMelding.aanroepen)throw Error('Renderwrapper is niet gebruikt');
return _geenMelding;
