from pathlib import Path
import subprocess,os,time,json,hashlib
r=Path(__file__).resolve().parents[3];u=Path(__file__).resolve().parent
sha=lambda:hashlib.sha256((r/'src/editors.tsx').read_bytes()).hexdigest()
assert sha()=='af657e18fa369b880145adcaf646070311306df84d39f8f4d1f496dcd8a0a654'
env=os.environ.copy();env['PATH']='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/home/aia01/.cargo/bin:'+env['PATH'];env['OFFICE_TEST_CHROMIUM']='/home/aia01/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'
pnpm='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm'
stappen=[('typescript',[pnpm,'exec','tsc','--noEmit']),('frontend',[pnpm,'exec','vitest','run','--maxWorkers=1','--no-file-parallelism']),('webbouw',[pnpm,'run','build'])]
for n in ['lettergrootte','kleur','spiegel','spelling']:stappen.append(('gui-'+n,['node','scripts/test-writer-'+n+'-gui.mjs']))
result=[]
for naam,cmd in stappen:
 assert sha()=='af657e18fa369b880145adcaf646070311306df84d39f8f4d1f496dcd8a0a654'
 env['OFFICE_TEST_UIT']=str(u/naam);start=time.monotonic()
 (u/'actief.json').write_text(json.dumps({'pid':os.getpid(),'stap':naam,'opdracht':cmd})+'\n')
 with(u/(naam+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 result.append({'naam':naam,'code':p.returncode,'seconden':time.monotonic()-start,'opdracht':cmd});(u/'controles.json').write_text(json.dumps(result,indent=2)+'\n');print(naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(u/'actief.json').write_text(json.dumps({'status':'klaar','resultaat':'Alle frontend-/browserstappen geslaagd; native kandidaat nog niet gebouwd of geaccepteerd.'})+'\n')
