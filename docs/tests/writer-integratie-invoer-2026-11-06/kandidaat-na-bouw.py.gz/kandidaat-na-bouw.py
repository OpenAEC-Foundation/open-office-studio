"""Eindige Writer-GUI-proeven op alleen de eigen geïntegreerde testbinary."""
from pathlib import Path
import os,json,hashlib,subprocess,time
wt=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06')
root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');uit=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/.local/integratiecontrole/invoer-zonder-projectiemelding')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
begin=time.monotonic()
while not(uit/'desktop.json').exists():
 poort=uit/'controles.json'
 if poort.exists() and any(p['code'] for p in json.loads(poort.read_text())):raise SystemExit('Frontendpoort afgekeurd; geen native GUI')
 assert time.monotonic()-begin<3600,'Nativebouw nog niet klaar na begrensd wachten'
 time.sleep(5)
meta=json.loads((uit/'desktop.json').read_text());assert meta['code']==0

exe=Path(meta['programma']);assert sha(exe)==meta['programma_sha256']
env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
py=str(root/'.local/doorwerk-2026-11-02/gui-python/bin/python')
proeven=[('tekst','scripts/test-writer-rust-tekst-native.py',[]),('plakken','scripts/test-writer-rijk-plakken-native.py',['--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken']),('lang','scripts/test-writer-lang-native.py',['--herstelstart','--verwacht-rust-tekst','--verwacht-incrementele-bron','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--workerbron'])]
rapport=[]
for naam,script,args in proeven:
 assert sha(exe)==meta['programma_sha256']
 cmd=[py,str(wt/script),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(uit/('gui-'+naam)),*args]
 print('START',naam,flush=True);start=time.monotonic()
 with(uit/('gui-'+naam+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 rapport.append({'fase':naam,'code':p.returncode,'seconden':time.monotonic()-start,'programma_sha256':sha(exe),'testbron_sha256':sha(wt/script),'opdracht':cmd})
 (uit/'gui.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('Canonieke GUI-proeven geslaagd; beelden en prestatielimieten afzonderlijk beoordelen.',flush=True)

# Fysieke respons met ongewijzigde bron-/rasterpoort, zonder positieobserver.
# Ook een mislukte referentie blijft als afkeuring bewaard; nooit tijdgrens verhogen.
helper=root/'.local/doorwerk-2026-11-06/positie-integratie56/zonder-observer.py'
base=json.loads((root/'.local/doorwerk-2026-11-06/positie-integratie56/diagnose-opdracht.json').read_text())
base[1]=str(helper)
ref=wt/'.local/integratiecontrole/open-office-studio-integratie-56aa1fec'
assert sha(ref)=='c8e22ebd5501bcbf03a50682919715daf03b0b237ba7a19674129352caf86fee'
metingen=[]
for ronde,volgorde in [('ABBA',['referentie','kandidaat','kandidaat','referentie']),('BAAB',['kandidaat','referentie','referentie','kandidaat'])]:
 for nummer,naam in enumerate(volgorde,1):
  druk=[]
  for p in Path('/proc').glob('[0-9]*/comm'):
   try:n=p.read_text().strip()
   except OSError:continue
   if n in ['cargo','rustc','rust-lld','ld.lld','cc']or n.startswith('node (vitest'):druk.append(n)
  assert not druk,('Geen fysieke proef naast compiler/test',druk)
  programma=ref if naam=='referentie'else exe;pad=uit/('fysiek-'+ronde+'-'+str(nummer)+'-'+naam);cmd=list(base);cmd[cmd.index('--programma')+1]=str(programma);cmd[-1]=str(pad)
  with(uit/(pad.name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  verslag=json.loads((pad/'profiel.json').read_text());metingen.append({'ronde':ronde,'nummer':nummer,'naam':naam,'code':p.returncode,'programma_sha256':sha(programma),'geslaagd':verslag['geslaagd'],'getekende_tekst_ms':verslag.get('getekende_tekst_ms'),'broncontrole':verslag.get('broncontrole'),'achtergrond_bij_start':druk,'opdracht':cmd});(uit/'fysieke-metingen.json').write_text(json.dumps(metingen,ensure_ascii=False,indent=2)+'\n');print('FYSIEK',ronde,nummer,naam,p.returncode,verslag.get('getekende_tekst_ms'),flush=True)
print('Metingen beëindigd: geen automatische promotie, commit, installatie of release; inhoud, pixels, opmaakactualiteit en methode eerst beoordelen.',flush=True)
