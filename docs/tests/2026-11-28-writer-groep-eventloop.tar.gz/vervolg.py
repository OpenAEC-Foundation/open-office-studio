from pathlib import Path
import json,shutil,subprocess,os,hashlib,time
r=Path.cwd();p=r/'.local/integratiecontrole/groep-eventloop';first=p/'open-office-studio-eventloop-proef'
while not first.exists():time.sleep(5)
# Eerste variant apart behouden: abort moet ook de eigen invoerbuffer opruimen.
shutil.copytree(p/'dist',p/'dist-levensduur');f=next((p/'dist-levensduur/assets').glob('editors-*.js'));s=f.read_text();old='if(!re(c))return}$e.current===ft&&($e.current=null),await Je';new='if(!re(c)){$e.current===ft&&($e.current=null);return}}$e.current===ft&&($e.current=null),await Je';assert s.count(old)==1;f.write_text(s.replace(old,new));subprocess.run(['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--check',str(f)],check=True)
(p/'levensduur.json').write_text(json.dumps({'eerste_binary_sha256':hashlib.sha256(first.read_bytes()).hexdigest(),'eerste_variant_GUI_getest':False,'reden':'Bij abort na de extra onderbreking ook uitsluitend de eigen nog aanwezige invoerbuffer opruimen; geen nieuwere buffer wissen.','old':old,'new':new},indent=2)+'\n')
env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','TAURI_CONFIG':json.dumps({'build':{'frontendDist':str(p/'dist-levensduur')}}),'CARGO_TARGET_DIR':str(p/'target-proef')};cmd=['cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];t=time.monotonic()
with(p/'bouw-levensduur.log').open('x')as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while child.poll()is None:
  try:child.wait(timeout=20)
  except subprocess.TimeoutExpired:print('BOUW LEVENSDUUR',round(time.monotonic()-t),flush=True)
assert child.returncode==0;exe=p/'open-office-studio-eventloop-levensduur';shutil.copy2(p/'target-proef/release/open-office-studio',exe);(p/'bouwen-levensduur.json').write_text(json.dumps({'code':child.returncode,'programma':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'seconden':time.monotonic()-t,'opdracht':cmd},indent=2)+'\n');print('BOUW GEREED',flush=True)
