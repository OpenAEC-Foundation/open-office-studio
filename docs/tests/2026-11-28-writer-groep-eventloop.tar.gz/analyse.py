from pathlib import Path
import json,statistics
p=Path(__file__).resolve().parent;rows=[]
for run in json.loads((p/'runs.json').read_text()):
 d=json.loads((p/run['label']/'rapport.json').read_text());samples=d['nativefasen']['monsters'];sizes=[len(x['text'])for x in d['native_opdrachten'][:len(samples)]];assert sum(sizes)==1052 and not d['nativefasen']['overgeslagen'];assert len(samples)>0
 row={k:v for k,v in run.items()if k not in ['nativefasen','invoer']};row.update({'wall_ms':d['lange_invoer']['wall_begin_tot_frame_ms'],'groepen':len(samples),'groepsgroottes':sizes,'gemiddelde_tekens':statistics.mean(sizes),'rust_binnen_totaal_ms':sum(x['rustBinnenMs']for x in samples),'provider_vensters_totaal_ms':sum(x['duurMs']for x in samples),'voorbereiding_per_groep_mediaan_ms':statistics.median(x['rustBinnenMs']for x in samples),'laatste_keyup_tot_frame_ms':d['lange_invoer']['laatste_keyup_tot_frame_ms'],'fouten':d['fouten'],'tabellen':d['bewaarde_tabellen_exact']});rows.append(row)
summary={'ronden':rows,'grenzen':['Provider-/transportvensters bevatten wachten; geen exclusieve CPUtijd of volledige SDK-publicatiefasen.','Zelfde ELF met diagnostische vlag uit/aan. Geen ongeïnstrumenteerde productacceptatie.','Eén eventlooppost is geen absolute wandklokgrens of getoetste maximale eerste-toetslatentie.','Geen directe geïnjecteerde wachtrijwisseling tijdens het uitgestelde moment; normale levensduur-/lateantwoordroutes afzonderlijk getoetst.']}
if len(rows)==4:
 a=statistics.median(x['wall_ms']for x in rows if not x['flag']);b=statistics.median(x['wall_ms']for x in rows if x['flag']);summary.update({'basis_mediaan_ms':a,'yield_mediaan_ms':b,'verschil_procent':(b/a-1)*100})
(p/'analyse.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
