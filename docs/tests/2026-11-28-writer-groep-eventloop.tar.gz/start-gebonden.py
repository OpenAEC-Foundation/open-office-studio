from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/groep-eventloop';exe=p/'open-office-studio-eventloop-gebonden';tools=p.parent/'font-rij-native/gereedschap/uitgepakt/usr';env={**os.environ,'PATH':str(tools/'bin')+':/usr/bin:/bin','LD_LIBRARY_PATH':str(tools/'lib/x86_64-linux-gnu'),'OFFICE_TEST_JOURNAAL':'0'};rows=[]
while not(p/'bouwen-gebonden.json').exists():time.sleep(5)
for label,flag in [('a',False),('b',True),('b2',True),('a2',False)]:
 cmd=['/usr/bin/python3',str(p/'proef.py'),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/label)];t=time.monotonic();print('START',label,flush=True)
 with(p/(label+'.log')).open('x')as log:
  child=subprocess.Popen(cmd,env={**env,'OFFICE_TEST_GROEPYIELD':'1'if flag else'0'},stdout=log,stderr=subprocess.STDOUT)
  while child.poll()is None:
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-t),flush=True)
 d=json.loads((p/label/'rapport.json').read_text());row={'label':label,'flag':flag,'code':child.returncode,'geslaagd':d['geslaagd'],'yield_aantal':d.get('yield_aantal'),'programma_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'invoer':d.get('lange_invoer'),'nativefasen':d.get('nativefasen'),'seconden':time.monotonic()-t};rows.append(row);(p/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print('EINDE',json.dumps({k:v for k,v in row.items()if k!='nativefasen'}),flush=True);assert child.returncode==0 and d['geslaagd']
