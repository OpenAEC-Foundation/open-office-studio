from pathlib import Path
import brotli,json,hashlib
p=Path(__file__).resolve().parent;f=next((p/'dist-gebonden/assets').glob('editors-*.js'));expected=f.read_bytes();hits=[]
for q in(p/'target-proef/release/build').glob('*/out/tauri-codegen-assets/*.js'):
 try:data=brotli.decompress(q.read_bytes())
 except brotli.error:continue
 if data==expected:hits.append(q)
assert len(hits)==1;raw=hits[0].read_bytes();assert raw in(p/'open-office-studio-eventloop-gebonden').read_bytes();assert 'if(!re(c,__oosRij))'in f.read_text();assert '$e.current===ft&&($e.current=null);return'in f.read_text();print(hashlib.sha256(expected).hexdigest(),len(raw))
