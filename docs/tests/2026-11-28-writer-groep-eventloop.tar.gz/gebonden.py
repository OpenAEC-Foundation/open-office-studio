from pathlib import Path
import json,shutil,subprocess,os,hashlib,time
r=Path.cwd();p=r/'.local/integratiecontrole/groep-eventloop';first=p/'open-office-studio-eventloop-levensduur'
while not(p/'bouwen-levensduur.json').exists():time.sleep(5)
# Eerste variant apart behouden: abort moet ook de eigen invoerbuffer opruimen.
shutil.copytree(p/'dist-levensduur',p/'dist-gebonden');f=next((p/'dist-gebonden/assets').glob('editors-*.js'));s=f.read_text();old='globalThis.__OOS_GROEP_YIELD_AANTAL__=';new='const __oosRij=G.current;globalThis.__OOS_GROEP_YIELD_AANTAL__=';assert s.count(old)==1;s=s.replace(old,new);assert s.count('if(!re(c)){$e.current===ft')==1;f.write_text(s.replace('if(!re(c)){$e.current===ft','if(!re(c,__oosRij)){$e.current===ft'));subprocess.run(['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--check',str(f)],check=True)
(p/'wachtrijbinding.json').write_text(json.dumps({'eerste_binary_sha256':hashlib.sha256(first.read_bytes()).hexdigest(),'voorafgaande_variant_GUI_getest':False,'reden':'Na de extra onderbreking ook de oorspronkelijke wachtrij-identiteit controleren. Beide eerdere varianten uitsluitend gebouwd, niet in de GUI getoetst.','old':old,'new':new},indent=2)+'\n')
env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','TAURI_CONFIG':json.dumps({'build':{'frontendDist':str(p/'dist-gebonden')}}),'CARGO_TARGET_DIR':str(p/'target-proef')};cmd=['cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];t=time.monotonic()
with(p/'bouw-gebonden.log').open('x')as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while child.poll()is None:
  try:child.wait(timeout=20)
  except subprocess.TimeoutExpired:print('BOUW LEVENSDUUR',round(time.monotonic()-t),flush=True)
assert child.returncode==0;exe=p/'open-office-studio-eventloop-gebonden';shutil.copy2(p/'target-proef/release/open-office-studio',exe);(p/'bouwen-gebonden.json').write_text(json.dumps({'code':child.returncode,'programma':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'seconden':time.monotonic()-t,'opdracht':cmd},indent=2)+'\n');print('BOUW GEREED',flush=True)
