from pathlib import Path
import json,hashlib,stat,tarfile
r=Path.cwd();p=r/'.local/integratiecontrole/groep-eventloop';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text());old=read(p.parent/'tabel-paginavakken-productie/referenties-nacontrole.json');assert len(old)==55 and all(sha(Path(f))==v for f,v in old.items());refs=dict(old)
for f in p.glob('open-office-studio-*'):refs[str(f)]=sha(f)
assert len(refs)==58;(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
standard=read(p.parent/'projectie-context-telling-herbouw/standaardbundel.json');assert set(standard)=={str(f.relative_to(r/'dist'))for f in(r/'dist').rglob('*')if f.is_file()}
for name,v in standard.items():
 f=r/'dist'/name;assert {'sha256':sha(f),'mode':stat.S_IMODE(f.stat().st_mode),'mtime_ns':f.stat().st_mtime_ns}==v,name
plain=read(p.parent/'tabel-paginavakken-productie/frontend-sha256.json');assert all(sha(p.parent/'tabel-paginavakken-productie/dist'/n)==v for n,v in plain.items())
(p/'behoud.json').write_text(json.dumps({'oudere_ELF_paden':len(old),'alle_ELF_paden':len(refs),'SHA_exact':True,'standaardbestanden':len(standard),'byte_mode_mtime_exact':True,'aanvullende_basisbundel_SHA_exact':len(plain)},indent=2)+'\n')
runs=read(p/'runs.json');assert len(runs)==4 and all(x['code']==0 and x['geslaagd']for x in runs);assert all((x['yield_aantal']>0)==x['flag']for x in runs)
for x in runs:
 d=read(p/x['label']/'rapport.json');assert not any(d['fouten'].values())and d['bewaarde_tabellen_exact']==128
first=read(p/'bouwen.json')[0]['sha256'];assert first==read(p/'levensduur.json')['eerste_binary_sha256'];assert read(p/'bouwen-levensduur.json')['sha256']==read(p/'wachtrijbinding.json')['eerste_binary_sha256']
files=[]
for f in p.rglob('*'):
 rel=f.relative_to(p)
 if any(x.startswith('dist')or x.startswith('target-')or x=='__pycache__'for x in rel.parts):continue
 if f.is_file()and f.suffix in {'.json','.py','.log','.png','.docx'}and f.name not in {'manifest.json','archief.json'}:files.append(f)
manifest=[{'pad':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(set(files))];(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(p/'manifest.json');out=r/'docs/tests/2026-11-28-writer-groep-eventloop.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz',compresslevel=6)as tar:
 for f in sorted(set(files)):tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(out)as tar:
 for x in manifest:
  data=tar.extractfile(x['pad']).read();assert len(data)==x['bytes']and hashlib.sha256(data).hexdigest()==x['sha256']
print(json.dumps({'archief':str(out.relative_to(r)),'sha256':sha(out),'bytes':out.stat().st_size,'bestanden':len(set(files)),'manifest_groen':True},indent=2))
