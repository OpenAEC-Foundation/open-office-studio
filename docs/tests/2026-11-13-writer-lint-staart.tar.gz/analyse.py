from pathlib import Path
import collections,gzip,hashlib,json,statistics
u=Path(__file__).resolve().parent;p=u/'opname';r=json.loads((p/'rapport.json').read_text());o=json.loads((u/'opzet.json').read_text());assert r['geslaagd'] and not any(r['fouten'].values());assert r['schema']==2 and r['bewaarde_tabellen_exact']==128;assert r['programma_sha256']==o['programma_sha256']=='acb77036935feed425b7c81a5dbd2ef796ffcb4307db96c9845aa6dd8b70c958'
t=r['publicatietijdlijn'];assert t['hersteld'] and not t['overgeslagen'];rows=t['regels'];counts=collections.Counter(x['soort'] for x in rows);assert counts['applyLocalUpdate']==counts['onUpdate']==len(r['nativefasen']['monsters'])
last=r['lange_invoer']['laatste_keyup_ms'];final=last+r['lange_invoer']['laatste_keyup_tot_frame_ms'];start=final-r['lange_invoer']['begin_tot_frame_ms'];first=min(x['begin'] for x in rows if x['soort']=='keydown');assert r['profiel_begin_klok']<=start<=first
windows={}
for naam,lo,hi in [('invoer',start,last),('staart',last,final)]:
 win={}
 for soort in ['onUpdate','applyLocalUpdate','setSelection','tablePayload','readParagraphs','readStories']:
  a=[x for x in rows if x['soort']==soort and lo<=x['begin']<=hi];ds=[x['einde']-x['begin'] for x in a];win[soort]={'aantal':len(a),'som_ms':sum(ds),'max_ms':max(ds,default=0),'eerste_begin_ms':min((x['begin'] for x in a),default=None),'laatste_einde_ms':max((x['einde'] for x in a),default=None)}
 frames=[x['begin'] for x in rows if x['soort']=='rAF' and lo<=x['begin']<=hi];gaps=[{'begin':a,'einde':b,'pauze_ms':b-a} for a,b in zip(frames,frames[1:])];win['raf_callbackpauzes']=sorted(gaps,key=lambda x:x['pauze_ms'],reverse=True)[:8];windows[naam]=win
# De methodenklokken en rAF-tijdlijn zijn echt; profielstacks worden nooit
# kunstmatig over de wandtijd verdeeld wanneer de engine nulstempels levert.
ev=json.load(gzip.open(p/'profielen.json.gz','rt'));klaar=[e for e in ev if e.get('method')=='ScriptProfiler.trackingComplete'];assert len(klaar)==1;samples=klaar[0]['params']['samples']['stackTraces'];assert len(samples)==r['profiel_samples'];timestamps=collections.Counter(x.get('timestamp') for x in samples)
bronnen={}
for b in r['scriptbronnen']:
 data=gzip.decompress((p/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256'];bronnen[b['url']]=data.decode()
leden=collections.Counter();rects=[]
for s in samples:
 namen={f['name'] for f in s['stackFrames']}
 for naam in ['buildStory','storySegmentUnitDigests','tablePayload','readParagraphs','targetAt','wasm-stub']:
  if naam in namen:leden[naam]+=1
 if s['stackFrames'] and s['stackFrames'][0]['name']=='getClientRects':rects.append(s)
contexts=[];seen=set()
for s in rects:
 key=tuple((f.get('name'),f.get('url'),f.get('line'),f.get('column')) for f in s['stackFrames'][:4])
 if key in seen:continue
 seen.add(key);context=[]
 for f in s['stackFrames'][1:4]:
  if f.get('url') not in bronnen:continue
  line=bronnen[f['url']].split('\n')[f['line']-1];i=f['column']-1;context.append({'frame':f,'bron':line[max(0,i-70):i+850]})
 contexts.append(context)
uit={'programma_sha256':r['programma_sha256'],'functioneel_geslaagd':True,'invoer':r['lange_invoer'],'native_groepen':len(r['nativefasen']['monsters']),'tijdlijnregels':len(rows),'telling':dict(counts),'vensters':windows,'profiel_begin_ms':r['profiel_begin_klok'],'invoer_begin_ms':start,'eerste_keydown_ms':first,'laatste_keyup_ms':last,'framegrens_ms':final,'profiel_eind_ms':r['profiel_eind_klok'],'samples':len(samples),'sampletijdstempels':dict(timestamps),'stacks_overlappend':dict(leden),'getClientRects_leafsamples':len(rects),'getClientRects_broncontexten':contexts,'grenzen':['Eén geïnstrumenteerde ronde, geen prestatieacceptatie of herhaling tot groen.','Klokvensters gebruiken echte performance.now-tijdstempels van de probe. Aantallen delen grenspunten; synchrone duren tellen per methode en zijn geen exclusieve CPU.','Sampletijdstempels kunnen alle nul zijn; geen tijdkoppeling van CPUstacks naar invoer of staart.','Probe-opruimen/exporteren en inspectie bij stoppen vallen deels na frame in profielvenster.','rAF-callbackpauzes zijn geen fysieke schermpaint/FPS. Geen app-/issue-/migratieacceptatie.']}
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:uit[k] for k in ['invoer','telling','vensters','samples','sampletijdstempels','stacks_overlappend','getClientRects_leafsamples']},ensure_ascii=False,indent=2))
