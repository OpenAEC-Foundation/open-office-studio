(() => {
  'use strict';
  if (window._publicatieProbe) throw Error('Publicatieprobe bestaat al');
  const doel = sessie(), regels = [], oud = new Map(), wrappers = new Map();
  let actief = true, overgeslagen = 0, raf;
  function voeg(soort, begin, einde = begin, extra = {}) {
    if (!actief) return;
    if (regels.length < 8192) regels.push({soort, begin, einde, ...extra});
    else overgeslagen++;
  }
  const namen = ['applyLocalUpdate', 'setSelection', 'readParagraphs', 'tablePayload',
    ...(typeof doel.readStories === 'function' ? ['readStories'] : [])];
  for (const naam of namen) {
    const descriptor = Object.getOwnPropertyDescriptor(doel, naam), fn = doel[naam];
    if (typeof fn !== 'function' || (descriptor && !descriptor.configurable)) throw Error('Niet veilig te volgen: '+naam);
    oud.set(naam, {descriptor, fn});
  }
  for (const naam of namen) {
    const wrapper = function(...args) {
      const begin = performance.now();
      try { return Reflect.apply(oud.get(naam).fn, this, args); }
      finally { voeg(naam, begin, performance.now()); }
    };
    wrappers.set(naam, wrapper);
    Object.defineProperty(doel, naam, {value: wrapper, configurable: true, writable: true,
      enumerable: oud.get(naam).descriptor?.enumerable ?? false});
  }
  // Alleen een klok en herkomst, geen versie-, selectie- of documentlezing.
  const afmelden = doel.onUpdate((_, herkomst) => voeg('onUpdate', performance.now(), undefined,
    {herkomst: typeof herkomst === 'string' ? herkomst : null}));
  const toets = e => voeg(e.type, performance.now(), undefined, {key: e.key.toLowerCase(), eventTijd: e.timeStamp});
  window.addEventListener('keydown', toets, true);
  window.addEventListener('keyup', toets, true);
  const frame = () => { if (!actief) return; voeg('rAF', performance.now()); raf = requestAnimationFrame(frame); };
  raf = requestAnimationFrame(frame);
  window._publicatieProbe = {stop() {
    actief = false; cancelAnimationFrame(raf); afmelden();
    window.removeEventListener('keydown', toets, true); window.removeEventListener('keyup', toets, true);
    let hersteld = true;
    for (const naam of namen) {
      if (doel[naam] !== wrappers.get(naam)) { hersteld = false; continue; }
      const d = oud.get(naam).descriptor;
      if (d) Object.defineProperty(doel, naam, d); else delete doel[naam];
    }
    return {regels, overgeslagen, grens: 8192, hersteld, geen_extra_enginelezingen: true};
  }};
  return {namen, grens: 8192, observer: 'uitsluitend klokken, geen aanvullende enginequery'};
})()
