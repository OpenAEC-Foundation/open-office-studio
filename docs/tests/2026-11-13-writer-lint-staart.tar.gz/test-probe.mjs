import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const bron=fs.readFileSync(new URL('probe.js',import.meta.url),'utf8');let proeven=0;
function maak(){let klok=0,rafId=0,cancel,off=0,observer,aanroepen=0;const events=new Map(),ontvangen=[],antwoord={},promise=Promise.resolve(antwoord),fout=new Error('eigen fout');
 const proto={readParagraphs(...args){aanroepen++;ontvangen.push([this,args]);if(args[0]==='fout')throw fout;return antwoord}};
 const doel=Object.assign(Object.create(proto),{applyLocalUpdate(){aanroepen++;return antwoord},setSelection(){aanroepen++},tablePayload(){aanroepen++;return antwoord},readStories(){aanroepen++;return promise},onUpdate(fn){observer=fn;return()=>{off++}}});
 const oude=Object.getOwnPropertyDescriptors(doel);const w={addEventListener(n,fn){events.set(n,fn)},removeEventListener(n,fn){assert.equal(events.get(n),fn);events.delete(n)}};
 const c=vm.createContext({window:w,sessie:()=>doel,performance:{now:()=>++klok},requestAnimationFrame:fn=>{c.frame=fn;return ++rafId},cancelAnimationFrame:id=>{cancel=id},Reflect,Error});vm.runInContext(bron,c);
 return {doel,w,oude,antwoord,promise,fout,events,ontvangen,observer:()=>observer(),get off(){return off},get calls(){return aanroepen},frame:()=>c.frame(),get cancel(){return cancel}};
}
{
 const m=maak(),args=['tekst',{eigen:true}];assert.equal(m.doel.readParagraphs(...args),m.antwoord);assert.equal(m.ontvangen[0][0],m.doel);assert.equal(m.ontvangen[0][1][1],args[1]);proeven++;
 assert.equal(m.doel.readStories(),m.promise);proeven++;
 assert.throws(()=>m.doel.readParagraphs('fout'),e=>e===m.fout);proeven++;
 const n=m.calls;m.observer();assert.equal(m.calls,n);proeven++;
 m.events.get('keyup')({type:'keyup',key:'A',timeStamp:12});m.frame();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(m.off,1);assert.equal(m.events.size,0);assert.equal(m.doel.readParagraphs,Object.getPrototypeOf(m.doel).readParagraphs);assert.equal(Object.hasOwn(m.doel,'readParagraphs'),false);for(const [k,d]of Object.entries(m.oude))assert.deepEqual(Object.getOwnPropertyDescriptor(m.doel,k),d);proeven++;
 assert(r.regels.some(x=>x.soort==='onUpdate'));assert(r.regels.some(x=>x.soort==='keyup'));assert(r.regels.some(x=>x.soort==='rAF'));proeven++;
}
{const m=maak(),eigen=()=>7;m.doel.tablePayload=eigen;const r=m.w._publicatieProbe.stop();assert.equal(r.hersteld,false);assert.equal(m.doel.tablePayload,eigen);proeven++;}
{const m=maak();for(let i=0;i<8300;i++)assert.equal(m.doel.applyLocalUpdate(),m.antwoord);const r=m.w._publicatieProbe.stop();assert.equal(r.regels.length,8192);assert.equal(r.overgeslagen,108);assert(r.hersteld);proeven++;}
console.log(`${proeven} transparantie-/opruim-/grenscontroles geslaagd`);
