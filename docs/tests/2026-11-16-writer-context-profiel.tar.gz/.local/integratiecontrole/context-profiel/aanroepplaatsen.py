from pathlib import Path
import gzip,json,collections,hashlib,functools
p=Path(__file__).resolve().parent;dist=p.parent/'projectie-context/dist';result=[]
@functools.lru_cache(None)
def fragment(path,line,col):
 s=path.read_text();lines=s.splitlines(True);pos=sum(map(len,lines[:line-1]))+col-1
 return s[max(0,pos-180):pos+300]
for event in json.load(gzip.open(p/'native/profielen.json.gz','rt')):
 role='hoofdthread'
 if event['method']=='Worker.dispatchMessageFromWorker':role=event['params']['workerId'];event=json.loads(event['params']['message'])
 if event.get('method')!='ScriptProfiler.trackingComplete':continue
 counts=collections.Counter();saved={}
 for t in event['params']['samples']['stackTraces']:
  fs=t['stackFrames']
  for name in ['buildStory','storySegmentUnitDigests','layout_font_requirements_json','paragraphSavePlan','storyToBlocks','readParagraphs']:
   idx=next((i for i,f in enumerate(fs)if f.get('name')==name),None)
   if idx is None:continue
   stack=[]
   for f in fs[idx:idx+16]:
    loc=f.get('expressionLocation');item={k:f.get(k)for k in ['name','url','line','column','expressionLocation']}
    if loc and '/assets/'in f.get('url','') and loc['line']>0 and loc['column']>0:
     path=dist/'assets'/f['url'].split('/assets/')[1]
     if path.is_file():
      item['expressie_bron']=fragment(path,loc['line'],loc['column'])
    stack.append(item)
   k=(name,json.dumps(stack,sort_keys=True));counts[k]+=1;saved[k]=stack
 grouped={}
 for k,n in counts.most_common():
  a=grouped.setdefault(k[0],[])
  if len(a)<3:a.append({'samples':n,'stack':saved[k]})
 result.append({'context':role,'aanroepplaatsen':grouped})
(p/'aanroepplaatsen.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
for d in result:
 for name in ['layout_font_requirements_json','paragraphSavePlan','buildStory']:
  for t in d['aanroepplaatsen'].get(name,[])[:1]:
   print(d['context'],name,t['samples'])
   for f in t['stack'][:9]:print(f['name'],f.get('expressie_bron','')[:480])
