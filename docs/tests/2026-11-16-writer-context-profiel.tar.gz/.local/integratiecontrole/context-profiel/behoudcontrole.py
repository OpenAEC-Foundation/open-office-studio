from pathlib import Path
import hashlib,json,stat,shutil,py_compile
p=Path(__file__).resolve().parent;r=Path.cwd();old=p.parent/'projectie-context-telling-herbouw';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==27
for f,h in refs.items():assert sha(Path(f))==h,f
pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact']
for f,h in pins.items():assert sha(r/f)==h,f
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
assert set(bundle)=={str(f.relative_to(r/'dist'))for f in (r/'dist').rglob('*')if f.is_file()}
for f,v in bundle.items():
 q=r/'dist'/f;s=q.stat();assert sha(q)==v['sha256']and stat.S_IMODE(s.st_mode)==v['mode']and s.st_mtime_ns==v['mtime_ns'],f
for f,v in json.loads((p/'analyse.json').read_text())['bronbestanden'].items():assert sha(Path(f))==v['sha256']
for f in p.glob('*.py'):py_compile.compile(str(f),doraise=True)
result={'referenties27_exact':True,'standaarddist529_byte_mode_mtime_exact':True,'sdk_vendor_canonieke_bron_exact':pins,'private_geprofileerde_bron_exact':True,'python_syntaxis':sorted(f.name for f in p.glob('*.py')),'vrije_bytes_na':shutil.disk_usage(r).free,'productbron':'41e7000198f89d992e1059e9715636a44b39d21a'}
(p/'behoud.json').write_text(json.dumps(result,indent=2)+'\n');print('27 referenties,529 standaardbestanden,SDK/vendor/canonieke bron en profielscripts gecontroleerd')
