from pathlib import Path
import gzip,json,hashlib,collections
p=Path(__file__).resolve().parent;dist=p.parent/'projectie-context/dist';raw=json.load(gzip.open(p/'native/profielen.json.gz','rt'));out=[];sources={}
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def key(f):return (f.get('name',''),f.get('url',''),f.get('line'),f.get('column'))
def describe(k):
 name,url,line,col=k;d={'naam':name,'url':url,'regel':line,'kolom':col}
 if '/assets/' in url and line and col and line>0 and col>0:
  f=dist/'assets'/url.split('/assets/')[1]
  if f.is_file():
   s=f.read_text();lines=s.splitlines(True);offset=sum(map(len,lines[:line-1]))+col-1
   d['bron_rond_functiestart']=s[max(0,offset-50):offset+650];sources[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size}
 return d
for event in raw:
 role='hoofdthread'
 if event['method']=='Worker.dispatchMessageFromWorker':role=event['params']['workerId'];event=json.loads(event['params']['message'])
 if event.get('method')!='ScriptProfiler.trackingComplete':continue
 params=event['params'];traces=params['samples']['stackTraces'];counts=collections.Counter();leaf=collections.Counter();targets={}
 names=['buildStory','segments','storySegmentUnitDigests','readParagraphs','layout_font_requirements_json','paragraphSavePlan','storyToBlocks','layout_document_with_regions_retained_json','apply_update_with_inference']
 for t in traces:
  fs=t['stackFrames'];counts.update(set(map(key,fs)))
  if fs:leaf.update([key(fs[0])])
  for name in names:
   ids=[i for i,f in enumerate(fs) if f.get('name')==name]
   if ids:
    i=ids[0];targets.setdefault(name,collections.Counter()).update([tuple(key(f)for f in fs[i:i+7])])
 out.append({'context':role,'samples':len(traces),'nultijdstempels':sum(t['timestamp']==0 for t in traces),'profieltijdstempel':params['timestamp'],'inclusief_top':[dict(describe(k),samples=n)for k,n in counts.most_common(35)],'blad_top':[dict(describe(k),samples=n)for k,n in leaf.most_common(15)],'gerichte_stacks':{name:[{'samples':n,'stack':[describe(k)for k in ks]}for ks,n in c.most_common(4)]for name,c in targets.items()}})
result={'profielen':out,'bronbestanden':sources,'grenzen':['Stackvolgorde afzonderlijk leaf-first gekalibreerd; aantallen zijn samples, geen aanroepen of CPU-milliseconden.','Inclusieve stacklidmaatschappen overlappen; niet optellen.','Hoofdthread heeft uitsluitend nul-tijdstempels; geen fase- of staarttijdlijn afleidbaar. Workers hebben eigen klokken en meestal nul-tijdstempels.','Bronkoppeling aan bewaarde private dist van ee89c80e; runtimebronnen niet opnieuw opgehaald. Minified bron rond gemelde 1-based functiestart, geen oorspronkelijke sourcemap of Wasm-symbolisering.']}
(p/'analyse.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
for d in out:
 print(d['context'],d['samples'],d['nultijdstempels'])
 for name,stacks in d['gerichte_stacks'].items():
  print(name,[(s['samples'],[f['naam']for f in s['stack']])for s in stacks])
