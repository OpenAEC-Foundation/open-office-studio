from pathlib import Path
import py_compile,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/context-profiel';base=r/'.local/integratiecontrole/status-plugin/proef-rijk.py';old=(r/'.local/integratiecontrole/projectie-uitvoering/native-zonder-debugger.py').read_text();s=base.read_text();start=old.index('    from gui.webkit_inspector import Inspector as BasisInspector');end=old.index('    a.uitvoer.mkdir',start);inspector=old[start:end];s=s.replace('    from gui.webkit_inspector import Inspector\n',inspector)
for line in ["                r['wachtrijprobe'] = await p.ev((REPO / '.local/integratiecontrole/adaptieve-invoer/wachtrij-probe.js').read_text())\n","                r['uitleesprobe'] = await p.ev((REPO / '.local/integratiecontrole/bron-uitlezingen/probe.js').read_text())\n","                r['uitlezingen'] = await p.ev('_uitleesProbe.stop()')\n","                assert r['uitlezingen']['hersteld'] and r['uitlezingen']['overgeslagen']==0\n","                r['wachtrijtaken'] = await p.ev('_wachtrijProbe.stop()')\n"]:
 assert s.count(line)==1,line;s=s.replace(line,'')
anchor="                await p.ev('window._voor=stand();window._voorTekst=tekst();true')";assert s.count(anchor)==1
begin='''                r['worker_enable'] = await p.command('Worker.enable')
                assert not r['worker_enable'].get('error')
                await p.ev('void 0')
                await asyncio.sleep(.2)
                await p.ev('void 0')
                workers = {e['params']['workerId']: e['params'] for e in p.gebeurtenissen if e.get('method') == 'Worker.workerCreated'}
                assert workers, 'Geen eigen workers'
                r['workers'] = workers
                r['worker_profiel_begin'] = {}
                for worker in workers:
                    init = await p.command('Worker.initialized', {'workerId':worker})
                    antwoord = await p.worker(worker,'ScriptProfiler.startTracking',{'includeSamples':True})
                    assert not init.get('error') and not antwoord.get('error')
                    r['worker_profiel_begin'][worker] = {'initialized':init,'start':antwoord}
                r['profiel_begin'] = await p.command('ScriptProfiler.startTracking', {'includeSamples':True})
                assert not r['profiel_begin'].get('error')
                r['profiel_begin_klok'] = await p.ev('performance.now()')
'''
s=s.replace(anchor,anchor+'\n'+begin)
anchor="                assert await p.ev('tekst()===_voorTekst+_langeInvoer'), 'Gewone lange invoer ontbreekt'";assert s.count(anchor)==1
stop='''                r['profiel_eind_klok'] = await p.ev('performance.now()')
                r['profiel_stop'] = await p.command('ScriptProfiler.stopTracking')
                assert not r['profiel_stop'].get('error')
                r['worker_profiel_stop'] = {}
                for worker in workers:
                    antwoord = await p.worker(worker,'ScriptProfiler.stopTracking')
                    assert not antwoord.get('error')
                    r['worker_profiel_stop'][worker] = antwoord
                await p.ev('void 0')
                r['worker_disable'] = await p.command('Worker.disable')
                assert not r['worker_disable'].get('error')
                with gzip.open(a.uitvoer/'profielen.json.gz','wt',encoding='utf-8') as f:
                    json.dump(p.gebeurtenissen,f,ensure_ascii=False)
                r['notificatie_bytes'] = p.notificatie_bytes
'''
# Hergebruik alleen de afzonderlijke hoofdthread-stackkalibratie uit de bewezen proef.
a=old.index('                vanaf_kalibratie = len(p.gebeurtenissen)');b=old.index('                samples = compleet[0]',a);calibration=old[a:b]
s=s.replace(anchor,anchor+'\n'+stop+calibration)
assert 'Debugger.' not in s
(p/'native-profiel.py').write_text(s);py_compile.compile(str(p/'native-profiel.py'),doraise=True);(p/'bronpinnen.json').write_text(json.dumps({'basis_helper':str(base.relative_to(r)),'basis_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'profiel_helper_sha256':hashlib.sha256(s.encode()).hexdigest(),'grens':'ScriptProfiler op pagina en bestaande workers;geen Debugger,geen versie/positieprobes of nieuwe ELF. Extra uitlees/wachtrijwrappers verwijderd;standaard functie/fetch/selectiediagnose blijft.'},indent=2)+'\n')
