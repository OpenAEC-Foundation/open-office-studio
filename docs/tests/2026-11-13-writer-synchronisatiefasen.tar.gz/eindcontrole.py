from pathlib import Path
import json,hashlib,ast,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/replica-kosten';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();refs=json.load(open(p/'referenties-voor.json'));assert len(refs)==18;build=json.load(open(p/'desktop.json'));refs[build['programma']]=build['programma_sha256']
for f,h in refs.items():assert sha(Path(f))==h,f
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n');expected=json.load(open(p/'standaardbundel.json'));actual={str(f.relative_to(r/'dist')):{'sha256':sha(f),'mode':f.stat().st_mode&0o777,'mtime_ns':f.stat().st_mtime_ns}for f in(r/'dist').rglob('*')if f.is_file()};assert len(actual)==529 and actual==expected
pins={'node_modules/@betteroffice/docx-react/dist/index.mjs':'85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb','vendor/tekstengine/docx_edit_bg.wasm':'737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9','vendor/tekstengine/docx_layout_bg.wasm':'e339c612f7a027965aaa990239818c7c556d30877f018f6a3efaf6425a86e8fc','node_modules/@betteroffice/docx/dist/generated/edit/docx_edit_bg.wasm':'ff775228796835f0007a20742c67b5926e1e3f1f12d23e69fc295f7ff9511431'}
for f,h in pins.items():assert sha(r/f)==h,f
source=r/'.local/integratiecontrole/font-hergebruik/bron/crates/docx-edit/src';restored=json.load(open(r/'.local/integratiecontrole/replica-fontcache/bron-hersteld.json'))['bestanden']
for f,h in restored.items():assert sha(source/f)==h,f
checks=[]
for f in sorted(p.glob('*.py')):ast.parse(f.read_text());checks.append({'pad':f.name,'controle':'Python AST','code':0})
for pattern in ['*.mjs','*.js']:
 for f in sorted(p.glob(pattern)):
  cmd=['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--check',str(f)];z=subprocess.run(cmd,capture_output=True,text=True);assert z.returncode==0,(f,z.stderr);checks.append({'pad':f.name,'controle':'node --check','code':0})
(p/'behoud.json').write_text(json.dumps({'elf_referenties_exact':len(refs),'standaarddist_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':pins,'private_rust_bron_exact_ongewijzigd':restored,'scriptcontroles':checks},ensure_ascii=False,indent=2)+'\n');print('BEHOUD',len(refs),len(actual),'scriptcontroles',len(checks))
