from pathlib import Path
import json,collections,statistics,hashlib
from zipfile import ZipFile
from xml.etree import ElementTree as ET
p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();out={};docs={}
for name in ['native-a-een','native-b-een','native-b-twee','native-a-twee','native-sync-a','native-sync-b']:
 r=json.load(open(p/name/'rapport.json'));assert r['geslaagd'];raw=r['fasen_eind'][0]['result']['result']['value'];assert raw['overgeslagen']==0;beg={};taken={};spans=collections.defaultdict(list);openf={}
 for x in raw['regels']:
  if x['soort']=='ontvangst':taken.setdefault(x['id'],{})['ontvangst']=x
  elif x['soort']=='taak.begin':taken.setdefault(x['id'],{})['begin']=x
  elif x['soort']=='taak.einde':taken.setdefault(x['id'],{})['eind']=x
  if x['soort'].endswith('.begin'):assert(x['soort'][:-6],x['id'])not in beg;beg[(x['soort'][:-6],x['id'])]=x
  elif x['soort'].endswith('.einde'):
   k=(x['soort'][:-6],x['id']);b=beg.pop(k);spans[k[0]+'/'+str(x['type'])].append({'id':x['id'],'begin':b['tijd'],'eind':x['tijd'],'ms':x['tijd']-b['tijd']})
 assert not beg
 for id,v in taken.items():
  assert 'begin'in v and'eind'in v,(name,id)
  if 'ontvangst'in v:v['wachttijd_ms']=v['begin']['tijd']-v['ontvangst']['tijd']
  v['taak_ms']=v['eind']['tijd']-v['begin']['tijd']
 ts=sorted([(v['begin']['tijd'],v['eind']['tijd'])for v in taken.values()]);overlap=[];prior=None;union=0
 for start,end in ts:
  if prior is None:prior=[start,end]
  elif start<prior[1]:overlap.append({'begin':start,'eind':min(end,prior[1])});prior[1]=max(prior[1],end)
  else:union+=prior[1]-prior[0];prior=[start,end]
 if prior:union+=prior[1]-prior[0]
 stats={k:{'aantal':len(v),'som_ms':sum(x['ms']for x in v),'mediaan_ms':statistics.median(x['ms']for x in v),'min_ms':min(x['ms']for x in v),'max_ms':max(x['ms']for x in v)}for k,v in spans.items()}
 syncs=[x for x in r['werkertijdlijn']['regels']if x.get('type')=='sync'and x['richting']=='verzending'];meta=[x for x in syncs if'sync'in x]
 doc=p/name/'Ontwerpnotitie.docx';assert sha(doc)==r['bewaring_sha256'];parts={}
 with ZipFile(doc)as z:
  assert z.testzip()is None
  for n in z.namelist():
   data=z.read(n)
   if n.endswith(('.xml','.rels')):ET.fromstring(data)
   parts[n]=hashlib.sha256(data).hexdigest()
  root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};text=''.join(x.text or''for x in root.findall('.//w:t',ns));tables=len(root.findall('.//w:tbl',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128==r['bewaarde_tabellen_exact']and units==91423
 docs[name]={'sha256':sha(doc),'tabellen':tables,'utf16':units,'pakketdelen':parts}
 out[name]={'geslaagd':True,'invoer':r['lange_invoer'],'runtime_wasm':r['runtime_wasm'],'fasen':dict(spans),'sommen':stats,'taken':taken,'taakinterval_unie_ms':union,'overlappende_taakintervallen':overlap,'sync_verzendingen':syncs,'sync_metagegevens':meta,'geen_logverlies':True,'fouten':r['fouten']}
base=docs['native-a-een']['pakketdelen']
for n,d in docs.items():d['verschillende_pakketdelen_vs_a_een']=[k for k in set(base)|set(d['pakketdelen'])if base.get(k)!=d['pakketdelen'].get(k)]
r={'ronden':out,'documenten':docs,'grenzen':'Faseklokken zijn verstreken Worker-tijd,geen exclusieve CPU. Resident/projectie/pakket overlappen als ouder/kind; niet optellen. Taakintervallen en overlap apart vastgelegd. Geïnstrumenteerde ronden geen normale desktop-snelheidsacceptatie. Sync-metadata toont aantallen/groottes/revisies/stack,geen inhoudshash en geen bewijs dat sync veilig weg kan.'};(p/'analyse.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
for n,v in out.items():print(n,{k:(d['aantal'],round(d['som_ms'],1))for k,d in v['sommen'].items()},'overlap',len(v['overlappende_taakintervallen']))
