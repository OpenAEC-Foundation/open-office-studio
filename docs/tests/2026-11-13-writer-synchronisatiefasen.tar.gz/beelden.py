from pathlib import Path
import json
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent;out=[]
for base,candidate in [('native-a-een','native-b-een'),('native-a-een','native-b-twee'),('native-a-een','native-a-twee'),('native-sync-a','native-sync-b')]:
 for n in ['invoer-redo.png','snel-getypt-bewaard.png','nieuw-na-laat-antwoord.png']:
  a=Image.open(p/base/n).convert('RGB');b=Image.open(p/candidate/n).convert('RGB');assert a.size==b.size;diff=ImageChops.difference(a,b);bbox=diff.getbbox();count=0 if bbox is None else sum(any(c)for c in diff.crop(bbox).getdata());out.append({'referentie':base+'/'+n,'kandidaat':candidate+'/'+n,'bbox':bbox,'verschillende_pixels':count})
r={'paren':out,'exact':sum(x['verschillende_pixels']==0 for x in out),'grens':'Alleen drie vaste gehele screenshots; geen maskers of volledige visuele-/platformacceptatie.'};(p/'beelden.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
