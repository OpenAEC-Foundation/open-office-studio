from pathlib import Path
import os,subprocess,json,hashlib,statistics,time
p=Path(__file__).resolve().parent;repo=p.parents[2];opzet=json.load(open(p/'opzet.json'));modules={m['naam']:m for m in opzet['modules']};node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';results=[];velden=['replica_update_ms','replica_font_ms','replica_retained_ms','replica_frame_ms','replica_volledig_json_ms','replica_voor_controle_totaal_ms'];gelijk=['blokken_sha256','layout_sha256','alinea_sha256','bronvector_sha256','font_sha256','font_bytes'];start=time.monotonic()
for pos,idx in [('eerste','0'),('middelste','middelste'),('laatste','-1')]:
 golden=None;seen={}
 for name in opzet['volgorde']:
  seen[name]=seen.get(name,0)+1;label=pos+'-'+name+('-een'if seen[name]==1 else'-twee');m=modules[name];env={**os.environ,'BEELD':'1','ALINEA':idx,'LOKAAL':'1','OPWARMEN':'1'};print('START',label,flush=True)
  cmd=[node,str(p/'acht-stappen.mjs'),str(repo/m['pad']),label,m['sha256']]
  with(p/(label+'.log')).open('x')as f:rc=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180).returncode
  r=json.load(open(p/(label+'.json')));assert rc==0 and r['geslaagd'],label
  projectie=[{k:step[k]for k in gelijk}for step in r['metingen']]
  if golden is None:golden=projectie
  assert projectie==golden,label
  times={k:{'alle': [step[k]for step in r['metingen']],'mediaan_zonder_eerste':statistics.median(step[k]for step in r['metingen'][1:]),'som':sum(step[k]for step in r['metingen'])}for k in velden}
  results.append({'naam':label,'module':name,'positie':pos,'opdracht':cmd,'volledige_projectie_acht_stappen_exact':True,'doel':r['doel'],'tijden':times});(p/'ronden.json').write_text(json.dumps({'geslaagd':True,'afgeronde_ronden':len(results),'geplande_ronden':24,'seconden':time.monotonic()-start,'ronden':results},ensure_ascii=False,indent=2)+'\n');print('EINDE',label,json.dumps({k:round(v['mediaan_zonder_eerste'],2)for k,v in times.items()}),flush=True)
