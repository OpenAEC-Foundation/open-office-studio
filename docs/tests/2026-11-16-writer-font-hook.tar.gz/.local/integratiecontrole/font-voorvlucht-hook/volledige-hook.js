function Af(e) { let { document: t$1, session: n$1, renderEnv: o$1, pageGap: r$1, zoom: i$1, residentMeasurementConfig: s, deferLayoutPass: a, displayListQueries: c$1, interactionPageHostRef: u, pagesContainerRef: d, viewportLayoutRef: f, getSelectionHead: w, displayPositionToYrsLoc: g, yrsLocToDisplayPosition: p, syncCoordinator: S, getScrollContainer: m, onError: P$1, onTotalPagesChange: x, onLayoutComputed: b, layoutInWorker: C, fontRequirementsInWorker: L, experimentalWorkerOpen: O = false, onAnchorPositionsChange: y } = e, [R, D$1] = useState(null), Y = useRef(P$1); Y.current = P$1; let k = useRef(x), A = useRef(b), v = useRef(y), F = useRef(c$1), q$1 = useRef(a), te = useRef(g), le = useRef(p), B = useRef(C); B.current = C; let ne = useRef(L); ne.current = L; let j$1 = useRef(O); j$1.current = O; let K = useRef(0), Re = useRef(n$1); Re.current = n$1; let pe = useRef(null), De = useRef(null), _e = useRef(null), He = useCallback(ce => { let W = _e.current; !W || W.session !== ce || (W.release(), _e.current = null); }, []); useEffect(() => () => He(n$1), [He, n$1]); let xe = useRef(null); xe.current !== n$1 && (xe.current = null); let ot = useRef(null), Qe = useRef(null), et = useRef(null), Ke = useRef(false), _ = useRef(null), $$1 = useRef(() => { }), he = useRef(false); k.current = x, A.current = b, v.current = y, F.current = c$1, q$1.current = a, te.current = g, le.current = p; let tt = useRef(0); useEffect(() => { R && n$1 && ($(n$1) ? Z(n$1)?.snapshot() : V(n$1)?.initialized) && !i(R) && c(R) === n$1.version() && o(R) === l($(n$1) ? Z(n$1).revisionPreview() : proposalRevisionPreview(n$1.getProposals())) && j(n$1, false), A.current?.(R); let ce = $a(R); ce !== tt.current && (tt.current = ce, k.current?.(ce)); }, [R]); let qe = useRef(null); qe.current || (qe.current = new Zs); let Ee = qe.current, Bt = useRef(0), kt = useCallback(() => { Bt.current += 1, Ee.cancel(); }, [Ee]), ct = useRef(null), gt = useRef(n$1), G$1 = useRef(true), xn = useRef(null); gt.current !== n$1 && (gt.current = n$1, ct.current = null); let At = useRef(null), Ue = useRef("remote"), Ge = useCallback(() => { _.current != null || he.current || (_.current = requestAnimationFrame(() => { _.current = null, At.current && $$1.current(); })); }, []), ut = useCallback(ce => { let W = te.current?.(ce); if (!n$1 || !W || le.current?.(W) !== ce)
    return null; try {
    return n$1.encodeStickyPosition(W);
}
catch {
    return null;
} }, [n$1]), Ut = useCallback(ce => { let W = n$1?.resolveStickyPosition(ce); return W ? le.current?.(W) ?? null : null; }, [n$1]), Ye = useCallback(() => { let ce = F.current, W = d.current, Q = u?.current ?? W, ie = m() ?? (W ? findVerticalScrollParentOrRoot(W) : null), fe = ce && Q && ie?.isConnected ? If(ce, Q, ie, ut) : null; ct.current = fe ? { anchor: fe, navigationEpoch: Bt.current } : null; }, [ut, m, u, d]), Ft = useCallback(ce => D(ce) || B.current?.isViewerSession?.(ce) === true, []), Cn = useCallback((ce, W) => { let Q = Ft(ce), ie = Q && B.current?.fail ? B.current.fail(ce, W) : Q && !(W instanceof Sr) && !(W instanceof ResidentWorkerOutOfMemoryError) ? new Sr("layout", W) : W instanceof Error ? W : new Error(String(W)); return Q && (Ke.current = false, At.current = null, j(ce, false)), Q && ie instanceof St || (!Q && $(ce) && !Z(ce)?.retirementReason() && !(ie instanceof St) && ba(ce, ie), Y.current?.(ie, ce)), ie; }, [Ft]), wn = useCallback(ce => Ft(ce) || Z(ce)?.holdsWorkerState() === true || j$1.current && (H(ce) || B.current?.ownsDocument?.(ce) === true), [Ft]), Dt = useCallback(ce => { Ke.current = true, j(ce, true), ot.current = ya(ot.current, true), At.current = zi(At.current, "remote"); }, []), cr = useCallback(ce => { let W = n$1 !== null && (Ft(n$1) || Z(n$1)?.holdsWorkerState() === true || j$1.current && ce?.onHost !== true && H(n$1)), Q = () => { De.current?.session === n$1 && (De.current.final = false); }; n$1 && j$1.current && H(n$1) && B.current?.ownsDocument?.(n$1) !== true && Q(); let ie = !W && (ce?.onHost === true || n$1 !== null && xe.current === n$1), fe = W || !ie && ot.current === true, vt = Qe.current; if ((fe || !ie && (j$1.current && n$1 !== null && H(n$1) || ot.current === null && !vt?.opening)) && n$1 && vt?.session === n$1) {
    Ke.current = true, j(n$1, true), At.current ?? (At.current = "remote");
    return;
} Ke.current = false, ot.current = null; let Ce = ++K.current, ke = At.current ?? "remote"; At.current = null, ke === "local" && Ee.cancel(); let Jt = performance.now(), Ne = S.getStateSeq(); if (S.onLayoutStart(), q$1.current() || !n$1) {
    At.current = zi(At.current, ke), xe.current = ie ? n$1 : null, ot.current = ya(ot.current, fe), S.onLayoutComplete(Ne);
    return;
} let dt = () => { let dn = t(n$1); return j$1.current ? P(n$1, dn) : dn; }, Tt = Zl(n$1, o$1), yt = dn => { let Nt = null; try {
    ie && j$1.current && N(n$1);
    let Te = buildResidentRegionLayoutRequest(t$1, r$1, Tt);
    j$1.current && (Te.cachedPageTotals = !0);
    let We = JSON.stringify(Te), ge = !ie && (Ft(n$1) || j$1.current || Z(n$1)?.holdsWorkerState() || B.current?.canSyncHostUpdates?.(n$1) === true) && dn === void 0 ? ne.current?.(n$1, We) : null;
    if (ge) {
        let openaecFontBron = B.current?.canSyncHostUpdates?.(n$1) === true ? dt() : void 0;
        ge.then(Oe => { if (Ce !== K.current || Re.current !== n$1)
            return; if (openaecFontBron !== void 0 && openaecFontBron !== null && dt() !== openaecFontBron) {
            At.current = zi(At.current, ke);
            xe.current = ie ? n$1 : null;
            ot.current = ya(ot.current, fe);
            S.onLayoutComplete(Ne);
            Ge();
            return;
        } yt(openaecFontBron === null ? null : Oe); }, Oe => { Ce !== K.current || Re.current !== n$1 || (Q(), j(n$1, !1), Oe instanceof St ? Ft(n$1) && !n$1.isDisplayOnly?.() && (Dt(n$1), Ge()) : Cn(n$1, Oe), S.onLayoutComplete(Ne)); });
        return;
    }
    if (Ft(n$1) && dn == null)
        throw new Error("The document worker did not return font requirements");
    let ft = JSON.parse(dn ?? n$1.layoutFontRequirementsJson(We));
    Nt = s(ft);
}
catch (Te) {
    Q(), Ft(n$1) || console.error("[PagedEditor] Worker font preflight error:", Te), j(n$1, false), He(n$1), Cn(n$1, Te), S.onLayoutComplete(Ne);
    return;
} if (!Nt) {
    if (!ie && _e.current?.session !== n$1) {
        let Te = dt();
        if (Te !== null && (pe.current?.session !== n$1 || Te === (j$1.current ? P(n$1, pe.current.version) : pe.current.version)))
            try {
                let We = B.current?.prewarm?.(n$1);
                We && (_e.current?.release(), _e.current = { session: n$1, release: We });
            }
            catch { }
    }
    At.current = zi(At.current, ke), xe.current = ie ? n$1 : null, ot.current = ya(ot.current, fe), S.onLayoutComplete(Ne);
    return;
} xe.current = null, V(n$1)?.initialized || j(n$1, false); let E = { document: t$1, pageGap: r$1, session: n$1, renderEnv: Tt, measurement: Nt, ...j$1.current ? { cachedPageTotals: true } : {} }, N$1 = dt(), Z$1 = l(Tt.revisionPreview), U = { ...buildResidentRegionLayoutRequest(t$1, r$1, Tt), measurement: Nt, ...j$1.current ? { cachedPageTotals: true } : {} }, Se = JSON.stringify({ ...U, measurement: void 0 }, (Te, We) => Te === "revisionPreview" ? void 0 : We), ve = De.current; if (!Ft(n$1) && Z(n$1)?.holdsWorkerState() !== true && j$1.current && H(n$1) && G(n$1) && B.current?.ownsDocument?.(n$1) === true && ve?.session === n$1 && ve.final && ve.zoom === i$1 && P(n$1, ve.version) === N$1 && ve.request === Se && ve.previewKey === Z$1 && JSON.stringify(ve.measurement) === JSON.stringify(Nt)) {
    h(ve.layout, false), j(n$1, false), S.onLayoutComplete(Ne);
    return;
} let ye = (Te, We = ke, ge = N$1, ft = true) => { let { layout: Oe } = Te; b$3(Oe, j$1.current ? P(n$1, ge) : ge), n(Oe, Z$1), r(Oe, q(Tt.reservationSets ?? Tt.reservations)), De.current = { session: n$1, layout: Oe, version: ge, request: Se, previewKey: Z$1, measurement: E.measurement, zoom: i$1, final: ft }; let it = d.current, Rt = m() ?? (it ? findVerticalScrollParentOrRoot(it) : null), Ht = u?.current ?? it, pn = F.current, mn = ct.current, Jn = Rt?.isConnected && Ht && pn ? We === "remote" ? mn?.navigationEpoch === Bt.current ? { kind: "viewport", anchor: mn.anchor } : null : { kind: "selection", anchor: Df(pn, Ht, Rt, w?.() ?? 0) } : null; G$1.current = false, Ue.current = We, D$1(Oe); let ur = f.current; if (ur) {
    let oe = ua(Oe, r$1);
    ur.style.minHeight = `${oe}px`, ur.style.marginBottom = i$1 !== 1 ? `${oe * (i$1 - 1)}px` : "";
} Rt?.isConnected && Jn ? Ee.capture(Jn) : Ee.cancel(); }, Ct = ({ recovery: Te }) => { if (Ft(n$1)) {
    Cn(n$1, new Error("The document worker did not return a viewer layout"));
    return;
} if (Z(n$1)?.holdsWorkerState() || !Te && ce?.onHost !== true && j$1.current && H(n$1)) {
    Dt(n$1), Qe.current || Ge();
    return;
} try {
    j$1.current && N(n$1);
    let We = dt(), ge = computeLayout(E);
    ye(ge, ke, We);
    let ft = performance.now() - Jt;
    ft > 2e3 && console.warn(`[PagedEditor] Layout pipeline took ${Math.round(ft)}ms total (${ge.layout.pages.length} pages)`);
}
catch (We) {
    console.error("[PagedEditor] Layout pipeline error:", We), $(n$1) ? Cn(n$1, We) : Y.current?.(We instanceof Error ? We : new Error(String(We)), n$1);
} }; pe.current?.session !== n$1 && (pe.current = { session: n$1, version: N$1 }); let Be = ve?.session === n$1 && ve.version === N$1 && ve.request === Se && (JSON.stringify(ve.measurement) === JSON.stringify(Nt) || ve.previewKey !== Z$1 && dP(ve.measurement, E.measurement)), pt = null; if (Ft(n$1) || Z(n$1)?.holdsWorkerState() || !ie && (B.current?.canSyncHostUpdates?.(n$1) === true || j$1.current && H(n$1) || N$1 !== null && (Be || fe || N$1 === (j$1.current ? P(n$1, pe.current.version) : pe.current.version))))
    try {
        pt = B.current?.(n$1, JSON.stringify(U)) ?? null;
    }
    catch (Te) {
        if (Q(), !Ft(n$1) && aa(n$1) === Te) {
            S.onLayoutComplete(Ne);
            return;
        }
        if (Ft(n$1) || console.error("[PagedEditor] Document worker layout could not start:", Te), Ft(n$1) || Z(n$1)?.holdsWorkerState()) {
            Cn(n$1, Te), S.onLayoutComplete(Ne);
            return;
        }
    } if (He(n$1), !pt) {
    Q(), Ct({ recovery: true }), S.onLayoutComplete(Ne);
    return;
} Qe.current = { pass: Ce, session: n$1, opening: !fe && !Be }, pt.then(Te => { if (Ce !== K.current || Re.current !== n$1)
    return; Te || Q(); let We = dt() !== (j$1.current ? P(n$1, N$1) : N$1); if (!Te && j$1.current && H(n$1)) {
    Ke.current || Ct({ recovery: true });
    return;
} We && !Ke.current && wn(n$1) && Dt(n$1); let ge = Ke.current; if (!Te || We && !ge) {
    ge || Ct({ recovery: !Te });
    return;
} (We || ge) && h(Te.layout), ye(Te, ke, N$1, !Te.complete), Te.complete?.then(ft => { if (!(Ce !== K.current || Re.current !== n$1))
    if (ft || Q(), ft && dt() === (j$1.current ? P(n$1, N$1) : N$1))
        Ke.current && h(ft.layout), ye(ft, "remote");
    else {
        if (Ke.current)
            return;
        ft && wn(n$1) || !ft && !Ft(n$1) && Z(n$1)?.holdsWorkerState() === true ? (Dt(n$1), Ge()) : !ft && j$1.current && B.current?.ownsDocument?.(n$1) === true && (et.current?.session !== n$1 || P(n$1, et.current.version) !== N$1) ? (et.current = { session: n$1, version: N$1 }, Dt(n$1), Ge()) : Ct({ recovery: !ft });
    } }, ft => { if (!(Ce !== K.current || Re.current !== n$1) && (Q(), !(!Ft(n$1) || ft instanceof ResidentWorkerOutOfMemoryError))) {
    if (ft instanceof St) {
        if (n$1.isDisplayOnly?.())
            return;
        Dt(n$1), Ge();
        return;
    }
    Cn(n$1, ft);
} }); }, Te => { if (Ce === K.current && (Q(), !(Te instanceof ResidentWorkerOutOfMemoryError) && !(!Ft(n$1) && aa(n$1) === Te))) {
    if (Te instanceof St) {
        Ft(n$1) && !n$1.isDisplayOnly?.() && Dt(n$1);
        return;
    }
    Ft(n$1) || console.error("[PagedEditor] Layout pipeline error:", Te), Cn(n$1, Te);
} }).finally(() => { Ce === K.current && S.onLayoutComplete(Ne), Qe.current?.pass === Ce && (Qe.current = null, Ke.current && Re.current === n$1 && Ge()); }); }; yt(); }, [r$1, i$1, S, t$1, n$1, o$1, s, m, w, u, d, f, Ee, Ge, He, wn, Dt, Ft, Cn]); useLayoutEffect(() => { let ce = Ee.peek(); if (!ce)
    return; let W = d.current, Q = m() ?? (W ? findVerticalScrollParentOrRoot(W) : null); Q?.isConnected && Ee.run(ce, () => { Lf(ce.value.anchor, Q), xn.current = Q.scrollTop; }); }, [R, m, d, Ee]), useLayoutEffect(() => { let ce = Ee.peek(), W = d.current, Q = u?.current ?? W, ie = m() ?? (W ? findVerticalScrollParentOrRoot(W) : null); if (!ce || !c$1 || !Q || !ie?.isConnected)
    return; let fe = Ee.take(); if (!fe)
    return; let vt = () => { fe.value.kind === "viewport" ? Ef(fe.value.anchor, c$1, Q, ie, Ut) : Tf(fe.value.anchor, c$1, Q, ie), xn.current = ie.scrollTop; }; if (!Ee.run(fe, vt))
    return; let Kt = requestAnimationFrame(() => { ie.isConnected && Ee.run(fe, vt); }); return () => cancelAnimationFrame(Kt); }, [c$1, m, u, d, Ut, Ee]), useLayoutEffect(() => { if (!c$1)
    return; G$1.current = true, Ye(); let ce = requestAnimationFrame(() => { Ye(); }); return () => cancelAnimationFrame(ce); }, [Ye, c$1]), useEffect(() => { let ce = d.current, W = m() ?? (ce ? findVerticalScrollParentOrRoot(ce) : null); if (!W)
    return; W.addEventListener("wheel", kt, { capture: true, passive: true }), W.addEventListener("touchstart", kt, { capture: true, passive: true }), W.addEventListener("pointerdown", kt, { capture: true, passive: true }); let Q = null, ie = () => { let fe = xn.current; xn.current = null, (fe == null || Math.abs(W.scrollTop - fe) > .5) && kt(), Q !== null && clearTimeout(Q), Q = setTimeout(() => { Q = null, G$1.current && Ye(); }, 80); }; return W.addEventListener("scroll", ie, { passive: true }), () => { W.removeEventListener("wheel", kt, true), W.removeEventListener("touchstart", kt, true), W.removeEventListener("pointerdown", kt, true), W.removeEventListener("scroll", ie), Q !== null && clearTimeout(Q); }; }, [kt, Ye, m, d]), $$1.current = cr; let Xt = useCallback((ce = "local", W = ce === "remote") => { ce === "local" && Ee.cancel(), At.current = zi(At.current, ce), ot.current = ya(ot.current, W), Ge(); }, [Ge, Ee]); useEffect(() => (he.current = false, () => { he.current = true, Re.current && j(Re.current, false), K.current += 1, _.current != null && cancelAnimationFrame(_.current), _.current = null; }), []); let Yn = useCallback(() => { if (!n$1 || Ft(n$1))
    return null; let ce = buildResidentRegionLayoutRequest(t$1, r$1, Zl(n$1, o$1)); j$1.current && (ce.cachedPageTotals = true); let W = JSON.parse(n$1.layoutFontRequirementsJson(JSON.stringify(ce))), Q = s(W); return Q ? (ce.measurement = Q, JSON.stringify(ce)) : null; }, [t$1, Ft, r$1, o$1, s, n$1]), rr = useCallback(async () => { if (!n$1)
    return null; let ce = buildResidentRegionLayoutRequest(t$1, r$1, Zl(n$1, o$1)); j$1.current && (ce.cachedPageTotals = true); let W = await ne.current?.(n$1, JSON.stringify(ce)); if (W == null) {
    if (Ft(n$1))
        throw Cn(n$1, new Error("The document worker did not return font requirements"));
    return null;
} let Q = s(JSON.parse(W)); return Q ? (ce.measurement = Q, JSON.stringify(ce)) : null; }, [t$1, Ft, r$1, o$1, s, Cn, n$1]), on = useCallback(() => Bt.current, []); return { layout: R, layoutUpdateOrigin: Ue.current, runLayoutPipeline: cr, scheduleLayout: Xt, cancelPendingScrollRestore: kt, navigationEpoch: on, getLayoutRequest: Yn, readLayoutRequest: rr }; }