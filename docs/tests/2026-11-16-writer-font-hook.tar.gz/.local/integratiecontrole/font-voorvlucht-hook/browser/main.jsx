import React,{useState,act,StrictMode}from'react';import{createRoot}from'react-dom/client';import{LayoutSelectionGate}from'@betteroffice/docx/layout';
import{proefHook as baseline}from'./sdk/baseline.mjs';import{proefHook as kandidaat}from'./sdk/kandidaat.mjs';
window.IS_REACT_ACT_ENVIRONMENT=true;let result,configure,serial=0;const root=createRoot(document.getElementById('root')),frames=new Map();let frameId=0;window.requestAnimationFrame=f=>{frames.set(++frameId,f);return frameId};window.cancelAnimationFrame=id=>frames.delete(id);
function App({hook,initial}){const[props,set]=useState(initial);configure=set;result=hook(props);return null}
const tick=async()=>act(async()=>{for(let i=0;i<20;i++)await Promise.resolve()});const frame=async()=>act(async()=>{for(const[id,f]of[...frames])if(frames.delete(id))f(performance.now())});
const ok=(v,m)=>{if(!v)throw Error(m)};
async function setup(candidate,strict=false){
 const fonts=[],layouts=[],errors=[],local=[],published=[];let version=1;
 const session={version:()=>String(version),layoutFontRequirementsJson:()=> '[]',layoutDocumentWithRegionsRetainedJson:()=>{local.push(version);return JSON.stringify({layout:{pages:[]},notesConverged:true})},getProposals:()=>({version:String(version),proposals:[],previewVersion:0}),residentWorkerProbe:()=>({layoutRevision:1})};
 const worker=Object.assign((asked,request)=>new Promise(resolve=>layouts.push({request,version,session:asked,resolve})),{ownsDocument:()=>true,canSyncHostUpdates:()=>true,isViewerSession:()=>false});
 let props={document:null,session,renderEnv:{},pageGap:24,zoom:1,residentMeasurementConfig:()=>({fontChains:{},defaults:{fontSize:11,fontFamily:'test'},compat:{},authoritativeShaping:true}),deferLayoutPass:()=>false,pagesContainerRef:{current:null},viewportLayoutRef:{current:null},syncCoordinator:new LayoutSelectionGate(),getScrollContainer:()=>null,onError:e=>errors.push(String(e)),onLayoutComputed:l=>published.push(l),experimentalWorkerOpen:true,layoutInWorker:worker,fontRequirementsInWorker:(s,input)=>new Promise((resolve,reject)=>fonts.push({input,version,session:s,resolve,reject}))};
 const app=<App key={++serial} hook={candidate?kandidaat:baseline} initial={props}/>;await act(async()=>root.render(strict?<StrictMode>{app}</StrictMode>:app));
 return {fonts,layouts,errors,local,published,session,version:v=>{version=v},async props(p){props={...props,...p};await act(async()=>configure(props));},async run(options){await act(async()=>result.runLayoutPipeline(options))},async font(i){fonts[i].resolve('[]');await tick()},async layout(i){layouts[i].resolve({layout:{pages:[]},notesConverged:true});await tick()},async close(){await act(async()=>root.render(null));await tick()}};
}
window.run=async(candidate)=>{
 const cases=[];
 for(const strict of[false,true]){
 const p=await setup(candidate,strict);for(let i=1;i<=100;i++){p.version(i);if(i%20===0)await p.props({renderEnv:{showHiddenText:i%40===0}});await p.run()}
 ok(p.fonts.length===(candidate?1:100),'Burst heeft onjuist aantal voorvluchten');if(candidate){await p.font(0);ok(p.fonts.length===2,'Laatste wachtende taak niet gestart');await p.font(1)}else for(let i=0;i<100;i++)await p.font(i);
 ok(p.layouts.length===1,'Niet precies één laatste layout');const request=p.layouts[0].request;await p.layout(0);ok(result.layout!==null,'Geen layout gepubliceerd');ok(p.errors.length===0,'Burst geeft fout');
 p.version(101);await p.run();await p.font(p.fonts.length-1);ok(p.layouts.length===2,'Rij niet opnieuw bruikbaar');await p.layout(1);
 cases.push({naam:'burst-en-hergebruik',strict,fontaanvragen:p.fonts.length,layouts:p.layouts.length,laatste_request:request});await p.close();
 }
 // Andere fontgebruiker deelt de rij niet.
 const r=await setup(candidate);await r.run();r.version(2);await r.run();const read=result.readLayoutRequest();await tick();ok(r.fonts.length===(candidate?2:3),'Afzonderlijke lezer ten onrechte geblokkeerd');r.fonts.at(-1).resolve('[]');ok(await read!==null,'Afzonderlijke lezer niet beantwoord');await r.font(0);if(candidate)await r.font(2);else await r.font(1);ok(r.layouts.length===1,'Afzonderlijke lezer wijzigt layoutplanning');await r.layout(0);cases.push({naam:'afzonderlijke-lezer',fontaanvragen:r.fonts.length,layouts:r.layouts.length});await r.close();
 // Gewijzigde bron zonder nieuw passnummer behoudt herplanning.
 const s=await setup(candidate);await s.run();s.version(2);await s.font(0);ok(s.layouts.length===0,'Oude bron toch ingedeeld');await frame();await tick();ok(s.fonts.length===2,'Bronwijziging niet herpland');await s.font(1);ok(s.layouts.length===1,'Herplande bron ontbreekt');await s.layout(0);cases.push({naam:'bronwijziging-zonder-nieuwe-pass',fontaanvragen:s.fonts.length,layouts:s.layouts.length});await s.close();
 // Wachtende oude fout niet publiceren; huidige fout wel.
 const f=await setup(candidate);await f.run();f.version(2);await f.run();f.fonts[0].reject(new Error('oude fout'));await tick();f.fonts[1].reject(new Error('huidige fout'));await tick();ok(f.errors.length===1&&f.errors[0].includes('huidige fout'),'Foutpad wijkt af');cases.push({naam:'fouten',fouten:f.errors});await f.close();
 // Sessieovergang en unmount mogen oude antwoorden niet publiceren.
 const u=await setup(candidate,true);await u.run();u.version(2);await u.run();await u.close();for(const f of u.fonts)f.resolve('[]');await tick();ok(u.layouts.length===0&&u.errors.length===0,'Laat antwoord na unmount gepubliceerd');cases.push({naam:'strict-unmount',fontaanvragen:u.fonts.length,layouts:u.layouts.length});
 const w=await setup(candidate);await w.run();w.version(2);await w.run();const next={...w.session,version:()=> 'volgende'};await w.props({session:next});await w.run();for(const f of w.fonts)f.resolve('[]');await tick();ok(w.layouts.length===1&&w.layouts[0].session===next,'Sessieovergang publiceert oude bron');await w.layout(0);cases.push({naam:'sessiewissel',fontaanvragen:w.fonts.length,layouts:w.layouts.length});await w.close();
 // Directe nullroute en expliciete hostlayout blijven bereikbaar.
 const z=await setup(candidate);await z.props({fontRequirementsInWorker:()=>null});await z.run();ok(z.fonts.length===0&&z.layouts.length===1,'Nullroute uitgesteld of geblokkeerd');await z.layout(0);cases.push({naam:'direct-null',fonts:z.fonts.length,layouts:z.layouts.length});await z.close();
 const h=await setup(candidate);await h.run({onHost:true});ok(h.fonts.length===0&&h.local.length===1&&h.errors.length===0,'Hostlayout wijkt af');cases.push({naam:'onHost',fonts:h.fonts.length,lokale_layouts:h.local.length});await h.close();
 // Uitgestelde layout vraagt nog geen fonts; hervatten blijft mogelijk.
 const d=await setup(candidate);await d.props({deferLayoutPass:()=>true});await d.run();ok(d.fonts.length===0,'Fonts gestart tijdens uitstel');await d.props({deferLayoutPass:()=>false});await d.run();ok(d.fonts.length===1,'Geen fonts na hervatten');await d.font(0);await d.layout(0);cases.push({naam:'uitstel-hervatten',fonts:d.fonts.length,layouts:d.layouts.length});await d.close();
 // Nieuwe omgeving en fontmeetconfiguratie gaan volledig naar de nieuwste layout.
 const e=await setup(candidate);await e.run();await e.props({renderEnv:{showHiddenText:true,defaultParagraphStyleId:'Nieuw',themeColors:{accent1:'123456'}},residentMeasurementConfig:()=>({fontChains:{nieuw:[7]},defaults:{fontSize:17,fontFamily:'nieuw'},compat:{},authoritativeShaping:true}),zoom:1.5});e.version(2);await e.run();await e.font(0);await e.font(1);ok(e.layouts.length===1,'Omgevingswissel publiceert oude layout');const req=JSON.parse(e.layouts[0].request);ok(req.renderEnv.showHiddenText&&req.measurement.defaults.fontSize===17,'Nieuwe omgeving/fonts verloren');await e.layout(0);cases.push({naam:'omgeving-font-zoom',request:e.layouts[0].request});await e.close();
 return {geslaagd:true,cases};
};window.ready=true;
