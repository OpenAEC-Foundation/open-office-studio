from pathlib import Path
import os,subprocess,json,hashlib,shutil
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';m=json.loads((r/'observer47-bronnen.json').read_text());resultaten=[]
def controleer_bron():
    for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
controleer_bron()
for fase,cmd,lognaam in [('frontend',['node_modules/.bin/vitest','run'],'observer47-volledig.log'),('python',['python3','-m','unittest','discover','-s','tests','-v'],'observer47-python.log'),('engines',['node','scripts/test-kantoor-engines.mjs'],'observer47-engines.log'),('opdrachten',['node','scripts/test-opdrachten.mjs'],'observer47-opdrachten.log'),('desktop',['node_modules/.bin/tauri','build','--no-bundle'],'observer47-bouw.log')]:
    print('START',fase,flush=True)
    with (r/lognaam).open('w') as log:
        p=subprocess.Popen(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
        (r/'observer47-levende-fase.json').write_text(json.dumps({'fase':fase,'pid':p.pid,'opdracht':cmd},indent=2)+'\n');code=p.wait()
    resultaten.append({'fase':fase,'code':code,'opdracht':cmd});(r/'observer47-bouwuitkomsten.json').write_text(json.dumps(resultaten,indent=2)+'\n')
    print('EINDE',fase,code,flush=True)
    if code:raise SystemExit(code)
controleer_bron();bron=repo/'src-tauri/target/release/open-office-studio';doel=r/'open-office-studio-45.47-observer';assert not doel.exists()
digest=hashlib.sha256(bron.read_bytes()).hexdigest();assert digest!='68564779708401d92a2f1b67b323db1ba9fe8a32603da733491e011798beac4b';shutil.copy2(bron,doel)
m.update(programma=str(doel.relative_to(repo)),programma_sha256=digest);(r/'observer47-bronnen.json').write_text(json.dumps(m,indent=2)+'\n')
env=os.environ.copy();env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];python=repo/'.local/doorwerk-2026-11-02/gui-python/bin/python';context=r/'ci846-foutcontext/writer-foutcontext';script=context/'scripts/test-writer-rust-plakken-volgorde-native.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='7a036f1fbe9c334f42bad331b8cf0aa7edede53c9e883f245697eb126c114f1a'
for ronde in range(1,4):
    naam=f'observer47-oorspronkelijke-proef-{ronde}';cmd=[str(python),str(script),'--programma',str(doel),'--versie','2026.45.47','--uitvoer',str(r/naam)]
    print('START',naam,flush=True)
    with (r/(naam+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=context,env=env,stdout=log,stderr=subprocess.STDOUT)
    print('EINDE',naam,p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
for fase,script in [('native','voer-observer47-proeven.py'),('fysieke vergelijking','voer-observer47-passieve-metingen.py')]:
    print('START',fase,flush=True);p=subprocess.run(['python3',str(r/script)],cwd=repo,env=env);print('EINDE',fase,p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
