"""CPU-attributie van een eigen 129-paginakopie met 256 tabellen na opnieuw openen in de native Linux-app.

Gebruik --bron <docx> naast --programma, --versie en --uitvoer.
De proef bedient echte toetsen en bewaart begrensde WebKit-ScriptProfilerdata.
Geen proces-CPUduur: deze runtime levert geen trackingUpdate-intervallen.
De stackvolgorde wordt op dezelfde runtime met drie geneste functies geijkt.
"""
import asyncio, importlib.util, json, os, signal, subprocess, sys, time, shutil, hashlib
from pathlib import Path
REPO = Path('/home/aia01/Documenten/GitHub/Open-Office-Studio')
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('basis', REPO / 'scripts/test-writer-lang-native.py')
basis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(basis)

async def proef(a):
    from Xlib import X, display
    from PIL import Image
    from gui.webkit_inspector import Inspector as BasisInspector
    from collections import Counter
    import gzip

    class Inspector(BasisInspector):

        async def __aenter__(self):
            self.gebeurtenissen = []
            self.notificatie_bytes = 0
            await super().__aenter__()
            self.ws.max_size = 64 * 1024 * 1024
            return self

        async def command(self, method, params=None):
            self.i += 1
            nummer = self.i
            await self.ws.send(json.dumps({'id': nummer, 'method': 'Target.sendMessageToTarget', 'params': {'targetId': self.target, 'message': json.dumps({'id': nummer, 'method': method, 'params': params or {}})}}))
            while True:
                bericht = json.loads(await asyncio.wait_for(self.ws.recv(), timeout=90))
                if bericht.get('method') != 'Target.dispatchMessageFromTarget':
                    if bericht.get('id') == nummer and bericht.get('error'):
                        raise RuntimeError(bericht['error'])
                    continue
                inhoud = bericht['params']['message']
                bericht = json.loads(inhoud)
                if 'method' in bericht:
                    if bericht['method'] == 'Console.messageAdded':self.consoleberichten.append(bericht['params']['message'])
                    self.notificatie_bytes += len(inhoud)
                    if self.notificatie_bytes > 64 * 1024 * 1024:
                        raise RuntimeError('Profiel overschrijdt de datagrens')
                    self.gebeurtenissen.append(bericht)
                if bericht.get('id') == nummer:
                    return bericht

        async def worker(self, worker, method, params=None):
            nummer = 100000 + self.i
            vanaf = len(self.gebeurtenissen)
            antwoord = await self.command('Worker.sendMessageToWorker', {'workerId': worker, 'message': json.dumps({'id': nummer, 'method': method, 'params': params or {}})})
            if antwoord.get('error'):
                return antwoord
            einde = time.monotonic() + 15
            while time.monotonic() < einde:
                for ev in self.gebeurtenissen[vanaf:]:
                    if ev.get('method') == 'Worker.dispatchMessageFromWorker' and ev['params']['workerId'] == worker:
                        binnen = json.loads(ev['params']['message'])
                        if binnen.get('id') == nummer:
                            return binnen
                await self.ev('void 0')
                await asyncio.sleep(0.05)
            raise TimeoutError('Worker-profielantwoord ontbreekt')
    a.uitvoer.mkdir(parents=True, exist_ok=False)
    bron = a.uitvoer / 'Prestatieproef.docx'
    shutil.copyfile(Path(os.environ['OFFICE_PROFIEL_BRON']), bron)
    cfg = Path(os.environ['XDG_CONFIG_HOME']) / 'org.openaec.office-studio'
    cfg.mkdir(parents=True)
    (cfg / 'voorkeuren.json').write_text(json.dumps({'taal': 'en', 'thema': 'forge', 'updates': {'automatisch': False, 'kanaal': 'ontwikkel'}}))
    subprocess.run(['dbus-update-activation-environment', 'DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME'], check=True)
    d = display.Display()
    log = (a.uitvoer / 'programma.log').open('w')
    app = subprocess.Popen([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    r = {'bron_sha256': hashlib.sha256(bron.read_bytes()).hexdigest(), 'omvang': 'Eigen 129-paginakopie met 256 tabellen na opnieuw openen, echte toetsen zonder ScriptProfiler; geen algemene snelheidsmeting. Bron- en layoutsignalen via inspectie; geen fysieke FPS.'}
    try:
        einde = time.monotonic() + 60
        v = None
        while not v and time.monotonic() < einde:
            for w in d.screen().root.query_tree().children:
                prop = w.get_full_property(d.intern_atom('_NET_WM_NAME'), X.AnyPropertyType)
                naam = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else ''
                if w.get_attributes().map_state == X.IsViewable and 'Office Studio' in naam:
                    v = w
                    break
            await asyncio.sleep(0.1)
        assert v
        v.configure(x=0, y=0, width=1440, height=1000)
        v.set_input_focus(X.RevertToParent, X.CurrentTime)
        d.sync()
        await asyncio.sleep(12)
        async with Inspector(int(os.environ['OFFICE_PROEF_HTTP'])) as p:
            await p.run("window.api=()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return null;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next){let v=s.memoizedState?.current;if(v?.getEditorRef&&v.commands)return v}return null};let eind=performance.now()+60000;while(api()?.getTotalPages()!==129||!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen 129 paginas');await new Promise(r=>setTimeout(r,100))}let e=api().getEditorRef(),alinea=e.getYrsSession().paragraphs('body').at(-1);window.voor=alinea.text;e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:alinea.paraId,offset:e.getYrsSession().paragraphSpans('body').find(p=>p.paraId===alinea.paraId).length}));api().scrollToPage(129);api().focus();await api().flushPendingInput();return true;")
            await asyncio.sleep(3)
            r['cursor_voor_voltooide_layout'] = await p.run("const e=api().getEditorRef(),s=e.getYrsSession(),p=s.paragraphs('body').at(-1),doel={story:'body',paraId:p.paraId,offset:e.getYrsSession().paragraphSpans('body').find(a=>a.paraId===p.paraId).length},positie=e.yrsLocToDisplayPosition(doel);return {doel,positie,terug:positie===null?null:e.displayPositionToYrsLoc(positie),selectie:s.selection(),display:e.getSelectionRange()};")
            r['volledige_layout'] = await p.run("\n              const begin=performance.now(),eind=begin+120000;let laatste=null;\n              while(performance.now()<eind){\n                const s=api().getEditorRef().getYrsSession(),layout=api().getEditorRef().getLayout();\n                const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst .paged-editor');\n                if(!el)throw Error('Actieve paginaview ontbreekt');\n                let gevonden=0;\n                for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)\n                  for(let slot=f.memoizedState,n=0;slot&&n<1500;n++,slot=slot.next){\n                    const v=slot.memoizedState?.current;\n                    if(v?.session!==s||!v.layout||typeof v.final!=='boolean')continue;\n                    gevonden++;\n                    laatste={final:v.final,versie_actueel:v.version===s.version(),layout_actief:v.layout===layout,paginas:v.layout.pages.length};\n                    if(laatste.final&&laatste.versie_actueel&&laatste.layout_actief)\n                      return {...laatste,wacht_ms:performance.now()-begin};\n                  }\n                if(!gevonden)laatste={gevonden,paginas:api().getTotalPages()};\n                await new Promise(r=>setTimeout(r,100));\n              }\n              throw Error('Laatste bron heeft geen voltooide paginering: '+JSON.stringify(laatste));\n            ", t=130)
            r['cursor_na_voltooide_layout'] = await p.run("const e=api().getEditorRef(),s=e.getYrsSession(),p=s.paragraphs('body').at(-1),doel={story:'body',paraId:p.paraId,offset:e.getYrsSession().paragraphSpans('body').find(a=>a.paraId===p.paraId).length},positie=e.yrsLocToDisplayPosition(doel);return {doel,positie,terug:positie===null?null:e.displayPositionToYrsLoc(positie),selectie:s.selection(),display:e.getSelectionRange()};")
            r['programma_sha256'] = hashlib.sha256(a.programma.read_bytes()).hexdigest()
            r['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
            c = r['cursor_na_voltooide_layout']
            assert c['doel'] == c['terug'], 'Voltooide layout vertaalt het alineaeinde niet bronexact'
            r['cursor_na_focus'] = await p.run("const e=api().getEditorRef(),p=e.getYrsSession().paragraphs('body').at(-1);e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:p.paraId,offset:e.getYrsSession().paragraphSpans('body').find(a=>a.paraId===p.paraId).length}));api().focus();await api().flushPendingInput();return {selectie:e.getYrsSession().selection(),display:e.getSelectionRange()};")
            r['programma_sha256'] = hashlib.sha256(a.programma.read_bytes()).hexdigest()
            r['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
            r['versie'] = await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|version');")
            assert r['versie'] == a.versie
            await p.ev("window._profielToetsen=[];window.addEventListener('keyup',e=>_profielToetsen.push(e.key),true);true")
            r['inputmeting'] = 'Ongeprofileerde koude invoer na opnieuw openen: native laatste keyup en invoerbarrière, zonder eis aan zichtbare spellingsgolven. Volledige alinea- en celteksten buiten het profiel gecontroleerd; geen vergelijking met de 500-paginameting of de gelijktijdige hercontrole direct na plakken.'
            r['golven_vooraf'] = await p.ev("document.querySelectorAll('.spelling-golf').length")
            teksten_voor = await p.ev("Object.fromEntries(api().getEditorRef().getYrsSession().storyIds().map(id=>[id,api().getEditorRef().getYrsSession().paragraphs(id).map(p=>p.text)]))")
            await p.run("window._tabelMetingen={actief:false,tablePayload:{calls:0,ms:0},storySegments:{calls:0,ms:0}};const s=api().getEditorRef().getYrsSession();for(const naam of ['tablePayload','storySegments']){const oud=s[naam];s[naam]=function(...args){if(!_tabelMetingen.actief)return oud.apply(this,args);const begin=performance.now();_tabelMetingen[naam].calls++;try{return oud.apply(this,args)}finally{_tabelMetingen[naam].ms+=performance.now()-begin}}}return true;")
            await p.begin_foutbewaking()
            r['fouten_voor'] = await p.fouten()
            assert not any(r['fouten_voor'].values()), 'Enginefout vóór de invoermeting'
            await p.ev('_tabelMetingen.actief=true')
            begin = time.monotonic()
            subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '20', ' Een proefzin.'], check=True)
            await p.run("let einde=performance.now()+90000;while(!_profielToetsen.includes('.')){if(performance.now()>einde)throw Error('Laatste native toets ontbreekt');await new Promise(r=>setTimeout(r,50))}await api().flushPendingInput();return true;", t=100)
            r['invoer_en_inspectie_ms'] = round((time.monotonic() - begin) * 1000)
            r['tabel_metingen'] = await p.ev('(()=>{_tabelMetingen.actief=false;return _tabelMetingen})()')
            r['layout_na_invoer'] = await p.run("\n              const begin=performance.now(),eind=begin+120000;let laatste=null;\n              while(performance.now()<eind){\n                const s=api().getEditorRef().getYrsSession(),layout=api().getEditorRef().getLayout();\n                const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst .paged-editor');\n                if(!el)throw Error('Actieve paginaview ontbreekt');\n                let gevonden=0;\n                for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)\n                  for(let slot=f.memoizedState,n=0;slot&&n<1500;n++,slot=slot.next){\n                    const v=slot.memoizedState?.current;\n                    if(v?.session!==s||!v.layout||typeof v.final!=='boolean')continue;\n                    gevonden++;\n                    laatste={final:v.final,versie_actueel:v.version===s.version(),layout_actief:v.layout===layout,paginas:v.layout.pages.length};\n                    if(laatste.final&&laatste.versie_actueel&&laatste.layout_actief)\n                      return {...laatste,wacht_ms:performance.now()-begin};\n                  }\n                if(!gevonden)laatste={gevonden,paginas:api().getTotalPages()};\n                await new Promise(r=>setTimeout(r,100));\n              }\n              throw Error('Laatste bron heeft geen voltooide paginering: '+JSON.stringify(laatste));\n            ", t=130)
            r['invoer_tot_finale_layout_ms'] = round((time.monotonic()-begin)*1000)
            r.update(await p.ev("({voor,na:api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text,paginas:api().getTotalPages()})"))
            assert r['na'] == r['voor'] + ' Een proefzin.'
            teksten_na = await p.ev("Object.fromEntries(api().getEditorRef().getYrsSession().storyIds().map(id=>[id,api().getEditorRef().getYrsSession().paragraphs(id).map(p=>p.text)]))")
            verwacht = {k:list(v) for k,v in teksten_voor.items()}
            verwacht['body'][-1] += ' Een proefzin.'
            assert teksten_na == verwacht, 'Volledige alinea- en celteksten wijken af'
            r['volledige_teksten_exact'] = True
            r['verhalen'] = len(teksten_na)
            r['golven_achteraf'] = await p.ev("document.querySelectorAll('.spelling-golf').length")
            g = v.get_geometry()
            raw = v.get_image(0, 0, g.width, g.height, X.ZPixmap, 4294967295)
            Image.frombytes('RGB', (g.width, g.height), raw.data, 'raw', 'BGRX').save(a.uitvoer / 'profiel.png')
            r['fouten_na'] = await p.fouten()
            assert not any(r['fouten_na'].values()), 'Enginefout na de invoermeting'
            r['geslaagd'] = True
            print(json.dumps({'invoer_en_inspectie_ms':r['invoer_en_inspectie_ms'],'tabel_metingen':r['tabel_metingen']},ensure_ascii=False),flush=True)
    except Exception as e:
        r['fout'] = repr(e)
        raise
    finally:
        if app.poll() is None:
            os.killpg(app.pid, signal.SIGTERM)
            try:
                app.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(app.pid, signal.SIGKILL)
                app.wait(timeout=10)
        d.close()
        log.close()
        (a.uitvoer / 'profiel.json').write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
    return 0
basis.proef = proef
basis.__file__ = str(Path(__file__).resolve())
if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('--bron', type=Path, default=os.environ.get('OFFICE_PROFIEL_BRON'))
    eigen, overig = p.parse_known_args()
    if eigen.bron is None and '--help' not in overig:
        p.error('Geef --bron met een eigen DOCX van 129 pagina’s met 256 tabellen; de proef werkt uitsluitend op een kopie.')
    if eigen.bron is not None:
        os.environ['OFFICE_PROFIEL_BRON'] = str(eigen.bron.resolve(strict=True))
    sys.argv = [sys.argv[0], *overig]
    basis.__doc__ = __doc__
    raise SystemExit(basis.main())
