import json, os, subprocess, time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=r.parents[2]
python=repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'
uitkomsten=[]
for naam,script,programma,versie,args,extra in json.loads((r/'proeven.json').read_text()):
 env=os.environ.copy();env.update(extra)
 env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
 cmd=[str(python),script,'--programma',programma,'--versie',versie,'--uitvoer',str(r/naam),*args]
 print('START',naam,flush=True);begin=time.time()
 with (r/(naam+'.log')).open('w') as log:uit=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 uitkomsten.append({'naam':naam,'code':uit.returncode,'seconden':round(time.time()-begin,2),'opdracht':cmd,'omgeving':extra})
 (r/'proefuitkomsten.json').write_text(json.dumps(uitkomsten,indent=2)+'\n')
 print('EINDE',naam,uit.returncode,flush=True)
 if uit.returncode:raise SystemExit(uit.returncode)
