# Volgende kostenpost: volledige broncodering per Rust-invoer

De oorspronkelijke 45.36-opname cpu-36-tweede heeft 160 encode_state-stacks.
Alle 160 hebben direct daarboven de Rust-plakbrug (`plak`, editors-FhlTQooi.js
regel 72 kolom 176113). Gewone tekst hergebruikt die brug. rustPlakken.ts
encodeert op iedere poging de volledige bron met encodeStateAsUpdate(),
hasht die, maakt base64 en verstuurt haar naar de native voorbereiding.
Dit is een concrete volgende profilerings-/migratiekandidaat, geen bewezen
volledige oorzaak of huidige productwijziging.

Mogelijke aanpak om te onderzoeken: een begrensde bevestigde Rust-bronspiegel
per editor/document; eerste bron volledig, volgende aanvragen alleen Yrs-delta
tegen een native bevestigde bronvector. Alleen vanuit de frontend gecommitte
mutaties opnemen in die spiegel; de voorgestelde native edit nooit alvast
committeren. Iedere voorbereiding blijft een apart voorstel met dezelfde
clientidentiteit. De huidige bron-/levensduur-/selectiecontroles en uitgestelde
antwoordproeven moeten ongewijzigd streng blijven. Een verouderd antwoord mag
noch cursor, noch Undo, noch selectie veranderen. Verloren bevestigingen moeten
veilig en idempotent hersynchroniseren; ongeldige basis moet expliciet om een
nieuwe volledige bron vragen. Geheugen, levensduur en venstereigenaar begrenzen.

Nog te beoordelen: echte winst ten opzichte van Rust-importvoorbereiding,
statevector- en deletiesemantiek, versie-/hashbinding, type/schemawijziging,
rollbackvrije bevestigingsregels, begin-/wissel-/stopgedrag en vrijgave van
native spiegels. Niet implementeren door de huidige bronbewaking te verzwakken.
