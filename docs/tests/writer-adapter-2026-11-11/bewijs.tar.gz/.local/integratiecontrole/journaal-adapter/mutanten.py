from pathlib import Path
import json,subprocess,shutil,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-adapter';s=r/'native/onderzoek/writer-bronjournaal';basis=json.loads((u/'bouw.json').read_text())['opdracht'];result=[]
for naam,oud,nieuw,test in [('zonder_levensduur','if self.actief.as_ref() != Some(binding) || a.document_id != binding.document {','if false {','verkeerd_venster_document_en_generatie_nemen_geen_opdracht_over'),('corruptie_als_capaciteit','Err(Fout::Ongeldig(e)) => return Err(AdapterFout::Ongeldig(e)),','Err(Fout::Ongeldig(_e)) => return Ok(json!({"route":"bestaandeRoute"})),','capaciteit_is_alleen_advies_zonder_delta_en_corruptie_geeft_nooit_advies')]:
 m=u/naam;m.mkdir(exist_ok=True)
 for f in ['journaal.rs','adapter.rs','adapterproef.rs']:shutil.copyfile(s/f,m/f)
 p=m/'adapter.rs';v=p.read_text();assert v.count(oud)==1; p.write_text(v.replace(oud,nieuw))
 c=basis.copy();c[c.index('-o')-1]=str(m/'adapterproef.rs');c[c.index('-o')+1]=str(m/'proef');p=subprocess.run(c,capture_output=True,text=True,timeout=60);(m/'bouw.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 p=subprocess.run([str(m/'proef'),'--exact',test],capture_output=True,text=True,timeout=30);(m/'proef.log').write_text(p.stdout+p.stderr);assert p.returncode==101 and 'FAILED' in p.stdout,(p.returncode,p.stdout,p.stderr)
 result.append({'naam':naam,'verwacht_afgekeurd':True,'code':p.returncode,'test':test,'bouwopdracht':c,'binary_sha256':hashlib.sha256((m/'proef').read_bytes()).hexdigest()})
(u/'mutanten.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
