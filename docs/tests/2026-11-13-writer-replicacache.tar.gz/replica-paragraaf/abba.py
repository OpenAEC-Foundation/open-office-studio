from pathlib import Path
import os,subprocess,json
p=Path(__file__).resolve().parent;repo=p.parents[2];env={**os.environ,'PATH':'/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'],'BEELD':'1','ALINEA':'0'};h=json.load(open(p/'kern/bouw.json'))['sha256']
for label,wasm,pin in [('a-een',repo/'vendor/tekstengine/docx_edit_bg.wasm','737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9'),('b-een',p/'kern/docx_edit_bg.wasm',h),('b-twee',p/'kern/docx_edit_bg.wasm',h),('a-twee',repo/'vendor/tekstengine/docx_edit_bg.wasm','737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9')]:
 with (p/(label+'.log')).open('x')as f:subprocess.run(['node',str(p/'acht-stappen.mjs'),str(wasm),label,pin],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=120)
