from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;repo=p.parents[2];src=repo/'.local/integratiecontrole/font-hergebruik/bron/crates/docx-edit/src';pin=json.load(open(repo/'.local/integratiecontrole/mutatiebewijs/bronpinnen.json'))
for n in ['lib.rs','wasm.rs','mutation_proof.rs']:
 assert hashlib.sha256((src/n).read_bytes()).hexdigest()==pin[n]['na_sha256']
for n in ['engine.rs','wasm.rs','mutation_proof.rs','lib.rs']:(p/(n+'.voor')).write_bytes((src/n).read_bytes())
f=src/'engine.rs';s=f.read_text();begin=s.index('    pub(crate) fn edit_resident_text(');end=s.index('    fn patch_lowered_body(',begin);method=s[begin:end];tail_start=method.index('        let mut render = self.render.borrow_mut();');tail_end=method.index('        Ok(receipt)',tail_start);tail=method[tail_start:tail_end];call='''        self.record_resident_text_edit(&range, text, lower_locally, before, seed_epoch_valid,
            preview_plain, preview_length, attrs, single_delete, measurement_patch, &receipt);
''';method=method[:tail_start]+call+method[tail_end:];helper='''    #[allow(clippy::too_many_arguments)]
    fn record_resident_text_edit(
        &self, range: &crate::StoryRange, text: Option<&str>, lower_locally: bool,
        before: u64, seed_epoch_valid: bool, preview_plain: bool, preview_length: u32,
        attrs: Option<yrs::types::Attrs>, single_delete: bool,
        measurement_patch: Option<MeasurementPatch>, receipt: &crate::Receipt,
    ) {
'''+tail+'''    }

    #[cfg(feature = "wasm")]
    pub(crate) fn prepare_remote_text_update(&self) -> Option<RemoteTextPreparation> {
        if !self.local_lowering.get() || self.doc.holds_pending_update() {
            return None;
        }
        let before = self.doc_epoch();
        let (generation, env) = {
            let render = self.render.borrow();
            let lowered = render.stories.get("body")?;
            if lowered.doc_epoch != before || lowered.media != self.doc.media_sources()
                || !lowered.local.matches_source(&self.doc) {
                return None;
            }
            (lowered.generation, lowered.env.clone())
        };
        Some(RemoteTextPreparation {
            before, doc_before: self.doc.committed_epoch(), generation, env,
            length: self.doc.story_len("body").ok()?,
            measurement_patch: self.measurement_patch().take(),
        })
    }

    #[cfg(feature = "wasm")]
    pub(crate) fn cancel_remote_text_update(&self) {
        self.typing_epoch.set(None);
        self.typing_preserves_seeds.set(false);
        if let Some(lowered) = self.render.borrow_mut().stories.get_mut("body") {
            lowered.local.edit = None;
            lowered.preview_edit = None;
            lowered.preview_paragraph_edits.clear();
        }
    }

    #[cfg(feature = "wasm")]
    pub(crate) fn record_remote_text_update(&self, prepared: Option<RemoteTextPreparation>,
        proof: &crate::mutation_proof::Proof) -> bool {
        let Some((prepared, candidate)) = prepared.zip(proof.insertion()) else {
            self.cancel_remote_text_update();
            return false;
        };
        let units = candidate.text.encode_utf16().count() as u32;
        let valid = candidate.before_epoch == prepared.doc_before
            && candidate.after_epoch == self.doc.committed_epoch()
            && self.doc_epoch() == prepared.before.wrapping_add(1)
            && prepared.length.checked_add(units) == self.doc.story_len("body").ok()
            && self.render.borrow().stories.get("body").is_some_and(|lowered| {
                lowered.doc_epoch == prepared.before && lowered.generation == prepared.generation
                    && lowered.env == prepared.env && lowered.media == self.doc.media_sources()
                    && lowered.local.matches_source(&self.doc)
            });
        if !valid {
            self.cancel_remote_text_update();
            return false;
        }
        let range = crate::StoryRange::new("body", candidate.start, candidate.start);
        let receipt = crate::Receipt {
            new_para_ids: Vec::new(), revision_ids: Vec::new(),
            range: Some(crate::LocRange {
                start: crate::Loc::new("body", &candidate.paragraph, candidate.offset),
                end: crate::Loc::new("body", &candidate.paragraph, candidate.offset + units),
            }),
        };
        self.record_resident_text_edit(&range, Some(&candidate.text), true, prepared.before,
            true, true, prepared.length, Some(candidate.attributes.clone()), false,
            prepared.measurement_patch, &receipt);
        self.render.borrow().stories.get("body").is_some_and(|lowered| lowered.local.edit.is_some())
    }

''';s=s[:begin]+method+helper+s[end:];at=s.index('#[derive(Debug)]\nstruct MeasurementPatch');s=s[:at]+'''#[cfg(feature = "wasm")]
pub(crate) struct RemoteTextPreparation {
    before: u64,
    doc_before: u64,
    generation: u64,
    env: RenderEnv,
    length: u32,
    measurement_patch: Option<MeasurementPatch>,
}

'''+s[at:];f.write_text(s)
f=src/'mutation_proof.rs';s=f.read_text().replace('    attribute_keys: Vec<String>,','    attribute_keys: Vec<String>,\n    #[serde(skip)]\n    attributes: yrs::types::Attrs,');s=s.replace('    observed: Observed,','    observed: Observed,\n    #[serde(skip)]\n    candidate: Option<Insertion>,');s=s.replace('pub(crate) struct UpdateWatch {','''pub(crate) struct Insertion {
    pub(crate) before_epoch: u64,
    pub(crate) after_epoch: u64,
    pub(crate) start: u32,
    pub(crate) offset: u32,
    pub(crate) paragraph: String,
    pub(crate) text: String,
    pub(crate) attributes: yrs::types::Attrs,
}

impl Proof {
    pub(crate) fn insertion(&self) -> Option<&Insertion> { self.candidate.as_ref() }
}

pub(crate) struct UpdateWatch {''');s=s.replace('state.attribute_keys.sort();','state.attribute_keys.sort();\n                                        state.attributes = (**attributes).clone();');s=s.replace('|| start < before.start','|| start < before.node_start\n                || before.pilcrow.checked_add(observed.text.as_ref()?.encode_utf16().count() as u32) != Some(after.pilcrow)');s=s.replace('''        Proof {
            accepted: observed.reasons.is_empty(),''','''        let candidate = observed.reasons.is_empty().then(|| Insertion {
            before_epoch, after_epoch, start: observed.start.unwrap(), offset: offset.unwrap(),
            paragraph: paragraph.clone().unwrap(), text: observed.text.clone().unwrap(),
            attributes: observed.attributes.clone(),
        });
        Proof {
            accepted: observed.reasons.is_empty(),
            candidate,''');f.write_text(s)
f=src/'wasm.rs';s=f.read_text().replace('        let watch = crate::mutation_proof::UpdateWatch::new(self.engine.doc());','        let prepared = self.engine.prepare_remote_text_update();\n        let watch = crate::mutation_proof::UpdateWatch::new(self.engine.doc());');a='''        let inference =
            apply_update_with_typing_inference(self.engine.doc(), update).map_err(js_err)?;
        let proof = watch.finish(self.engine.doc());
        *self.last_apply_profile_json.borrow_mut() = serde_json::to_string(&proof).map_err(js_err)?;''';b='''        let inference = match apply_update_with_typing_inference(self.engine.doc(), update) {
            Ok(inference) => inference,
            Err(error) => { self.engine.cancel_remote_text_update(); return Err(js_err(error)); }
        };
        let proof = watch.finish(self.engine.doc());
        let recorded = self.engine.record_remote_text_update(prepared, &proof);
        let mut profile = serde_json::to_value(&proof).map_err(js_err)?;
        profile["cache_recorded"] = json!(recorded);
        *self.last_apply_profile_json.borrow_mut() = serde_json::to_string(&profile).map_err(js_err)?;''';assert s.count(a)==1;f.write_text(s.replace(a,b))
