import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';import{pathToFileURL}from'node:url';
const dir=path.resolve('.local/integratiecontrole/replica-paragraaf'),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),wasm=fs.readFileSync('vendor/tekstengine/docx_edit_bg.wasm'),docx=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx');assert.equal(sha(wasm),'737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9');
const{preloadEditWasm,createEditSession}=await import(pathToFileURL(path.resolve('node_modules/@betteroffice/docx/dist/wasm-edit.mjs')).href);await preloadEditWasm(wasm);
const save=(name,bytes)=>{fs.writeFileSync(path.join(dir,name),bytes,{flag:'wx'});return{file:name,sha256:sha(bytes),bytes:bytes.length}},r={geslaagd:false,docx_sha256:sha(docx),gevallen:[]};
const kinds=['opmaak-vet','opmaak-lettertype','opmaak-hyperlink','positief-gemengd-positief'];
try{for(const kind of kinds){const a=createEditSession(901),b=createEditSession(902),c=createEditSession(903),peer=createEditSession(904);try{
 a.open_docx(docx,true);if(kind==='headertekst')a.create_story('hf-proef','Koptekst','Normal','left');
 const initialLast=JSON.parse(a.paragraphs('body')).at(-1);if(kind==='opmaak-vet')a.format_range('body',initialLast.paraId,0,initialLast.paraId,initialLast.text.length,JSON.stringify({bold:true}));if(kind==='opmaak-lettertype')a.format_range('body',initialLast.paraId,0,initialLast.paraId,initialLast.text.length,JSON.stringify({fontFamily:{ascii:'Liberation Serif',hAnsi:'Liberation Serif'},fontSize:18,italic:true}));if(kind==='opmaak-hyperlink')a.set_hyperlink('body',initialLast.paraId,0,initialLast.paraId,initialLast.text.length,JSON.stringify({href:'https://example.invalid/proef'}));const initial=a.encode_state();for(const s of[b,c,peer]){s.open_docx(docx,false);s.load(initial)}
 const pars=JSON.parse(a.paragraphs('body')),last=pars.at(-1),other=pars.find(p=>p.paraId!==last.paraId&&p.text.length>3),vector=b.encode_state_vector(),steps=[];assert(other);
 const insert=(s,p,at,text)=>s.insert_text('body',p.paraId,at,text,null,null),normal=()=>insert(a,last,last.text.length,' proef'),step=(bytes,accepted,throwing=false)=>steps.push({bytes,accepted,throwing});
 if(kind==='andere-font')a.format_range('body',other.paraId,0,other.paraId,2,JSON.stringify({fontFamily:{ascii:'Liberation Serif',hAnsi:'Liberation Serif'}}));
 if(kind==='andere-uitlijning')a.set_paragraph_attr(other.paraId,'alignment',JSON.stringify('right'));
 if(kind==='andere-delete')a.delete_range('body',other.paraId,0,other.paraId,1,null,null);
 if(kind==='andere-split')a.split_paragraph('body',other.paraId,1,null,null);
 if(kind==='marges')assert(a.set_section_margins('final',JSON.stringify({marginTop:1200})));
 if(kind==='documentmetadata')assert(a.set_document_property('metadata',JSON.stringify({body:{finalSectionProperties:{marginLeft:1200}}})));
 if(kind==='commentaar')a.add_comment(JSON.stringify([{story:'body',startPara:other.paraId,startOffset:0,endPara:other.paraId,endOffset:1}]),'Proef','2026-11-13T08:00:00Z',JSON.stringify({text:'Opmerking'}));
 if(kind==='nieuwe-story')a.create_story('hf-proef','Koptekst','Normal','left');
 if(kind==='twee-auteurs'){insert(peer,other,0,' Ander ');a.apply_update(peer.encode_diff(a.encode_state_vector()))}
 if(kind==='twee-posities')insert(a,last,0,' Begin ');
 if(kind==='zelfde-opmaak'||kind==='alleen-opmaak')a.format_range('body',last.paraId,0,last.paraId,2,JSON.stringify({bold:true}));
 if(kind==='positief-gemengd-positief'){let sv=vector,offset=last.text.length;for(const [i,text]of [' een',' العربية',' einde'].entries()){if(i===1)a.format_range('body',other.paraId,0,other.paraId,2,JSON.stringify({fontFamily:{ascii:'Liberation Serif'}}));insert(a,last,offset,text);step(a.encode_diff(sv),i!==1);sv=a.encode_state_vector();offset+=text.length;}}else if(kind==='pending'){
  normal();const first=a.encode_diff(vector),mid=a.encode_state_vector();insert(a,last,last.text.length+6,' vervolg');const second=a.encode_diff(mid);step(second,false);step(first,false);step(second,false);
 }else if(kind==='headertekst'){
  const h=JSON.parse(a.paragraphs('hf-proef'))[0];a.insert_text('hf-proef',h.paraId,0,' Kop ',null,null);step(a.encode_diff(vector),false);
 }else if(kind==='alleen-delete'){
  a.delete_range('body',last.paraId,0,last.paraId,1,null,null);step(a.encode_diff(vector),false);
 }else if(kind==='alleen-opmaak')step(a.encode_diff(vector),false);
 else if(kind==='lege-update')step(new Uint8Array([0,0]),false);
 else{
  const text=kind==='unicode'?' Ω العربية 漢字 🙂':kind==='te-groot'?'x'.repeat(4097):kind==='leeg-tekst'?'':' proef';insert(a,last,last.text.length+(kind==='twee-posities'?7:0),text);
  const update=a.encode_diff(vector),accepted=['opmaak-vet','opmaak-lettertype','opmaak-hyperlink'].includes(kind);step(update,accepted);
  if(kind==='herhaling')step(update,false);
  if(kind==='fout-na-goed')step(new Uint8Array([255,255,255,255]),false,true);
 }
 const entry={kind,initial:save(kind+'-initial.bin',initial),stappen:[]};
 for(let i=0;i<steps.length;i++){
  const {bytes,accepted,throwing}=steps[i];let errorB=null,errorC=null,inference=null;try{inference=JSON.parse(b.apply_update_with_inference(bytes))}catch(e){errorB=String(e)}try{c.apply_update(bytes)}catch(e){errorC=String(e)}
  assert.equal(errorB!==null,throwing,kind);assert.equal(errorC!==null,throwing,kind);assert.deepEqual(b.encode_state(),c.encode_state(),kind);assert.deepEqual(b.encode_state_vector(),c.encode_state_vector(),kind);
  entry.stappen.push({update:save(kind+'-'+i+'.bin',bytes),accepted,throwing,inference,error:errorB,state_sha256:sha(b.encode_state()),vector_sha256:sha(b.encode_state_vector()),body_sha256:sha(b.story_segments('body')),marges:JSON.parse(b.section_margins_json()),documentmetadata:JSON.parse(b.document_properties_json())});
 }
 r.gevallen.push(entry);
}finally{a.free();b.free();c.free();peer.free()}}r.geslaagd=true}catch(e){r.fout=String(e);throw e}finally{fs.writeFileSync(path.join(dir,'extra-corpus.json'),JSON.stringify(r,null,2)+'\n')}
console.log(JSON.stringify({geslaagd:r.geslaagd,gevallen:r.gevallen.length,stappen:r.gevallen.reduce((n,x)=>n+x.stappen.length,0)}));
