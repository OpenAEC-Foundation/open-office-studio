from pathlib import Path
import os,subprocess,json,hashlib,time
repo=Path.cwd();p=repo/'.local/integratiecontrole/replica-paragraaf';sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();baseline=repo/'.local/integratiecontrole/lint-invoer/open-office-studio-lint-invoer';candidate=p/'open-office-studio-replica-paragraaf';assert sha(baseline)=='acb77036935feed425b7c81a5dbd2ef796ffcb4307db96c9845aa6dd8b70c958';assert sha(candidate)=='5934f4985ea248c7dac6525b1753fd164c596f3e0220d9ba3dba616a2d906e82';env={**os.environ,'PATH':'/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+os.environ['PATH']};python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python';results=[]
for kind in ['klein','rijk']:
 helper=repo/('.local/integratiecontrole/status-plugin/proef-'+kind+'.py');pin=sha(helper)
 for label,exe in [('a-een',baseline),('b-een',candidate),('b-twee',candidate),('a-twee',baseline)]:
  assert sha(helper)==pin;name='native-'+kind+'-'+label;cmd=[python,str(helper),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(p/name)];print('START',name,flush=True);begin=time.monotonic()
  with(p/(name+'.log')).open('x')as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450).returncode
  r=json.load(open(p/name/'rapport.json'));results.append({'naam':name,'code':rc,'geslaagd':r['geslaagd'],'fout':r.get('fout'),'seconden':time.monotonic()-begin,'programma_sha256':r['programma_sha256'],'helper_sha256':pin,'opdracht':cmd,'invoer':r.get('lange_invoer')});(p/'native-ronden.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print('EINDE',name,json.dumps(results[-1]),flush=True);assert rc==0 and r['geslaagd'],name
