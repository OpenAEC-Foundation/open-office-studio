from pathlib import Path
import json,subprocess,os
p=Path(__file__).resolve().parent;repo=p.parents[2];sha=json.load(open(p/'kern/bouw.json'))['sha256'];env={**os.environ,'PATH':'/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
for mode,label,wasm,h in [('warm','definitief-warm',p/'kern/docx_edit_bg.wasm',sha),('koud','definitief-koud',p/'kern/docx_edit_bg.wasm',sha),('zonder-lokaal','definitief-zonder-lokaal',p/'kern/docx_edit_bg.wasm',sha)]:
 with (p/(label+'.log')).open('x')as f:subprocess.run(['node',str(p/'proef.mjs'),str(wasm),h,label,mode],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
