from pathlib import Path
import json,statistics
p=Path(__file__).resolve().parent;data={n:json.loads((p/('gescheiden-'+n+'.json')).read_text())for n in ['controle','profiel','kandidaat']};assert all(len(d)==18 for d in data.values())
for label in ['profiel','kandidaat']:
 for a,b in zip(data['controle'],data[label]):
  for k in ['naam','ronde','plan','peer_plan','bron_sha256','vector_sha256','peer_gelijk_aan_editor','bron_en_vector_exact']:assert a[k]==b[k],(label,a['naam'],k)
marks={};current=None
for line in(p/'gescheiden-profiel.log').read_text().splitlines():
 if line.startswith('OOS_BEGIN '):current=tuple(line.split()[1:])
 elif line.startswith('OOS_GUARD_BEGIN'):current=None
 elif line.startswith('OOS_PLAN ')and current:
  prev=0;phases={}
  for k,t in json.loads(line[9:]):phases[k]=(t-prev)/1e6;prev=t
  assert current not in marks;marks[current]=phases
assert len(marks)==54
rows=[]
for name in dict.fromkeys(r['naam']for r in data['controle']):
 group={k:[r for r in v if r['naam']==name]for k,v in data.items()};first=[marks[(name,str(i),'0')]for i in range(3)]
 row={'geval':name,'fasen_profiel_eerste_mediaan_ms':{k:statistics.median(x[k]for x in first)for k in first[0]},'varianten':{}}
 for variant,runs in group.items():
  row['varianten'][variant]={'openen_mediaan_ms':statistics.median(r['openen_ns']/1e6 for r in runs),'eerste_plan_mediaan_ms':statistics.median(r['planner_ns'][0]/1e6 for r in runs),'identiteiten_mediaan_ms':statistics.median(r['identiteiten_ns']/1e6 for r in runs),'openen_identiteiten_eerste_plan_mediaan_ms':statistics.median((r['openen_ns']+r['identiteiten_ns']+r['planner_ns'][0])/1e6 for r in runs)}
 a=row['varianten']['controle']['openen_identiteiten_eerste_plan_mediaan_ms'];b=row['varianten']['kandidaat']['openen_identiteiten_eerste_plan_mediaan_ms'];row['daling_totaal_procent']=100*(1-b/a);rows.append(row)
result={'editorplannen_per_variant_gelijk_aan_controle':18,'replicaplannen_per_variant_gelijk_aan_controle':18,'bron_vector_SHA_gelijk_in_alle_varianten':18,'tijdgemeten_planlezingen_met_directe_bron_vector_controle':162,'aanvullende_guard_planlezingen':162,'replica_editor_verschillen_ook_in_ongewijzigde_controle':sum(not r['peer_gelijk_aan_editor']for r in data['controle']),'gevallen':rows}
(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
