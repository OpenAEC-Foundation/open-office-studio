from pathlib import Path
import subprocess,os,time,json,signal,shutil
p=Path.cwd()/'.local/integratiecontrole/basistoestand-bewaren';rows=[];env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_TARGET_DIR':str(p/'target'),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true'}
for label,manifest in [('profiel',p/'Cargo.toml'),('kandidaat',p/'kandidaat/Cargo.toml'),('controle',p/'controle/Cargo.toml')]:
 cmd=['cargo','build','--manifest-path',str(manifest),'--release','--offline']
 if label=='kandidaat':cmd+=['--features','kandidaat']
 begin=time.monotonic();print('START BOUW',label,flush=True)
 with(p/('bouwen-herzien-'+label+'.log')).open('x')as log:
  child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=300)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=15);code='timeout'
 rows.append({'label':label,'code':code,'duur_s':time.monotonic()-begin,'opdracht':cmd});(p/'bouwen-herzien.json').write_text(json.dumps(rows,indent=2)+'\n');print('BOUW',label,code,flush=True)
 if code!=0:break
 shutil.copy2(p/'target/release'/('oos-basistoestand-'+label),p/('planner-'+label))
 with(p/(label+'.json')).open('w')as out,(p/(label+'.log')).open('w')as log:res=subprocess.run([str(p/('planner-'+label)),str(Path.cwd()/'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx')],stdout=out,stderr=log,timeout=180)
 rows.append({'label':label+'-proef','code':res.returncode});(p/'bouwen-herzien.json').write_text(json.dumps(rows,indent=2)+'\n');print('PROEF',label,res.returncode,flush=True)
 if res.returncode!=0:break
