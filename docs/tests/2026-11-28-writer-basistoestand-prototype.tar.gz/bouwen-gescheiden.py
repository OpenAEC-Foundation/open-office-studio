from pathlib import Path
import os,subprocess,time,json,shutil,signal,hashlib
p=Path.cwd()/'.local/integratiecontrole/basistoestand-bewaren';rows=[]
for label in ['controle','profiel','kandidaat']:
 target=p/('target-'+label);basis=p.parent/'planner-bron/target'if label!='kandidaat'else p/'target';shutil.copytree(basis,target)
 if label=='profiel':
  for f in(target/'release/deps').glob('libdocx_edit.*'):f.unlink()
  for f in(target/'release').glob('libdocx_edit.*'):f.unlink()
  for f in(target/'release/.fingerprint').glob('betteroffice-docx-edit-*'):shutil.rmtree(f)
 manifest=p/'Cargo.toml'if label=='profiel'else p/label/'Cargo.toml';cmd=['cargo','build','--manifest-path',str(manifest),'--release','--offline']
 if label=='kandidaat':cmd+=['--features','kandidaat']
 env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true'};begin=time.monotonic();print('START',label,flush=True)
 with(p/('gescheiden-bouw-'+label+'.log')).open('x')as log:
  child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=300)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=15);code='timeout'
 rows.append({'label':label,'code':code,'duur_s':time.monotonic()-begin,'opdracht':cmd,'target':str(target)});(p/'bouwen-gescheiden.json').write_text(json.dumps(rows,indent=2)+'\n');print('BOUW',label,code,flush=True)
 if code!=0:break
 exe=p/('planner-gescheiden-'+label);shutil.copy2(target/'release'/('oos-basistoestand-'+label),exe);rows[-1]['exe_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest();rows[-1]['rlib_sha256']=hashlib.sha256((target/'release/deps/libdocx_edit.rlib').read_bytes()).hexdigest()
 with(p/('gescheiden-'+label+'.json')).open('x')as out,(p/('gescheiden-'+label+'.log')).open('x')as log:res=subprocess.run([str(exe),str(Path.cwd()/'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx')],stdout=out,stderr=log,timeout=180)
 rows.append({'label':label+'-proef','code':res.returncode});(p/'bouwen-gescheiden.json').write_text(json.dumps(rows,indent=2)+'\n');print('PROEF',label,res.returncode,flush=True)
 if res.returncode!=0:break
