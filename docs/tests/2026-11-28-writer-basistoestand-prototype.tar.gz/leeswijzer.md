# Eigen bronproef

Alleen de gescheiden-* bestanden, bouwen-gescheiden.json en analyse.json vormen het definitieve resultaat. Overige bouwscripts, harnassen en rapporten zijn bewaarde tussenstappen. De gedeelde targetmap maakte enkele herhalingen ongeldig; die zijn uitgesloten. De eerste replica/editor-Eq is eveneens vervangen door gelijksoortige controles.

De definitieve volledige .rs-bronnen en Cargo.toml/Cargo.lock staan per variant; de wijzigingen van de bibliotheek staan in bron/ en patches/ in het bewijsarchief. Maak per variant een afzonderlijke Cargo-targetmap. Native Instant-metingen en oos_probe-methoden zijn onderzoeksinstrumenten en horen niet in een Wasm-productbouw.
