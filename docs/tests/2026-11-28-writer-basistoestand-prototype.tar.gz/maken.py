from pathlib import Path
import shutil
r=Path.cwd();p=r/'.local/integratiecontrole/basistoestand-bewaren';oud=p.parent/'planner-bron'
shutil.copytree(oud/'docx-edit',p/'docx-profiel');shutil.copytree(oud/'target',p/'target')
f=p/'docx-profiel/src/identity.rs';s=f.read_text();start=s.index('    pub fn paragraph_save_plan');i=s.index('        let seeded = if ',start);s=s[:i]+'        __fasen.push(("voor_seed", __begin.elapsed().as_nanos()));\n'+s[i:];f.write_text(s)
shutil.copytree(p/'docx-profiel',p/'docx-kandidaat')
f=p/'docx-kandidaat/src/lib.rs';s=f.read_text();old='    #[cfg(feature = "wasm")]\n    pub(crate) fn mark_seeded(&self)';assert s.count(old)==1;s=s.replace(old,'    pub(crate) fn mark_seeded(&self)');f.write_text(s)
f=p/'docx-kandidaat/src/seed.rs';s=f.read_text()
for old in ['    document.begin_opening(None);\n    Ok(())\n}\n\n/// [`seed_from_docx`]', '    document.begin_opening(Some(generation));\n    Ok(())']:
 assert s.count(old)==1,old
 new=old.replace('    Ok(())','    document.mark_seeded();\n    document.prepare_seeded_save_baseline();\n    Ok(())',1);s=s.replace(old,new)
f.write_text(s)
f=p/'docx-kandidaat/src/identity.rs';s=f.read_text();i=s.index('    pub fn paragraph_save_plan(&self)')
helper='''    /// Alleen na voltooide, oorspronkelijke seeding; bewaart de basistoestand één keer.
    pub(crate) fn prepare_seeded_save_baseline(&self) -> bool {
        if !self.unchanged_since_seeded() { return false; }
        let Some(source) = self.source_index() else { return false; };
        if source.seed_states.get().is_some() || !source.opened_under_own_digest() { return false; }
        let txn = self.yrs_doc().transact();
        if !self.unchanged_since_seeded() { return false; }
        let metadata = self.source_metadata();
        let media = self.media_table();
        let stories = story_states_in(self, &txn);
        let patch_table_styles = metadata.as_ref().map(|m| m.patch_table_styles().clone()).unwrap_or_default();
        // Zelfde pakket, media, metadata en commitgrens vasthouden tot het vullen van de cache.
        let current_media = self.media.lock().unwrap();
        let current_source = self.source.lock().unwrap();
        let current_metadata = self.metadata.lock().unwrap();
        let same = |a: &Option<Arc<crate::seed::SourceMetadata>>, b: &Option<Arc<crate::seed::SourceMetadata>>| match (a,b) { (Some(a),Some(b)) => Arc::ptr_eq(a,b), (None,None)=>true, _=>false };
        let same_media = match (&media, &*current_media) { (Some(a),Some(b)) => Arc::ptr_eq(a,b), (None,None)=>true, _=>false };
        if !self.unchanged_since_seeded() || !same(&metadata, &current_metadata) || !same_media || !matches!(&*current_source, Some(SourcePackage::Ready(current)) if Arc::ptr_eq(current, &source)) { return false; }
        source.seed_states_or(|| SeedStates { stories, patch_table_styles });
        true
    }

    /// Uitsluitend voor de eigen bronproef; geen aansluiting in de desktop.
    #[cfg(feature = "writer-bronjournaal")]
    pub fn oos_probe_prepare_seed_baseline(&self) -> bool { self.prepare_seeded_save_baseline() }

    #[cfg(feature = "writer-bronjournaal")]
    pub fn oos_probe_has_seed_baseline(&self) -> bool { self.source_index().is_some_and(|s| s.seed_states.get().is_some()) }

'''
s=s[:i]+helper+s[i:];f.write_text(s)
manifest=(oud/'Cargo.toml').read_text().replace('oos-planner-bronproef','oos-basistoestand-profiel').replace('path = "docx-edit"','path = "docx-profiel"');(p/'Cargo.toml').write_text(manifest)
shutil.copy2(oud/'Cargo.lock',p/'Cargo.lock')
for label,dep in [('kandidaat',str(p/'docx-kandidaat')),('controle',str(r/'native/vendor/docx-edit'))]:
 d=p/label;d.joinpath('src').mkdir(parents=True)
 m=manifest.replace('oos-basistoestand-profiel','oos-basistoestand-'+label).replace('path = "docx-profiel"','path = "'+dep+'"');m+='\n[features]\nkandidaat = []\n';(d/'Cargo.toml').write_text(m);shutil.copy2(oud/'Cargo.lock',d/'Cargo.lock')
s=(oud/'src/main.rs').read_text().replace('seed_from_docx','seed_from_docx_with_generation').replace('seed_from_docx_with_generation(&doc, &bytes)','seed_from_docx_with_generation(&doc, &bytes, "eigen-planner-proef")')
s=s.replace('            let ctx = ','''            #[cfg(feature = "kandidaat")]
            assert!(doc.oos_probe_has_seed_baseline());
            let ctx = ''')
s=s.replace('            let voor = doc.encode_state_as_update_v1();','''            #[cfg(feature = "kandidaat")]
            {
                assert!(!doc.oos_probe_prepare_seed_baseline());
                let peer = EditingDoc::new(72); peer.keep_deleted();
                peer.apply_update_v1(&doc.encode_state_as_update_v1()).unwrap();
                peer.retain_source_docx(bytes.clone());
                let before = peer.encode_state_as_update_v1();
                assert!(!peer.oos_probe_prepare_seed_baseline());
                assert_eq!(peer.encode_state_as_update_v1(), before);
                assert_eq!(peer.paragraph_save_plan(), doc.paragraph_save_plan());
            }
            let voor = doc.encode_state_as_update_v1();''')
# De guards hierboven mogen de tijdmeting niet warmen: werk op een afzonderlijke verse sessie.
s=s.replace('                assert_eq!(peer.paragraph_save_plan(), doc.paragraph_save_plan());','                assert!(peer.paragraph_save_plan().spliced_parts.len() <= 10);')
for d in [p,p/'kandidaat',p/'controle']:(d/'src/main.rs').write_text(s)
