//! OpenAEC: onveranderlijke bevestigde bron met begrensde updategeschiedenis.
use super::*;
use std::sync::Arc;

const MAX_UPDATES: usize = 32;
const MAX_UPDATE_BYTES: usize = 512 * 1024;

/// Alleen deze module kan bronbytes, geschiedenis en binding samen aanmaken.
/// Een aanroeper kan geen eigen digest aan andere bronbytes koppelen.
#[derive(Clone)]
pub struct ConfirmedClipboardSource {
    client_id: u64,
    checkpoint: Arc<[u8]>,
    updates: Vec<Arc<[u8]>>,
    update_bytes: usize,
    fingerprint: [u8; 32],
}
impl ConfirmedClipboardSource {
    fn checkpoint(client_id: u64, bytes: Vec<u8>) -> Self {
        let mut hash = Sha256::new();
        hash.update(b"OpenAEC bevestigde bron 1\0");
        hash.update(client_id.to_le_bytes());
        hash.update((bytes.len() as u64).to_le_bytes());
        hash.update(&bytes);
        Self {
            client_id,
            checkpoint: bytes.into(),
            updates: Vec::new(),
            update_bytes: 0,
            fingerprint: hash.finalize().into(),
        }
    }
    fn append(&self, bytes: &[u8]) -> Self {
        // De canonieke lege v1-update bevestigt geen nieuwe inhoud of verwijdering.
        if bytes == [0, 0] {
            return self.clone();
        }
        let mut hash = Sha256::new();
        hash.update(b"OpenAEC bevestigde update 1\0");
        hash.update(self.fingerprint);
        hash.update((bytes.len() as u64).to_le_bytes());
        hash.update(bytes);
        let mut next = self.clone();
        next.updates.push(Arc::from(bytes));
        next.update_bytes = next.update_bytes.saturating_add(bytes.len());
        next.fingerprint = hash.finalize().into();
        next
    }
    pub fn bytes(&self) -> usize {
        self.checkpoint.len().saturating_add(self.update_bytes)
    }
    pub fn update_count(&self) -> usize {
        self.updates.len()
    }
    /// Ondoorzichtige bronbinding; geen afleidbare versie of inhoudelijke vector.
    pub fn binding(&self) -> String {
        self.fingerprint
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect()
    }
    fn apply_to(&self, doc: &EditingDoc) -> OpResult<()> {
        doc.apply_verbatim_v1(&self.checkpoint)
            .map_err(OpError::from)?;
        for update in &self.updates {
            doc.apply_verbatim_v1(update).map_err(OpError::from)?;
        }
        Ok(())
    }
    /// Volledige materialisatie voor export/controle; niet het warme invoerpad.
    pub fn snapshot(&self) -> OpResult<Vec<u8>> {
        let doc = EditingDoc::new(self.client_id);
        doc.keep_deleted();
        self.apply_to(&doc)?;
        if doc.holds_pending_update() {
            return Err(ongeldig("De bewaarde Writer-bron is onvolledig"));
        }
        Ok(doc.encode_state_as_update_v1())
    }
}

pub struct JournalClipboardBatchResult {
    pub source: ConfirmedClipboardSource,
    pub batch: ClipboardBatchResult,
    pub replica: PreparedClipboardReplica,
    pub reused: bool,
    pub checkpointed: bool,
}

#[allow(clippy::too_many_arguments)]
pub fn prepare_journal_clipboard_fragment(
    cached: Option<PreparedClipboardReplica>,
    base: Option<&ConfirmedClipboardSource>,
    update: &[u8],
    client_id: u64,
    expected_vector: &[u8],
    range: &LocRange,
    fragment: &Value,
    ctx: &EditCtx,
    max_source_bytes: usize,
) -> OpResult<JournalClipboardBatchResult> {
    let expected = StateVector::decode_v1(expected_vector).map_err(|e| ongeldig(e.to_string()))?;
    let fragment: Fragment =
        serde_json::from_value(fragment.clone()).map_err(|e| ongeldig(e.to_string()))?;
    if range.start.story != range.end.story {
        return Err(ongeldig("Bereik loopt over verschillende verhalen"));
    }
    if base.is_some_and(|b| b.client_id != client_id) {
        return Err(ongeldig("De Writer-bron hoort bij een andere client"));
    }
    let cached = cached.filter(|c| {
        c.client_id == client_id
            && c.proposed_update == update
            && base.is_some_and(|b| b.fingerprint == c.base_digest)
    });
    let reused = cached.is_some();
    let doc = if let Some(c) = cached {
        c.doc
    } else {
        let doc = EditingDoc::new(client_id);
        doc.keep_deleted();
        if let Some(base) = base {
            base.apply_to(&doc)?;
        }
        doc.apply_verbatim_v1(update).map_err(OpError::from)?;
        doc
    };
    if doc.holds_pending_update() {
        return Err(ongeldig(
            "De Writer-bron bevat nog onopgeloste afhankelijkheden",
        ));
    }
    let vector = doc.encode_state_vector_v1();
    if StateVector::decode_v1(&vector).map_err(|e| ongeldig(e.to_string()))? != expected {
        return Err(ongeldig(
            "De samengestelde Writer-bron heeft een andere bronvector",
        ));
    }
    let mut source = match base {
        Some(base) => base.append(update),
        None => ConfirmedClipboardSource::checkpoint(client_id, update.to_vec()),
    };
    let checkpointed = source.updates.len() >= MAX_UPDATES
        || source.update_bytes >= MAX_UPDATE_BYTES
        || source.bytes() > max_source_bytes;
    if checkpointed {
        source = ConfirmedClipboardSource::checkpoint(client_id, doc.encode_state_as_update_v1());
    }
    if source.bytes() > max_source_bytes {
        return Err(ongeldig("De samengestelde Writer-bron is te groot"));
    }
    // De volledige bevestigde bron wordt vastgelegd voordat de voorstelmutatie begint.
    let batch = prepare_clipboard_in_doc(&doc, range, fragment, ctx)?;
    let replica = PreparedClipboardReplica {
        doc,
        client_id,
        base_digest: source.fingerprint,
        proposed_update: batch.update.clone(),
    };
    Ok(JournalClipboardBatchResult {
        source,
        batch,
        replica,
        reused,
        checkpointed,
    })
}
