/** De snelle route moet dezelfde getekende tabelgrepen opleveren als positielezen. */
import { readFileSync } from "node:fs";
import { createYrsSession } from "@betteroffice/docx/yrs";
import type { DisplayList } from "@betteroffice/docx/layout/render";
import type { DocxPluginGeometry } from "@betteroffice/docx-react";
import { describe, expect, it, vi } from "vitest";
import { tabelBeelden, tabelPositiesUitIdentiteiten, type TabelPlekInfo } from "./geometrie";

type Sessie = Parameters<typeof tabelPositiesUitIdentiteiten>[1];
type Weergave = Parameters<typeof tabelBeelden>[0];
const bestand = new Uint8Array(readFileSync("docs/tests/writer-lettertypeworker/tabelbron-256.docx"));
function lijst(seed: string, semantisch = true): DisplayList {
  const id = `body:table:${seed}`;
  const cel = (rij: number, kolom: number) => ({
    kind: "rect" as const, x: 100 + kolom * 100, y: 50 + rij * 30, w: 100, h: 30, fill: "#fff",
    docStart: 100 + rij * 20 + kolom * 4,
    cell: { row: rij, col: kolom, rowSpan: 1, colSpan: 1, ...(semantisch ? { cellId: `${id}-r${rij}-c${kolom}` } : {}) },
    table: { tableId: id, rowStart: rij, rowEnd: rij + 1, rowCount: 3, columnCount: 2 },
  });
  return { pages: [
    { pageIndex: 0, width: 800, height: 1000, primitives: [cel(0, 0), cel(0, 1)] },
    { pageIndex: 1, width: 800, height: 1000, primitives: [cel(1, 0), cel(1, 1), cel(2, 0), cel(2, 1)] },
  ] };
}
const geometrie = (displayList: DisplayList) => ({ dom: { queries: { displayList, isReady: () => true } } }) as unknown as DocxPluginGeometry;

describe("celidentiteiten voor tabelgrepen", () => {
  it("behoudt alle randen over twee pagina's zonder zes celposities opnieuw uit te lezen", async () => {
    const s = await createYrsSession({ clientId: 71 });
    try {
      s.openDocx(bestand, true);
      const payload = s.tablePayload("body", 255) as unknown as TabelPlekInfo["payload"];
      expect(payload.rows).toHaveLength(3);
      const seed = payload.rows[0].cells[0].story;
      const opzoeken = vi.fn((pos: number) => {
        const rij = Math.floor((pos - 100) / 20), kolom = ((pos - 100) % 20) / 4;
        return { story: payload.rows[rij].cells[kolom].story, paraId: "alinea", offset: 0 };
      });
      const weergave = { displayPositionToYrsLoc: opzoeken } as unknown as Weergave;
      const oud = tabelBeelden(weergave, s, geometrie(lijst(seed, false)), [], 0, 1, s.version());
      expect(oud).toHaveLength(2);
      expect(opzoeken).toHaveBeenCalledTimes(6);
      opzoeken.mockClear();
      const nieuw = tabelBeelden(weergave, s, geometrie(lijst(seed)), [], 0, 1, s.version());
      expect(nieuw).toEqual(oud);
      expect(opzoeken).not.toHaveBeenCalled();
      // Dezelfde bronpunten kunnen op een vervolgpagina als herhaalde kop verschijnen.
      const herhaald = lijst(seed);
      herhaald.pages[1].primitives.push({ ...herhaald.pages[0].primitives[0], cell: { ...herhaald.pages[0].primitives[0].cell!, repeatedHeader: true } });
      expect(tabelPositiesUitIdentiteiten(herhaald, s, 1, 1, s.version()).get(100)?.loc).toEqual({ story: "body", tableIndex: 255 });
    } finally { s.destroy(); }
  });

  it("blijft bij onbekende celidentiteiten dezelfde positieroute gebruiken", async () => {
    const s = await createYrsSession({ clientId: 72 });
    try {
      s.openDocx(bestand, true);
      const payload = s.tablePayload("body", 255) as unknown as TabelPlekInfo["payload"];
      const seed = payload.rows[0].cells[0].story;
      const l = lijst(seed);
      l.pages.forEach(p => p.primitives.forEach(p => { p.cell!.cellId = "onbekende-identiteit"; }));
      const opzoeken = vi.fn((pos: number) => ({ story: payload.rows[Math.floor((pos - 100) / 20)].cells[((pos - 100) % 20) / 4].story, paraId: "p", offset: 0 }));
      const weergave = { displayPositionToYrsLoc: opzoeken } as unknown as Weergave;
      const verwacht = tabelBeelden(weergave, s, geometrie(lijst(seed, false)), [], 0, 1, s.version());
      opzoeken.mockClear();
      expect(tabelBeelden(weergave, s, geometrie(l), [], 0, 1, s.version())).toEqual(verwacht);
      expect(opzoeken).toHaveBeenCalledTimes(6);
    } finally { s.destroy(); }
  });

  it("bevestigt geen tegenstrijdige tabelidentiteiten voor hetzelfde bronpunt", async () => {
    const s = await createYrsSession({ clientId: 73 });
    try {
      s.openDocx(bestand, true);
      const a = s.tablePayload("body", 254) as unknown as TabelPlekInfo["payload"];
      const b = s.tablePayload("body", 255) as unknown as TabelPlekInfo["payload"];
      const l = lijst(a.rows[0].cells[0].story);
      l.pages[0].primitives.push(lijst(b.rows[0].cells[0].story).pages[0].primitives[0]);
      expect(tabelPositiesUitIdentiteiten(l, s, 0, 0, s.version()).get(100)).toBeNull();
    } finally { s.destroy(); }
  });

  it("gebruikt geen verdwenen begincel en geeft een Wasm-trap ongewijzigd door", () => {
    const s = { hasStory: vi.fn(() => false), tablePayload: vi.fn() } as unknown as Sessie;
    const l = lijst("body:t0:r0c0");
    expect([...tabelPositiesUitIdentiteiten(l, s, 0, 1, "bron").values()].every(x => x === null)).toBe(true);
    expect(s.tablePayload).not.toHaveBeenCalled();
    const fout = new WebAssembly.RuntimeError("getrapte proefinstantie");
    vi.mocked(s.hasStory).mockImplementation(() => { throw fout; });
    expect(() => tabelPositiesUitIdentiteiten(l, s, 0, 1, "bron")).toThrow(fout);
  });

  it("controleert rasterkolommen en ververst na een gewijzigde bron", () => {
    const seed = "body:t0:r0c0";
    let payload = { grid: [1000, 1000, 1000], rows: [{ trPr: { gridBefore: 1 }, cells: [{ story: seed, tcPr: { colspan: 2 } }] }] };
    const s = { hasStory: (id: string) => id === seed, tablePayload: () => payload } as unknown as Sessie;
    const l = lijst(seed); l.pages = [l.pages[0]]; l.pages[0].primitives = [l.pages[0].primitives[0]];
    const p = l.pages[0].primitives[0];p.cell = { ...p.cell!, col: 1, colSpan: 2, cellId: `body:table:${seed}-r0-c1` };p.table = { ...p.table!, rowCount: 1, columnCount: 3 };
    expect(tabelPositiesUitIdentiteiten(l, s, 0, 0, "eerste").get(100)?.payload).toEqual(payload);
    p.cell.colSpan = 1;
    expect(tabelPositiesUitIdentiteiten(l, s, 0, 0, "eerste").get(100)).toBeNull();
    p.cell.colSpan = 2;
    payload = { ...payload, rows: [] };
    expect(tabelPositiesUitIdentiteiten(l, s, 0, 0, "tweede").get(100)).toBeNull();
  });
});
