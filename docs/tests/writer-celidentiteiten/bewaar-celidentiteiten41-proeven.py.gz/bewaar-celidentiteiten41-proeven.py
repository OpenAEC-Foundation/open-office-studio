from pathlib import Path
import gzip,hashlib,json
from PIL import Image,ImageChops
r=Path('.local/doorwerk-2026-11-04/incrementele-invoer'); uit=Path('docs/tests/writer-celidentiteiten');uit.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((r/'celidentiteiten41-app-bronnen.json').read_text());sha=a['programma_sha256'];assert h((r/'open-office-studio-45.41-celidentiteiten').read_bytes())==sha
for n,v in a['bronbestanden'].items():assert h((r/'celidentiteiten41-bevroren-bron'/n).read_bytes())==v,n
fun=json.loads((r/'celidentiteiten41-proefuitkomsten.json').read_text());metingen=json.loads((r/'celidentiteiten41-passieve-uitkomsten.json').read_text());rpc=json.loads((r/'celidentiteiten41-rpc-uitkomst.json').read_text());assert len(fun)==10 and len(metingen)==4
p={'schema':1,'versie':'2026.45.41','applicatiebron':a,'bestanden':{},'functioneel':[],'metingen':[],'raster':{},'acceptatie':'AFGEKEURD: beide nieuwe fysieke invoerronden zijn trager dan de referentie. Tabelceloptimalisatie niet behouden; geen download, gesloten issue of acceptatievlag.','grenzen':['Alleen eigen Linux-omgeving; geen volledige suite-, FPS-, platform- of migratieacceptatie.','Bronidentiteit komt uit de bevroren 41-bronnen, niet uit latere lokale wijzigingen.']}
def bewaar(src,naam):
 b=src.read_bytes();b=gzip.compress(b,mtime=0) if naam.endswith('.gz') and not src.name.endswith('.gz') else b
 t=uit/naam;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);p['bestanden'][naam]=h(b)
for v in fun:
 assert v['code']==0;d=json.loads((r/v['naam']/'rapport.json').read_text());assert d['geslaagd'] and d['programma_sha256']==sha
 p['functioneel'].append({'naam':v['naam'],'code':v['code'],'seconden':v['seconden']})
for v in metingen:
 assert v['code']==0;d=json.loads((r/v['naam']/'profiel.json').read_text());assert d['geslaagd'];assert d['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True}
 p['metingen'].append({'naam':v['naam'],**{k:d[k] for k in ['getekende_tekst_ms','broncontrole','programma_sha256']}})
ref=Image.open(r/metingen[0]['naam']/'profiel.png').convert('RGB')
for v in metingen:
 im=Image.open(r/v['naam']/'profiel.png').convert('RGB');assert im.size==ref.size
 diff=ImageChops.difference(ref,im);cs=diff.split();mask=ImageChops.lighter(ImageChops.lighter(cs[0],cs[1]),cs[2]);doc=mask.crop((320,208,1138,978));zonder=mask.copy();zonder.paste(0,(491,347,496,366));dc=zonder.crop((320,208,1138,978))
 p['raster'][v['naam']]={'pixels':im.width*im.height-mask.histogram()[0],'bbox':mask.getbbox(),'documentpixels':doc.width*doc.height-doc.histogram()[0],'document_zonder_cursorpixels':dc.width*dc.height-dc.histogram()[0]}
assert rpc['code']==0;d=json.loads((r/rpc['naam']/'profiel.json').read_text());assert d['geslaagd'] and d['programma_sha256']==sha
p['rpc']={k:d[k] for k in ['getekende_tekst_ms','broncontrole'] if k in d};p['rpc']['batches']=len(d['rpcmeting']['aanvragen'])
for v in [*fun,*metingen,rpc]:
 for f in (r/v['naam']).rglob('*'):
  if f.is_file() and f.suffix in ['.json','.log','.png']:bewaar(f,str(f.relative_to(r))+('' if f.suffix=='.png' else '.gz'))
 bewaar(r/(v['naam']+'.log'),v['naam']+'/proef.log.gz')
for f in (r/'celidentiteiten41-bevroren-bron').rglob('*'):
 if f.is_file():bewaar(f,'bevroren-bron/'+str(f.relative_to(r/'celidentiteiten41-bevroren-bron'))+'.gz')
for n in ['celidentiteiten41-app-bronnen.json','celidentiteiten41-applicatie.patch.gz','celidentiteiten41-confirmed_source.rs.gz','celidentiteiten41-test.ts.gz','celidentiteiten41-bouw.log','celidentiteiten41-proefuitkomsten.json','celidentiteiten41-passieve-uitkomsten.json','celidentiteiten41-rpc-uitkomst.json','voer-celidentiteiten41-proeven.py','voer-celidentiteiten41-passieve-metingen.py','meet-passief-doortypen-native.py','meet-rpc-native.py','bewaar-celidentiteiten41-proeven.py']:bewaar(r/n,n+('' if n.endswith('.gz') else '.gz'))
Path('docs/tests/2026-11-04-writer-celidentiteiten.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'bestanden':len(p['bestanden']),'metingen':p['metingen'],'raster':p['raster']},ensure_ascii=False))
