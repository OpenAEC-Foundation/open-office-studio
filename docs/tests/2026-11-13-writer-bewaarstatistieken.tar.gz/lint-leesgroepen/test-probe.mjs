import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const bron=fs.readFileSync(new URL('probe.js',import.meta.url),'utf8');let proeven=0;
function maak(groepsantwoord){let klok=0,rafId=0,cancel,off=0,observer,aanroepen=0;const events=new Map(),ontvangen=[],antwoord={},promise=Promise.resolve(antwoord),fout=new Error('eigen fout');
 const proto={readParagraphs(...args){aanroepen++;ontvangen.push([this,args]);if(args[0]==='fout')throw fout;return antwoord}};
 const doel=Object.assign(Object.create(proto),{applyLocalUpdate(){aanroepen++;return antwoord},setSelection(){aanroepen++},tablePayload(){aanroepen++;return antwoord},readStories(){aanroepen++;return groepsantwoord??promise},onUpdate(fn){observer=fn;return()=>{off++}}});
 const publiek={readParagraphs(...args){ontvangen.push([this,args]);if(args[0]==='fout')throw fout;return promise}};const publiekOrigineel=Object.getOwnPropertyDescriptors(publiek);const oude=Object.getOwnPropertyDescriptors(doel);const w={addEventListener(n,fn){events.set(n,fn)},removeEventListener(n,fn){assert.equal(events.get(n),fn);events.delete(n)}};
 const c=vm.createContext({window:w,sessie:()=>doel,api:()=>publiek,performance:{now:()=>++klok},requestAnimationFrame:fn=>{c.frame=fn;return ++rafId},cancelAnimationFrame:id=>{cancel=id},Reflect,Error});vm.runInContext(bron,c);
 return {doel,publiek,publiekOrigineel,w,oude,antwoord,promise,fout,events,ontvangen,observer:()=>observer(),get off(){return off},get calls(){return aanroepen},frame:()=>c.frame(),get cancel(){return cancel}};
}
{
 const m=maak(),args=['tekst',{eigen:true}];assert.equal(m.doel.readParagraphs(...args),m.antwoord);assert.equal(m.ontvangen[0][0],m.doel);assert.equal(m.ontvangen[0][1][1],args[1]);proeven++;
 assert.equal(m.doel.readStories(),m.promise);proeven++;
 assert.throws(()=>m.doel.readParagraphs('fout'),e=>e===m.fout);proeven++;
 const n=m.calls;m.observer();assert.equal(m.calls,n);proeven++;
 m.events.get('keyup')({type:'keyup',key:'A',timeStamp:12});m.frame();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(m.off,1);assert.equal(m.events.size,0);assert.equal(m.doel.readParagraphs,Object.getPrototypeOf(m.doel).readParagraphs);assert.equal(Object.hasOwn(m.doel,'readParagraphs'),false);for(const [k,d]of Object.entries(m.oude))assert.deepEqual(Object.getOwnPropertyDescriptor(m.doel,k),d);proeven++;
 assert(r.regels.some(x=>x.soort==='onUpdate'));assert(r.regels.some(x=>x.soort==='keyup'));assert(r.regels.some(x=>x.soort==='rAF'));proeven++;
}
{const m=maak(),eigen=()=>7;m.doel.tablePayload=eigen;const r=m.w._publicatieProbe.stop();assert.equal(r.hersteld,false);assert.equal(m.doel.tablePayload,eigen);proeven++;}
{const m=maak();for(let i=0;i<8300;i++)assert.equal(m.doel.applyLocalUpdate(),m.antwoord);const r=m.w._publicatieProbe.stop();assert.equal(r.regels.length,8192);assert.equal(r.overgeslagen,108);assert(r.hersteld);proeven++;}
{ const m=maak(),oud=m.publiek.readParagraphs; assert.equal(m.publiek.readParagraphs('eigen'),m.promise);assert.equal(m.ontvangen[0][0],m.publiek);assert.throws(()=>m.publiek.readParagraphs('fout'),e=>e===m.fout);for(let i=0;i<20;i++)m.publiek.readParagraphs();const r=m.w._publicatieProbe.stop();assert(r.hersteld);assert.equal(r.aanroepers.filter(x=>x.label==='openbaar.readParagraphs').length,4);assert.notEqual(m.publiek.readParagraphs,oud);assert.deepEqual(Object.getOwnPropertyDescriptors(m.publiek),m.publiekOrigineel);proeven++; }

{const m=maak(),vreemd=()=>m.antwoord;m.publiek.readParagraphs=vreemd;const r=m.w._publicatieProbe.stop();assert.equal(r.hersteld,false);assert.equal(m.publiek.readParagraphs,vreemd);proeven++;}


{const antwoord={ok:true,truncated:false,stories:[{story:'body'}]},m=maak(antwoord),req={stories:['body']};for(let i=0;i<70;i++)assert.equal(m.doel.readStories(req),antwoord);const r=m.w._publicatieProbe.stop();assert.equal(r.leesgroepen.length,64);assert.equal(r.leesgroepen[0].gevraagd,1);assert.equal(r.leesgroepen[0].ontvangen,1);assert.equal(r.leesgroepen[0].truncated,false);proeven++;}
{let getters=0;const req={get stories(){getters++;return ['body']}},m=maak({ok:true,truncated:true,stories:[]});m.doel.readStories(req);assert.equal(getters,0);const r=m.w._publicatieProbe.stop();assert.equal(r.leesgroepen[0].gevraagd,null);assert.equal(r.leesgroepen[0].truncated,true);proeven++;}
console.log(`${proeven} transparantie-/opruim-/grenscontroles geslaagd`);
