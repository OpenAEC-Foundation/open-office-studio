(() => {
  'use strict';
  if (window._publicatieProbe) throw Error('Publicatieprobe bestaat al');
  const doel = sessie(), regels = [], oud = new Map(), wrappers = new Map();
  let actief = true, overgeslagen = 0, raf;
  const aanroepers = [], aantallen = new Map(), leesgroepen = [];
  const waarde = (o,k) => o && Object.getOwnPropertyDescriptor(o,k)?.value;
  function groep(args,r) {
    if (leesgroepen.length >= 64) return;
    try { const ids=waarde(args[0],'stories'), stories=waarde(r,'stories'); leesgroepen.push({begin:performance.now(),gevraagd:Array.isArray(ids)?ids.length:null,ok:waarde(r,'ok')??null,truncated:waarde(r,'truncated')??null,ontvangen:Array.isArray(stories)?stories.length:null}); } catch { /* Geen invloed op de echte leesroute. */ }
  }
  function herkomst(label) {
    if ((aantallen.get(label) ?? 0) >= 4) return;
    aantallen.set(label, (aantallen.get(label) ?? 0) + 1);
    try { aanroepers.push({label, begin: performance.now(), stack: String(new Error().stack ?? '').slice(0, 4096)}); } catch { /* Diagnostiek mag de echte aanroep nooit afbreken. */ }
  }
  const openbaar = api(), openbaarOud = Object.getOwnPropertyDescriptor(openbaar, 'readParagraphs'), openbaarFn = openbaar.readParagraphs;
  if (typeof openbaarFn !== 'function' || (openbaarOud && !openbaarOud.configurable)) throw Error('Openbare lezer niet veilig te volgen');
  const openbaarWrapper = function(...args) { herkomst('openbaar.readParagraphs'); return Reflect.apply(openbaarFn, this, args); };
  function voeg(soort, begin, einde = begin, extra = {}) {
    if (!actief) return;
    if (regels.length < 8192) regels.push({soort, begin, einde, ...extra});
    else overgeslagen++;
  }
  const namen = ['applyLocalUpdate', 'setSelection', 'readParagraphs', 'tablePayload',
    ...(typeof doel.readStories === 'function' ? ['readStories'] : [])];
  const nieuweRefs = [];
  function volgNieuweRef() {
    const ref=api();
    if(!ref || ref===openbaar || nieuweRefs.some(x=>x.ref===ref) || nieuweRefs.length>=128) return;
    const descriptor=Object.getOwnPropertyDescriptor(ref,'readParagraphs'),fn=ref.readParagraphs;
    if(typeof fn!=='function'||descriptor&&!descriptor.configurable)return;
    const wrapper=function(...args){herkomst('actueel.readParagraphs');return Reflect.apply(fn,this,args)};
    Object.defineProperty(ref,'readParagraphs',{value:wrapper,configurable:true,writable:true,enumerable:descriptor?.enumerable??false});
    nieuweRefs.push({ref,descriptor,fn,wrapper});
  }
  for (const naam of namen) {
    const descriptor = Object.getOwnPropertyDescriptor(doel, naam), fn = doel[naam];
    if (typeof fn !== 'function' || (descriptor && !descriptor.configurable)) throw Error('Niet veilig te volgen: '+naam);
    oud.set(naam, {descriptor, fn});
  }
  for (const naam of namen) {
    const wrapper = function(...args) {
      const begin = performance.now();
      if (naam === 'readParagraphs') herkomst('sessie.readParagraphs');
      try { const r=Reflect.apply(oud.get(naam).fn, this, args); if(naam==='readStories')groep(args,r); return r; }
      finally { voeg(naam, begin, performance.now()); }
    };
    wrappers.set(naam, wrapper);
    Object.defineProperty(doel, naam, {value: wrapper, configurable: true, writable: true,
      enumerable: oud.get(naam).descriptor?.enumerable ?? false});
  }
  Object.defineProperty(openbaar, 'readParagraphs', {value: openbaarWrapper, configurable: true, writable: true, enumerable: openbaarOud?.enumerable ?? false});
  // Alleen een klok en herkomst, geen versie-, selectie- of documentlezing.
  const afmelden = doel.onUpdate((_, herkomst) => voeg('onUpdate', performance.now(), undefined,
    {herkomst: typeof herkomst === 'string' ? herkomst : null}));
  const toets = e => voeg(e.type, performance.now(), undefined, {key: e.key.toLowerCase(), eventTijd: e.timeStamp});
  window.addEventListener('keydown', toets, true);
  window.addEventListener('keyup', toets, true);
  const frame = () => { if (!actief) return; volgNieuweRef(); voeg('rAF', performance.now()); raf = requestAnimationFrame(frame); };
  raf = requestAnimationFrame(frame);
  window._publicatieProbe = {stop() {
    actief = false; cancelAnimationFrame(raf); afmelden();
    window.removeEventListener('keydown', toets, true); window.removeEventListener('keyup', toets, true);
    let hersteld = true; const oorspronkelijke_ref_nog_actueel=api()===openbaar;
    for(const x of nieuweRefs){if(x.ref.readParagraphs!==x.wrapper){hersteld=false;continue}if(x.descriptor)Object.defineProperty(x.ref,'readParagraphs',x.descriptor);else delete x.ref.readParagraphs;}
    if (openbaar.readParagraphs !== openbaarWrapper) hersteld = false;
    else if (openbaarOud) Object.defineProperty(openbaar, 'readParagraphs', openbaarOud);
    else delete openbaar.readParagraphs;
    for (const naam of namen) {
      if (doel[naam] !== wrappers.get(naam)) { hersteld = false; continue; }
      const d = oud.get(naam).descriptor;
      if (d) Object.defineProperty(doel, naam, d); else delete doel[naam];
    }
    return {regels, oorspronkelijke_ref_nog_actueel, aantal_nieuwe_refs:nieuweRefs.length, refgrens:128, leesgroepen, leesgroepgrens:64, aanroepers, aanroepergrens_per_label: 4, overgeslagen, grens: 8192, hersteld, geen_extra_enginelezingen: true};
  }};
  return {namen, grens: 8192, observer: 'uitsluitend klokken, geen aanvullende enginequery'};
})()
