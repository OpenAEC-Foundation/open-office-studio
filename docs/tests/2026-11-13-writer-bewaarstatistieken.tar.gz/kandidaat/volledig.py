from pathlib import Path
import subprocess,os,json
r=Path.cwd();u=r/'.local/integratiecontrole/bewaar-groepen';env=os.environ.copy();env['PATH']='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback:'+env['PATH'];env['WRITER_JOURNAAL_HOST']=str(r/'.local/integratiecontrole/journaal-frontend/writer-journaal-draad');uit={}
for naam,cmd in [('frontend',['pnpm','exec','vitest','run']),('typescript',['pnpm','exec','tsc','--noEmit']),('vite',['pnpm','exec','vite','build','--outDir',str(u/'dist')])]:
 print('START',naam,flush=True)
 with (u/(naam+'.log')).open('x') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 uit[naam]=p.returncode;(u/'controles.json').write_text(json.dumps(uit)+'\n');assert p.returncode==0,(naam,p.returncode)
 print('GROEN',naam,flush=True)
print('START native_bouw',flush=True);p=subprocess.run(['python3',str(u/'bouwen.py')],env=env);assert p.returncode==0
print('START native_ABBA',flush=True);p=subprocess.run(['python3',str(u/'native-rondes.py')],env=env);assert p.returncode==0
