/** Bewaarstatistieken uit echte bron, zonder losse lezingen per tabelcel. */
import { strToU8, unzipSync, zipSync } from "fflate";
import { createYrsSession } from "@betteroffice/docx/yrs";
import type { DocxEditorRef, DocxPluginContext } from "@betteroffice/docx-react";
import { afterAll, beforeAll, expect, it, vi } from "vitest";
vi.mock("@betteroffice/docx-react", () => ({ defineDocxPlugin: (definitie: unknown) => definitie }));
import { telTekst } from "../../lint/tekst-logica";
import { leesEigenschappen, schrijfEigenschappen } from "./docprops";
import { werkEigenschappenBij } from "./opslaan";
import { maakStatusLeesPlugin } from "./statusLeesPlugin";

let bron: Awaited<ReturnType<typeof createYrsSession>>;
const cellen = Array.from({ length: 65 }, (_, i) => `<w:tbl><w:tblPr/><w:tblGrid><w:gridCol w:w="2400"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Cel ${i}: ideeën blijven behouden.</w:t></w:r></w:p></w:tc></w:tr></w:tbl>`).join("");
const bytes = zipSync({
  "[Content_Types].xml": strToU8(`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`),
  "_rels/.rels": strToU8(`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="r1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`),
  "word/document.xml": strToU8(`<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Eigen hoofdtekst met woorden.</w:t></w:r></w:p>${cellen}<w:sectPr/></w:body></w:document>`),
});
beforeAll(async () => { bron = await createYrsSession({ clientId: 998 }); bron.openDocx(bytes, true); });
afterAll(() => bron?.destroy());

function proef(ongeldig = false) {
  let invoer = false;
  const leven = new AbortController(), opruimers: (() => void)[] = [];
  const losLezen = vi.fn(() => { throw Error("Geen losse bewaarlezingen"); });
  const ref = { getEditorRef: () => ({ getYrsSession: () => bron, hasPendingInput: () => invoer }),
    readParagraphs: losLezen, getTotalPages: () => 7 } as unknown as DocxEditorRef;
  const lees = vi.fn(async (r: Parameters<typeof bron.readStories>[0]) => {
    const antwoord = bron.readStories(r);
    if (ongeldig) invoer = true;
    return antwoord;
  });
  const vers = { snapshot: { generation: "bewaarproef" }, lifetimeSignal: leven.signal, read: { readStories: lees } };
  const ctx = { ...vers, onCleanup: (fn: () => void) => opruimers.push(fn),
    run: async (fn: (v: typeof vers) => Promise<void>) => fn(vers) } as unknown as DocxPluginContext<Record<string, never>>;
  const plugin = maakStatusLeesPlugin(() => ref) as unknown as { initialize(c: typeof ctx): void };
  plugin.initialize(ctx);
  return { ref, lees, losLezen, stop: () => { leven.abort(); opruimers.forEach(fn => fn()); } };
}

it("bewaart exacte tellingen voor hoofdtekst en alle cellen met de bestaande groepslezer", async () => {
  const p = proef(), vector = bron.encodeStateVector(), versie = bron.version();
  try {
    const ids = bron.storyIds().filter(id => id === "body" || /^body:t\d+:r\d+c\d+/.test(id));
    const teksten = ids.flatMap(story => {
      const r = bron.readParagraphs({ story, view: "accepted" });
      if (!r.ok) throw Error("Oraclebron niet leesbaar");
      return r.paragraphs.map(a => a.text);
    });
    const telling = telTekst(teksten);
    const uit = await werkEigenschappenBij({}, p.ref, bytes, true);
    expect(leesEigenschappen(uit)).toMatchObject({ woorden: telling.woorden, tekens: telling.tekensZonderSpaties,
      tekensMetSpaties: telling.tekens, alineas: telling.alineas, paginas: 7 });
    expect(ids).toHaveLength(66);
    expect(p.lees).toHaveBeenCalledTimes(Math.ceil(ids.length / 32));
    expect(p.losLezen).not.toHaveBeenCalled();
    expect(unzipSync(uit)["word/document.xml"]).toEqual(unzipSync(bytes)["word/document.xml"]);
    expect(bron.version()).toBe(versie); expect(bron.encodeStateVector()).toEqual(vector);
  } finally { p.stop(); }
});

it("laat bestaande cijfers staan als nieuwe invoer de lezing ongeldig maakt", async () => {
  const p = proef(true), invoer = schrijfEigenschappen(bytes, { woorden: 17, tekens: 41, tekensMetSpaties: 53, alineas: 3 });
  try {
    const uit = await werkEigenschappenBij({}, p.ref, invoer, true);
    expect(leesEigenschappen(uit)).toMatchObject({ woorden: 17, tekens: 41, tekensMetSpaties: 53, alineas: 3 });
    expect(p.lees).toHaveBeenCalledOnce(); expect(p.losLezen).not.toHaveBeenCalled();
    expect(unzipSync(uit)["word/document.xml"]).toEqual(unzipSync(invoer)["word/document.xml"]);
  } finally { p.stop(); }
});
