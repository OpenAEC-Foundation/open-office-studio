/**
 * Gedeelde toegang tot de lagere engine-API van @betteroffice/docx-react 0.5.1
 * (`getEditorRef()` → `PagedEditorRef`, `getYrsSession()`). Die API is
 * experimenteel; alles wat de Word-functies (#28, #29, #48, #49, #57) daarmee
 * doen loopt via deze hulpjes, zodat een engine-update op één plek te volgen is.
 *
 * Werkwijze bij een directe Yrs-bewerking:
 *  1. `begin(ref)` sluit de lopende ongedaan-maakstap af, zodat de bewerking
 *     niet samenvalt met eerder typen;
 *  2. de bewerking op de sessie (één of meer aanroepen in dezelfde taak worden
 *     door de engine als één ongedaan-maakstap vastgelegd);
 *  3. `klaar(...)` publiceert de wijziging naar de weergave (herindeling,
 *     selectie, onChange) en sluit de stap af.
 */
import type { DocxEditorRef } from "@betteroffice/docx-react";
import i18next from "../../i18n/config";

/** Sessie en weergave van de editor; gooit een begrijpelijke fout zonder document. */
export function engine(ref: DocxEditorRef | null) {
  const weergave = ref?.getEditorRef() ?? null;
  const sessie = weergave?.getYrsSession() ?? null;
  if (!ref || !weergave || !sessie) throw new Error(i18next.t("writer:general.documentNotReady"));
  return { ref, weergave, sessie };
}
export type Engine = ReturnType<typeof engine>;
export type Sessie = Engine["sessie"];

const vorigeModus = new WeakMap<object, string>();

/**
 * Begint één ongedaan-maakstap. In de modus `auto` maakt de engine per
 * verhaal (elke tabelcel is een verhaal) een eigen stap; tijdens onze
 * bewerking zetten we de modus op `manual`, zodat alles één stap wordt.
 */
export function begin(e: Engine) {
  try {
    // Sommige sessiebewerkingen (ruwe ops, acceptChange) starten de opname
    // niet zelf; zonder dit is zo'n eerste stap na het openen niet terug te draaien.
    e.sessie.beginUndoCapture();
    e.sessie.addUndoBoundary();
    vorigeModus.set(e.sessie, e.sessie.undoCaptureMode());
    e.sessie.setUndoCaptureMode("manual");
  } catch {
    // Oudere sessies kennen dit niet; dan valt de stap hooguit uiteen.
  }
}

/** Publiceert een directe sessiebewerking en sluit de ongedaan-maakstap af. */
export function klaar(e: Engine, verhalen: readonly string[] = ["body"], herindelen = true) {
  try {
    e.weergave.syncYrsInputState(true, [...new Set(verhalen)]);
    // Embed-attributen veranderen niet altijd de verhaaltekst: ook herindelen.
    if (herindelen) e.weergave.relayout();
  } finally {
    // Een fout in de weergave mag de volgende bewerking niet in een open
    // handmatige ongedaan-maakstap achterlaten.
    sluitStap(e);
  }
}

/** Sluit de ongedaan-maakstap af en zet de opnamemodus terug. */
export function sluitStap(e: Engine) {
  try {
    e.sessie.addUndoBoundary();
    const modus = vorigeModus.get(e.sessie);
    if (modus === "auto" || modus === "manual") e.sessie.setUndoCaptureMode(modus);
    vorigeModus.delete(e.sessie);
  } catch {
    // Zie begin().
  }
}

/** Voert een directe sessiebewerking uit als één ongedaan-maakstap. */
export function bewerk<T>(ref: DocxEditorRef | null, doe: (e: Engine) => { resultaat: T; verhalen: readonly string[] }) {
  const e = engine(ref);
  begin(e);
  let uit: { resultaat: T; verhalen: readonly string[] };
  try {
    uit = doe(e);
  } catch (fout) {
    sluitStap(e);
    throw fout;
  }
  const { resultaat, verhalen } = uit;
  klaar(e, verhalen);
  return resultaat;
}

/** De ingestelde auteursnaam (dezelfde sleutel als het opmerkingenvenster), of "". */
export function eigenAuteur() {
  try {
    return localStorage.getItem("open-tekst-auteur")?.trim() ?? "";
  } catch {
    return "";
  }
}

/**
 * Auteur voor bijgehouden wijzigingen. Zonder ingestelde naam een
 * standaardnaam in de interfacetaal van dat moment (zoals Word).
 */
export function auteur() {
  return eigenAuteur() || i18next.t("writer:general.unknownAuthor");
}

/** Het bijhouden-voorstel voor sessiebewerkingen in de modus Voorstellen. */
export function voorstel(ref: DocxEditorRef) {
  const modus = ref.commands.getState("editingMode").value;
  return modus === "suggesting" ? { name: auteur(), date: new Date().toISOString() } : undefined;
}

/**
 * Ruwe bewerkingen (`applyRawOps`) starten de ongedaan-maakopname niet zelf,
 * zoals de gewone sessiebewerkingen wel doen. Zonder deze aanroep is een ruwe
 * bewerking als eerste stap na het openen niet ongedaan te maken. De opname
 * starten is idempotent en kiest het verhaal voor de geschiedenis.
 */
export function vangOngedaanMaken(sessie: Sessie, verhaal: string) {
  (sessie.beginUndoCapture as (verhaal?: string) => void)(verhaal);
}

/** Ruwe bewerkingen op een verhaal, met ongedaan-maakopname. */
export function ruw(sessie: Sessie, verhaal: string, bewerkingen: readonly unknown[]) {
  vangOngedaanMaken(sessie, verhaal);
  sessie.applyRawOps(verhaal, bewerkingen as Parameters<Sessie["applyRawOps"]>[1]);
}

export const fout =(error: unknown) => (error instanceof Error ? error.message : String(error));

/**
 * Alle alinea's voor het tellen en voor de documenteigenschappen: de hoofdtekst
 * én de cellen van elke tabel daarin, want elke tabelcel is een eigen verhaal
 * (`body:t0:r0c0`). Lees je alleen de hoofdtekst, dan telt een document dat
 * alleen uit een tabel bestaat nul woorden terwijl de cellen wel tekst bevatten
 * (bevestigde afwijking in docs/tests/2026-10-30-vrijgavecontrole.md).
 *
 * Kop- en voetteksten en noten tellen niet mee, net als bij de spellingcontrole.
 * Gooit een fout als er niets te lezen is; slagen slechts enkele verhalen, dan
 * tellen die.
 */
export async function leesAlleAlineas(ref: DocxEditorRef) {
  const { sessie } = engine(ref);
  let verhalen: string[];
  try {
    const ids = sessie.storyIds?.() ?? ["body"];
    verhalen = ids.filter((id) => id === "body" || /^body:t\d+:r\d+c\d+/.test(id));
    if (!verhalen.includes("body")) verhalen = ["body", ...verhalen];
  } catch {
    verhalen = ["body"];
  }
  const gelezen = await Promise.all(
    verhalen.map(async (story) => {
      const r = await ref.readParagraphs({ view: "accepted", story });
      return r.ok ? r.paragraphs : null;
    }),
  );
  const gelukt = gelezen.filter((a): a is NonNullable<typeof a> => a !== null);
  if (!gelukt.length) throw new Error(i18next.t("ribbon:writer.errors.documentUnreadable"));
  return gelukt.flat();
}
