from pathlib import Path
import json,hashlib,urllib.request,tarfile,subprocess
p=Path(__file__).resolve().parent
items=[('bindgen','https://github.com/wasm-bindgen/wasm-bindgen/releases/download/0.2.129/wasm-bindgen-0.2.129-x86_64-unknown-linux-musl.tar.gz','82d12bb940e2d4e72e0d5605387fc1b8ca179044e012b620f0ce4e7440e8320e',11695824),('binaryen','https://github.com/WebAssembly/binaryen/releases/download/version_132/binaryen-version_132-x86_64-linux.tar.gz','195ddc94f9bc89f45abdabb0b9eea86023d727ba90eac8b35b80f2544fc30572',117057408)]
r=[]
for naam,url,h,grootte in items:
 archief=p/(naam+'.tar.gz');doel=p/'gereedschap'/naam
 if not archief.exists():
  with urllib.request.urlopen(url,timeout=60) as bron,archief.open('xb') as uit:
   n=0
   while blok:=bron.read(1024*1024):
    n+=len(blok);assert n<=grootte;uit.write(blok)
 assert archief.stat().st_size==grootte and hashlib.sha256(archief.read_bytes()).hexdigest()==h
 if not doel.exists():
  doel.mkdir(parents=True)
  with tarfile.open(archief) as t:
   for m in t:
    delen=Path(m.name).parts
    assert not Path(m.name).is_absolute() and '..' not in delen
    if not m.isfile():continue
    q=doel.joinpath(*delen[1:]);q.parent.mkdir(parents=True,exist_ok=True)
    with t.extractfile(m) as bron,q.open('xb') as uit:
     while blok:=bron.read(1024*1024):uit.write(blok)
    q.chmod(m.mode&0o777)
 r.append({'naam':naam,'url':url,'sha256':h,'bytes':grootte})
bindgen=next((p/'gereedschap/bindgen').rglob('wasm-bindgen'));opt=next((p/'gereedschap/binaryen').rglob('wasm-opt'))
for q,versie in [(bindgen,'wasm-bindgen 0.2.129'),(opt,'wasm-opt version 132')]:
 tekst=subprocess.check_output([str(q),'--version'],text=True).strip();assert tekst.startswith(versie);r.append({'uitvoerbaar':str(q),'versie':tekst,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
(p/'gereedschap.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
