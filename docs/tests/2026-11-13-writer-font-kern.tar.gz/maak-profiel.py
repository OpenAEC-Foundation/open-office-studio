from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
assert json.load(open(p/'bouw-basis.json'))['code']==0
kern=p/'bron/crates/docx-edit/src/engine.rs';wasm=p/'bron/crates/docx-edit/src/wasm.rs';s=kern.read_text();w=wasm.read_text()
(p/'engine-voor.rs').write_text(s);(p/'wasm-voor.rs').write_text(w)
a=s.index('    fn layout_font_requirements(\n');b=s.index('\n        Ok(json)\n    }',a)+len('\n        Ok(json)\n    }');f=s[a:b]
sig='''    fn layout_font_requirements(
        &self,
        input_json: &str,
        use_preview_superset: bool,
    ) -> Result<String, String> {'''
assert f.startswith(sig)
nieuw=sig+'''
        self.layout_font_requirements_traced(input_json, use_preview_superset, &mut |_| {})
    }

    pub fn layout_font_requirements_profiled(&self, input_json: &str, note: &mut dyn FnMut(&'static str)) -> Result<String, String> {
        self.layout_font_requirements_traced(input_json, true, note)
    }

    fn layout_font_requirements_traced(&self, input_json: &str, use_preview_superset: bool, note: &mut dyn FnMut(&'static str)) -> Result<String, String> {'''
f=f.replace(sig,nieuw,1)
for oud,na in [
 ('        let request: RegionLayoutInput =','        note("begin");\n        let request: RegionLayoutInput ='),
 ('let (input, regions, notes, measurement, render_env, body_story) = request.split();','let (input, regions, notes, measurement, render_env, body_story) = request.split();\n        note("parse");'),
 ('        let mut collector =','        note("collector_begin");\n        let mut collector ='),
 ('        if let Some(body_story) = body_story {','        note("measured_gereed");\n        if let Some(body_story) = body_story {'),
 ('            for story in stories {','            for story in stories {\n                note("story_begin");'),
 ('                self.with_resident_story(&story, &render_env, |blocks| {','                self.with_resident_story(&story, &render_env, |blocks| {\n                    note("story_gereed");'),
 ('                })\n                .map_err','                    note("collect_gereed");\n                })\n                .map_err'),
 ('        let requirements = collector.finish();','        let requirements = collector.finish();\n        note("finish");'),
 ('        Ok(json)','        note("json");\n        Ok(json)'),
]:
 assert f.count(oud)==1,oud;f=f.replace(oud,na,1)
f=f.replace('self.layout_font_requirements(input_json, false)','self.layout_font_requirements_traced(input_json, false, note)')
s=s[:a]+f+s[b:]
oud='''        self.engine
            .layout_font_requirements_json(input)
            .map_err(|error| JsValue::from_str(&error))'''
na='''        let mut marks = Vec::new();
        let result = self.engine.layout_font_requirements_profiled(input, &mut |name| marks.push((name, performance_now())));
        *self.last_apply_profile_json.borrow_mut() = serde_json::to_string(&marks).map_err(js_err)?;
        result.map_err(|error| JsValue::from_str(&error))'''
assert w.count(oud)==1;w=w.replace(oud,na,1)
kern.write_text(s);wasm.write_text(w)
(p/'profiel-bronpinnen.json').write_text(json.dumps({'engine_voor':hashlib.sha256((p/'engine-voor.rs').read_bytes()).hexdigest(),'engine_na':hashlib.sha256(kern.read_bytes()).hexdigest(),'wasm_voor':hashlib.sha256((p/'wasm-voor.rs').read_bytes()).hexdigest(),'wasm_na':hashlib.sha256(wasm.read_bytes()).hexdigest()},indent=2)+'\n')
