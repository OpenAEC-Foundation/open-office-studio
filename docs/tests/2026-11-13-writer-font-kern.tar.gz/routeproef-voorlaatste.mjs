import fs from 'node:fs';import path from 'node:path';import{pathToFileURL}from'node:url';import assert from'node:assert/strict';import{performance}from'node:perf_hooks';import crypto from'node:crypto';
const dir=path.resolve('.local/integratiecontrole/font-hergebruik'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const wasm=fs.readFileSync('vendor/tekstengine/docx_edit_bg.wasm');assert.equal(hash(wasm),'737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9');const{preloadEditWasm,createEditSession}=await import(pathToFileURL(path.resolve('node_modules/@betteroffice/docx/dist/wasm-edit.mjs')).href);await preloadEditWasm(wasm);
const bytes=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'),a=createEditSession(901),b=createEditSession(902);let r={geslaagd:false,wasm_sha256:hash(wasm),bron_sha256:hash(bytes),metingen:[]};
try{
 a.open_docx(bytes,true);b.open_docx(bytes,false);b.load(a.encode_state());a.set_local_lowering(true);b.set_local_lowering(true);
 const req=JSON.stringify({bodyStory:'body',renderEnv:{}}),body=()=>JSON.parse(a.read_paragraphs_json(JSON.stringify({story:'body',view:'accepted'})));
 const init=body();assert(init.ok&&init.paragraphs.length>0);const p=init.paragraphs.at(-2);let offset=p.text.length;assert.equal(typeof p.paraId,'string');
 a.layout_document_with_regions_retained(req);b.layout_document_with_regions_retained(req);const initA=a.layout_font_requirements_json(req),initB=b.layout_font_requirements_json(req);assert.equal(initA,initB);
 for(const [i,tekst]of [' Een proef',' met woorden',' en spaties.',' Ω',' العربية',' 漢字',' 🙂',' extra'].entries()){
  const vector=b.encode_state_vector(),voor=performance.now();a.edit_text_resident('body',p.paraId,offset,p.paraId,offset,tekst);const lokaalBewerken=performance.now()-voor;
  const update=a.encode_diff(vector),v=performance.now();b.apply_update(update);const updateMs=performance.now()-v;
  const t=performance.now(),fontsA=a.layout_font_requirements_json(req),lokaalMs=performance.now()-t;
  const u=performance.now(),fontsB=b.layout_font_requirements_json(req),replicaMs=performance.now()-u;
  assert.equal(fontsA,fontsB,`fontresultaat ${i}`);const pa=JSON.parse(a.read_paragraphs_json(JSON.stringify({story:'body',view:'accepted'}))),pb=JSON.parse(b.read_paragraphs_json(JSON.stringify({story:'body',view:'accepted'})));assert.deepEqual(pa.paragraphs,pb.paragraphs,`alinearesultaat ${i}`);assert.deepEqual(a.encode_state_vector(),b.encode_state_vector(),`bronvector ${i}`);
  r.metingen.push({stap:i,tekst,lokaal_bewerken_ms:lokaalBewerken,replica_update_ms:updateMs,lokaal_font_ms:lokaalMs,replica_font_ms:replicaMs,update_bytes:update.length,font_sha256:hash(fontsA),font_bytes:Buffer.byteLength(fontsA),fontresultaat_exact:true,alinearesultaat_exact:true,bronvector_exact:true});offset+=tekst.length;
 }
 r.herhaalde_lezingen=[];for(let i=0;i<5;i++){const t=performance.now();const x=a.layout_font_requirements_json(req);r.herhaalde_lezingen.push({ms:performance.now()-t,font_sha256:hash(x)})}r.geslaagd=true;
}catch(e){r.fout=String(e);throw e}finally{a.free();b.free();fs.writeFileSync(path.join(dir,'routeproef-voorlaatste.json'),JSON.stringify(r,null,2)+'\n')}
console.log(JSON.stringify(r));
