from pathlib import Path
import json,collections
r=Path('.local/doorwerk-2026-11-04/incrementele-invoer');d=json.loads((r/'invoerfasen49-profiel/profiel.json').read_text());m=d['invoerfasen']['monsters'];assert d['geslaagd'] and m and not any(d['fouten_na'].values());assert all(x['uitkomst']=='rust'for x in m)
stappen=collections.defaultdict(list)
for x in m:
 for n,v in x['stappen'].items():stappen[n].append(v)
uit={'geslaagd':True,'getekende_tekst_ms':d['getekende_tekst_ms'],'monsters':len(m),'sessies_en_levensduren':sorted(set((x['sessie'],x['levensduur'])for x in m)),'totaal_eigen_koppeling_ms':sum(x['duurMs']for x in m),'rust_binnen_ms':sum(x['rustBinnenMs']for x in m),'stappen':{n:{'aantal':len(v),'ms':sum(v),'max_ms':max(v)}for n,v in stappen.items()},'overgeslagen':d['invoerfasen']['overgeslagen'],'broncontrole':d['broncontrole'],'grenzen':d['invoerfasen']['grensomschrijving']}
assert len(uit['sessies_en_levensduren'])==1 and uit['overgeslagen']==0
(r/'invoerfasen49-samenvatting.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print(json.dumps(uit,ensure_ascii=False,indent=2))
