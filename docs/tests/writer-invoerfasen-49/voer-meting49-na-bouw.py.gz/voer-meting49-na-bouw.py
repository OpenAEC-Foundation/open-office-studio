from pathlib import Path
import subprocess,json,time,os
r=Path('.local/doorwerk-2026-11-04/incrementele-invoer');uit=[]
for n in ['voer-meting49-passieve-metingen.py','voer-invoerfasen49.py','voer-meting49-proeven.py']:
 print('START',n,flush=True);begin=time.monotonic()
 with (r/(n+'.log')).open('w')as log:p=subprocess.run(['python3',str(r/n)],stdout=log,stderr=subprocess.STDOUT)
 uit.append({'script':n,'code':p.returncode,'seconden':time.monotonic()-begin});(r/'meting49-na-bouw-uitkomsten.json').write_text(json.dumps(uit,indent=2)+'\n');print('EINDE',n,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
