from pathlib import Path
import os,subprocess,json,hashlib,shutil,time
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';m=json.loads((r/'meting49-bronnen.json').read_text());resultaten=[]
env=os.environ.copy();env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/home/aia01/.cargo/bin:'+env['PATH'];python=repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'
def controleer():
 for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
def voer(fase,cmd,werkmap=repo):
 print('START',fase,flush=True);begin=time.monotonic()
 with (r/(fase+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=werkmap,env=env,stdout=log,stderr=subprocess.STDOUT)
  (r/'meting49-levende-fase.json').write_text(json.dumps({'fase':fase,'pid':p.pid,'opdracht':cmd},indent=2)+'\n');code=p.wait()
 resultaten.append({'fase':fase,'code':code,'seconden':time.monotonic()-begin,'opdracht':cmd});(r/'meting49-uitkomsten.json').write_text(json.dumps(resultaten,indent=2)+'\n');print('EINDE',fase,code,flush=True)
 if code:raise SystemExit(code)
controleer()
for fase,cmd in [('meting49-frontend',['node_modules/.bin/vitest','run']),('meting49-typescript',['node_modules/.bin/tsc','--noEmit']),('meting49-python',['python3','-m','unittest','discover','-s','tests','-v']),('meting49-engines',['node','scripts/test-kantoor-engines.mjs']),('meting49-opdrachten',['node','scripts/test-opdrachten.mjs']),('meting49-week',['node','scripts/controleer-weekversie.mjs']),('meting49-bouw',['node_modules/.bin/tauri','build','--no-bundle'])]:voer(fase,cmd)
controleer();p=repo/'src-tauri/target/release/open-office-studio';doel=r/'open-office-studio-45.49-meting';assert not doel.exists();shutil.copy2(p,doel);m.update(programma=str(doel.relative_to(repo)),programma_sha256=hashlib.sha256(doel.read_bytes()).hexdigest());(r/'meting49-bronnen.json').write_text(json.dumps(m,indent=2)+'\n')
