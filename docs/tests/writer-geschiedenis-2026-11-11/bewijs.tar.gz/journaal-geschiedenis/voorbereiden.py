from pathlib import Path
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-geschiedenis';s=(r/'.local/integratiecontrole/bronhergebruik/proef.py').read_text();s=s.replace('window._bronopname=startOpname(window);','window._bronopname=startOpname(window,64,24*1024*1024);');anchor="                r['invoerketen'] = await p.ev('({...window._invoerketen.stop(),aanvragen:window._bronopname.stop(),rustketen:window.__OPENAEC_WRITER_INVOERMETING__.stop(),wachtend:api().getEditorRef().hasPendingInput()})')";assert s.count(anchor)==1
extra='''                # Geen snelheidsmeting: echte geschiedenis en daarna een nieuwe tak.
                await p.run("await api().flushPendingInput();window._geschKeys=[];window.addEventListener('keyup',e=>_geschKeys.push(e.key.toLowerCase()),true);window._geschHeel=api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text;return true")
                async def geschtoets(key):
                    vanaf = await p.ev('_geschKeys.length')
                    proc = await asyncio.create_subprocess_exec('xdotool','key','--clearmodifiers','ctrl+'+key)
                    assert await proc.wait() == 0
                    await p.run("let eind=performance.now()+30000;while(!_geschKeys.slice("+str(vanaf)+").includes("+json.dumps(key)+")){if(performance.now()>eind)throw Error('Geschiedenistoets ontbreekt');await new Promise(r=>setTimeout(r,50))}await api().flushPendingInput();return true",t=40)
                await geschtoets('z')
                undo = await p.run("let eind=performance.now()+30000;while(true){let t=api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text;if(t!==_geschHeel&&t.length<_geschHeel.length){window._geschUndo=t;return t}if(performance.now()>eind)throw Error('Undo verandert tekst niet');await new Promise(r=>setTimeout(r,100))}",t=40)
                await geschtoets('y')
                await p.run("let eind=performance.now()+30000;while(api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text!==_geschHeel){if(performance.now()>eind)throw Error('Redo herstelt tekst niet exact');await new Promise(r=>setTimeout(r,100))}return true",t=40)
                await geschtoets('z')
                await p.run("let eind=performance.now()+30000;while(api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text!==_geschUndo){if(performance.now()>eind)throw Error('Tweede Undo wijkt af');await new Promise(r=>setTimeout(r,100))}let e=api().getEditorRef(),s=e.getYrsSession(),p=s.paragraphs('body').at(-1);e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:p.paraId,offset:s.paragraphSpans('body').find(v=>v.paraId===p.paraId).length}));api().focus();await api().flushPendingInput();return true",t=40)
                voor = await p.ev('voor')
                assert undo.startswith(voor), 'Undo verwijdert oorspronkelijke voorbeeldtekst'
                tak = ' vertakking'
                proc = await asyncio.create_subprocess_exec('xdotool','type','--clearmodifiers','--delay','20',tak)
                assert await proc.wait() == 0
                verwacht = undo + tak
                await p.run("let eind=performance.now()+90000;while(api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text!=="+json.dumps(verwacht)+"){if(performance.now()>eind)throw Error('Nieuwe tak na Undo niet exact verwerkt');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true",t=100)
                await geschtoets('y')
                assert await p.ev("api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text") == verwacht, 'Redo overschrijft de nieuwe invoertak'
                tekst = undo[len(voor):] + tak
                r['geschiedenis'] = {'undo_verwijdert_nieuwe_tekst':True,'redo_herstelt_exact':True,'tweede_undo_gelijk':True,'nieuwe_tak_exact':True,'redo_na_tak_verandert_niets':True,'eindtoevoeging':tekst,'eindverwachting':verwacht,'grens':'Native Ctrl+Z/Y en ASCII-typinvoer op eigen kopie. Geen uitspraak over gewenste Undo-groepering of algemene snelheid.'}
'''
s=s.replace(anchor,extra+'\n'+anchor);compile(s,'geschiedenis-proef.py','exec');(u/'proef.py').write_text(s)
s=(r/'.local/integratiecontrole/bronhergebruik/uitvoeren.py').read_text().replace(".local/integratiecontrole/bronhergebruik';",".local/integratiecontrole/journaal-geschiedenis';");assert "u=r/'.local/integratiecontrole/journaal-geschiedenis'"in s;(u/'uitvoeren.py').write_text(s)
