from pathlib import Path
import json,subprocess,shutil,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-unicode-revisie';meta=json.loads((r/'.local/integratiecontrole/bronjournaal/bouw-proef-herhaling.json').read_text());cmd=meta['opdracht'];oud=r/'.local/integratiecontrole/bronjournaal/proef.rs';cmd[cmd.index(str(oud))]=str(u/'orakel.rs');cmd[cmd.index('-o')+1]=str(u/'orakel');assert shutil.disk_usage(u).free>1536*1024**2
with(u/'bouw.log').open('x')as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
(u/'bouw.json').write_text(json.dumps({'code':p.returncode,'opdracht':cmd},indent=2)+'\n');assert p.returncode==0
with(u/'orakel.log').open('x')as log:p=subprocess.run([str(u/'orakel'),str(r/'.local/integratiecontrole/journaal-geschiedenis/aanvraagreeks.json'),str(u/'aanvraagreeks.json')],stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0,'Unicode-afleiding/orakel afgekeurd'
prog=r/'.local/integratiecontrole/journaal-geschiedenis/geschiedenis'
with(u/'journaal.json').open('x')as out,(u/'journaal.log').open('x')as log:p=subprocess.run([str(prog),str(u/'aanvraagreeks.json')],stdout=out,stderr=log,timeout=180)
(u/'uitkomst.json').write_text(json.dumps({'code':p.returncode,'programma_sha256':hashlib.sha256(prog.read_bytes()).hexdigest(),'grens':'Native Unicode/revisie-afleiding uit echte geschiedenis; geen fysieke Unicode-/revisie-/IME-GUItest.'},indent=2)+'\n');print('Unicode-journaal:',p.returncode,flush=True)
