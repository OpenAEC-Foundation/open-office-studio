from pathlib import Path
import json,time,subprocess,hashlib,os,signal,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-revisies';oud=r/'.local/integratiecontrole/bronjournaal';begin=time.monotonic()
while not(u/'resultaat.json').exists():
 assert time.monotonic()-begin<600
 time.sleep(2)
assert json.loads((u/'resultaat.json').read_text())['code']==0,'Native opname afgekeurd; geen positieve herhaling'
d=json.loads((u/'opname/profiel.json').read_text());assert d['geslaagd'];m=d['invoerketen']['aanvragen'];assert not m['overgeslagen']and not m['fouten'];rows=m['regels'];assert len(rows)<=64
(u/'aanvraagreeks.json').write_text(json.dumps(rows,ensure_ascii=False)+'\n');cmd=json.loads((oud/'bouw-proef-herhaling.json').read_text())['opdracht'];cmd[cmd.index(str(oud/'proef.rs'))]=str(r/'native/onderzoek/writer-bronjournaal/geschiedenis.rs');cmd[cmd.index('-o')+1]=str(u/'geschiedenis');assert shutil.disk_usage(u).free>1536*1024**2
begin=time.monotonic()
with(u/'bouw.log').open('x')as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  if shutil.disk_usage(u).free<1024**3 or time.monotonic()-begin>180:os.killpg(p.pid,signal.SIGTERM);p.wait();raise SystemExit('Eigen kleine bouw afgebroken bij ruimte/tijdgrens')
  time.sleep(.2)
(u/'bouw.json').write_text(json.dumps({'code':p.returncode,'opdracht':cmd,'bron_sha256':hashlib.sha256((r/'native/onderzoek/writer-bronjournaal/geschiedenis.rs').read_bytes()).hexdigest()},indent=2)+'\n');assert p.returncode==0
# Eerst dezelfde echte bronreeks door de bestaande originele Rust-route.
refmeta=json.loads((r/'.local/integratiecontrole/bronhergebruik/bouw-desktop.json').read_text());c=refmeta['opdracht'];ref=c[c.index('-o')+1]
result=[]
for naam,prog in [('referentie',ref),('journaal',str(u/'geschiedenis'))]:
 with(u/(naam+'.json')).open('x')as out,(u/(naam+'.log')).open('x')as log:p=subprocess.run([prog,str(u/'aanvraagreeks.json')],stdout=out,stderr=log,timeout=180)
 result.append({'naam':naam,'code':p.returncode,'programma_sha256':hashlib.sha256(Path(prog).read_bytes()).hexdigest()});(u/'herhaling.json').write_text(json.dumps(result,indent=2)+'\n');print(naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
