from pathlib import Path
import json,subprocess,hashlib,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-unicode';meta=json.loads((u/'bouw.json').read_text());cmd=meta['opdracht'];cmd[cmd.index(str(u/'orakel.rs'))]=str(r/'native/onderzoek/writer-bronjournaal/unicode.rs');cmd[cmd.index('-o')+1]=str(u/'orakel-definitief');assert shutil.disk_usage(u).free>1536*1024**2
with(u/'bouw-definitief.log').open('x')as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0
(u/'bouw-definitief.json').write_text(json.dumps({'code':p.returncode,'opdracht':cmd,'bron_sha256':hashlib.sha256((r/'native/onderzoek/writer-bronjournaal/unicode.rs').read_bytes()).hexdigest()},indent=2)+'\n');result=[]
for naam,extra in [('gewoon',[]),('revisie',['--revisie'])]:
 dataset=u/('definitief-'+naam+'-aanvragen.json')
 with(u/('definitief-'+naam+'-orakel.log')).open('x')as log:p=subprocess.run([str(u/'orakel-definitief'),str(r/'.local/integratiecontrole/journaal-geschiedenis/aanvraagreeks.json'),str(dataset),*extra],stdout=log,stderr=log,timeout=180)
 assert p.returncode==0
 prog=r/'.local/integratiecontrole/journaal-geschiedenis/geschiedenis'
 with(u/('definitief-'+naam+'.json')).open('x')as out,(u/('definitief-'+naam+'.log')).open('x')as log:p=subprocess.run([str(prog),str(dataset)],stdout=out,stderr=log,timeout=180)
 assert p.returncode==0
 result.append({'naam':naam,'code':p.returncode,'programma_sha256':hashlib.sha256(prog.read_bytes()).hexdigest(),'dataset_sha256':hashlib.sha256(dataset.read_bytes()).hexdigest()});print(naam,p.returncode,flush=True)
(u/'definitief-uitkomsten.json').write_text(json.dumps(result,indent=2)+'\n')
