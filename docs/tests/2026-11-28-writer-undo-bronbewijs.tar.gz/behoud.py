from pathlib import Path
import json,hashlib,stat,ast,subprocess
r=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();refs=json.loads((r/'.local/integratiecontrole/context-kaart-fasen/referenties-nacontrole.json').read_text());assert len(refs)==38
for f,h in refs.items():assert sha(Path(f))==h
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];assert len(pins)==15
for f,h in pins.items():assert sha(r/f)==h
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
for obj in json.loads((r/'.local/integratiecontrole/digest-fasen/bronpinnen.json').read_text()).values():
 if isinstance(obj,dict)and'pad'in obj:assert sha(Path(obj['pad']))==obj['sha256']
for name in ['bouw.json','bouw-klein.json','bouw-cache.json','bouw-pending.json']:
 build=json.loads((p/name).read_text());assert build['code']==0
 for f,h in build['bibliotheken'].items():assert sha(Path(f))==h
oracle_dir=r/'.local/integratiecontrole/digest-fasen';oracle=json.loads((oracle_dir/'orakel.json').read_text());assert oracle['geslaagd'];frames=0
for case in oracle['cases']:
 for frame in case['frames']:assert sha(oracle_dir/frame['file'])==frame['sha256'];frames+=1
assert frames==80
for f in p.glob('*.py'):ast.parse(f.read_text())
pins=json.loads((p/'yrs-bronpinnen.json').read_text());registry=Path('/home/aia01/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/yrs-0.27.4');assert len(pins)==61
for f,h in pins.items():assert sha(registry/f)==h and sha(p/'yrs-basis'/f)==h
assert [f for f,h in pins.items()if sha(p/'yrs-gesorteerd'/f)!=h]==['src/undo.rs']
result={'yrs_bronbestanden61_exact':True,'diagnose_alleen_undo_rs':True,'causale_drivers':{v:sha(p/'causaal-target/release'/('causaal-'+v))for v in ['basis','gesorteerd']},'referenties38_exact':True,'bronpinnen15_exact':True,'standaardbundel529_byte_mode_mtime_exact':True,'native_bibliotheken_exact':True,'orakelframes80_sha_exact':True,'rustc':subprocess.check_output(['/home/aia01/.cargo/bin/rustc','--version'],text=True).strip(),'drivers':{n:sha(p/n)for n in ['proef','klein','proef-cache','pending']},'nieuwe_desktop_of_wasm_bouw':False};(p/'behoud.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
