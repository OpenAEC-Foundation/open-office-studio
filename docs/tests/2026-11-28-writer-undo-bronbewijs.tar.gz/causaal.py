from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/undo-bronbewijs';src=Path('/home/aia01/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/yrs-0.27.4');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();log=[]
main='''use yrs::{Doc,Map,Transact,ReadTxn,Origin,StateVector,undo::{UndoManager,Options},types::ToJson};
use std::collections::HashSet;
fn main(){let mut bad=0;for _ in 0..64{let a=Doc::with_client_id(777);let b=Doc::with_client_id(777);let ma=a.get_or_insert_map("metadata");let mb=b.get_or_insert_map("metadata");for(d,m)in[(&a,&ma),(&b,&mb)]{let mut t=d.transact_mut();for k in ["a","b","c","d","e","f","g","h"]{m.insert(&mut t,k,"0");}}
let options=||Options{tracked_origins:HashSet::from([Origin::from(777u64)]),..Options::default()};let mut ua=UndoManager::<()>::with_options(options());let mut ub=UndoManager::<()>::with_options(options());ua.expand_scope(&a,&ma);ub.expand_scope(&b,&mb);for(d,m)in[(&a,&ma),(&b,&mb)]{let mut t=d.transact_mut_with(777u64);for k in ["a","b","c","d","e","f","g","h"]{m.insert(&mut t,k,"1");}}
assert_eq!(a.transact().encode_state_as_update_v1(&StateVector::default()),b.transact().encode_state_as_update_v1(&StateVector::default()));for redo in [false,true]{assert!(if redo{ua.redo_blocking()&&ub.redo_blocking()}else{ua.undo_blocking()&&ub.undo_blocking()});assert_eq!(ma.to_json(&a.transact()),mb.to_json(&b.transact()));assert_eq!(a.transact().state_vector(),b.transact().state_vector());if a.transact().encode_state_as_update_v1(&StateVector::default())!=b.transact().encode_state_as_update_v1(&StateVector::default()){bad+=1;}}}println!("{bad}");}
'''
for variant in ['basis','gesorteerd']:
 dst=p/('yrs-'+variant);shutil.copytree(src,dst,dirs_exist_ok=False)
 f=dst/'src/undo.rs';before=f.read_text()
 if variant=='gesorteerd':
  old='for &ptr in to_redo.iter() {';new='let mut redo_order: Vec<_> = to_redo.iter().copied().collect();\n        redo_order.sort_by_key(|ptr| *ptr.id());\n        for ptr in redo_order {';assert before.count(old)==1;f.write_text(before.replace(old,new))
 app=p/('causaal-'+variant);(app/'src').mkdir(parents=True);(app/'src/main.rs').write_text(main);(app/'Cargo.toml').write_text('[package]\nname="causaal-'+variant+'"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\nyrs={path="../yrs-'+variant+'"}\n')
 command=['/home/aia01/.cargo/bin/cargo','run','--release','--offline','--manifest-path',str(app/'Cargo.toml'),'--target-dir',str(p/'causaal-target'),'-j','2'];result=subprocess.run(command,capture_output=True,text=True,timeout=240);(p/('causaal-'+variant+'.log')).write_text(result.stderr);(p/('causaal-'+variant+'.uit')).write_text(result.stdout);log.append({'variant':variant,'bronsha_undo':sha(f),'code':result.returncode,'uitvoer':result.stdout.strip(),'opdracht':command});(p/'causaal.json').write_text(json.dumps(log,indent=2)+'\n');print(json.dumps(log[-1]),flush=True);assert result.returncode==0
