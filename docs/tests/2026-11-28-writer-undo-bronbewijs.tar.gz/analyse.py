from pathlib import Path
import json,collections,hashlib,re
p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
result={}
for name,expected in [('proef',166),('proef-cache',166),('klein',96)]:
 d=json.loads((p/(name+'.json')).read_text());assert d['geslaagd'];rows=d['vergelijkingen'];assert len(rows)==expected
 assert all(r['alle_wortels_getypeerd_gelijk'] and r['vector_gelijk']for r in rows)
 assert all(r['bytes_gelijk']for r in rows if r['fase']in['basis','lokaal'])
 counts=collections.Counter((r['fase'],r['bytes_gelijk'])for r in rows)
 result[name]={'vergelijkingen':len(rows),'alle_wortels_en_vectoren_gelijk':True,'fasen':[{'fase':f,'bytes_gelijk':b,'aantal':n}for(f,b),n in counts.items()]}
causal=json.loads((p/'causaal.json').read_text());assert [(r['variant'],r['code'],r['uitvoer'])for r in causal]==[('basis',0,'128'),('gesorteerd',0,'0')]
result['causaal']={'paren_per_variant':64,'undo_redo_per_paar':2,'byteverschillen_basis':128,'byteverschillen_alleen_gesorteerde_herstelloop':0,'live_waarden_en_vectoren_gelijk_in_beide':True,'dependencywaarschuwingen_per_variant':{v:int(re.search(r'generated (\d+) warnings',(p/('causaal-'+v+'.log')).read_text()).group(1))for v in ['basis','gesorteerd']},'diagnosekopie_geen_productpatch':True}
pending=json.loads((p/'pending.json').read_text());assert pending['geslaagd']and pending['promoties']==0 and pending['eindbron_exact'];result['pending']=pending
pattern=r'\(<(\d+)#(\d+)>, len: (\d+), origin-l: <(\d+)#(\d+)>(?:, origin-r: <(\d+)#(\d+)>)?'
for prefix in ['', 'kleine-uitvoer/']:
 pairs=[]
 for letter in ['a','b']:
  f=p/(prefix+'eerste-'+letter+'.txt');rows=re.findall(pattern,f.read_text());client=rows[0][0];items=[{'client':int(a),'clock':int(b),'len':int(c),'origin_left':[int(d),int(e)],'origin_right':[int(f),int(g)]if f else None}for a,b,c,d,e,f,g in rows if a==client];pairs.append(items)
 result['klein_idbewijs' if prefix else 'corpus_idbewijs']={'A':pairs[0],'B':pairs[1],'verschillend':pairs[0]!=pairs[1],'bronbestanden_sha256':{letter:sha(p/(prefix+'eerste-'+letter+'.bin'))for letter in ['a','b']}}
 assert pairs[0]!=pairs[1]
result['grenzen']=['Live bronstructuren/tekst-diffs/attributen getypeerd vergeleken; geen gelijkheid van verwijderde historie of CRDT-identiteiten aangenomen.','Zelfde-documentbronbytes blijven vóór/na alle lezingen exact; geen canonisering, terugschrijven of verzwakken van behoudscontract.','Alleen native componentproeven. Geen Wasm-/desktop-/GUI-/visuele-/platformacceptatie of nieuwe prestatiemeting.']
(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if 'idbewijs'not in k},ensure_ascii=False))
