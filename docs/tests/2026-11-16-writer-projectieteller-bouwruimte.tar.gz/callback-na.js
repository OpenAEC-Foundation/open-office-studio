(oe) => {
    const z = r.session;
    if (!z || !z.hasStory(oe))
        return null;
    if (r.experimentalWorkerOpen) {
        const ready = r.replicaReadyRef?.current ?? r.replicaReady;
        if (dn.current !== ready) {
            dn.current = ready;
            Mt.current += 1;
        }
    }
    const ce = Ot.current;
    const projectionReady = !r.experimentalWorkerOpen || (r.replicaReadyRef?.current ?? r.replicaReady);
    const projectionGeneration = r.sessionGeneration;
    const currentSegmentSource = Tt.current;
    if (ce?.version === Mt.current &&
        ce.session === z &&
        ce.rootStory === oe &&
        ce.generation === projectionGeneration &&
        ce.ready === projectionReady &&
        ce.segmentSource === currentSegmentSource &&
        !currentSegmentSource?.disposed &&
        ce.opening === r.opening &&
        ce.previewing === r.previewing &&
        ce.experimentalWorkerOpen === r.experimentalWorkerOpen) {
try{const P=window._officeProjectionProbe;if(P)P.note("fast",{root:oe,manual:Mt.current,cacheManual:ce?.version,session:P.id(z),cacheSession:P.id(ce?.session),projection:P.id(ce?.projection),segments:P.id(currentSegmentSource),cacheSegments:P.id(ce?.segmentSource),segmentSession:P.id(currentSegmentSource?.session),generation:projectionGeneration,cacheGeneration:ce?.generation,ready:projectionReady,cacheReady:ce?.ready,worker:r.experimentalWorkerOpen,cacheWorker:ce?.experimentalWorkerOpen,opening:r.opening,cacheOpening:ce?.opening,preview:r.previewing,cachePreview:ce?.previewing,disposed:currentSegmentSource?.disposed,cacheRoot:ce?.rootStory,cacheSourceVersion:ce?.sourceVersion,hasCache:!!ce})}catch{window._officeProjectionProbe?.error()}
        return ce.projection;
    }
    if (ce && oe === 'body' && ce.rootStory === oe && ce.session === z &&
        ce.opening === false && ce.previewing === false && ce.experimentalWorkerOpen === true &&
        r.experimentalWorkerOpen && projectionReady === true && ce.ready === true &&
        Number.isSafeInteger(projectionGeneration) && ce.generation === projectionGeneration &&
        ce.segmentSource === currentSegmentSource && currentSegmentSource?.session === z &&
        !currentSegmentSource.disposed && !r.opening && !r.previewing &&
        typeof ce.sourceVersion === 'string' && ce.sourceVersion === z.version()) {
try{const P=window._officeProjectionProbe;if(P)P.note("reuse",{root:oe,manual:Mt.current,cacheManual:ce?.version,session:P.id(z),cacheSession:P.id(ce?.session),projection:P.id(ce?.projection),segments:P.id(currentSegmentSource),cacheSegments:P.id(ce?.segmentSource),segmentSession:P.id(currentSegmentSource?.session),generation:projectionGeneration,cacheGeneration:ce?.generation,ready:projectionReady,cacheReady:ce?.ready,worker:r.experimentalWorkerOpen,cacheWorker:ce?.experimentalWorkerOpen,opening:r.opening,cacheOpening:ce?.opening,preview:r.previewing,cachePreview:ce?.previewing,disposed:currentSegmentSource?.disposed,cacheRoot:ce?.rootStory,cacheSourceVersion:ce?.sourceVersion,hasCache:!!ce})}catch{window._officeProjectionProbe?.error()}
        ce.version = Mt.current;
        return ce.projection;
    }
try{const P=window._officeProjectionProbe;if(P)P.note("build",{root:oe,manual:Mt.current,cacheManual:ce?.version,session:P.id(z),cacheSession:P.id(ce?.session),projection:P.id(ce?.projection),segments:P.id(currentSegmentSource),cacheSegments:P.id(ce?.segmentSource),segmentSession:P.id(currentSegmentSource?.session),generation:projectionGeneration,cacheGeneration:ce?.generation,ready:projectionReady,cacheReady:ce?.ready,worker:r.experimentalWorkerOpen,cacheWorker:ce?.experimentalWorkerOpen,opening:r.opening,cacheOpening:ce?.opening,preview:r.previewing,cachePreview:ce?.previewing,disposed:currentSegmentSource?.disposed,cacheRoot:ce?.rootStory,cacheSourceVersion:ce?.sourceVersion,hasCache:!!ce,sourceVersion:z.version()})}catch{window._officeProjectionProbe?.error()}
    const Re = A(z);
    const rt = uO(z, oe, Re);
    Re.scheduleDigests();
    if (!rt)
        return null;
    Ot.current = {
        version: Mt.current,
        session: z,
        rootStory: oe,
        projection: rt,
        sourceVersion: z.version(),
        generation: projectionGeneration,
        ready: projectionReady,
        segmentSource: Re,
        opening: r.opening,
        previewing: r.previewing,
        experimentalWorkerOpen: r.experimentalWorkerOpen,
    };
    return rt;
}
