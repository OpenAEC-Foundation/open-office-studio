from pathlib import Path
import json,collections
p=Path(__file__).resolve().parent;r=json.loads((p/'native/rapport.json').read_text());assert r['geslaagd'];t=r['projectie_telling'];assert t['overflow']==t['errors']==0;assert sum(t['counts'].values())==sum(g['calls']for g in t['groups']);assert r['teller_verwijderd'];reasons=collections.Counter();per=collections.defaultdict(collections.Counter);builds=[]
for group in t['groups']:
 d=group['data'];tag=group['tag'];n=group['calls'];version=d.get('sourceVersion')if tag=='build'else d.get('cacheSourceVersion');key=json.dumps([d.get('session'),d.get('generation'),d.get('root'),d.get('segments'),version]);per[key][tag]+=n
 if tag!='build':continue
 bad=[]
 for ok,label in [
  (d['hasCache'],'geen-cache'),(d['root']=='body','andere-root'),(d.get('cacheRoot')==d['root'],'cache-root'),(d.get('cacheSession')==d['session'],'sessie'),
  (d.get('cacheOpening')is False,'oude-opening'),(d.get('cachePreview')is False,'oude-preview'),(d.get('cacheWorker')is True,'oude-workerroute'),
  (d.get('worker')is True,'workerroute'),(d.get('ready')is True,'gereedheid'),(d.get('cacheReady')is True,'oude-gereedheid'),
  (type(d.get('generation'))is int and abs(d['generation'])<2**53,'onbekende-generatie'),(d.get('cacheGeneration')==d.get('generation'),'generatie'),
  (d.get('cacheSegments')==d.get('segments'),'segmentbron'),(d.get('segmentSession')==d.get('session'),'segmentsessie'),(not d.get('disposed'),'segment-opgeruimd'),
  (not d.get('opening'),'opening'),(not d.get('preview'),'preview'),(isinstance(d.get('cacheSourceVersion'),str),'oude-bronversie-onbekend'),
  (d.get('cacheSourceVersion')==d.get('sourceVersion'),'bronversie')]:
  if not ok:bad.append(label);reasons[label]+=n
 builds.append({'calls':n,'redenen':bad,'data':d});assert bad,'Herbouw zonder verklaarde hergebruikafwijzing'
result={'tellingen':t['counts'],'groepen':len(t['groups']),'nul_verlies_fouten':True,'bevestigde_editor_sessie':r['teller_sessie'],'waargenomen_sessies':sorted({g['data']['session']for g in t['groups']}),'afwijzingen':dict(reasons),'constructies':builds,'per_bron_context':[{'sleutel':json.loads(k),'tellingen':dict(v)}for k,v in per.items()],'grens':'Normale JS-meetuitdrukkingen, verliesloos gegroepeerd. Elke build leest bronversie aanvullend; fast/reuse niet. Geen tijdbenchmark of volledige causaliteit.'};(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['tellingen','groepen','bevestigde_editor_sessie','waargenomen_sessies','afwijzingen']}))
