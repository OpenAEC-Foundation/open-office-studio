from pathlib import Path
import hashlib, io, json, tarfile
r = Path.cwd()
p = r / '.local/integratiecontrole/projectie-context-telling'
out = r / 'docs/tests'
label = '2026-11-16-writer-projectieteller-bouwruimte'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
assert read('collector-proef.json')['geslaagd'] and read('native-orakel.json')['geslaagd']
assert read('desktop.json')['code'] == -15
assert read('actief.json')['standaarddist_hersteld']
files = [f for f in sorted(p.rglob('*')) if f.is_file()
         and not set(f.relative_to(p).parts) & {'dist', '__pycache__', 'standaarddist'}]
manifest = {str(f.relative_to(p)): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in files}
archive = out / (label + '.tar.gz')
with tarfile.open(archive, 'w:gz') as t:
    for f in files:
        t.add(f, arcname=str(f.relative_to(p)), recursive=False)
    b = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(b)
    t.addfile(info, io.BytesIO(b))
with tarfile.open(archive) as t:
    assert set(t.getnames()) == set(manifest) | {'manifest.json'}
    for name, v in manifest.items():
        b = t.extractfile(name).read()
        assert len(b) == v['bytes'] and hashlib.sha256(b).hexdigest() == v['sha256']
report = {
    'datum': '2026-11-16', 'basis_integratie': '2007f329', 'basis_hoofdbranch': '239add06',
    'productbron': '41e7000198f89d992e1059e9715636a44b39d21a',
    'besluit': 'Drie gewone JS-meetpunten voorbereid en componentmatig getoetst. Native meetbouw door eigen ruimtebewaking gestopt; geen nieuwe ELF of werkelijk uitgevoerde native cachetellingen. Productbron en bestaande referenties behouden.',
    'implementatie': 'Alleen editors-JS van private ee89c80e-contextkandidaat: waarneming bij huidige hit, extra hergebruik en constructie. Telt geldige storyvragen na oorspronkelijke sessie/hasStory-afwijzing. Geen voorwaarden/retours/invalidaties veranderd. Alleen constructiemetingen lezen version() aanvullend; snelle hits en hergebruik niet. Verliesloze groepering begrensd op4096. Geen hoofdthread-Debugger.',
    'bundel': read('bundel.json'), 'collector': read('collector-proef.json'),
    'volledige_projectie_orakel': read('native-orakel.json'),
    'native_bouw': read('desktop.json'), 'herstel': read('actief.json'),
    'behoud': read('behoud.json'),
    'grenzen': [
        'Collectorproef bewaart100000herhaalde hits exact, stopt correct en signaleert opzettelijke overloop bij4097unieke groepen.',
        'De echte voor/na-callbacks op geaccepteerde Rust/Wasm geven dezelfde volledige projectie in vijf contextreeksen met elk1000huidigehits. Zeven constructies en drie extra hergebruikshits;477455locatie- en481305node/targetcontroles exact. Zeven extra versielezingen, exact één per constructie. Gecontroleerde adapter en idleplanner; geen native/browserprestatieproef.',
        'Cargo compileerde uitsluitend de eigen appcrate. Start7626166272vrije bytes, gemeten minimum2998657024bytes; bewaking stopt bij minder dan3GiB. Standaardbundel byte/mode/mtime hersteld. Geen nieuwe uitvoerbare referentie geaccepteerd.',
        'Na afloop circa2GiBvrij. Ongeveer1MBrecent in eigen target aangetroffen; geen grote eigen afgebroken resten gevonden. Geen bestaande caches/referenties/gebruikersbestanden verwijderd. Oorzaak overige ruimteafname niet vastgesteld.',
        'Geen native functie-/beeld-/DOCX-/snelheidscontrole voor deze meetkopie uitgevoerd. Geen daadwerkelijke fast/reuse/build-aanroepaantallen op de desktop beschikbaar. Analyse- en nativeproefscript zijn voorbereid en syntactisch gecontroleerd, nog niet tegen deze meet-ELF uitgevoerd.'
    ],
    'niet_gecontroleerd': ['Geen volledige frontend/TypeScript/Python-suite of product-CI; geen Windows/macOS/installer/andere editie/feature/schema/releaseacceptatie.',
                           'Geen productwijziging, geheugen-/RefCell-foutfix of issue-/migratievoltooiing.'],
    'vervolg': 'Controleer eerst vrije schijfruimte en actieve schrijvers. Onder3,1GiB geen nieuwe native bouw starten en bij ongewijzigde ruimte stil blijven. Zodra voldoende ruimte beschikbaar is, bewaar deze afgebroken poging ongewijzigd en gebruik een apart uitvoer-/logpad voor de nieuwe meetbouw; behoud stopvloer3GiB en alle26referenties/529standaardbestanden. Voer daarna native-proef.py op de nieuwe meet-ELF uit met eigen bron/profiel en analyse.py op het rapport. Bevestig verliesloze fast/reuse/build-tellingen en afwijzingsredenen vóór enige nieuwe cache-/uitstelwijziging. Geen hoofdthread-Debugger. R(k) apart; Database laatst.',
    'afhankelijkheden': [{'pad': 'docs/tests/2026-11-16-writer-projectie-context.tar.gz',
                         'sha256': sha(out / '2026-11-16-writer-projectie-context.tar.gz')}],
    'bewijs': {'pad': str(archive.relative_to(r)), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
               'bestanden': len(files), 'alle_leden_byteexact_gecontroleerd': True,
               'uitsluiting': 'Geen dist/ELF/Wasm. Wel callbackvoor/na,editor-JSgzip,collector/orakel/voorbereider/bouw/native/analyse-scripts,logs,bouwafkeuring/herstel en referentie-/bronpinnen.'}
}
(out / (label + '.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['bewijs']))
