from pathlib import Path
import json,subprocess,time,statistics,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/bronjournaal';meta=json.loads((r/'.local/integratiecontrole/bronhergebruik/bouw-desktop.json').read_text());cmd=meta['opdracht'];referentie=Path(cmd[cmd.index('-o')+1]);proef=u/'proef';bron=r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json';begin=time.monotonic()
while not(u/'uitkomst.json').exists():
 assert time.monotonic()-begin<200
 time.sleep(.5)
assert json.loads((u/'uitkomst.json').read_text())['code']==0
result=[]
for nr,naam in enumerate(['referentie','journaal','journaal','referentie'],1):
 programma=referentie if naam=='referentie'else proef;uit=u/('vergelijk-'+str(nr)+'.json');start=time.monotonic()
 with uit.open('x')as out,(u/('vergelijk-'+str(nr)+'.log')).open('x')as log:p=subprocess.run([str(programma),str(bron)],stdout=out,stderr=log,timeout=180)
 assert p.returncode==0,(naam,p.returncode)
 d=json.loads(uit.read_text());rij=d['groepen']if naam=='referentie'else d['rondes'];assert len(rij)==21
 key='totaal_ms'if naam=='referentie'else 'ms';waarden=[x[key]for x in rij[1:]]
 result.append({'ronde':nr,'naam':naam,'programma_sha256':hashlib.sha256(programma.read_bytes()).hexdigest(),'code':p.returncode,'warme_20_groepen_mediaan_ms':statistics.median(waarden),'warme_20_groepen_som_ms':sum(waarden),'eerste_groep_ms':rij[0][key],'hele_proef_wandtijd_s':time.monotonic()-start,'grens':'Losse native functies, geen GUI/FPS/desktopmeting. Schema3 wijzigt alleen in de journaalproef het tokencontract. JSON-deserialisatie ligt in de twee wrappers niet op exact hetzelfde meetpunt.'});(u/'vergelijking.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(naam,result[-1]['warme_20_groepen_mediaan_ms'],flush=True)
