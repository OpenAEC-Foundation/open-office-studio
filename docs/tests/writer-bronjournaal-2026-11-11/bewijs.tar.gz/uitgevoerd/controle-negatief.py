from pathlib import Path
import subprocess,json,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/bronjournaal';cmd=json.loads((u/'bouw-proef-herhaling.json').read_text())['opdracht'];cmd[cmd.index(str(u/'proef.rs'))]=str(u/'proef-mutant.rs');cmd[cmd.index('-o')+1]=str(u/'proef-mutant');assert shutil.disk_usage(u).free>1536*1024**2
with(u/'mutant-bouw.log').open('x')as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0
with(u/'mutant.json').open('x')as out,(u/'mutant.log').open('x')as log:p=subprocess.run([str(u/'proef-mutant'),str(r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json')],stdout=out,stderr=log,timeout=180)
s=(u/'mutant.log').read_text();assert p.returncode!=0 and 'Negatief vector'in s,(p.returncode,s[:200]);(u/'mutant-uitkomst.json').write_text(json.dumps({'code':p.returncode,'verwachte_afkeuring':'Negatief vector','afkeuring_gecontroleerd':True,'doel':'De regressieproef keurt werkelijk ontbrekende bronvectorcontrole af.'},indent=2)+'\n');print('Ontbrekende bronvectorcontrole wordt aantoonbaar afgekeurd.')
