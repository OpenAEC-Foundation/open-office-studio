from pathlib import Path
import json,subprocess,hashlib,time,shutil,os,signal
r=Path.cwd();u=r/'.local/integratiecontrole/bronjournaal';meta=json.loads((r/'.local/integratiecontrole/bronhergebruik/bouw-huidige-bronkosten.json').read_text());oud=meta['opdracht'];cache=next(x for x in oud if x.startswith('dependency='));cmd=['/home/aia01/.cargo/bin/rustc','--edition=2024','-C','opt-level=3','-L',cache,'-L','dependency='+str(u),str(u/'proef.rs'),'-o',str(u/'proef')]
for naam in ['office_writer_plakken','serde_json','base64','sha2','yrs']:
 waarde=next(x for x in oud if x.startswith(naam+'='));cmd+=['--extern',waarde]
cmd+=['--extern','docx_journal='+str(u/'libdocx_edit_journaal.rlib')]
assert json.loads((u/'bouw.json').read_text())['code']==0 and shutil.disk_usage(u).free>1536*1024**2
begin=time.monotonic()
with(u/'bouw-proef.log').open('x')as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  if shutil.disk_usage(u).free<1024**3 or time.monotonic()-begin>180:os.killpg(p.pid,signal.SIGTERM);p.wait();raise SystemExit('Eigen proefbouw afgebroken bij ruimte-/tijdgrens')
  time.sleep(.2)
(u/'bouw-proef.json').write_text(json.dumps({'code':p.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd},indent=2)+'\n');assert p.returncode==0
with(u/'resultaat.json').open('x')as out,(u/'proef.log').open('x')as log:p=subprocess.run([str(u/'proef'),str(r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json')],stdout=out,stderr=log,timeout=180)
(u/'uitkomst.json').write_text(json.dumps({'code':p.returncode})+'\n');print('Bronjournaalproef:',p.returncode,flush=True)
