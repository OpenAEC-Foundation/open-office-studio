from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,signal
r=Path.cwd();u=r/'.local/integratiecontrole/bronjournaal';root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');cache=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release';pinnen=json.loads((r/'.local/integratiecontrole/bronhergebruik/bouw-huidige-bronkosten.json').read_text())['bibliotheken'];doc=Path(next(p for p in pinnen if p.endswith('/libdocx_edit.rlib')));j=json.loads((cache/'.fingerprint/betteroffice-docx-edit-d94709e6655e5581/lib-docx_edit.json').read_text());libs={}
for dep in j['deps']:
 naam=dep[1];gevonden=[p for p in(cache/'.fingerprint').glob('*/lib-'+naam)if int.from_bytes(bytes.fromhex(p.read_text().strip()),'little')==dep[3]];assert len(gevonden)==1,(naam,len(gevonden));p=gevonden[0];h=p.parent.name.rsplit('-',1)[1];keus=[cache/'deps'/('lib'+naam+'-'+h+s)for s in ['.rlib','.so']]+[cache/'deps'/('lib'+naam+s)for s in ['.rlib','.so']];lib=next((x for x in keus if x.exists()),None);assert lib,(naam,keus);libs[naam]=lib
cmd=['/home/aia01/.cargo/bin/rustc','--crate-name','docx_edit_journaal','--crate-type','rlib','--edition=2024','-C','opt-level=3','-C','debuginfo=0','-L','dependency='+str(cache/'deps'),str(u/'docx-edit/src/lib.rs'),'-o',str(u/'libdocx_edit_journaal_import.rlib')]
for feature in json.loads(j['features']):cmd+=['--cfg','feature='+json.dumps(feature)]
for naam,lib in libs.items():cmd+=['--extern',naam+'='+str(lib)]
assert shutil.disk_usage(u).free>1536*1024**2
begin=time.monotonic();env=os.environ.copy();env['CARGO_PKG_VERSION']='0.5.1';env['CARGO_MANIFEST_DIR']=str(u/'docx-edit')
with(u/'bouw-import.log').open('x')as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  if shutil.disk_usage(u).free<1024**3 or time.monotonic()-begin>300:os.killpg(p.pid,signal.SIGTERM);p.wait();raise SystemExit('Eigen onderzoeksbouw afgebroken bij ruimte-/tijdgrens')
  time.sleep(.5)
(u/'bouw-import.json').write_text(json.dumps({'code':p.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd,'bibliotheken':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in libs.values()}},indent=2)+'\n');print('Onderzoeksbibliotheek:',p.returncode,flush=True)
