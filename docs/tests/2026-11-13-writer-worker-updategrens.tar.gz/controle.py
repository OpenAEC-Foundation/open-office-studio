from pathlib import Path
import hashlib,json,stat,statistics
p=Path(__file__).resolve().parent;repo=p.parents[2];sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
a=json.load(open(p/'werkelijk-basis.json'));b=json.load(open(p/'werkelijk-klok.json'));assert a['geslaagd'] and b['geslaagd'];assert len(a['metingen'])==len(b['metingen'])==8
velden=['stap','tekst','alinea_sha256','bronvector_sha256','font_sha256','font_bytes','update_bytes','inference']
for x,y in zip(a['metingen'],b['metingen'],strict=True):
 for k in velden:assert x[k]==y[k],k
routes={k:[next(z[0]for z in x['font_trace_'+k]if z[0].startswith('route_'))for x in b['metingen']]for k in ['a','b']};assert set(routes['b'])=={'route_volledig_loweren'};assert set(routes['a'])=={'route_overige_patch'}
proef=json.load(open(p/'proef.json'));assert proef['geslaagd'] and len(proef['gevallen'])==6
for x in proef['gevallen']:
 assert x['font_en_alineas_en_vector_alle_drie_exact'] and x['herhaling_inference'] is None
 if x['kind']=='twee-auteurs':assert x['inference'] is None
 else:assert x['inference']==proef['gevallen'][0]['inference']
refs=json.load(open(repo/'.local/integratiecontrole/werker-fasekopie/referenties-nacontrole.json'));assert len(refs)==16
for q,h in refs.items():assert sha(Path(q))==h
oud=json.load(open(repo/'.local/integratiecontrole/werker-fasekopie/standaardbundel.json'));assert len(oud)==529
for n,v in oud.items():
 q=repo/'dist'/n;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns']
assert len([q for q in (repo/'dist').rglob('*')if q.is_file()])==529
assert sha(repo/'node_modules/@betteroffice/docx-react/dist/index.mjs')=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
meta=json.load(open(repo/'patches/tekstengine-nootnummering.json'))
for q,h in [('vendor/tekstengine/docx_edit_bg.wasm',meta['wasmSha256']),('vendor/tekstengine/docx_layout_bg.wasm',meta['layoutWasmSha256']),('node_modules/@betteroffice/docx/dist/generated/edit/docx_edit_bg.wasm',meta['oorspronkelijkWasmSha256'])]:assert sha(repo/q)==h
r={'geslaagd':True,'kernen_acht_stappen_acht_velden_exact':True,'routes':routes,'mediaan_font_ms':{k:statistics.median(x[k]for x in b['metingen'])for k in ['lokaal_font_ms','replica_font_ms']},'zes_updategevallen_groen':True,'vijf_inferences_identiek_ondanks_vier_gemengde_updates':True,'eerste_afkeuring_bewaard':'De compacte read_paragraphs_json-projectie bevat geen alineaeigenschappen; die proef gaf terecht geen bewijs van de uitlijningswijziging. Vervolgens paragraphs plus alle body-story_segments over drie sessies vergeleken en uitlijning expliciet geverifieerd. Eerste bron/log/resultaat en tweede geslaagde vijfgevallenronde behouden.','behoud':{'ELFs_exact':16,'standaarddist_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':True}}
(p/'controle.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r))
