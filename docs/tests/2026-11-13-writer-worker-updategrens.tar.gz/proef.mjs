import fs from 'node:fs';import path from 'node:path';import{pathToFileURL}from'node:url';import assert from'node:assert/strict';import crypto from'node:crypto';
const dir=path.resolve('.local/integratiecontrole/worker-updategrens'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const wasm=fs.readFileSync('vendor/tekstengine/docx_edit_bg.wasm');assert.equal(sha(wasm),'737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9');
const{preloadEditWasm,createEditSession}=await import(pathToFileURL(path.resolve('node_modules/@betteroffice/docx/dist/wasm-edit.mjs')).href);await preloadEditWasm(wasm);
const bytes=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx');assert.equal(sha(bytes),'f69528bf0ee7b1e2d89aff2e893a131696e0485dd494b2a7c15b16f55d95b7a5');
const request=JSON.stringify({bodyStory:'body',renderEnv:{}}),read=s=>JSON.parse(s.paragraphs('body'));
let result={geslaagd:false,wasm_sha256:sha(wasm),bron_sha256:sha(bytes),gevallen:[]};
try{for(const kind of ['tekst','andere-alinea-font-en-tekst','andere-alinea-uitlijning-en-tekst','andere-alinea-verwijderen-en-tekst','andere-alinea-splitsen-en-tekst','twee-auteurs']){
 const a=createEditSession(901),b=createEditSession(902),c=createEditSession(903),peer=createEditSession(904);
 try{
  a.open_docx(bytes,true);const state=a.encode_state();for(const s of[b,c,peer])s.load(state);
  const pars=read(a),last=pars.at(-1),other=pars.find(p=>p.paraId!==last.paraId&&p.text.length>2);assert(other);const beforeFonts=b.layout_font_requirements_json(request),beforePars=read(b),vector=b.encode_state_vector();
  if(kind==='andere-alinea-font-en-tekst')a.format_range('body',other.paraId,0,other.paraId,2,JSON.stringify({fontFamily:{ascii:'Liberation Serif',hAnsi:'Liberation Serif'}}));
  if(kind==='andere-alinea-uitlijning-en-tekst')a.set_paragraph_attr(other.paraId,'alignment',JSON.stringify('right'));
  if(kind==='andere-alinea-verwijderen-en-tekst')a.delete_range('body',other.paraId,0,other.paraId,1,null,null);
  if(kind==='andere-alinea-splitsen-en-tekst')a.split_paragraph('body',other.paraId,1,null,null);
  if(kind==='twee-auteurs'){
   peer.insert_text('body',other.paraId,0,' Tweede ',null,null);a.apply_update(peer.encode_diff(a.encode_state_vector()));
  }
  a.insert_text('body',last.paraId,last.text.length,' Ω العربية 漢字 🙂',null,null);
  const update=a.encode_diff(vector),inference=JSON.parse(b.apply_update_with_inference(update));c.apply_update(update);
  const pa=read(a),pb=read(b),pc=read(c);const sa=JSON.parse(a.story_segments('body')),sb=JSON.parse(b.story_segments('body')),sc=JSON.parse(c.story_segments('body'));assert.deepEqual(sa,sb);assert.deepEqual(sb,sc);assert.deepEqual(pa,pb);assert.deepEqual(pb,pc);assert.deepEqual(a.encode_state_vector(),b.encode_state_vector());assert.deepEqual(b.encode_state_vector(),c.encode_state_vector());
  const fonts=a.layout_font_requirements_json(request);assert.equal(fonts,b.layout_font_requirements_json(request));assert.equal(fonts,c.layout_font_requirements_json(request));
  if(kind==='twee-auteurs')assert.equal(inference,null);else{assert(inference);assert.equal(inference.paraId,last.paraId);assert.equal(inference.story,'body')}
  const changedOther=JSON.stringify(pa.find(p=>p.paraId===other.paraId))!==JSON.stringify(beforePars.find(p=>p.paraId===other.paraId));
  if(kind==='andere-alinea-font-en-tekst')assert(fonts.includes('Liberation Serif'));
  if(kind==='andere-alinea-uitlijning-en-tekst'||kind==='andere-alinea-verwijderen-en-tekst')assert(changedOther);if(kind==='andere-alinea-splitsen-en-tekst')assert.equal(pb.length,beforePars.length+1);if(kind==='andere-alinea-uitlijning-en-tekst')assert.equal(pb.find(p=>p.paraId===other.paraId).properties.alignment,'right');
  const replay=JSON.parse(b.apply_update_with_inference(update));assert.equal(replay,null);assert.deepEqual(pb,read(b));assert.equal(fonts,b.layout_font_requirements_json(request));
  result.gevallen.push({kind,inference,herhaling_inference:replay,update_sha256:sha(update),update_bytes:update.length,bronvector_sha256:sha(b.encode_state_vector()),alinea_sha256:sha(JSON.stringify(pb)),story_segmenten_sha256:sha(JSON.stringify(sb)),font_sha256:sha(fonts),font_gewijzigd:fonts!==beforeFonts,andere_alinea_gewijzigd:changedOther,font_en_alineas_en_vector_alle_drie_exact:true,fontvereisten:JSON.parse(fonts)});
 }finally{a.free();b.free();c.free();peer.free()}
}result.geslaagd=true}catch(error){result.fout=String(error);throw error}finally{fs.writeFileSync(path.join(dir,'proef.json'),JSON.stringify(result,null,2)+'\n')}
console.log(JSON.stringify(result));
