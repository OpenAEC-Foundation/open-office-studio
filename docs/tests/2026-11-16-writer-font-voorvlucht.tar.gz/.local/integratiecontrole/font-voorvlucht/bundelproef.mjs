import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import crypto from 'node:crypto';
import {maakVoorvluchtRij}from'./wachtrij.mjs';
const map=new URL('./',import.meta.url),bron=new URL('../projectie-context/dist/assets/editors-bODdYQ4o.js',map),tekst=fs.readFileSync(bron,'utf8');
const begin=tekst.indexOf('let Nt=JSON.stringify(dt),Zt='),einde=tekst.indexOf('if(Rt(n)&&En==null)',begin);assert(begin>0&&einde>begin);const fragment=tekst.slice(begin,einde);assert.equal(tekst.split(fragment).length,2);fs.writeFileSync(new URL('kandidaat-voorvlucht.js',map),fragment);
class Kn extends Error{}const vloei=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
function opzet(begrensd,versieguard=true){
 let versie=0;const n={isDisplayOnly:()=>false},X={current:0},le={current:n},aanvragen=[],uit=[],fouten=[],compleet=[],herplan=[],rij=maakVoorvluchtRij(()=>new Kn());
 const ctx=vm.createContext({Ve:false,Rt:()=>false,cr:()=>null,V:{current:true},N:{current:{canSyncHostUpdates:()=>versieguard}},W:{current:()=>{}},n,X,le,Dn:()=>String(versie),He:{current:null},K:{current:null},ve:{current:null},pu:(a,b)=>b,mu:(a,b)=>b,b:{onLayoutComplete:e=>compleet.push(e)},Ce:()=>herplan.push(versie),jt:'local',zt:true,Fe:()=>{},_a:()=>{},Kn,mn:()=>{},Dt:(s,e)=>fouten.push(e)});
 const roep=vm.runInContext(`(function(en,dt,ct,done){const pn=En=>{${fragment}\n done(En);};pn();})`,ctx);
 return{aanvragen,uit,fouten,compleet,herplan,rij,vraag(v,omgeving={preview:v%2,font:v%3}){versie=v;const en=++X.current;ctx.W.current=(s,input)=>{const dispatch=()=>new Promise((resolve,reject)=>aanvragen.push({input,versie,resolve,reject}));return begrensd?rij.vraag(dispatch,()=>en!==X.current||le.current!==s):dispatch()};roep(en,omgeving,en,value=>uit.push({en,value}))},los(i){const a=aanvragen[i];a.resolve(JSON.stringify({versie:a.versie,input:a.input}))},versie(v){versie=v},wissel(){le.current={};++X.current;rij.stop()}};
}
const resultaten=[];
for(const guard of[false,true])for(const begrensd of[false,true]){
 const p=opzet(begrensd,guard);for(let i=1;i<=100;i++)p.vraag(i);assert.equal(p.aanvragen.length,begrensd?1:100);
 if(begrensd){p.los(0);await vloei();assert.equal(p.aanvragen.length,2);p.los(1)}else for(let i=0;i<100;i++)p.los(i);
 await vloei();assert.deepEqual(p.uit,[{en:100,value:JSON.stringify({versie:100,input:JSON.stringify({preview:0,font:1})})}]);assert.equal(p.fouten.length,0);assert.equal(p.herplan.length,0);resultaten.push({guard,begrensd,aanvragen:p.aanvragen.length,publicaties:p.uit.length,rij:p.rij.stand()});
}
const s=opzet(true);s.vraag(1);s.versie(2);s.los(0);await vloei();assert.equal(s.uit.length,0);assert.deepEqual(s.herplan,[2]);assert.deepEqual(s.compleet,[1]);
const f=opzet(true);f.vraag(1);f.vraag(2);const oud=new Error('oud'),nu=new Error('nu');f.aanvragen[0].reject(oud);await vloei();f.aanvragen[1].reject(nu);await vloei();assert.equal(f.fouten.length,1);assert.equal(f.fouten[0],nu);assert.deepEqual(f.compleet,[2]);
const u=opzet(true);u.vraag(1);u.vraag(2);u.wissel();u.los(0);await vloei();assert.equal(u.aanvragen.length,1);assert.equal(u.uit.length,0);
const rapport={geslaagd:true,bundel_sha256:crypto.createHash('sha256').update(tekst).digest('hex'),fragment_sha256:crypto.createHash('sha256').update(fragment).digest('hex'),resultaten,bronversiewijziging_zonder_nieuwe_pass:'Geen publicatie; bestaande native bronversieguard herplant en voltooit epoch1.',fouten:'Oude fout genegeerd,huidige fout exact behouden;epoch2 voltooid.',sessiewissel:'Wachtende taak geannuleerd;laat antwoord niet gepubliceerd.',grens:'Exacte voorvlucht-/pass-/bronversieguard uit ee89c80e-bundel in VM; geen volledige React-hook, Worker, Wasm, native invoer of mutatiepariteit. Wachtrij nog niet in bundel geïntegreerd.'};fs.writeFileSync(new URL('bundelrapport.json',map),JSON.stringify(rapport,null,2)+'\n');console.log(JSON.stringify(rapport));
