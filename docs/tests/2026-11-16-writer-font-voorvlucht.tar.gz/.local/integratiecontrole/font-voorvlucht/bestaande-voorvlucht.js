          const pendingRequirements =
            !onHost && (isViewerSession(session) || workerOpenEnabledRef.current ||
              registeredWorkerProposalAuthority(session)?.holdsWorkerState()) &&
              workerRequirements === undefined
              ? fontRequirementsInWorkerRef.current?.(session, input)
              : null;
          if (pendingRequirements) {
            void pendingRequirements.then(
              (requirements) => {
                if (pass === passRef.current && sessionRef.current === session) run(requirements);
              },
              (error) => {
                if (pass !== passRef.current || sessionRef.current !== session) return;
                invalidateRetainedLayout();
                markLayoutQueued(session, false);
                // A superseded preflight drops its pass; the pass that superseded it lays out.
                if (!(error instanceof SupersededPreviewError)) {
                  reportLayoutError(session, error);
                } else if (isViewerSession(session) && !session.isDisplayOnly?.()) {
                  queueWorkerPass(session);
                  requestPass();
                }
                syncCoordinator.onLayoutComplete(currentEpoch);
              }
            );
            return;
          }
