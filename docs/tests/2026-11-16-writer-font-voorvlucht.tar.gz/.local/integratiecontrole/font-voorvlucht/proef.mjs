import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { maakVoorvluchtRij } from './wachtrij.mjs';
const map=new URL('./',import.meta.url);
const bron=new URL('../font-hergebruik/bron/packages/docx-react/src/components/DocxEditor/hooks/useLayoutPipeline.ts',map);
const tekst=fs.readFileSync(bron,'utf8'),begin=tekst.indexOf('          const pendingRequirements ='),einde=tekst.indexOf('          if (isViewerSession(session) && workerRequirements == null)',begin);
assert(begin>0&&einde>begin);const origineel=tekst.slice(begin,einde);assert.equal(origineel.split('(error: unknown)').length,2);const fragment=origineel.replace('(error: unknown)','(error)');assert.equal(tekst.split(origineel).length,2);fs.writeFileSync(new URL('bestaande-voorvlucht.js',map),fragment);
class SupersededPreviewError extends Error {}
const vloei=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
function opzet(begrensd) {
 const sessie={},passRef={current:0},sessionRef={current:sessie},aanvragen=[],resultaten=[],fouten=[],compleet=[];
 const rij=maakVoorvluchtRij(()=>new SupersededPreviewError());let versie=0;
 function dispatch(input){return new Promise((resolve,reject)=>aanvragen.push({input,versie,resolve,reject}))}
 const ctx=vm.createContext({onHost:false,isViewerSession:()=>false,workerOpenEnabledRef:{current:true},registeredWorkerProposalAuthority:()=>null,session:sessie,sessionRef,passRef,fontRequirementsInWorkerRef:{current:()=>{}},invalidateRetainedLayout:()=>{},markLayoutQueued:()=>{},reportLayoutError:(s,e)=>fouten.push(e),syncCoordinator:{onLayoutComplete:e=>compleet.push(e)},SupersededPreviewError,queueWorkerPass:()=>{},requestPass:()=>{},console});
 const maak=vm.runInContext(`(function(pass,input,currentEpoch,done){const run=(workerRequirements)=>{${fragment}\n done(workerRequirements);};run();})`,ctx);
 return {aanvragen,resultaten,fouten,compleet,rij,passRef,
  vraag(n,input=`omgeving-${n%3}`){versie=n;const pass=++passRef.current;ctx.fontRequirementsInWorkerRef.current=(s,i)=>begrensd?rij.vraag(()=>dispatch(i),()=>pass!==passRef.current||sessionRef.current!==s):dispatch(i);maak(pass,input,pass,value=>resultaten.push({pass,value}));},
  los(i){const a=aanvragen[i];a.resolve(JSON.stringify({versie:a.versie,input:a.input}));},
  wissel(){sessionRef.current={};++passRef.current;rij.stop();}
 };
}
const vergelijk=[];
for(const begrensd of [false,true]){
 const p=opzet(begrensd);for(let i=1;i<=100;i++)p.vraag(i);
 assert.equal(p.aanvragen.length,begrensd?1:100);
 if(begrensd){p.los(0);await vloei();assert.equal(p.aanvragen.length,2);assert.equal(p.aanvragen[1].versie,100);p.los(1);}else for(let i=0;i<100;i++)p.los(i);
 await vloei();assert.deepEqual(p.resultaten,[{pass:100,value:JSON.stringify({versie:100,input:'omgeving-1'})}]);assert.equal(p.fouten.length,0);
 vergelijk.push({begrensd,aanvragen:p.aanvragen.length,resultaten:p.resultaten,rij:p.rij.stand()});
}
// Een fout bij de huidige aanvraag blijft zichtbaar; een oude fout overschrijft die niet.
const f=opzet(true);f.vraag(1);f.vraag(2);const oud=new Error('oude fout'),nu=new Error('huidige fout');f.aanvragen[0].reject(oud);await vloei();f.aanvragen[1].reject(nu);await vloei();assert.equal(f.fouten.length,1);assert.equal(f.fouten[0],nu);assert.deepEqual(f.compleet,[2]);
// Wissel/unmount: wachtend werk vervalt, een laat antwoord publiceert niets.
const w=opzet(true);w.vraag(1);w.vraag(2);w.wissel();w.los(0);await vloei();assert.equal(w.aanvragen.length,1);assert.equal(w.resultaten.length,0);assert.equal(w.fouten.length,0);
// Zonder bewijs van achterhaaldheid blijft de andere gebruiker werken.
let resolve;const rij=maakVoorvluchtRij(()=>new SupersededPreviewError());const p1=rij.vraag(()=>new Promise(r=>resolve=r),()=>false),p2=rij.vraag(()=>2,()=>false),p3=rij.vraag(()=>3,()=>false);assert.equal(await p3,3);resolve(1);assert.equal(await p1,1);assert.equal(await p2,2);await vloei();assert.equal(rij.stand().terugval,1);
const rapport={geslaagd:true,bron_sha256:crypto.createHash('sha256').update(tekst).digest('hex'),fragment_sha256:crypto.createHash('sha256').update(fragment).digest('hex'),vergelijk,proeven:['100 opeenvolgende versies en drie verschillende volledige inputstrings; alleen laatste resultaat identiek','Huidige fout behouden; oude fout niet gepubliceerd','Sessieovergang/unmount en laat antwoord leveren geen publicatie','Geen bewezen achterhaaldheid: andere gebruiker niet annuleren'],grens:'Exacte bestaande Promise-/passguard uit primaire TS-bron uitgevoerd in gecontroleerde VM, geen volledige React-hook, Worker, echte Wasm of native desktop. Geen bron/env- of mutatiepariteit bewezen en geen snelheidsclaim. Private rij nog niet in hook of product geïntegreerd.'};fs.writeFileSync(new URL('rapport.json',map),JSON.stringify(rapport,null,2)+'\n');console.log(JSON.stringify(rapport));
