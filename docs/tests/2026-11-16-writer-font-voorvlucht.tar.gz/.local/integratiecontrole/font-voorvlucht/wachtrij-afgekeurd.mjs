/** Private proef: alleen aantoonbaar achterhaalde wachtende voorvluchten vervangen. */
export function maakVoorvluchtRij(achterhaald) {
  let actief = null, wachtend = null, gestopt = false;
  const telling = { gestart: 0, vervangen: 0, terugval: 0 };
  function start(taak) {
    actief = taak; telling.gestart++;
    let resultaat;
    try { resultaat = taak.uitvoeren(); } catch (fout) { resultaat = Promise.reject(fout); }
    Promise.resolve(resultaat).then(taak.resolve, taak.reject).finally(() => {
      if (actief !== taak) throw Error('Onjuiste voorvluchteigenaar');
      actief = null;
      const volgende = wachtend; wachtend = null;
      if (volgende) start(volgende);
    });
  }
  return {
    vraag(uitvoeren, isAchterhaald) {
      if (gestopt) return Promise.reject(achterhaald());
      return new Promise((resolve, reject) => {
        const taak = { uitvoeren, isAchterhaald, resolve, reject };
        if (!actief) { start(taak); return; }
        if (wachtend) {
          if (!wachtend.isAchterhaald()) {
            // Zonder bewijs geen andere gebruiker annuleren of blokkeren.
            telling.terugval++;
            try { Promise.resolve(uitvoeren()).then(resolve, reject); } catch(fout) { reject(fout); }
            return;
          }
          telling.vervangen++; wachtend.reject(achterhaald());
        }
        wachtend = taak;
      });
    },
    stop() { gestopt = true; if (wachtend) { wachtend.reject(achterhaald()); wachtend = null; } },
    stand() { return { ...telling, actief: !!actief, wachtend: !!wachtend, gestopt }; }
  };
}
