from pathlib import Path
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/opslaggereed53';s=(r/'scripts/test-writer-rust-tekst-native.py').read_text().replace('REPO = Path(__file__).resolve().parents[1]',f'REPO = Path({str(r)!r})').replace("REPO / 'docs/voorbeelden/Ontwerpnotitie.docx'","REPO / 'docs/tests/writer-doortypen/bron.docx'")
base=(r/'scripts/test-writer-lang-native.py').read_text();a='            await p.ev("window._docRef=';i=base.index(a);j=base.index('\n',i);meet=base[i:j].strip().replace('proefApi()','api()')
a='                await p.begin_foutbewaking()\n';i=s.index(a)+len(a);j=s.index("                r['geslaagd'] = True",i)
body='''                await p.ev("window._toetsen=[];window.addEventListener('keyup',e=>_toetsen.push(e.key.toLowerCase()),true);window.sessie=()=>api().getEditorRef().getYrsSession();window.tekst=()=>sessie().paragraphs('body').map(p=>p.text).join('');true")
                VOEG_METING_TOE
                def bronstand_code():
                    return "Object.fromEntries(sessie().storyIds().sort().map(id=>[id,sessie().paragraphs(id).map(p=>p.text)]))"
                verwacht = await p.ev(bronstand_code())
                assert len(verwacht)==1537 and sum(map(len,verwacht.values()))==3329
                r['bewaarproeven']=[]
                api_voor=await p.ev('_docSeen.has(api())')
                assert api_voor
                for n in range(1,4):
                    await p.ev('api().focus();true')
                    await toets(p,'ctrl+End')
                    marker=' '+str(70+n)
                    subprocess.run(['xdotool','type','--clearmodifiers','--delay','20',marker],check=True)
                    await toets(p,'Right')
                    verwacht['body'][-1]+=marker
                    assert await p.ev(bronstand_code())==verwacht,'Invoeging wijkt af'
                    voor=bron.stat().st_mtime_ns
                    await p.ev('_docProef.calls=0;_docProef.ms=0;true')
                    begin=time.monotonic()
                    await toets(p,'ctrl+s',leeg=False)
                    eind=time.monotonic()+30
                    while True:
                        klaar=await p.ev("(()=>{const b=document.querySelector('button.office-snelknop[aria-label=\\"Save\\"]');if(!b)throw Error('Opslagknop ontbreekt');return !b.disabled})()")
                        if bron.stat().st_mtime_ns!=voor and klaar:break
                        assert time.monotonic()<eind,'Bewaren niet afgerond'
                        await asyncio.sleep(.03)
                    ms=(time.monotonic()-begin)*1000
                    meting=await p.ev('({..._docProef,actieve_api_gevolgd:_docSeen.has(api())})')
                    assert meting['actieve_api_gevolgd']
                    with ZipFile(bron)as z:xml=ET.fromstring(z.read('word/document.xml'))
                    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                    bodyxml=xml.find('w:body',ns)
                    bodyteksten=[''.join(t.text or ''for t in par.findall('.//w:t',ns))for par in bodyxml.findall('w:p',ns)]
                    assert bodyteksten==verwacht['body'],'Bewaring mist bodytekst'
                    from collections import Counter
                    cellen=[''.join(t.text or ''for t in c.findall('.//w:t',ns))for tabel in bodyxml.findall('w:tbl',ns)for rij in tabel.findall('w:tr',ns)for c in rij.findall('w:tc',ns)]
                    assert Counter(cellen)==Counter(''.join(v)for k,v in verwacht.items()if k!='body'),'Bewaring wijzigt celteksten'
                    assert await p.ev(bronstand_code())==verwacht,'Bron na bewaren wijkt af'
                    r['bewaarproeven'].append({'ronde':n,'ctrl_s_tot_file_en_knop_gereed_ms':ms,'getDocument':meting,'docx_sha256':hashlib.sha256(bron.read_bytes()).hexdigest(),'body_en_cellen_exact':True})
                    shutil.copyfile(bron,a.uitvoer/('bewaard-'+str(n)+'.docx'))
                await p.ev("Object.defineProperty(_docRef,'current',{..._docDescriptor,value:_docValue});for(const[a,oud]of _docOrig)a.getDocument=oud;true")
                r['fouten']=await p.fouten();assert not any(r['fouten'].values())
                r['stappen'].append('Drie echte Ctrl+S-opdrachten met voorafgaande invoer, bron-/API-bewaking en onafhankelijke DOCX-body-/celcontrole')
                beeld('na-drie-bewaringen')
'''.replace('VOEG_METING_TOE',meet)
s=s[:i]+body+s[j:];p=u/'bewaarproef.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s)
