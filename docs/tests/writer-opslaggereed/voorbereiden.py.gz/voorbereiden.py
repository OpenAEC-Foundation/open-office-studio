from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/opslaggereed53';bron=u/'bron';assert not bron.exists()
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert commit=='8c25cf1d431f441921e48856b1693fd5f257ab8e'
b=subprocess.check_output(['git','archive',commit]);
with tarfile.open(fileobj=io.BytesIO(b))as t:t.extractall(bron,filter='data')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();basis={str(p.relative_to(bron)):h(p)for p in bron.rglob('*')if p.is_file()}
mod=bron/'node_modules';mod.mkdir()
for p in (r/'node_modules').iterdir():
 if p.name.startswith('.vite')or p.name=='.cache':continue
 (mod/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
test='src/tekst/opslaggereed.test.ts';(bron/test).write_bytes((u/'opslaggereed.test.ts').read_bytes())
env=os.environ.copy();node=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';env['PATH']=str(node.parent)+':'+env['PATH']
with (u/'regressie-oud.log').open('w')as log:p=subprocess.run([str(node),'node_modules/vitest/vitest.mjs','run',test],cwd=bron,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode!=0 and 'Onnodige volledige documentprojectie' in (u/'regressie-oud.log').read_text()
f=bron/'src/editors.tsx';s=f.read_text();a='if (!ref?.getDocument())';assert s.count(a)==1;s=s.replace(a,'if (!ref?.getEditorRef()?.getYrsSession())');f.write_text(s)
subprocess.run([str(node),'scripts/weekversie.mjs','2026-11-06','53'],cwd=bron,env=env,check=True)
f=bron/'src-tauri/tauri.conf.json';c=json.loads(f.read_text());c['build']['beforeBuildCommand']='python3 '+str(u/'voorbouw.py');f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
wijzig={k:h(bron/k)for k,sha in basis.items()if h(bron/k)!=sha};assert set(wijzig)=={'src/editors.tsx','package.json','versie.json','src-tauri/tauri.conf.json','src-tauri/Cargo.toml','src-tauri/Cargo.lock','apps/database-studio/src-tauri/tauri.conf.json','apps/database-studio/src-tauri/Cargo.toml','apps/database-studio/src-tauri/Cargo.lock'}
(u/'bronnen.json').write_text(json.dumps({'basis':commit,'bestanden':basis,'wijzigingen':wijzig,'toegevoegd':{test:h(bron/test)},'sdk_sha256':h(mod/'@betteroffice/docx-react/dist/index.mjs'),'oude_regressie_code':p.returncode},indent=2)+'\n')
print('Afzonderlijke kandidaat 45.53 voorbereid; oorspronkelijke bron en SDK behouden')
