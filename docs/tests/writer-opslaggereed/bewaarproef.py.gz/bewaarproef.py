#!/usr/bin/env python3
"""Echte native tekstinvoer: Undo, selectie en bewaren tijdens een vertraagd Rust-antwoord.

Alleen het terugbezorgen van een werkelijk berekend tekstantwoord wordt
vastgehouden. Eigen bron/profiel/venster; dit is geen snelheidsmeting.
"""
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
from xml.etree import ElementTree as ET
from zipfile import ZipFile

REPO = Path('/home/aia01/Documenten/GitHub/Open-Office-Studio')
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('basis', REPO / 'scripts/test-writer-lang-native.py')
basis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(basis)


async def proef(a):
    from Xlib import X, display
    from PIL import Image
    from gui.webkit_inspector import Inspector
    a.uitvoer.mkdir(parents=True, exist_ok=False)
    bron = a.uitvoer / 'Ontwerpnotitie.docx'
    shutil.copyfile(REPO / 'docs/tests/writer-doortypen/bron.docx', bron)
    cfg = Path(os.environ['XDG_CONFIG_HOME']) / 'org.openaec.office-studio'
    cfg.mkdir(parents=True)
    (cfg / 'voorkeuren.json').write_text(json.dumps({'taal': 'en', 'thema': 'forge', 'updates': {'automatisch': False}}))
    subprocess.run(['dbus-update-activation-environment', 'DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME'], check=True)
    d = display.Display()
    log = (a.uitvoer / 'programma.log').open('w')
    app = subprocess.Popen([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    r = {'geslaagd': False, 'versie': a.versie, 'programma_sha256': hashlib.sha256(a.programma.read_bytes()).hexdigest(), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'stappen': [], 'grenzen': __doc__}
    v = None

    def stop():
        if app.poll() is None:
            try:
                os.killpg(app.pid, signal.SIGTERM)
                app.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(app.pid, signal.SIGKILL)
                app.wait(timeout=10)
            except ProcessLookupError:
                pass

    timer = threading.Timer(360, stop)
    timer.daemon = True
    timer.start()

    def beeld(naam):
        g = v.get_geometry()
        raw = v.get_image(0, 0, g.width, g.height, X.ZPixmap, 0xffffffff)
        Image.frombytes('RGB', (g.width, g.height), raw.data, 'raw', 'BGRX').save(a.uitvoer / (naam + '.png'))

    async def toets(p, *toetsen, leeg=True):
        vanaf = await p.ev('_toetsen.length')
        subprocess.run(['xdotool', 'key', '--clearmodifiers', *toetsen], check=True)
        laatste = {'left': 'arrowleft', 'right': 'arrowright'}.get(toetsen[-1].split('+')[-1].lower(), toetsen[-1].split('+')[-1].lower())
        await p.run('let eind=performance.now()+10000;while(!_toetsen.slice(' + str(vanaf) + ').includes(' + json.dumps(laatste) + ')){if(performance.now()>eind)throw Error("Toets niet ontvangen");await new Promise(r=>setTimeout(r,20))}return true;')
        if leeg:
            await p.run('await api().flushPendingInput();return true;')

    async def klik(p, expressie):
        xy = await p.ev('(()=>{let e=' + expressie + ';if(!e)throw Error("Geen knop");let r=e.getBoundingClientRect();return{x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)}})()')
        subprocess.run(['xdotool', 'mousemove', '--window', str(v.id), str(xy['x']), str(xy['y']), 'click', '1'], check=True)

    try:
        eind = time.monotonic()+60
        while v is None and time.monotonic() < eind:
            assert app.poll() is None
            for w in d.screen().root.query_tree().children:
                pid = w.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
                if w.get_attributes().map_state == X.IsViewable and pid is not None and int(pid.value[0]) == app.pid:
                    v = w
                    break
            await asyncio.sleep(.1)
        assert v, 'Geen eigen venster'
        pid_prop = v.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
        pid = int(pid_prop.value[0])
        werkelijk = Path(f'/proc/{pid}/exe').read_bytes()
        assert werkelijk.startswith(b'\x7fELF')
        r['startprogramma_sha256'] = r['programma_sha256']
        r['programma_sha256'] = hashlib.sha256(werkelijk).hexdigest()
        v.configure(x=0, y=0, width=1440, height=1000)
        v.set_input_focus(X.RevertToParent, X.CurrentTime)
        d.sync()
        await asyncio.sleep(12)
        async with Inspector(int(os.environ['OFFICE_PROEF_HTTP'])) as p:
            try:
                await p.run("window.api=()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return null;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next){let v=s.memoizedState?.current;if(v?.getEditorRef&&v.commands)return v}return null};let eind=performance.now()+60000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen sessie');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true;")
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|version');") == a.versie
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|identifier');") == 'org.openaec.office-studio'
                await p.begin_foutbewaking()
                await p.ev("window._toetsen=[];window.addEventListener('keyup',e=>_toetsen.push(e.key.toLowerCase()),true);window.sessie=()=>api().getEditorRef().getYrsSession();window.tekst=()=>sessie().paragraphs('body').map(p=>p.text).join('');true")
                await p.ev("window._docRef=(()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next)if(s.memoizedState?.current?.getEditorRef&&s.memoizedState.current.commands)return s.memoizedState;throw Error('API-ref ontbreekt')})();window._docDescriptor=Object.getOwnPropertyDescriptor(_docRef,'current');if(!_docDescriptor?.configurable||!('value' in _docDescriptor))throw Error('API-ref niet meetbaar');window._docValue=_docRef.current;window._docProef={calls:0,ms:0,api_wissels:0};window._docOrig=[];window._docSeen=new WeakSet;window._docVolg=a=>{if(!a||_docSeen.has(a))return;let oud=a.getDocument;if(typeof oud!=='function')throw Error('GetDocument-meetpunt ontbreekt');_docSeen.add(a);_docOrig.push([a,oud]);a.getDocument=function(...args){_docProef.calls++;let begin=performance.now();try{return oud.apply(this,args)}finally{_docProef.ms+=performance.now()-begin}}};_docVolg(_docValue);Object.defineProperty(_docRef,'current',{configurable:true,enumerable:_docDescriptor.enumerable,get(){return _docValue},set(a){_docProef.api_wissels++;_docVolg(a);_docValue=a}});true")
                def bronstand_code():
                    return "Object.fromEntries(sessie().storyIds().sort().map(id=>[id,sessie().paragraphs(id).map(p=>p.text)]))"
                verwacht = await p.ev(bronstand_code())
                assert len(verwacht)==1537 and sum(map(len,verwacht.values()))==3329
                r['bewaarproeven']=[]
                api_voor=await p.ev('_docSeen.has(api())')
                assert api_voor
                for n in range(1,4):
                    await p.ev('api().focus();true')
                    await toets(p,'ctrl+End')
                    marker=' '+str(70+n)
                    subprocess.run(['xdotool','type','--clearmodifiers','--delay','20',marker],check=True)
                    await toets(p,'Right')
                    verwacht['body'][-1]+=marker
                    assert await p.ev(bronstand_code())==verwacht,'Invoeging wijkt af'
                    voor=bron.stat().st_mtime_ns
                    await p.ev('_docProef.calls=0;_docProef.ms=0;true')
                    begin=time.monotonic()
                    await toets(p,'ctrl+s',leeg=False)
                    eind=time.monotonic()+30
                    while True:
                        klaar=await p.ev("(()=>{const b=document.querySelector('button.office-snelknop[aria-label=\"Save\"]');if(!b)throw Error('Opslagknop ontbreekt');return !b.disabled})()")
                        if bron.stat().st_mtime_ns!=voor and klaar:break
                        assert time.monotonic()<eind,'Bewaren niet afgerond'
                        await asyncio.sleep(.03)
                    ms=(time.monotonic()-begin)*1000
                    meting=await p.ev('({..._docProef,actieve_api_gevolgd:_docSeen.has(api())})')
                    assert meting['actieve_api_gevolgd']
                    with ZipFile(bron)as z:xml=ET.fromstring(z.read('word/document.xml'))
                    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                    bodyxml=xml.find('w:body',ns)
                    bodyteksten=[''.join(t.text or ''for t in par.findall('.//w:t',ns))for par in bodyxml.findall('w:p',ns)]
                    assert bodyteksten==verwacht['body'],'Bewaring mist bodytekst'
                    from collections import Counter
                    cellen=[''.join(t.text or ''for t in c.findall('.//w:t',ns))for tabel in bodyxml.findall('w:tbl',ns)for rij in tabel.findall('w:tr',ns)for c in rij.findall('w:tc',ns)]
                    assert Counter(cellen)==Counter(''.join(v)for k,v in verwacht.items()if k!='body'),'Bewaring wijzigt celteksten'
                    assert await p.ev(bronstand_code())==verwacht,'Bron na bewaren wijkt af'
                    r['bewaarproeven'].append({'ronde':n,'ctrl_s_tot_file_en_knop_gereed_ms':ms,'getDocument':meting,'docx_sha256':hashlib.sha256(bron.read_bytes()).hexdigest(),'body_en_cellen_exact':True})
                    shutil.copyfile(bron,a.uitvoer/('bewaard-'+str(n)+'.docx'))
                await p.ev("Object.defineProperty(_docRef,'current',{..._docDescriptor,value:_docValue});for(const[a,oud]of _docOrig)a.getDocument=oud;true")
                r['fouten']=await p.fouten();assert not any(r['fouten'].values())
                r['stappen'].append('Drie echte Ctrl+S-opdrachten met voorafgaande invoer, bron-/API-bewaking en onafhankelijke DOCX-body-/celcontrole')
                beeld('na-drie-bewaringen')
                r['geslaagd'] = True
            finally:
                try:
                    r['diagnose'] = await p.ev('({opdrachten:window._rust?.aanvragen,updates:window._rust?.updates,selecties:window._diagnose,selectie:api()?.getEditorRef()?.getYrsSession()?.selection(),begin:api()?tekst().slice(0,100):null,eind:api()?tekst().slice(-100):null})')
                except Exception as diagnosefout:
                    r['diagnosefout'] = str(diagnosefout)

    except Exception as fout:
        r['fout'] = repr(fout)
        if 'p' in locals():
            r['console_bij_afkeuring'] = p.consoleberichten
        if v and app.poll() is None:
            try:
                beeld('afgekeurd')
            except Exception as beeldfout:
                r['beeldfout'] = repr(beeldfout)
        raise
    finally:
        timer.cancel()
        stop()
        d.close()
        log.close()
        (a.uitvoer / 'rapport.json').write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
    return 0


basis.proef = proef
basis.__file__ = str(Path(__file__).resolve())
if __name__ == '__main__':
    raise SystemExit(basis.main())
