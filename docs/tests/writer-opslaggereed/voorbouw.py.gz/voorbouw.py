import os,subprocess
from pathlib import Path
from controleer import controleer,BRON
controleer();node=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
for cmd in [[str(node),'scripts/kopieer-assets.mjs'],[str(node),'node_modules/typescript/bin/tsc','--noEmit'],[str(node),'node_modules/vite/bin/vite.js','build']]:subprocess.run(cmd,cwd=BRON,check=True)
controleer()
