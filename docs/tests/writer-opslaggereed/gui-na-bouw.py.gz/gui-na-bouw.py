"""Eindige vervolgproeven op uitsluitend de eigen 45.53-bouw; geen promotie."""
from pathlib import Path
import os,json,hashlib,subprocess,time
r=Path(__file__).resolve().parents[3];u=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rootbronnen={str(p.relative_to(r)):h(p)for p in(r/'scripts').rglob('*')if p.is_file()and p.suffix in ['.py','.js','.json','.txt','.mjs']}
(u/'gui-bronnen.json').write_text(json.dumps(rootbronnen,indent=2)+'\n');rapport=[]
def logboek(): (u/'gui-voortgang.json').write_text(json.dumps(rapport,indent=2)+'\n')
bouwpid=json.loads((u/'actief.json').read_text())['pids'][0];eind=time.monotonic()+2700
while not(u/'gebouwd.json').exists():
 if not Path(f'/proc/{bouwpid}').exists()or time.monotonic()>eind:
  rapport.append({'fase':'wachten','code':1,'reden':'Bouw niet voltooid; geen GUI-proeven gestart'});logboek();raise SystemExit(1)
 time.sleep(5)
meta=json.loads((u/'gebouwd.json').read_text());exe=Path(meta['programma']);assert h(exe)==meta['programma_sha256'];oud=r/'.local/doorwerk-2026-11-06/autocorrectie-invoer/open-office-studio-45.52-autocorrectie';assert h(oud)=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039'
env=os.environ.copy();env['PATH']=str(r/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+str(Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin')+':'+env['PATH'];py=str(r/'.local/doorwerk-2026-11-02/gui-python/bin/python')
proeven=[('tekst','scripts/test-writer-rust-tekst-native.py',[]),('plakken','scripts/test-writer-rijk-plakken-native.py',['--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken']),('lang','scripts/test-writer-lang-native.py',['--herstelstart','--verwacht-rust-tekst','--verwacht-incrementele-bron','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--workerbron'])]
for naam,script,args in proeven:
 for n,sha in rootbronnen.items():assert h(r/n)==sha,n
 cmd=[py,str(r/script),'--programma',str(exe),'--versie','2026.45.53','--uitvoer',str(u/('gui-'+naam)),*args]
 print('START',naam,flush=True);begin=time.monotonic()
 with(u/('gui-'+naam+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 rapport.append({'fase':naam,'code':p.returncode,'seconden':time.monotonic()-begin,'programma_sha256':h(exe),'opdracht':cmd});logboek();print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
uit=u/'gui-abba';uit.mkdir(exist_ok=False);tekst=json.loads((r/'.local/doorwerk-2026-11-04/incrementele-invoer/doortypen-38-zonder-profiel/profiel.json').read_text())['invoertekst']
for naam,programma,versie in [('referentie-a',oud,'2026.45.52'),('kandidaat-a',exe,'2026.45.53'),('kandidaat-b',exe,'2026.45.53'),('referentie-b',oud,'2026.45.52')]:
 druk=[]
 for p in Path('/proc').glob('[0-9]*/comm'):
  try:
   n=p.read_text().strip()
   if n in ['cargo','rustc','rust-lld','ld.lld','cc']or n.startswith('node (vitest'):druk.append(n)
  except OSError:pass
 if druk:
  rapport.append({'fase':naam,'code':2,'reden':'Geen rastervergelijking tijdens andere compiler','processen':druk});logboek();raise SystemExit(2)
 cmd=[py,str(r/'native/onderzoek/writer-desktopcache/meten.py'),'--zonder-profiel','--programma',str(programma),'--versie',versie,'--bron',str(r/'docs/tests/writer-doortypen/bron.docx'),'--paginas','129','--tekst',tekst,'--uitvoer',str(uit/naam)]
 print('START',naam,flush=True);begin=time.monotonic()
 with(uit/(naam+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 rapport.append({'fase':naam,'code':p.returncode,'seconden':time.monotonic()-begin,'programma_sha256':h(programma),'opdracht':cmd,'achtergrond_bij_start':druk});logboek();print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('Vervolgproeven klaar; resultaat handmatig beoordelen, geen automatische promotie.',flush=True)
