from pathlib import Path
import os,json,hashlib,subprocess
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/opslaggereed53';oud=r/'.local/doorwerk-2026-11-06/autocorrectie-invoer/open-office-studio-45.52-autocorrectie';nieuw=Path(json.loads((u/'gebouwd.json').read_text())['programma']);assert hashlib.sha256(oud.read_bytes()).hexdigest()=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039';assert hashlib.sha256(nieuw.read_bytes()).hexdigest()==json.loads((u/'gebouwd.json').read_text())['programma_sha256'];env=os.environ.copy();env['PATH']=str(r/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];py=str(r/'.local/doorwerk-2026-11-02/gui-python/bin/python');result=[];tekst=json.loads((r/'.local/doorwerk-2026-11-04/incrementele-invoer/doortypen-38-zonder-profiel/profiel.json').read_text())['invoertekst']
for soort,volgorde in [('typen-baab',[('nieuw-a',nieuw,'2026.45.53'),('oud-a',oud,'2026.45.52'),('oud-b',oud,'2026.45.52'),('nieuw-b',nieuw,'2026.45.53')]),('bewaar-frames',[('oud-a',oud,'2026.45.52'),('nieuw-a',nieuw,'2026.45.53'),('nieuw-b',nieuw,'2026.45.53'),('oud-b',oud,'2026.45.52')])]:
 uit=u/soort;uit.mkdir(exist_ok=False)
 for naam,exe,versie in volgorde:
  druk=[]
  for p in Path('/proc').glob('[0-9]*/comm'):
   try:
    n=p.read_text().strip()
    if n in ['cargo','rustc','rust-lld','ld.lld','cc']or n.startswith('node (vitest'):druk.append(n)
   except OSError:pass
  assert not druk,druk
  if soort=='typen-baab':cmd=[py,str(r/'native/onderzoek/writer-desktopcache/meten.py'),'--zonder-profiel','--programma',str(exe),'--versie',versie,'--bron',str(r/'docs/tests/writer-doortypen/bron.docx'),'--paginas','129','--tekst',tekst,'--uitvoer',str(uit/naam)]
  else:cmd=[py,str(u/'bewaarproef-frames.py'),'--programma',str(exe),'--versie',versie,'--uitvoer',str(uit/naam)]
  print('START',soort,naam,flush=True)
  with(uit/(naam+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  result.append({'soort':soort,'naam':naam,'code':p.returncode,'opdracht':cmd,'programma_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'achtergrond_bij_start':druk});(u/'herhaling.json').write_text(json.dumps(result,indent=2)+'\n');print('EINDE',soort,naam,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
