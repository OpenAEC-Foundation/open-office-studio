from pathlib import Path
import hashlib,json
UIT=Path(__file__).resolve().parent;BRON=UIT/'bron'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def controleer():
 m=json.loads((UIT/'bronnen.json').read_text())
 for naam,h in {**m['bestanden'],**m['wijzigingen'],**m['toegevoegd']}.items():assert sha(BRON/naam)==h,naam
 assert sha(BRON/'node_modules/@betteroffice/docx-react/dist/index.mjs')==m['sdk_sha256']
 return m
