from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/opslaggereed53';bron=u/'bron';assert bron.is_dir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();commit='8c25cf1d431f441921e48856b1693fd5f257ab8e';basis={}
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',commit])))as t:
 for f in t:
  if f.isfile():
   digest=hashlib.sha256(t.extractfile(f).read()).hexdigest();basis[f.name]=digest;assert h(bron/f.name)==digest,f.name
assert (bron/'node_modules/@betteroffice/docx-react/dist/index.mjs').samefile(r/'node_modules/@betteroffice/docx-react/dist/index.mjs')
test='src/tekst/opslaggereed.test.ts';assert h(bron/test)==h(u/'opslaggereed.test.ts')
assert 'Onnodige volledige documentprojectie' in(u/'regressie-oud.log').read_text()
f=bron/'src/editors.tsx';s=f.read_text();a='const ref = docx.current;\n      if (!ref?.getDocument())';assert s.count(a)==1;s=s.replace(a,'const ref = docx.current;\n      if (!ref?.getEditorRef()?.getYrsSession())');f.write_text(s)
node=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';env=os.environ.copy();env['PATH']=str(node.parent)+':'+env['PATH'];subprocess.run([str(node),'scripts/weekversie.mjs','2026-11-06','53'],cwd=bron,env=env,check=True)
f=bron/'src-tauri/tauri.conf.json';c=json.loads(f.read_text());c['build']['beforeBuildCommand']='python3 '+str(u/'voorbouw.py');f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
wijzig={k:h(bron/k)for k,sha in basis.items()if h(bron/k)!=sha};assert set(wijzig)=={'src/editors.tsx','package.json','versie.json','src-tauri/tauri.conf.json','src-tauri/Cargo.toml','src-tauri/Cargo.lock','apps/database-studio/src-tauri/tauri.conf.json','apps/database-studio/src-tauri/Cargo.toml','apps/database-studio/src-tauri/Cargo.lock'}
(u/'bronnen.json').write_text(json.dumps({'basis':commit,'bestanden':basis,'wijzigingen':wijzig,'toegevoegd':{test:h(bron/test)},'sdk_sha256':h(bron/'node_modules/@betteroffice/docx-react/dist/index.mjs'),'oude_regressie_code':1,'opzetafkeuring':'Eerste algemene guard-anker kwam tweemaal voor; gestopt vóór patch. Deze opzet richt zich alleen op docx.current en verifieert eerst alle oorspronkelijke bronbytes.'},indent=2)+'\n');print('45.53-kandidaat gericht voorbereid; alle overige bronbytes behouden')
