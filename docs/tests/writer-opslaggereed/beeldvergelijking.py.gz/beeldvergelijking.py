from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib
u=Path(__file__).resolve().parent;ref=u/'gui-abba/referentie-a/profiel.png';beeld=Image.open(ref).convert('RGB');r=[]
for groep in ['gui-abba','typen-baab']:
 for p in sorted((u/groep).glob('*/profiel.png')):
  b=Image.open(p).convert('RGB');assert b.size==beeld.size==(1440,1000);diff=ImageChops.difference(beeld,b);bbox=diff.getbbox();document=diff.copy();pixels=document.load();
  for x in range(491,496):
   for y in range(347,366):pixels[x,y]=(0,0,0)
  document_bbox=document.crop((320,210,1140,950)).getbbox();assert document_bbox is None
  r.append({'bestand':str(p.relative_to(u)),'referentie':str(ref.relative_to(u)),'grootte':list(b.size),'verschil_bbox':bbox,'document_roi':[320,210,1140,950],'cursorzone':[491,347,496,366],'document_verschil_bbox':document_bbox,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
d={'grens':'Statische eindbeelden op één 129-paginabron; geen dialoog-, alle pagina-, thema- of animatieacceptatie. De eerste proef las een reeds uitgesneden 670x68 beeld met schermcoördinaten en gaf IndexError vóór een conclusie; deze proef vergelijkt alleen de volledige 1440x1000 beelden met ruwe verschilrechthoek plus afzonderlijke documentvergelijking buiten de vooraf vastgelegde cursorzone.','beelden':r};(u/'beeldvergelijking.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(d,ensure_ascii=False))
