/** Voer de werkelijke geregistreerde opslagcallback uit zonder de hele interface. */
import { readFileSync } from 'node:fs';
import { describe, expect, it, vi } from 'vitest';
const bron = readFileSync('src/editors.tsx', 'utf8');
const begin = bron.indexOf('    props.registreer(async () => {');
const slot = '\n    });', einde = bron.indexOf(slot, begin);
if (begin < 0 || einde < 0) throw Error('Opslagcallback niet gevonden');
const registreer = new Function('props', 'docx', 'interneOpslag', 'i18next', 'werkEigenschappenBij', 'herladen', bron.slice(begin, einde + slot.length));
function proef() {
  let opslaan!: () => Promise<Uint8Array>;
  const bytes = new Uint8Array([1, 7, 3]);
  const ref = {
    getDocument: vi.fn(() => { throw Error('Onnodige volledige documentprojectie'); }),
    getEditorRef: vi.fn(() => ({ getYrsSession: () => ({}) })),
    flushPendingInput: vi.fn(async () => {}),
    save: vi.fn(async (): Promise<Uint8Array | null> => bytes),
  };
  const docx: { current: typeof ref | null } = { current: ref };
  const werkBij = vi.fn(async (_handle: object, _ref: object, b: Uint8Array) => b);
  const opslag = { voerUit: vi.fn(async (f: () => Promise<Uint8Array>) => f()) }, handle = {};
  registreer({ registreer: (fn: typeof opslaan) => { opslaan = fn; } }, docx, opslag, { t: (s: string) => s }, werkBij, { api: handle });
  return { opslaan, ref, docx, bytes, werkBij, opslag, handle };
}
describe('gereedheid van Writer-opslag', () => {
  it('bewaart zonder volledige documentprojectie voor de gereedheidscontrole', async () => {
    const p = proef();
    expect(await p.opslaan()).toEqual(p.bytes);
    expect(p.ref.getDocument).not.toHaveBeenCalled();
    expect(p.ref.flushPendingInput).toHaveBeenCalledOnce();
    expect(p.ref.save).toHaveBeenCalledOnce();
    expect(p.werkBij).toHaveBeenCalledWith(p.handle, p.ref, p.bytes, true);
  });
  it('weigert een ontbrekende editor zonder de opslag te starten', async () => {
    const p = proef(); p.docx.current = null;
    await expect(p.opslaan()).rejects.toThrow('shell:errors.documentNotReady');
    expect(p.opslag.voerUit).not.toHaveBeenCalled();
  });
  it('weigert een nog ontbrekende pagina-editor', async () => {
    const p = proef(); p.ref.getEditorRef.mockReturnValue(null as never);
    await expect(p.opslaan()).rejects.toThrow('shell:errors.documentNotReady');
    expect(p.ref.save).not.toHaveBeenCalled();
  });
  it('weigert een ontbrekende sessie', async () => {
    const p = proef(); p.ref.getEditorRef.mockReturnValue({ getYrsSession: () => null } as never);
    await expect(p.opslaan()).rejects.toThrow('shell:errors.documentNotReady');
    expect(p.ref.save).not.toHaveBeenCalled();
  });
  it('wacht op hangende invoer voordat bewaren en eigenschappen bijwerken beginnen', async () => {
    const p = proef(); let los!: () => void;
    p.ref.flushPendingInput.mockImplementation(() => new Promise<void>(r => { los = r; }));
    const werk = p.opslaan();
    expect(p.ref.save).not.toHaveBeenCalled(); expect(p.werkBij).not.toHaveBeenCalled();
    los(); expect(await werk).toEqual(p.bytes);
    expect(p.ref.getDocument).not.toHaveBeenCalled();
  });
  it('behoudt de oorspronkelijke invoerfout en begint niet te bewaren', async () => {
    const p = proef(), fout = Error('Eigen invoerfout'); p.ref.flushPendingInput.mockRejectedValue(fout);
    await expect(p.opslaan()).rejects.toBe(fout);
    expect(p.ref.save).not.toHaveBeenCalled(); expect(p.werkBij).not.toHaveBeenCalled();
  });
  it('weigert een ontbrekend bewaarresultaat', async () => {
    const p = proef(); p.ref.save.mockResolvedValue(null);
    await expect(p.opslaan()).rejects.toThrow('shell:errors.documentSaveFailed');
    expect(p.werkBij).not.toHaveBeenCalled();
  });
});
