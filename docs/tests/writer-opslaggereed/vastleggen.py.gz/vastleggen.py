from pathlib import Path
import json,gzip,hashlib,sys
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/opslaggereed53';uit=r/'docs/tests/writer-opslaggereed';sys.path.insert(0,str(u));from controleer import controleer
m=controleer();ronden=json.loads((u/'herhaling.json').read_text());assert len(ronden)==8 and all(x['code']==0 for x in ronden)
assert not uit.exists();uit.mkdir();bestanden=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def bewaar(p,naam=None):
 b=p.read_bytes();n=naam or str(p.relative_to(u));gzippen=p.suffix in ['.json','.log','.py','.ts','.tsx','.toml','.lock'] or p.name in ['Cargo.lock','package.json'];doel=uit/(n+('.gz' if gzippen else ''));doel.parent.mkdir(parents=True,exist_ok=True);doel.write_bytes(gzip.compress(b,mtime=0)if gzippen else b);bestanden.append({'bestand':str(doel.relative_to(r/'docs/tests')),'sha256':sha(doel.read_bytes()),'origineel_sha256':sha(b),'origineel_bytes':len(b),'gzip':gzippen})
for p in sorted(u.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.py','.ts']:bewaar(p)
for naam in [*m['wijzigingen'],*m['toegevoegd']]:bewaar(u/'bron'/naam,'bron/'+naam)
for groep in ['gui-tekst','gui-plakken','gui-lang','gui-abba','typen-baab','bewaar-abba','bewaar-frames']:
 for p in sorted((u/groep).rglob('*')):
  if p.is_file():bewaar(p)
# Herleidbare canonieke helpers; geen wijziging aan hun voorwaarden/limieten.
for naam in ['scripts/test-writer-rust-tekst-native.py','scripts/test-writer-rijk-plakken-native.py','scripts/test-writer-lang-native.py','scripts/desktop_inspector.py','native/onderzoek/writer-desktopcache/meten.py']:
 p=r/naam
 if p.exists():bewaar(p,'canoniek/'+naam)
typ=[]
for groep in ['gui-abba','typen-baab']:
 punten=[]
 for p in sorted((u/groep).glob('*/profiel.json')):
  d=json.loads(p.read_text());assert d['geslaagd']and d['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True};assert not any(d['fouten_na'].values());punten.append({'naam':p.parent.name,'versie':d['versie'],'ms':d['getekende_tekst_ms'],'programma_sha256':d['programma_sha256']})
 oud=[x['ms']for x in punten if x['versie']=='2026.45.52'];nieuw=[x['ms']for x in punten if x['versie']=='2026.45.53'];assert len(oud)==len(nieuw)==2;typ.append({'groep':groep,'punten':punten,'verhouding_nieuw_oud':sum(nieuw)/sum(oud)})
bew=[]
for groep in ['bewaar-abba','bewaar-frames']:
 punten=[]
 for p in sorted((u/groep).glob('*/rapport.json')):
  d=json.loads(p.read_text());assert d['geslaagd']and not any(d['fouten'].values());assert all(x['body_en_cellen_exact']and x['getDocument']['actieve_api_gevolgd']for x in d['bewaarproeven']);punten.append({'naam':p.parent.name,'versie':d['versie'],'programma_sha256':d['programma_sha256'],'ronden':d['bewaarproeven']})
 oud=[s['ctrl_s_tot_file_en_knop_gereed_ms']for x in punten if x['versie']=='2026.45.52'for s in x['ronden']];nieuw=[s['ctrl_s_tot_file_en_knop_gereed_ms']for x in punten if x['versie']=='2026.45.53'for s in x['ronden']];assert len(oud)==len(nieuw)==6;bew.append({'groep':groep,'punten':punten,'verhouding_nieuw_oud':sum(nieuw)/sum(oud)})
d={'schema':1,'datum':'2026-11-06','basis':m['basis'],'besluit':'45.53 afgekeurd voor promotie: beide fysieke typvolgorden trager. Productiebron blijft 45.52/alpha57. Geen gerepareerd issue, release, platform- of migratieacceptatie.','wijziging':'Alleen de geregistreerde Writer-opslagcallback controleert de bestaande sessie in plaats van getDocument; interne herlaadcallback blijft gelijk. Zeven proeven tegen de echte callback; SDK/native kern gelijk.','programma':json.loads((u/'gebouwd.json').read_text()),'typvergelijking':typ,'bewaarvergelijking':bew,'controles':{'frontend':'1870 geslaagd, 7 overgeslagen van 1877. Vervolgens alle drie betrokken bestanden met bestaande proefdata herhaald: 53 geslaagd, geen skips; geen enkele volledige 1877-passronde geclaimd.','regressie_oud':'Zes van zeven nieuwe gevallen falen op oude bron; bewijst gerichte dekking, geen snelheid.','overig':'TypeScript, engines, opdrachten, weekversie, 118 Python-tests en Linux no-bundlebouw slagen. Canonieke tekst-, plak-/bewaar-/verwerp- en 500-pagina-/herstel-/spelling-/workerproeven slagen; exacte opdrachten/logs bewaard.'},'grenzen':['Eigen geïsoleerde vensters/profielen/documentkopieën; geen gebruikersdocumenten of installatie gewijzigd.','Vier typmetingen per versie, één 129-paginabron; geen algemene FPS-/soepelheidsclaim of oorzakelijk bewijs van de regressie.','Opslag bevat echte Ctrl+S, filewijziging én gereed gemelde opslagknop; bron en onafhankelijk DOCX-body-/celteksten exact; geen volledige opmaak-/onderdeelpariteit door deze aanvullende opslagproef.','rAF meet hoofdthreadcallback-intervallen, geen scherm-FPS; inspectie en eigen meetpunten kosten tijd. Eerste en warme bewaring afzonderlijk beoordelen.','Bouwmarker geen_gui_acceptatie uit gebouwd.json beschrijft de bouwfase; latere GUI-successen maken deze kandidaat nog niet geaccepteerd.','Sommige afgebroken voorbereidingen en eerste corpusronde zijn behouden; geen app-/testpoort verzwakt.','Ruwe getDocument-teller meet uitsluitend de aangeroepen publieke API; intern geïnduceerde projecties niet volledig geteld. Nieuwe eerste bewaring heeft nog één aanroep.','Geen 45.53-installers, Windows/macOS, zeveneditiematrix, release of downloadacceptatie. Eerdere worker-/leen-/verwerp-/zwarte-rasterafkeuringen blijven open.','Volgende stap: kalibreer de resterende buildStory-/paragraphSpans-/positiemapkosten per echte native invoergroep, met behoud van lokale oorsprong, Undo/Redo, revisies en brongelijkheid; geen applyHostUpdate als vervanger voor lokale mutaties.'],'bestanden':bestanden}
(r/'docs/tests/2026-11-06-writer-opslaggereed.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('Gearchiveerd',len(bestanden),'bestanden')
