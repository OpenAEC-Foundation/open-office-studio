const assert = require('node:assert/strict');
const { maakPublicatiePoort } = require('./poort.cjs');
let aantal = 0;
function proef(naam, fn) { fn(); aantal++; console.log(naam + ': geslaagd'); }
function basis(extra = {}) {
  const eigenaar = {}, ander = {}, taken = [], volgorde = [];
  const r = { eigenaar, ander, taken, volgorde, generatie: 0, versie: 'bron-1' };
  r.context = { sessie: eigenaar, worker: true, gereed: true, preview: false };
  r.poort = maakPublicatiePoort({ leesContext: () => r.context, leesVersie: () => r.versie, leesGeneratie: () => r.generatie,
    verhoog: () => { r.generatie++; volgorde.push('verhoog'); }, microtask: f => taken.push(f), ...extra });
  r.direct = () => r.poort.direct(eigenaar, () => { volgorde.push('direct'); return 12; });
  r.staat = (origin = 'local', owner = eigenaar) => r.poort.staat(owner, origin, () => { volgorde.push('staat'); return 34; });
  return r;
}
proef('exact één lokale combinatie en oorspronkelijke resultaten', () => {
 const r=basis();assert.equal(r.direct(),12);assert.equal(r.staat(),34);assert.equal(r.generatie,1);assert.deepEqual(r.volgorde,['direct','verhoog','staat']);r.staat();assert.equal(r.generatie,2);
});
for(const [naam,wijzig] of [
 ['bronversie',r=>r.versie='bron-2'], ['sessie',r=>r.context.sessie=r.ander],
 ['rendercontext',r=>r.context={...r.context}], ['preview',r=>r.context.preview=true],
 ['nog-niet-gereed',r=>r.context.gereed=false], ['geen-worker',r=>r.context.worker=false],
])proef(naam+' blijft invalideren',()=>{const r=basis();r.direct();wijzig(r);r.staat();assert.equal(r.generatie,2)});
proef('tussenliggende generatie blijft invalideren',()=>{const r=basis();r.direct();r.generatie++;r.staat();assert.equal(r.generatie,3)});
for(const origin of ['remote','host','undo','preview',null])proef(String(origin)+' blijft invalideren',()=>{const r=basis();r.direct();r.staat(origin);assert.equal(r.generatie,2);r.staat();assert.equal(r.generatie,3)});
proef('microtaskgrens verbreekt combinatie',()=>{const r=basis();r.direct();r.taken.shift()();r.staat();assert.equal(r.generatie,2)});
proef('slechts één geplande opruiming en alleen laatste directe stap',()=>{const r=basis();for(let i=0;i<100;i++)r.direct();assert.equal(r.taken.length,1);r.staat();assert.equal(r.generatie,100);r.staat();assert.equal(r.generatie,101)});
proef('verkeerde callbackeigenaar verbruikt token veilig',()=>{const r=basis();r.direct();r.staat('local',r.ander);r.staat();assert.equal(r.generatie,3)});
proef('oude renderclosure kan geen nieuwere sessie combineren',()=>{const r=basis();r.context.sessie=r.ander;r.direct();r.staat();assert.equal(r.generatie,2)});
proef('directe bronfout blijft dezelfde fout en verhoogt niet',()=>{const r=basis(),fout=Error('bron');assert.throws(()=>r.poort.direct(r.eigenaar,()=>{throw fout}),e=>e===fout);assert.equal(r.generatie,0);r.staat();assert.equal(r.generatie,1)});
proef('mislukte nieuwe publicatie verwijdert vorige combinatie',()=>{const r=basis();r.direct();assert.throws(()=>r.poort.direct(r.eigenaar,()=>{throw Error('bron')}));r.staat();assert.equal(r.generatie,2)});
proef('statefout blijft dezelfde fout en token is verbruikt',()=>{const r=basis(),fout=Error('state');r.direct();assert.throws(()=>r.poort.staat(r.eigenaar,'local',()=>{throw fout}),e=>e===fout);r.staat();assert.equal(r.generatie,2)});
proef('versieleesfout voegt geen nieuwe invoerfout toe',()=>{const r=basis({leesVersie(){throw Error('lezen')}});r.direct();r.staat();assert.equal(r.generatie,2)});
proef('geweigerd microtask plannen valt veilig terug',()=>{const r=basis({microtask(){throw Error('plannen')}});r.direct();r.staat();assert.equal(r.generatie,2)});
proef('expliciet wissen verbreekt combinatie',()=>{const r=basis();r.direct();r.poort.wis();r.staat();assert.equal(r.generatie,2)});
proef('reentrante staat kan token niet tweemaal gebruiken',()=>{const r=basis();r.direct();r.poort.staat(r.eigenaar,'local',()=>r.staat());assert.equal(r.generatie,2)});
for(const versie of [null,{},7,'','x'.repeat(257)])proef('onbekende versie '+typeof versie+' valt veilig terug',()=>{const r=basis();r.versie=versie;r.direct();r.staat();assert.equal(r.generatie,2)});
console.log(aantal+' publicatiegrenzen gecontroleerd; geen SDK-/GUI-promotie.');
