const fs=require('node:fs'),crypto=require('node:crypto'),path=require('node:path');
const {maakPublicatiePoort}=require('./poort.cjs');
const r=process.cwd(),u=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sdk=path.join(r,'node_modules/@betteroffice/docx-react/dist/index.mjs');
const bytes=fs.readFileSync(sdk);if(sha(bytes)!=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb')throw Error('Onbekende SDK-basis');
for(const n of ['patches/@betteroffice__docx-react@0.5.1.patch','pnpm-lock.yaml']){
 const d=path.join(u,path.basename(n)+'.origineel');if(fs.existsSync(d))throw Error('Bestaande referentie niet vervangen');fs.copyFileSync(path.join(r,n),d);
}
fs.writeFileSync(path.join(u,'index.mjs.origineel'),bytes,{flag:'wx'});
const a='Bn=useCallback(T=>{r.publishDirectInput(T),mt.current+=1;},[r.publishDirectInput])';
const b='let jn=useCallback((T,I)=>{mt.current+=1,Oe.incrementStateSeq(),Oe.requestRender(),fn(T,I);},[fn,Oe])';
const factory=String(maakPublicatiePoort).replace(/\n\s*/g,' ');
const nieuwA='_openaecPositieContext=useRef(null),_openaecPositiePoort=useRef(null),Bn=useCallback(T=>{_openaecPositiePoort.current.direct(r.session,()=>r.publishDirectInput(T));},[r.publishDirectInput,r.session])';
const initialisatie='_openaecPositieContext.current={sessie:r.session,gereed:r.replicaReady,worker:r.experimentalWorkerOpen,preview:true};try{_openaecPositieContext.current.preview=r.previewing===true||r.opening===true||r.session?.isDisplayOnly()!==false;}catch{}if(!_openaecPositiePoort.current)_openaecPositiePoort.current=('+factory+')({leesContext:()=>_openaecPositieContext.current,leesVersie:T=>T.version(),leesGeneratie:()=>mt.current,verhoog:()=>{mt.current+=1;},microtask:T=>queueMicrotask(T)});useEffect(()=>()=>{_openaecPositiePoort.current.wis();_openaecPositieContext.current=null;},[]);';
const nieuwB='let jn=useCallback((T,I)=>{_openaecPositiePoort.current.staat(r.session,T,()=>{Oe.incrementStateSeq(),Oe.requestRender(),fn(T,I);});},[fn,Oe,r.session])';
const p=path.join(r,'patches/@betteroffice__docx-react@0.5.1.patch');let s=fs.readFileSync(p,'utf8'),tellers=[0,0];
s=s.split('\n').map(l=>{
 if(!l.startsWith('+')||l.startsWith('+++'))return l;
 if(l.includes(a)){tellers[0]++;l=l.replace(a,nieuwA);const mark=nieuwA+';';if(!l.includes(mark))throw Error('Geen unieke initialisatieplek');l=l.replace(mark,mark+initialisatie);}
 if(l.includes(b)){tellers[1]++;l=l.replace(b,nieuwB);}return l;
}).join('\n');if(tellers.some(n=>n!==1))throw Error('Onbekende patchankers '+tellers);
fs.writeFileSync(p,s);
fs.writeFileSync(path.join(u,'voorbereiding.json'),JSON.stringify({basis:'1a69f57e22dc5d19f27b4fb642b91cd737ec7f98',sdk_voor:sha(bytes),patch_voor:sha(fs.readFileSync(path.join(u,path.basename(p)+'.origineel'))),patch_na:sha(Buffer.from(s)),factory_sha256:sha(Buffer.from(factory)),direct:nieuwA,staat:nieuwB,voorwaarden:'Alleen prototype; nog geen SDK-installatie, nativefunctie-/beeld-/tijdacceptatie of promotie.'},null,2)+'\n');
console.log('Patch voorbereid; alleen plusregels vervangen, SDK/referenties nog behouden.');
