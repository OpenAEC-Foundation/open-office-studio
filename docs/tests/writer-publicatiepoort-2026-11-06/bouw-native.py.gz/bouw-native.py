"""Eindige lokale integratiebouw; geen release of functionele acceptatie."""
from pathlib import Path
import os,subprocess,json,time,shutil,signal,hashlib
wt=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06')
root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio')
uit=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/.local/integratiecontrole/publicatiepoort')
target=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target'
referentie=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/open-office-studio-45.52-autocorrectie'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(referentie)=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039'
wachtbegin=time.monotonic()
while True:
 controle=uit/'actief.json'
 if controle.exists():
  stand=json.loads(controle.read_text())
  if stand.get('status')=='klaar':break
 uitslag=uit/'controles.json'
 if uitslag.exists() and any(p['code'] for p in json.loads(uitslag.read_text())):raise SystemExit('Frontend-/GUI-poort afgekeurd; geen nativebouw')
 assert time.monotonic()-wachtbegin<1200,'Frontendpoorten niet binnen twintig minuten voltooid'
 time.sleep(5)
assert b'Test Files  223 passed' in (uit/'frontend.log').read_bytes()
assert len(json.loads((uit/'controles.json').read_text()))==7
while not(uit/'lintbron-controle.json').exists():
 assert time.monotonic()-wachtbegin<1200,'Aanvullende lintbronpoort niet voltooid'
 time.sleep(2)
assert json.loads((uit/'lintbron-controle.json').read_text())['code']==0,'Actuele lintbron afgekeurd; geen nativebouw'

assert shutil.disk_usage(wt).free>6*1024**3,'Minder dan6GiB vrije ruimte; geen bouw'
bron=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=wt)
bronhash=hashlib.sha256(bron).hexdigest()
env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true')
cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol']
start=time.monotonic();reden=None
with (uit/'desktop.log').open('x') as log:
 p=subprocess.Popen(cmd,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (uit/'actief.json').write_text(json.dumps({'supervisor_pid':os.getpid(),'bouw_pid':p.pid,'status':'bouwen','bronpatch_sha256':bronhash,'opdracht':cmd,'target':str(target)},indent=2)+'\n')
 while p.poll() is None:
  time.sleep(5)
  if shutil.disk_usage(wt).free<3*1024**3 or time.monotonic()-start>2400:
   reden='Eigen bouw gestopt: vrije ruimte onder3GiB of maximale duur40minuten';os.killpg(p.pid,signal.SIGTERM);p.wait();break
result={'code':p.returncode,'reden':reden,'seconden':time.monotonic()-start,'opdracht':cmd,'bronpatch_sha256':bronhash,'doelplatform':'Linux x86_64','geen_installer':True,'geen_gui_acceptatie':True}
assert sha(referentie)=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039'
assert hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=wt)).hexdigest()==bronhash,'Integratiebron tijdens bouw veranderd'
if p.returncode==0:
 exe=uit/'open-office-studio-kandidaat-publicatiepoort';assert not exe.exists();shutil.copy2(target/'release/open-office-studio',exe);result.update(programma=str(exe),programma_sha256=sha(exe))
(uit/'desktop.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
(uit/'actief.json').write_text(json.dumps({'status':'klaar' if p.returncode==0 else 'afgekeurd','resultaat':result},ensure_ascii=False,indent=2)+'\n')
raise SystemExit(p.returncode)
