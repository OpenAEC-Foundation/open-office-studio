from pathlib import Path
import json,time,subprocess,os
r=Path(__file__).resolve().parents[3];u=Path(__file__).resolve().parent;begin=time.monotonic()
while True:
 p=u/'controles.json';d=json.loads(p.read_text()) if p.exists()else []
 if any(v['code'] for v in d):raise SystemExit('Frontendpoort afgekeurd')
 if any(v['naam']=='webbouw' and v['code']==0 for v in d):break
 assert time.monotonic()-begin<1200,'Webbouw nog niet voltooid'
 time.sleep(2)
env=os.environ.copy();env['PATH']='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH'];env['OFFICE_TEST_CHROMIUM']='/home/aia01/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome';env['OFFICE_TEST_UIT']=str(u/'gui-actuele-lintbron')
start=time.monotonic()
with(u/'lintbron-controle.log').open('x')as log:p=subprocess.run(['node',str(u/'lintbron-lettergrootte.mjs')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
d={'code':p.returncode,'seconden':time.monotonic()-start,'doel':'Actuele synchrone lintbron vóór bewaren, elf opmaak-/DOCX-poorten.'};(u/'lintbron-controle.json').write_text(json.dumps(d,indent=2)+'\n');print(d);raise SystemExit(p.returncode)
