// Alleen onderzoek: één strikt brongebonden, synchrone publicatiecombinatie.
function maakPublicatiePoort(opties) {
  let token = null, gepland = false;
  function lees(eigenaar) {
    try {
      const context = opties.leesContext();
      if (!eigenaar || context?.sessie !== eigenaar || context.gereed !== true || context.worker !== true || context.preview !== false) return null;
      const versie = opties.leesVersie(eigenaar), generatie = opties.leesGeneratie();
      if (typeof versie !== 'string' || !versie.length || versie.length > 256 || !Number.isSafeInteger(generatie) || generatie < 0) return null;
      return { context, eigenaar, versie, generatie };
    } catch { return null; }
  }
  function verval() {
    if (gepland) return;
    gepland = true;
    try { opties.microtask(() => { gepland = false; token = null; }); }
    catch { gepland = false; token = null; }
  }
  return {
    direct(eigenaar, publiceer) {
      token = null;
      const waarde = publiceer();
      opties.verhoog();
      token = lees(eigenaar);
      if (token) verval();
      return waarde;
    },
    staat(eigenaar, oorsprong, publiceer) {
      const vorig = token;
      token = null;
      const huidig = vorig && oorsprong === 'local' ? lees(eigenaar) : null;
      if (!vorig || !huidig || huidig.context !== vorig.context || huidig.eigenaar !== vorig.eigenaar || huidig.versie !== vorig.versie || huidig.generatie !== vorig.generatie) opties.verhoog();
      return publiceer();
    },
    wis() { token = null; },
  };
}
module.exports = { maakPublicatiePoort };
