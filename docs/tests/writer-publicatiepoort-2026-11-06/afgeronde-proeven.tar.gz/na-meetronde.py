from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path(__file__).resolve().parents[3];u=Path(__file__).resolve().parent
script=b'.local/integratiecontrole/publicatiepoort/na-bouw-herhaling.py';gevonden=[]
for p in Path('/proc').glob('[0-9]*/cmdline'):
 try:a=p.read_bytes().split(b'\0')
 except OSError:continue
 if len(a)>1 and a[0].split(b'/')[-1]==b'python3' and a[1]==script:gevonden.append(int(p.parent.name))
assert len(gevonden)<=1,gevonden
start=time.monotonic()
while gevonden and Path('/proc/'+str(gevonden[0])).exists():
 assert time.monotonic()-start<1200,'Eigen meetcontroller nog actief; geen overlappende controle starten'
 time.sleep(2)
root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
cmd=[str(root/'.local/doorwerk-2026-11-02/gui-python/bin/python'),str(r/'scripts/test-writer-lang-native.py'),'--programma',str(r/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding'),'--versie','2026.45.52','--uitvoer',str(u/'combinatie-baseline-volgordehersteld'),'--herstelstart','--verwacht-rust-tekst','--verwacht-incrementele-bron','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--workerbron','--lettertypebewijs']
with(u/'combinatie-baseline-volgordehersteld.log').open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
uit={'code':p.returncode,'opdracht':cmd,'proef_sha256':hashlib.sha256((r/'scripts/test-writer-lang-native.py').read_bytes()).hexdigest()};(u/'combinatie-baseline-volgordehersteld.json').write_text(json.dumps(uit,indent=2)+'\n');print('Volgordeherstel op behouden baseline:',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
with(u/'python-na-prototype.log').open('x')as log:p=subprocess.run(['python3','-m','unittest','discover','-s','tests'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Python:',p.returncode,flush=True)
from PIL import Image,ImageChops
ref=root/'.local/doorwerk-2026-11-04/incrementele-invoer/doortypen-38-zonder-profiel/profiel.png';roi=(395,298,1065,366);basis=Image.open(ref).convert('RGB').crop(roi);basis.paste((0,0,0),(96,49,101,68));result=[]
for pad in sorted(u.glob('fysiek-*/profiel.png')):
 im=Image.open(pad).convert('RGB').crop(roi);im.paste((0,0,0),(96,49,101,68));result.append({'bestand':str(pad.relative_to(u)),'sha256':hashlib.sha256(pad.read_bytes()).hexdigest(),'documentuitsnede_rgb_exact_buiten_cursor':ImageChops.difference(basis,im).getbbox()is None})
(u/'beeldvergelijking.json').write_text(json.dumps({'referentie':str(ref),'uitsnede':roi,'resultaten':result,'grens':'Alleen deze documentuitsnede; geen volledige UI-/suite-/platformacceptatie.'},indent=2)+'\n');print('Beelden:',len(result),'exact:',all(d['documentuitsnede_rgb_exact_buiten_cursor']for d in result),flush=True)
raise SystemExit(p.returncode)
