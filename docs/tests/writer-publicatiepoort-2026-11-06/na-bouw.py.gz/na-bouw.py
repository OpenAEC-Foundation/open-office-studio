"""Eindige Writer-GUI-proeven op alleen de eigen geïntegreerde testbinary."""
from pathlib import Path
import os,json,hashlib,subprocess,time
wt=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06')
root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');uit=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/.local/integratiecontrole/publicatiepoort')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
begin=time.monotonic()
while not(uit/'desktop.json').exists():
 poort=uit/'controles.json'
 if poort.exists() and any(p['code'] for p in json.loads(poort.read_text())):raise SystemExit('Frontendpoort afgekeurd; geen native GUI')
 assert time.monotonic()-begin<3600,'Nativebouw nog niet klaar na begrensd wachten'
 time.sleep(5)
meta=json.loads((uit/'desktop.json').read_text());assert meta['code']==0

exe=Path(meta['programma']);assert sha(exe)==meta['programma_sha256']
env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
py=str(root/'.local/doorwerk-2026-11-02/gui-python/bin/python')
proeven=[('tekst','scripts/test-writer-rust-tekst-native.py',[]),('plakken','scripts/test-writer-rijk-plakken-native.py',['--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken']),('lang','scripts/test-writer-lang-native.py',['--herstelstart','--verwacht-rust-tekst','--verwacht-incrementele-bron','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--workerbron','--lettertypebewijs'])]
rapport=[]
for naam,script,args in proeven:
 assert sha(exe)==meta['programma_sha256']
 cmd=[py,str(wt/script),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(uit/('gui-'+naam)),*args]
 print('START',naam,flush=True);start=time.monotonic()
 with(uit/('gui-'+naam+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 rapport.append({'fase':naam,'code':p.returncode,'seconden':time.monotonic()-start,'programma_sha256':sha(exe),'testbron_sha256':sha(wt/script),'opdracht':cmd})
 (uit/'gui.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('Canonieke GUI-proeven geslaagd; beelden en prestatielimieten afzonderlijk beoordelen.',flush=True)

# Alleen na functionele poorten: bewijs werkelijk één positieopbouw per native groep.
poscmd=json.loads((root/'.local/doorwerk-2026-11-06/positie-integratie56/diagnose-opdracht.json').read_text())
poscmd[poscmd.index('--programma')+1]=str(exe);poscmd[-1]=str(uit/'positie')
with(uit/'positie.log').open('x')as log:pos=subprocess.run(poscmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
assert pos.returncode==0,'Eigen native positieproef afgekeurd'
uitkomst=json.loads((uit/'positie/profiel.json').read_text());meting=uitkomst['positiemeting'];assert meting['gemist']==0
from collections import defaultdict
groepen=defaultdict(list)
for e in meting['regels']:
 if e['taak']:groepen[e['taak']].append(e)
poorten=[]
for nr,events in groepen.items():
 if not any(e['soort']=='nativebegin' for e in events):continue
 gen=[e for e in events if e['soort']=='generatie'];bouw=[e for e in events if e['soort']=='projectie']
 poorten.append({'taak':nr,'generaties':len(gen),'opbouwen':len(bouw),'verhaalbezoeken':[e['bezoeken']for e in bouw]})
(uit/'positiepoort.json').write_text(json.dumps({'groepen':poorten,'broncontrole':uitkomst['broncontrole']},indent=2)+'\n')
assert poorten and all(p['generaties']==1 and p['opbouwen']==1 and p['verhaalbezoeken']==[1537] for p in poorten),'Geen enkele unieke positieopbouw per native invoergroep bewezen; geen passieve prestatiepromotie'

# Fysieke respons met ongewijzigde bron-/rasterpoort, zonder positieobserver.
# Ook een mislukte referentie blijft als afkeuring bewaard; nooit tijdgrens verhogen.
helper=root/'.local/doorwerk-2026-11-06/positie-integratie56/zonder-observer.py'
base=json.loads((root/'.local/doorwerk-2026-11-06/positie-integratie56/diagnose-opdracht.json').read_text())
base[1]=str(helper)
ref=wt/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding'
assert sha(ref)=='c88c5d82f1b0b44bf1279645a6b3e930dc8f302e5e3f7bec57605b8d2df42c59'
metingen=[]
for ronde,volgorde in [('ABBA',['referentie','kandidaat','kandidaat','referentie']),('BAAB',['kandidaat','referentie','referentie','kandidaat'])]:
 for nummer,naam in enumerate(volgorde,1):
  druk=[]
  for p in Path('/proc').glob('[0-9]*/comm'):
   try:n=p.read_text().strip()
   except OSError:continue
   if n in ['cargo','rustc','rust-lld','ld.lld','cc']or n.startswith('node (vitest'):druk.append(n)
  assert not druk,('Geen fysieke proef naast compiler/test',druk)
  programma=ref if naam=='referentie'else exe;pad=uit/('fysiek-'+ronde+'-'+str(nummer)+'-'+naam);cmd=list(base);cmd[cmd.index('--programma')+1]=str(programma);cmd[-1]=str(pad)
  with(uit/(pad.name+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  verslag=json.loads((pad/'profiel.json').read_text());metingen.append({'ronde':ronde,'nummer':nummer,'naam':naam,'code':p.returncode,'programma_sha256':sha(programma),'geslaagd':verslag['geslaagd'],'getekende_tekst_ms':verslag.get('getekende_tekst_ms'),'broncontrole':verslag.get('broncontrole'),'achtergrond_bij_start':druk,'opdracht':cmd});(uit/'fysieke-metingen.json').write_text(json.dumps(metingen,ensure_ascii=False,indent=2)+'\n');print('FYSIEK',ronde,nummer,naam,p.returncode,verslag.get('getekende_tekst_ms'),flush=True)
print('Metingen beëindigd: geen automatische promotie, commit, installatie of release; inhoud, pixels, opmaakactualiteit en methode eerst beoordelen.',flush=True)
