from pathlib import Path
import zipfile,hashlib,json,xml.etree.ElementTree as E
p=Path(__file__).resolve().parent;r=Path.cwd();ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};sha=lambda b:hashlib.sha256(b).hexdigest()
def inspect(f):
 with zipfile.ZipFile(f)as z:
  assert z.testzip() is None
  names=z.namelist();assert len(names)==len(set(names));assert all(not n.startswith('/')and '..'not in Path(n).parts for n in names)
  contents={n:z.read(n)for n in names}
  for n,b in contents.items():
   if n.endswith(('.xml','.rels')):E.fromstring(b)
  root=E.fromstring(contents['word/document.xml']);text=''.join(x.text or ''for x in root.findall('.//w:t',ns));return{'sha256':sha(f.read_bytes()),'leden':len(names),'tabellen':len(root.findall('.//w:tbl',ns)),'utf16':len(text.encode('utf-16-le'))//2,'tekst_sha256':sha(text.encode()),'delen':{n:sha(b)for n,b in contents.items()}},text
initial,it=inspect(r/'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx');a,at=inspect(p/'save-baseline.docx');b,bt=inspect(p/'save-kandidaat.docx');assert a['tabellen']==b['tabellen']==initial['tabellen']==128;assert at==bt;extra=' eigen Ω العربية 漢字 🙂 a\u0301 einde';assert a['utf16']==b['utf16']==initial['utf16']+len(extra.encode('utf-16-le'))//2;assert extra in at
assert set(a['delen'])==set(b['delen']);diff=[n for n in a['delen']if a['delen'][n]!=b['delen'][n]];assert set(diff)<= {'docProps/core.xml'}
report={'geslaagd':True,'bron':initial,'baseline':a,'kandidaat':b,'verschillende_delen':diff,'grens':'ZIP/CRC/paden/XML en gecontroleerde tekst/tabellen; geen visuele of volledige formaatacceptatie.'};(p/'documenten.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'geslaagd':True,'tabellen':a['tabellen'],'utf16':a['utf16'],'verschillen':diff}))
