from pathlib import Path
import hashlib,json,tarfile,stat,re
r=Path.cwd();p=r/'.local/integratiecontrole/font-echte-werker';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();d=json.loads((p/'rapport.json').read_text());first=json.loads((p/'eerste-groen/rapport.json').read_text());docs=json.loads((p/'documenten.json').read_text());assert d['geslaagd']and first['geslaagd']and docs['geslaagd']
assert [d[k]['fontCount']for k in ['baseline','kandidaat']]==[13,2]
for k in ['baseline','kandidaat']:
 assert len(d[k]['checks'])==12
 assert all(c['retour']['byteExact']and c['retour']['projectieVectorExact']and c['repairBytes']>0 for c in d[k]['checks'])
 assert d[k]['peerMetadataBytes']>0 and not d[k]['errors']
 assert all(e['ok']for e in d[k]['events'])
# De bereikbare ongewijzigde SDK-modules vastpinnen, zonder te beweren dat alle
# dynamische takken tijdens deze proef zijn opgehaald.
entry=r/'node_modules/@betteroffice/docx/dist/yrs/docxWorker.mjs';todo=[entry];graph={};bare=set()
while todo:
 f=todo.pop().resolve()
 if str(f)in graph:continue
 graph[str(f)] = sha(f)
 for spec in re.findall(r'(?:from|import)\s*(?:\(\s*)?[\"\']([^\"\']+)[\"\']',f.read_text()):
  if spec.startswith('.'):
   q=(f.parent/spec).resolve()
   if q.suffix=='.mjs'and q.is_file():todo.append(q)
  else:bare.add(spec)
(p/'sdk-graaf.json').write_text(json.dumps({'modules':graph,'bare_imports':sorted(bare),'grens':'Bereikbare modules; geen opname van werkelijk gebruikte netwerkpaden of dekking van alle takken.'},indent=2)+'\n')
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';refs=json.loads((old/'referenties-nacontrole.json').read_text());pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];bundle=json.loads((old/'standaardbundel.json').read_text());preserve={'referenties':{f:('exact'if Path(f).exists()and sha(Path(f))==h else 'ontbreekt'if not Path(f).exists()else 'gewijzigd')for f,h in refs.items()},'bronpinnen':{f:sha(r/f)==h for f,h in pins.items()},'standaardbestanden':{f:sha(r/'dist'/f)==v['sha256']and stat.S_IMODE((r/'dist'/f).stat().st_mode)==v['mode']and(r/'dist'/f).stat().st_mtime_ns==v['mtime_ns']for f,v in bundle.items()}}
assert list(preserve['referenties'].values()).count('exact')==26 and list(preserve['referenties'].values()).count('ontbreekt')==1;assert all(preserve['bronpinnen'].values())and all(preserve['standaardbestanden'].values());(p/'behoud.json').write_text(json.dumps(preserve,indent=2)+'\n')
files={str(f.relative_to(p)):{'sha256':sha(f),'bytes':f.stat().st_size}for f in p.rglob('*')if f.is_file() and f.name!='bestanden.json'};(p/'bestanden.json').write_text(json.dumps(files,indent=2)+'\n');out=r/'docs/tests/2026-11-27-writer-echte-fontwerker'
with tarfile.open(str(out)+'.tar.gz','w:gz')as t:
 for f in sorted(p.rglob('*')):
  if f.is_file():t.add(f,arcname='font-echte-werker/'+str(f.relative_to(p)),recursive=False)
 f=r/'.local/integratiecontrole/font-voorvlucht-hook/browser/wachtrij.mjs';t.add(f,arcname='afhankelijkheden/wachtrij.mjs',recursive=False)
with tarfile.open(str(out)+'.tar.gz')as t:
 for m in t.getmembers():assert m.isfile()and not m.name.startswith('/')and '..'not in Path(m.name).parts;assert len(t.extractfile(m).read())==m.size
 for f,v in files.items():assert hashlib.sha256(t.extractfile('font-echte-werker/'+f).read()).hexdigest()==v['sha256']
report={'datum':'2026-11-27','basis_integratie':'50f7336d','basis_hoofdbranch':'f5ddf5c2','besluit':'Echte Chromium-Worker voert ongewijzigde geïnstalleerde SDK-Worker uit met expliciet aangeboden geaccepteerde Wasm. Twee volledige paren groen: fontaanvragen 13 tegenover2 bij twaalf updates; laatste fontresultaat gelijk. Vier DOCX-bestanden behouden tekst/tabellen. Herhaling toetst alle24nietlege herstelupdates byte-exact op bijbehorende bronstaat. Geen native snelheidsacceptatie.','eerste_paar':first,'herhaling':d,'documenten':docs,'eerste_documenten':json.loads((p/'eerste-groen/documenten.json').read_text()),'worker_entry_sha256':sha(entry),'sdk_graaf':{'modules':len(graph),'bare_imports':sorted(bare),'manifest_sha256':sha(p/'sdk-graaf.json')},'behoud':preserve,'archief':{'pad':out.name+'.tar.gz','sha256':sha(Path(str(out)+'.tar.gz'))},'grenzen':['Echte dedicated Worker, postMessage, compiled-module-overdracht en ArrayBuffer-kopie; eigen minimale protocolclient. Niet de volledige SDK-client, React-hook of editor in deze proef.','Fontantwoorden bewust tot het einde vastgehouden bij de aanvrager. Reeds uitgevoerde Worker-taak nooit geannuleerd; alleen achterhaalde nog wachtende taak vervangen. Geen native natuurlijke invoerbelasting of CPU-/looptijdmeting.','Alle twaalf updates per arm via syncUpdate, met vector en genormaliseerde paragraaf/storyvergelijking tegen Wasm-auteur. Niet-lege reparatieantwoorden afzonderlijk exact op de betreffende bronstaat toegepast; geen gewijzigde bronbytes/projecties/vector.','Peer metadata daadwerkelijk ontvangen (762603 bytes per arm), maar geen volledige bootstrap_peer-rehydratie of overdracht van lokale UndoSession-geschiedenis/selektie getest.','Vier bewaarbestanden met eigen fixture; finale twee onafhankelijk ZIP/CRC/paden/XML/tekst/tabelgetal gecontroleerd. Beide90399UTF16 en128tabellen, uitsluitend core.xml verschillend. Geen visuele of volledige formaatacceptatie.','Alle beginstaten, auteurupdates, bijbehorende bronstaten, herstelantwoorden en opgehaalde Worker-staten uit herhaling als binaire artifacts behouden.','Alle26aanwezige ELF-referenties,15bronpinnen en529standaardbestanden exact; eerdere ontbrekende autocorrectiereferentie niet hersteld of verwijderd.','Geen productbron-/SDK-/canonieke wijziging, nieuwe ELF/bouw, volledige suites/CI, andere platforms/edities/releases of issuevoltooiing.'],'vervolg':'Getoetste beperkte rij in afzonderlijke private native kandidaat op ee89c80e-basis zetten, positiecontextcorrectie behouden. Eerst actuele bouwcache/bronbinding inventariseren; alle referenties behouden. Dan vaste korte/rijke ABBA en invoer/selectie/UndoRedo/bewaren/verwerpen/laat antwoord/DOCX/beelden. SDK-client en metadata/geschiedenisgrenzen blijven afzonderlijk te dekken. Automatisch herstel behouden; Database laatst.'}
Path(str(out)+'.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'geslaagd':True,'archief_sha256':report['archief']['sha256'],'modules':len(graph),'binaire_bestanden':len(list((p/'retourcontrole').glob('*.bin')))}))
