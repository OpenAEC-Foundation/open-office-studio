/** Private proef: alleen aantoonbaar achterhaalde wachtende voorvluchten vervangen. */
export function maakVoorvluchtRij(achterhaald) {
  let actief = null, wachtend = null, gestopt = false;
  const telling = { gestart: 0, vervangen: 0, terugval: 0 };
  function voltooi(taak) {
    if (actief !== taak) throw Error('Onjuiste voorvluchteigenaar');
    actief = null;
    const volgende = wachtend; wachtend = null;
    if (volgende) start(volgende);
  }
  function volg(taak, waarde) {
    Promise.resolve(waarde).then(taak.resolve, taak.reject).then(() => voltooi(taak));
  }
  function start(taak) {
    actief = taak; telling.gestart++;
    let waarde;
    try { waarde = taak.uitvoeren(); } catch(fout) { waarde = Promise.reject(fout); }
    volg(taak, waarde);
  }
  return {
    vraag(uitvoeren, isAchterhaald) {
      if (gestopt) return Promise.reject(achterhaald());
      if (!actief) {
        // De bestaande callback kan null teruggeven of synchroon gooien.
        // Bewaar die directe route en de identiteit van een echte Promise.
        const taak = { uitvoeren, isAchterhaald, resolve: () => {}, reject: () => {} };
        actief = taak; telling.gestart++;
        let waarde;
        try { waarde = uitvoeren(); } catch(fout) { voltooi(taak); throw fout; }
        if (waarde == null || typeof waarde.then !== 'function') { voltooi(taak); return waarde; }
        volg(taak, waarde); return waarde;
      }
      return new Promise((resolve, reject) => {
        const taak = { uitvoeren, isAchterhaald, resolve, reject };
        if (wachtend) {
          if (!wachtend.isAchterhaald()) {
            // Zonder bewijs geen andere gebruiker annuleren of blokkeren.
            telling.terugval++;
            try { Promise.resolve(uitvoeren()).then(resolve, reject); } catch(fout) { reject(fout); }
            return;
          }
          telling.vervangen++; wachtend.reject(achterhaald());
        }
        wachtend = taak;
      });
    },
    annuleerWachtend() { if (wachtend) { wachtend.reject(achterhaald()); wachtend = null; } },
    stop() { gestopt = true; if (wachtend) { wachtend.reject(achterhaald()); wachtend = null; } },
    stand() { return { ...telling, actief: !!actief, wachtend: !!wachtend, gestopt }; }
  };
}
