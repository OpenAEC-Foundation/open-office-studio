(()=>{
const s=api().getEditorRef().getYrsSession(),beschrijvingen=[],stats={},stack=[],groepen={},herkomsten={};
const namen=Object.getOwnPropertyNames(s).filter(n=>/^(get|read|encode|paragraph|table|selection|story|storiesChangedSince|yrsBlocksForStory|locateParagraph|hasStory|version|list|can|document|retained|layout|buildDisplay|measure)/.test(n));
for(const naam of namen){const d=Object.getOwnPropertyDescriptor(s,naam);if(typeof d.value!=='function'||(!d.writable&&!d.configurable))continue;
const orig=d.value;stats[naam]={aantal:0,inclusiefMs:0,exclusiefMs:0,maxMs:0};
Object.defineProperty(s,naam,{...d,value:function(...args){let groep=null;if(['readParagraphs','paragraphSpans','storySegmentUnitDigests','tablePayload'].includes(naam)){const a=args[0],story=typeof a==='string'?a:a?.story??'alle',soort=story==='body'?'body':story.replace(/\d+/g,'#'),aantal=Array.isArray(a?.paraIds)?a.paraIds.length:'alle';const sleutel=JSON.stringify([naam,soort,aantal,typeof a==='object'?a?.view:null]);groep=groepen[sleutel]??=(Object.keys(groepen).length<64?{aantal:0,ms:0}:null);const herkomst=naam+':'+(story==='body'?'body':'overig');if(!herkomsten[herkomst])herkomsten[herkomst]=new Error().stack;}const begin=performance.now(),frame={kindMs:0};stack.push(frame);try{return Reflect.apply(orig,this,args)}finally{const ms=performance.now()-begin;stack.pop();if(stack.length)stack.at(-1).kindMs+=ms;const st=stats[naam];st.aantal++;st.inclusiefMs+=ms;st.exclusiefMs+=ms-frame.kindMs;st.maxMs=Math.max(st.maxMs,ms);if(groep){groep.aantal++;groep.ms+=ms}}}});beschrijvingen.push([naam,d]);
}
if(!stats.paragraphSpans||!stats.paragraphs)throw Error('Verwachte echte lezers ontbreken: '+JSON.stringify(namen));
window._stopLezers=()=>{for(const [naam,d] of beschrijvingen)Object.defineProperty(s,naam,d);delete window._stopLezers;return {stats,groepen,herkomsten,gemeten:namen,hersteld:true,grens:'Alleen synchrone aanroepduur van bestaande publieke sessielezers, inclusief geneste leestijd afzonderlijk. Geen worker-/async-CPUmeting; tijdelijke meetwrappers kunnen de meting beïnvloeden.'}};
return true;
})()
