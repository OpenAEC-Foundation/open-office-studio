(()=>{
const s=api().getEditorRef().getYrsSession(),beschrijvingen=[],stats={},stack=[];
const namen=Object.getOwnPropertyNames(s).filter(n=>/^(get|read|encode|paragraph|table|selection|story|hasStory|version|list|can|document|retained|layout|buildDisplay|measure)/.test(n));
for(const naam of namen){const d=Object.getOwnPropertyDescriptor(s,naam);if(typeof d.value!=='function'||(!d.writable&&!d.configurable))continue;
const orig=d.value;stats[naam]={aantal:0,inclusiefMs:0,exclusiefMs:0,maxMs:0};
Object.defineProperty(s,naam,{...d,value:function(...args){const begin=performance.now(),frame={kindMs:0};stack.push(frame);try{return Reflect.apply(orig,this,args)}finally{const ms=performance.now()-begin;stack.pop();if(stack.length)stack.at(-1).kindMs+=ms;const st=stats[naam];st.aantal++;st.inclusiefMs+=ms;st.exclusiefMs+=ms-frame.kindMs;st.maxMs=Math.max(st.maxMs,ms)}}});beschrijvingen.push([naam,d]);
}
if(!stats.paragraphSpans||!stats.paragraphs)throw Error('Verwachte echte lezers ontbreken: '+JSON.stringify(namen));
window._stopLezers=()=>{for(const [naam,d] of beschrijvingen)Object.defineProperty(s,naam,d);delete window._stopLezers;return {stats,gemeten:namen,hersteld:true,grens:'Alleen synchrone aanroepduur van bestaande publieke sessielezers, inclusief geneste leestijd afzonderlijk. Geen worker-/async-CPUmeting; tijdelijke meetwrappers kunnen de meting beïnvloeden.'}};
return true;
})()
