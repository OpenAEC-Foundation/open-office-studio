import {readFileSync,writeFileSync} from 'node:fs';
import {createYrsSession} from '@betteroffice/docx/yrs';
import {createHash} from 'node:crypto';
const s=await createYrsSession({clientId:994});
const bron=readFileSync('docs/tests/writer-doortypen/bron.docx');s.openDocx(new Uint8Array(bron),true);
const verhalen=s.storyIds(),resultaten=[];const rondes=[];
try{
 for(const gegroepeerd of [false,true,true,false]){
  const uit=[],begin=performance.now();
  if(gegroepeerd){for(let i=0;i<verhalen.length;i+=32){const r=s.readStories({stories:verhalen.slice(i,i+32),view:'accepted'});if(!r.ok||r.truncated)throw Error('Onvolledige groepslezing: '+JSON.stringify(r));for(const t of r.stories){if(!t.ok)throw Error('Geweigerd verhaal '+t.story);uit.push([t.story,t.paragraphs])}}}
  else{for(const story of verhalen){const r=s.readParagraphs({story,view:'accepted'});if(!r.ok)throw Error('Geweigerd verhaal '+story);uit.push([story,r.paragraphs])}}
  const ms=performance.now()-begin,tekst=JSON.stringify(uit.sort((a,b)=>a[0].localeCompare(b[0])));resultaten.push(tekst);rondes.push({gegroepeerd,ms,verhalen:uit.length,alineas:uit.reduce((n,[,p])=>n+p.length,0),sha256:createHash('sha256').update(tekst).digest('hex')});
 }
 if(!resultaten.every(r=>r===resultaten[0]))throw Error('Groepslezing wijkt af');
 const r={geslaagd:true,bron_sha256:createHash('sha256').update(bron).digest('hex'),rondes,grens:'Losse echte SDK/Wasm-leesproef; geen GUI-snelheid of wijziging aan spellingcontrole.'};writeFileSync('.local/doorwerk-2026-11-04/incrementele-invoer/proef-gegroepeerd-lezen47.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r));
}finally{s.destroy()}
