from pathlib import Path
import json,math,statistics
p=Path(__file__).resolve().parent
namen=['oud-klein-a-bevestigd','nieuw-klein-a','nieuw-klein-b','oud-klein-b','oud-rijk','nieuw-rijk']
def stats(v):
 v=sorted(v)
 return {'aantal':len(v),'mediaan_ms':statistics.median(v),'p95_ms':v[max(0,math.ceil(len(v)*.95)-1)],'max_ms':v[-1],'som_ms':sum(v)}
uit={}
for n in namen:
 r=json.loads((p/n/'rapport.json').read_text());assert r['geslaagd'] and r['hashprobe']['vectoren']==9 and r['hashmetingen']['hersteld']
 assert r['programma_sha256']=='7afdfb82ac07c31ef1e086598e4573c9695d1e6d4b72a91ec822c30bd128aa8f'
 assert r['nativefasen']['overgeslagen']==0
 monsters=r['nativefasen']['monsters'];assert all(m['uitkomst']=='rust' for m in monsters)
 fasen={k:stats([m['stappen'][k] for m in monsters]) for k in monsters[0]['stappen']}
 hs=r['hashmetingen']['metingen'];syn=[m for m in hs if m['synchroon']]
 if n.startswith('nieuw'):assert syn
 else:assert not syn
 t=r['lange_invoer'];uit[n]={'geslaagd':True,'schema':r['schema'],'invoer':t,'native_metingen':len(monsters),'hashprobe':r['hashprobe'],'fasen':fasen,'rust_binnen':stats([m['rustBinnenMs'] for m in monsters]),'hashoproepen_hele_proef':{'aantal':len(hs),'synchroon':len(syn),'max_bytes':max(m['bytes'] or 0 for m in hs),'synchrone_duur':stats([m['duurMs'] for m in syn]) if syn else None},'native_gewone_opdrachten':len(monsters),'na_flush_tot_marker_en_twee_frames_ms':t['begin_tot_frame_ms']-t['begin_tot_bron_ms'],'fouten':r['fouten'],'stappen':r['stappen']}
(p/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for n,r in uit.items(): print(n,r['invoer']['wall_begin_tot_frame_ms'],r['invoer']['laatste_keyup_tot_frame_ms'],'hash',r['fasen']['hash'])
