import Sha256 from '../../../node_modules/.pnpm/sha.js@2.4.12/node_modules/sha.js/sha256.js';
globalThis.__proefSha256=bytes=>new Sha256().update(bytes).digest();
