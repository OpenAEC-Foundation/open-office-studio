import vm from 'node:vm';
import fs from 'node:fs';
import {createHash,webcrypto} from 'node:crypto';
const ctx=vm.createContext({Uint8Array,ArrayBuffer,DataView,console});
vm.runInContext(fs.readFileSync(new URL('./sha-bundel.js',import.meta.url),'utf8'),ctx);
let aantal=0;
for(const n of [0,1,3,55,56,63,64,65,127,128,129,255,1024,4096,65535,65536,65537,1048576]){
 const b=Uint8Array.from({length:n+10},(_,i)=>(i*31+(i>>>8))&255).subarray(5,5+n);
 const h=Buffer.from(ctx.__proefSha256(b)).toString('hex');
 const verwacht=createHash('sha256').update(b).digest('hex');
 const web=Buffer.from(await webcrypto.subtle.digest('SHA-256',b)).toString('hex');
 if(h!==verwacht||h!==web)throw Error('Ongelijke SHA bij '+n);
 aantal++;
}
for(const [s,h] of [['','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'],['abc','ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad']]){
 if(Buffer.from(ctx.__proefSha256(new TextEncoder().encode(s))).toString('hex')!==h)throw Error('Vaste vector');aantal++;
}
console.log(JSON.stringify({geslaagd:true,vectoren:aantal,grens:'Alleen lokale bundelcorrectheid; geen UI- of snelheidsacceptatie.'}));
