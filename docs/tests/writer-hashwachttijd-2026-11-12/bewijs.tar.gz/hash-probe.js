(async()=>{
 const subtiel=crypto.subtle,oud=subtiel.digest,metingen=[];
 const hex=b=>Array.from(new Uint8Array(b),n=>n.toString(16).padStart(2,'0')).join('');
 for(const n of [0,1,55,56,63,64,65,65536,65537]){
   const b=Uint8Array.from({length:n+10},(_,i)=>(i*31+(i>>>8))&255).subarray(5,5+n);
   if(hex(await oud.call(subtiel,'SHA-256',b))!==hex(Uint8Array.from(__proefSha256(b)).buffer))throw Error('SHA verschilt in WebKit bij '+n);
 }
 const mode=window.__hashproefMode;
 if(!['referentie','synchroon-klein'].includes(mode))throw Error('Onbekende hashproef');
 subtiel.digest=function(alg,data){
   const naam=typeof alg==='string'?alg:alg?.name;
   const klein=String(naam).toUpperCase()==='SHA-256'&&(data instanceof Uint8Array||data instanceof ArrayBuffer)&&data.byteLength<=65536;
   const begin=performance.now();
   if(mode==='synchroon-klein'&&klein){
     try{const b=data instanceof ArrayBuffer?new Uint8Array(data):data;const r=Uint8Array.from(__proefSha256(b)).buffer;metingen.push({bytes:b.byteLength,synchroon:true,duurMs:performance.now()-begin});return Promise.resolve(r)}catch(e){return Promise.reject(e)}
   }
   metingen.push({bytes:data?.byteLength??null,synchroon:false});
   return oud.apply(this,arguments);
 };
 window.__hashproef={mode,metingen,stop(){subtiel.digest=oud;return{mode,metingen,hersteld:subtiel.digest===oud}}};
 return {mode,vectoren:9,grensBytes:65536};
})()
