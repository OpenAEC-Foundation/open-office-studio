from pathlib import Path
import json,hashlib,tarfile,subprocess
from zipfile import ZipFile
from xml.etree import ElementTree as E
p=Path(__file__).resolve().parent
refs=json.loads((p.parent/'adaptieve-invoer/referenties-na.json').read_text())
for pad,h in {**refs['programmas'],**refs['extra_prototypes']}.items():assert hashlib.sha256(Path(pad).read_bytes()).hexdigest()==h
assert hashlib.sha256(Path('node_modules/@betteroffice/docx-react/dist/index.mjs').read_bytes()).hexdigest()==refs['sdk']
(p/'referenties-na.json').write_text(json.dumps(refs,indent=2)+'\n')
for a,b in [('oud-klein-a-bevestigd','nieuw-klein-a'),('oud-klein-a-bevestigd','nieuw-klein-b'),('oud-klein-a-bevestigd','oud-klein-b'),('oud-rijk','nieuw-rijk')]:
 with ZipFile(p/a/'Ontwerpnotitie.docx') as x,ZipFile(p/b/'Ontwerpnotitie.docx') as y:
  for z in (x,y):
   root=E.fromstring(z.read('docProps/core.xml'))
   for e in root.findall('{http://purl.org/dc/terms/}modified'):e.text='tijdstip'
   if z is x:eerste=E.tostring(root)
   else:assert E.tostring(root)==eerste
analyse=json.loads((p/'analyse.json').read_text());beelden=json.loads((p/'beeldvergelijking.json').read_text())
report={'schema':1,'datum':'2026-11-12','status':'Diagnose afgerond; variant niet overgenomen als productoplossing. Writer-invoervertraging blijft open.','broncommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'productbron':'0a43e8c603d8f7053081a23f7c78d268f8bae91c','methode':json.loads((p/'opzet.json').read_text())['methode'],'uitkomsten':analyse,'beeldvergelijking':beelden,'visuele_controle':'Vier bewaarbeelden samen bekeken: tekst, tabel, pagina-indeling en donkere weergave blijven vergelijkbaar. Korte redo-beelden pixelgelijk; kleine verschillen in titel/status/cursor vastgelegd. Geen volledige pixelacceptatie. Rijke bewaring heeft 30 afwijkende cursorpixels; nieuw-documentbeeld pixelgelijk.','bewaring':'Alle bewaarde vergelijkingspakketten zijn bytegelijk behalve docProps/core.xml; na neutraliseren van uitsluitend dcterms:modified ook die inhoud gelijk. Helpers controleren daarnaast onafhankelijk tekst en tabel-XML. Geen echte GUI-heropening van deze bewaarde pakketten getest.','controles':{'onafhankelijke_hashvectoren':20,'webkit_vectoren_per_native_proef':9,'probe_api':'Twee modi, subviews, grens 65536/65537, ArrayBuffer, andere algoritmen, DataView, originele gedelegeerde Promise, this, invoerkopie en herstel slagen.','native_geldige_ronden':6,'python_tests':127,'python_syntaxis':'Beide helpers en analyse slagen.','frontend_rust_bouw':'Deze ronde niet opnieuw uitgevoerd: geen productbron/dependency/SDK/bundel gewijzigd; vorige frontenduitslag niet als nieuwe test geclaimd.'},'afkeuring':'Eerste functioneel geslaagde referentie niet meegenomen: inspector.ev wachtte niet op de Promise van de voorcontrole. Behouden als oud-klein-a met expliciete afkeurreden; definitieve helpers wachten de negen controles af en bewaken de uitslag.','duiding':'Korte totale wall-tijd is met kandidaat in beide rondes hoger; eindlatency juist lager. Rijke kandidaat is in één paar sneller totaal, maar heeft hogere eindlatency. De gemeten hashfasetotalen dalen sterk (rijk 3721 naar263ms), maar daarmee is geen veilige totale prestatieverbetering bewezen. Native aanvragen verschillen mee doordat eventverwerking/bundeling verandert. Geen geïsoleerde CPUbenchmark of statistische acceptatie.','grenzen':['Alleen Linux x86_64, eigen Xvfb-profielen en schema2 van dezelfde vaste feature-ELF. Geen installatie/release gewijzigd.','De bestaande async hashfunctie en awaits blijven bestaan: deze proef vervangt alleen de digest-Promise bij kleine buffers. Geen bewijs over een volledig synchrone bronimplementatie.','SHA-256-controle blijft behouden; grotere buffers gebruiken WebCrypto. Bronbinding, sessie, generatie, selectie en late antwoorden zijn niet versoepeld.','Gewone timing bevat geen kunstmatig antwoorduitstel. Selectie/bewaren/verwerpen gebruiken daarna bewust vastgehouden echte antwoorden.','Keyup is WebKit-ontvangst; totale wall-tijd omvat ook achterstand vóór ontvangst. Renderlijst plus2rAFs is geen fysieke paint/FPS.','Geen schema3, Windows/macOS, alle edities, fysieke OS-IME of volledige functiedekking getest. Geen issue/migratiegebied afgerond.'],'vervolg':'Profileer Rust-serialisatie/digest/bewerking afzonderlijk; onderzoek hoofdthreadwerk tussen flush en frame. Een eventuele volledig synchrone kleine hashroute vereist een afzonderlijke productproef met bron-/sessiechecks en korte én rijke latency.','bronlezing':json.loads((p/'bronlezing.json').read_text()),'bestanden_behouden':True,'geen_productwijziging':True}
(p/'samenvatting.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
# Alleen eigen meetbronnen, ruwe proeven, beelden, licenties en logs; geen ELF/cache.
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name not in ['sha-controle.js'])
doel=Path('docs/tests/writer-hashwachttijd-2026-11-12/bewijs.tar.gz');doel.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(doel,'w:gz') as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(doel,'r:gz') as tar:
 leden=tar.getmembers();assert len(leden)==len(files)
 for m in leden:assert hashlib.sha256(tar.extractfile(m).read()).digest()==hashlib.sha256((p/m.name).read_bytes()).digest()
report['bewijs']={'pad':str(doel),'sha256':hashlib.sha256(doel.read_bytes()).hexdigest(),'bytes':doel.stat().st_size,'bestanden':len(files),'alle_leden_bytegelijk_gecontroleerd':True}
Path('docs/tests/2026-11-12-writer-hashwachttijd.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report['bewijs']))
