import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto,createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const bundel=fs.readFileSync(new URL('./sha-bundel.js',import.meta.url),'utf8');
const probe=fs.readFileSync(new URL('./hash-probe.js',import.meta.url),'utf8');
for(const mode of ['referentie','synchroon-klein']){
 const aanroepen=[];
 const subtiel={digest(...args){assert.equal(this,subtiel);const p=webcrypto.subtle.digest(...args);aanroepen.push({args,p});return p}};
 const origineel=subtiel.digest;
 const ctx=vm.createContext({Uint8Array,ArrayBuffer,DataView,Promise,performance,crypto:{subtle:subtiel},__hashproefMode:mode});ctx.window=ctx;
 vm.runInContext(bundel,ctx);
 const opzet=await vm.runInContext(probe,ctx);assert.equal(opzet.vectoren,9);assert.equal(aanroepen.length,9);
 for(const n of [0,1,55,56,63,64,65,65535,65536,65537]){
  const data=Uint8Array.from({length:n+9},(_,i)=>i&255).subarray(5,n+5);
  const p=subtiel.digest({name:'SHA-256'},data);
  if(mode==='referentie'||n>65536)assert.equal(p,aanroepen.at(-1).p);
  const r=await p;assert.ok(r instanceof ArrayBuffer);assert.equal(r.byteLength,32);
  assert.equal(Buffer.from(r).toString('hex'),createHash('sha256').update(data).digest('hex'));
 }
 const anders=subtiel.digest('SHA-512',new Uint8Array(3));assert.equal(anders,aanroepen.at(-1).p);await anders;
 const groot=new ArrayBuffer(65537);const p=subtiel.digest('SHA-256',groot);assert.equal(p,aanroepen.at(-1).p);await p;
 const view=new DataView(new ArrayBuffer(4));const q=subtiel.digest('SHA-256',view);assert.equal(q,aanroepen.at(-1).p);await q;
 const eigen=new Uint8Array([1,2,3]);const h=subtiel.digest('SHA-256',eigen);eigen.fill(0);
 assert.equal(Buffer.from(await h).toString('hex'),createHash('sha256').update(new Uint8Array([1,2,3])).digest('hex'));
 const result=ctx.__hashproef.stop();assert.equal(result.hersteld,true);assert.equal(subtiel.digest,origineel);
 assert.equal(result.metingen.filter(m=>m.synchroon).length,mode==='referentie'?0:10);
}
console.log(JSON.stringify({geslaagd:true,modi:2,controles:'Bekende SHA-waarden, subviews, grens 65536/65537, ArrayBuffer, andere algoritmen, DataView, originele Promise bij delegatie, this, invoerkopie en herstel.'}));
