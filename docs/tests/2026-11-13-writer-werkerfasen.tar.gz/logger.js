var __wfActief=false,__wfRegels=[],__wfOver=0;
function __wf(soort,id,type){if(!__wfActief)return;try{if(__wfRegels.length<8192)__wfRegels.push({soort,id:id??null,type:type??null,tijd:performance.now()});else __wfOver++}catch{}}
if(typeof WorkerGlobalScope!=="undefined"&&globalThis instanceof WorkerGlobalScope)globalThis.__OPENAEC_WERKER_FASEN__={start(){__wfRegels=[];__wfOver=0;__wfActief=true;return true},note:__wf,stop(){__wfActief=false;return{regels:__wfRegels,overgeslagen:__wfOver,grens:8192}}};
