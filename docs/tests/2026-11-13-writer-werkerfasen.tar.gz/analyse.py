from pathlib import Path
import json,collections,statistics,hashlib
from zipfile import ZipFile
from xml.etree import ElementTree as ET
p=Path(__file__).resolve().parent
uit={}
for naam in ['opname','herhaling']:
 q=p/naam
 if not (q/'rapport.json').exists():continue
 r=json.load(open(q/'rapport.json'));raw=r['fasen_eind'][0]['result']['result']['value'];assert not raw['overgeslagen'];xs=raw['regels'];taken={};fases=collections.defaultdict(list);openf={}
 for x in xs:
  if x['soort']=='ontvangst':taken.setdefault(x['id'],{})['ontvangst']=x
  elif x['soort']=='taak.begin':taken.setdefault(x['id'],{})['begin']=x
  elif x['soort']=='taak.einde':taken.setdefault(x['id'],{})['eind']=x
  elif x['soort'].endswith('.begin'):openf[(x['soort'].split('.')[0],x['id'])]=x
  elif x['soort'].endswith('.einde'):
   k=(x['soort'].split('.')[0],x['id']);b=openf.pop(k);fases[k[0]].append({'id':x['id'],'begin':b['tijd'],'eind':x['tijd'],'ms':x['tijd']-b['tijd']})
 for id,v in taken.items():
  if 'ontvangst' in v and 'begin' in v:v['wachttijd_ms']=v['begin']['tijd']-v['ontvangst']['tijd']
  if 'begin' in v and 'eind' in v:v['taak_ms']=v['eind']['tijd']-v['begin']['tijd']
 with ZipFile(q/'Ontwerpnotitie.docx') as z:
  assert z.testzip() is None;xml=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tekst=''.join(x.text or '' for x in xml.findall('.//w:t',ns));assert len(xml.findall('.//w:tbl',ns))==128 and len(tekst.encode('utf-16-le'))//2==91423
 assert hashlib.sha256((q/'Ontwerpnotitie.docx').read_bytes()).hexdigest()==r['bewaring_sha256']
 uit[naam]={'geslaagd':r['geslaagd'],'fout':r.get('fout'),'invoer':r['lange_invoer'],'fases':dict(fases),'sommen':{k:{'aantal':len(v),'som_ms':sum(x['ms'] for x in v),'mediaan_ms':statistics.median(x['ms'] for x in v)} for k,v in fases.items()},'bewaartaken':{k:v for k,v in taken.items() if v.get('begin',{}).get('type')=='save'},'alle_taken':taken,'open_fases':list(map(str,openf)),'regels':len(xs),'docx_sha256':r['bewaring_sha256'],'docx_tabellen':128,'docx_utf16':91423,'stappen':r['stappen']}
(p/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for n,v in uit.items():print(n,v['geslaagd'],v['sommen'],v['bewaartaken'])
