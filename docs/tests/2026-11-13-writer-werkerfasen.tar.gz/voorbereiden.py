from pathlib import Path
import shutil,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/werker-fasekopie';bron=r/'.local/integratiecontrole/lint-invoer/dist';doel=p/'dist'
assert not doel.exists();shutil.copytree(bron,doel,copy_function=shutil.copy2)
log='''var __wfActief=false,__wfRegels=[],__wfOver=0;
function __wf(soort,id,type){if(!__wfActief)return;try{if(__wfRegels.length<8192)__wfRegels.push({soort,id:id??null,type:type??null,tijd:performance.now()});else __wfOver++}catch{}}
if(typeof WorkerGlobalScope!=="undefined"&&globalThis instanceof WorkerGlobalScope)globalThis.__OPENAEC_WERKER_FASEN__={start(){__wfRegels=[];__wfOver=0;__wfActief=true;return true},note:__wf,stop(){__wfActief=false;return{regels:__wfRegels,overgeslagen:__wfOver,grens:8192}}};
'''
(p/'logger.js').write_text(log)
patches=[]
def wijzig(naam,aanpassingen):
 f=doel/'assets'/naam;s=f.read_text();oud=s
 for a,b in aanpassingen:
  assert s.count(a)==1,(naam,a[:100],s.count(a));s=s.replace(a,b,1)
 f.write_text(s);assert f.stat().st_nlink==1
 patches.append({'bestand':naam,'voor':hashlib.sha256(oud.encode()).hexdigest(),'na':hashlib.sha256(s.encode()).hexdigest(),'vervangingen':len(aanpassingen)})
wijzig('chunk-Q7OC7M5Q-BzppsI5m.js',[
 ('async function Cc(e){ao.add(e.id)',log+'async function Cc(e){__wf("taak.begin",e.id,e.type);ao.add(e.id)'),
 ('finally{ao.delete(e.id)}}function wd','finally{__wf("taak.einde",e.id,e.type);ao.delete(e.id)}}function wd'),
 ('ra.onmessage=e=>{let t=e.data;','ra.onmessage=e=>{let t=e.data;__wf("ontvangst",t.id,t.type);'),
 ('let i=e.layoutFontRequirementsJson(Ro(e,t));','let i;__wf("font.begin",Mo,"font");try{i=e.layoutFontRequirementsJson(Ro(e,t))}finally{__wf("font.einde",Mo,"font")}'),
 ('let a=e.commentsSource==="host"?e.comments:i?.comments??e.comments,o=(no?await N.saveDocument(e.host,a,Tn):await N.save(new Uint8Array(Qt.bytes),Qt.hostJson,e.host,a,Tn,e.stories)).slice(0),s=e.stateVector?[Ft(N.encodeStateAsUpdate(e.stateVector))]:[],l=Ft(N.encodeStateVector()),d={saved:o,updates:s,stateVector:l,version:N.proposalEngine.version()};',
  'let a=e.commentsSource==="host"?e.comments:i?.comments??e.comments;__wf("save.begin",e.id,e.type);let o;try{o=(no?await N.saveDocument(e.host,a,Tn):await N.save(new Uint8Array(Qt.bytes),Qt.hostJson,e.host,a,Tn,e.stories)).slice(0)}finally{__wf("save.einde",e.id,e.type)}__wf("updatecode.begin",e.id,e.type);let s,l;try{s=e.stateVector?[Ft(N.encodeStateAsUpdate(e.stateVector))]:[];l=Ft(N.encodeStateVector())}finally{__wf("updatecode.einde",e.id,e.type)}let d={saved:o,updates:s,stateVector:l,version:N.proposalEngine.version()};')])
naam='chunk-YTGFUEEE-BR8wyl1E.js';f=doel/'assets'/naam;s=f.read_text();orig=s
s=s.replace('async function E(c,f,l,m,p,d,o,u,w){','function wf(s){try{globalThis.__OPENAEC_WERKER_FASEN__?.note(s,null,"resident")}catch{}}async function E(c,f,l,m,p,d,o,u,w){wf("resident.begin");try{',1)
s=s.replace('let t=x(e.session,h(s,p??e.host.document),a.projectionOptions());','wf("projectie.begin");let t;try{t=x(e.session,h(s,p??e.host.document),a.projectionOptions())}finally{wf("projectie.einde")}',1)
s=s.replace('let n=await D(e.session,t,d,o);','wf("pakket.begin");let n;try{n=await D(e.session,t,d,o)}finally{wf("pakket.einde")}',1)
s=s.replace('r.clear(),n}export','r.clear(),n}finally{wf("resident.einde")}}export',1)
assert s!=orig and all(s.count(t)==1 for t in ['wf("resident.begin")','wf("resident.einde")','wf("projectie.begin")','wf("projectie.einde")','wf("pakket.begin")','wf("pakket.einde")']);f.write_text(s)
patches.append({'bestand':naam,'voor':hashlib.sha256(orig.encode()).hexdigest(),'na':hashlib.sha256(s.encode()).hexdigest(),'vervangingen':4})
(p/'bundelwijzigingen.json').write_text(json.dumps(patches,indent=2)+'\n')
print(json.dumps(patches))
