from pathlib import Path
import json,hashlib,stat,tarfile,shutil
from zipfile import ZipFile
p=Path(__file__).resolve().parent;repo=p.parents[2]
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
refs=json.load(open(p/'referenties-voor.json'));bouw=json.load(open(p/'desktop.json'));assert bouw['code']==0
refs[str(p/'open-office-studio-werker-fasemeting')]=bouw['programma_sha256'];assert len(refs)==16
for q,h in refs.items():assert sha(Path(q))==h,q
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
oud=json.load(open(p/'standaardbundel.json'));assert len(oud)==529
for n,v in oud.items():
 q=repo/'dist'/n;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],n
assert len([q for q in (repo/'dist').rglob('*') if q.is_file()])==529
sdk=repo/'node_modules/@betteroffice/docx-react/dist/index.mjs';assert sha(sdk)=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
anal=json.load(open(p/'analyse.json'));assert len(anal)==2
with ZipFile(repo/'.local/integratiecontrole/bewaar-werkerprofiel/opname/Ontwerpnotitie.docx') as z:oud_pakket={n:z.read(n) for n in z.namelist()}
vergelijking={}
for naam,v in anal.items():
 assert v['geslaagd'] and not v['open_fases']
 with ZipFile(p/naam/'Ontwerpnotitie.docx') as z:nieuw={n:z.read(n) for n in z.namelist()}
 verschil=[n for n in sorted(set(oud_pakket)|set(nieuw)) if oud_pakket.get(n)!=nieuw.get(n)];assert set(verschil)<={'docProps/core.xml'};vergelijking[naam]=verschil
 for taak in v['bewaartaken'].values():assert taak['wachttijd_ms']==0
 for antwoord in json.load(open(p/naam/'rapport.json'))['werkers_binnen_eind']:
  w=antwoord['antwoord']['result']['result']['value'];assert w['hersteld'] and w['overgeslagen']==0
for naam in ['probe.js','werker.js','binnen.js']:
 shutil.copyfile(repo/'.local/integratiecontrole/bewaar-werker'/naam,p/naam)
(p/'wachtrij-probe.js').write_bytes((repo/'.local/integratiecontrole/adaptieve-invoer/wachtrij-probe.js').read_bytes())
(p/'behoud.json').write_text(json.dumps({'referenties_exact':16,'standaardbundel_byte_mode_mtime_exact':529,'sdk_index_sha256':sha(sdk),'sdk_bestanden_niet_bewerkt':True,'productbron_niet_gewijzigd':True},indent=2)+'\n')
files=[q for q in p.rglob('*') if q.is_file() and 'dist' not in q.relative_to(p).parts and '__pycache__' not in q.relative_to(p).parts and q.name!='open-office-studio-werker-fasemeting']
archief=repo/'docs/tests/2026-11-13-writer-werkerfasen.tar.gz'
with tarfile.open(archief,'w:gz') as t:
 for q in sorted(files):t.add(q,arcname=q.relative_to(p),recursive=False)
with tarfile.open(archief) as t:
 assert len(t.getmembers())==len(files)
 for m in t.getmembers():assert m.isfile() and sha(p/m.name)==hashlib.sha256(t.extractfile(m).read()).hexdigest()
rapport={'datum':'2026-11-13','basis_integratie':'a1478a2c','basis_productbron':'41e7000198f89d992e1059e9715636a44b39d21a','besluit':'Diagnostische kopie, geen productfix. Fontwerk tijdens invoer en afzonderlijke save-projectie/pakketfasen daadwerkelijk geklokt. Beide volledige native functieronden groen.','programma':bouw,'bundelwijzigingen':json.load(open(p/'bundelwijzigingen.json')),'ronden':anal,'pakketverschillen_tegen_vorige_referentieronde':vergelijking,'validatie':['Twee gewijzigde gekopieerde JS-bestanden door Node-syntaxcontrole;4loggercontroles groen;Python-collector compileert.','Native Linux-featurebouw groen,alleen app-crate opnieuw gecompileerd,119sec. Geen Vite/SDK/productbron gewijzigd.','Beide eigen native Linux/schema2-ronden behouden bron/opmaak/UndoRedo/selectie/vervangen/bewaren/verwerpen/nieuwdocument/laatantwoord.','Twee DOCX onafhankelijkSHA/ZIP/CRC/XML:128tabellen/91423UTF16, exact dezelfde pakketdelen als vorige referentie behalvecore.xml.','Herhalingsbewaarbeeld bekeken: lint,tekst,tabellen,paginaovergang zichtbaar. Geen volledige65pagina-/pixelacceptatie.','Vijftien eerdere ELF-referenties behouden; nieuwe2f3beb apart als16de. Standaarddist529bestanden byte/mode/mtime exact hersteld;SDK-index exact,geenSDKbestanden bewerkt.'],'grenzen':['Ingebedde compiled-JS-meetkopie,oudebestandsnamen behouden met gedocumenteerde nieuwe hashes; alleen eigen ELF,geen installatie/release.','Klokken zijn verstreken milliseconden in dezelfdeWorker. Fontfunctie/projectie/updateencoding synchronisch; pakket/save/resident omvatten await/scheduling. Geen exclusieveCPU-tijd of uitsluitendZIP-tijd.','Fontsom betreft hele invoerperiode:63/64aanroepen,6358/6500ms. Niet bij de eindstaart optellen.','Save2920/2938ms enresident2906/2926ms bevatten projectie737/756ms enpakket1784/1774ms. Geen overlappende fases optellen; overigeworkerwerking blijft apart.','Ontvangst→taakstart0ms op deze twee save-aanvragen bij klokresolutie van circa1ms; geen algemene wachtrijgarantie.','Geen onbeïnvloede ABBA-snelheidsvergelijking. Extra klokken/inspectors/profilers kunnen uitvoering beïnvloeden.','Bestaande externe fase-/transportprobes ongewijzigd uit vorige25getestecontroles gebruikt; niet opnieuw alle25synthetischecontroles uitgevoerd. Nieuwe4loggercontroles apart.','Geen volledige frontend/TS/Python-producttests/CI voor deze private meetkopie; geen platform-/release-/migratieacceptatie of geheugenfoutfix.'],'behoud':json.load(open(p/'behoud.json')),'vervolg':'Prioriteer aantoonbaar herhaald fontwerk: onderzoek versievaste samenvoeging van fontRequests of incrementele fontvereisten in native/vendor/docx-edit/src/engine.rs::layout_font_requirements/with_resident_story. Behoud nieuweUnicode-/fallbackfonts, stijlen, previews, body/cellen/koppen/noten en actieve bron/versie; huidigefontcache vervalt op iedere update. Geen blinde stale-cache. Controleer werkelijkeWasm/nativebronbinding vóór kernwijziging. Pakket1780ms enprojectie750ms zijn afzonderlijke tweede onderzoekslijn; updateencoding1–2ms geenprioriteit. Nieuwe gerichte kandidaat alleen na equivalentieproeven en vaste korte/rijke ABBA met inhoud/beeldbehoud. Tien migratiegebieden/geheugenfouten open; Database laatst.','bewijs':{'pad':str(archief.relative_to(repo)),'sha256':sha(archief),'bytes':archief.stat().st_size,'reguliere_leden':len(files),'alle_leden_byteexact_gecontroleerd':True}}
(repo/'docs/tests/2026-11-13-writer-werkerfasen.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rapport['bewijs']))
