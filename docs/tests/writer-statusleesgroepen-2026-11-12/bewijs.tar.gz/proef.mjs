import { createYrsSession } from '@betteroffice/docx/yrs';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>createHash('sha256').update(b).digest('hex');
const uit=[];
for(const pad of ['docs/tests/writer-doortypen/bron.docx','docs/voorbeelden/Ontwerpnotitie.docx']) {
 const bytes=readFileSync(pad),s=await createYrsSession({clientId:995});
 try {
 s.openDocx(new Uint8Array(bytes),true);
 const versie=s.version(),vector=s.encodeStateVector();
 const ids=s.storyIds().filter(id=>id==='body'||/^body:t\d+:r\d+c\d+/.test(id));
 if(!ids.includes('body'))ids.unshift('body');
 const begin=performance.now(),oud=ids.map(story=>{const r=s.readParagraphs({view:'accepted',story});assert.equal(r.ok,true);return {story,paragraphs:r.paragraphs}}),oudMs=performance.now()-begin;
 const nieuw=[],start=performance.now();let groepen=0;
 for(let i=0;i<ids.length;i+=32){
 const vraag=ids.slice(i,i+32),r=s.readStories({view:'accepted',stories:vraag});groepen++;
 assert.equal(r.ok,true);assert.equal(r.truncated,false);assert.equal(r.version,versie);assert.equal(r.view,'accepted');
 const map=new Map(r.stories.map(x=>[x.story,x]));assert.equal(map.size,vraag.length);assert.equal(r.stories.length,vraag.length);
 for(const story of vraag){const v=map.get(story);assert.equal(v.ok,true);assert.ok(v.paragraphs.every(p=>p.story===story));nieuw.push({story,paragraphs:v.paragraphs})}
 }
 const nieuwMs=performance.now()-start;
 assert.deepEqual(nieuw,oud);assert.equal(s.version(),versie);assert.deepEqual(s.encodeStateVector(),vector);
 uit.push({pad,bron_sha256:sha(bytes),verhalen:ids.length,alineas:oud.reduce((n,r)=>n+r.paragraphs.length,0),oud_aanroepen:ids.length,groepen,oudMs,nieuwMs,exacte_alineas:true,bron_ongewijzigd:true});
 }finally{s.destroy()}
}
writeFileSync('.local/integratiecontrole/status-leesgroepen/rapport.json',JSON.stringify({uit,grenzen:'Componentproef op echte Wasm-sessie; geen pluginlevensduur, GUI, invoerlatency, versieovergang of afgekorte resultaten geaccepteerd. Volgorde oud/nieuw, geen snelheidsacceptatie.'},null,2)+'\n');
console.log(uit);
