from pathlib import Path
import json,hashlib,tarfile,subprocess,datetime,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-middelen';s=r/'native/onderzoek/writer-bronjournaal'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
uit=json.loads((u/'uitkomst.json').read_text());extra=json.loads((u/'aanvullend.json').read_text());assert len(uit)==4 and all(x['code']==0 for x in uit);assert [x['code'] for x in extra]==[0,0,101]
for naam in ['journaal.rs','proef.rs','geschiedenis.rs','unicode.rs','grenzen.rs','middelen.rs']:assert (s/naam).read_bytes()==(u/'voorbereid'/naam).read_bytes()
p=subprocess.run(['python3',str(s/'voorbereiden.py'),'--uitvoer',str(u/'voorbereid')],capture_output=True,text=True);assert p.returncode!=0 and 'niets overschreven' in p.stderr;(u/'bestaande-uitvoer.log').write_text(p.stdout+p.stderr)
libs={}
for v in uit[0]['bouwopdracht']:
 if '.rlib' in v:
  naam,pad=v.split('=',1);libs[naam]={'pad':pad,'sha256':sha(Path(pad))}
(u/'bibliotheken.json').write_text(json.dumps(libs,indent=2))
keuze=[p for p in u.iterdir() if p.suffix in ['.json','.log','.py']]+[p for p in (u/'mutant').iterdir() if p.suffix in ['.rs','.log']]+[p for p in s.iterdir() if p.suffix in ['.rs','.py','.json','.md']]
for p in [r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json',r/'.local/integratiecontrole/journaal-geschiedenis/aanvraagreeks.json',r/'.local/integratiecontrole/journaal-unicode/definitief-gewoon-aanvragen.json',r/'.local/integratiecontrole/journaal-unicode/definitief-revisie-aanvragen.json']:keuze.append(p)
map=r/'docs/tests/writer-middelen-2026-11-11';map.mkdir(exist_ok=True);archief=map/'bewijs.tar.gz'
manifest={str(p.relative_to(r)):sha(p) for p in keuze}
with tarfile.open(archief,'w:gz') as t:
 for p in keuze:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(archief) as t:
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]
rapport={'datum_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Getypeerde toelating uitsluitend in afzonderlijk onderzoeksprototype; geen productintegratie.','bronbasis':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'bronbestanden':{str(p.relative_to(r)):sha(p) for p in s.iterdir() if p.is_file()},'controles':uit,'aanvullend':extra,'middelen':json.loads((u/'middelen.log').read_text()),'voorbereiden':{'zes_bronnen_bytegelijk':True,'alle_vendorpinnen_gevalideerd':True,'bestaande_uitvoer_geweigerd':True},'archief':{'pad':str(archief.relative_to(r)),'bytes':archief.stat().st_size,'sha256':sha(archief),'alle_bestandsbytes_teruggelezen':True,'manifest':manifest},'niet_getest':['Echte bronnen van 64–100 MiB, native heap en langdurige grote sessies','Desktopadapter, GUI, fysieke typvertraging, selectie, opslaan/heropenen/verwerpen met dit journaal','Unicode/IME en revisies via nieuwe GUI-route','Nieuwe desktopbuild, platformen en zeven edities'],'product':'Tauri/React/SDK, versie, geïnstalleerde app, documenten en referentiebinaries ongewijzigd. Geen issue of migratiegebied voltooid.','volgende_stap':'Voor productintegratie echte grote bron-/heap-/langdurige-sessiegrenzen en transactief herstel controleren; daarna expliciete adapter met schema-2-volledige-bronvalidatie en GUI-pariteit. Geen blinde fallback op ongeldige bronbinding.','vrije_gib':round(shutil.disk_usage(r).free/1024**3,2)}
(r/'docs/tests/2026-11-11-writer-middelen.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archief_bytes':archief.stat().st_size,'sha256':sha(archief),'vrije_gib':rapport['vrije_gib']},indent=2))
