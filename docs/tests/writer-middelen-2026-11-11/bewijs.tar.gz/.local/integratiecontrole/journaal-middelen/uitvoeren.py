import json,subprocess,pathlib,shutil,time,hashlib,os
r=pathlib.Path.cwd(); uit=r/'.local/integratiecontrole/journaal-middelen'; basis=json.loads((r/'.local/integratiecontrole/bronjournaal/bouw-proef-herhaling.json').read_text())['opdracht']; resultaten=[]
assert shutil.disk_usage(r).free>1.5*1024**3
for naam,args in [('middelen',[str(r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json')]),('proef',[str(r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json')]),('geschiedenis',[str(r/'.local/integratiecontrole/journaal-geschiedenis/aanvraagreeks.json')]),('grenzen',[])]:
    cmd=basis.copy(); cmd[cmd.index('-o')-1]=str(r/f'native/onderzoek/writer-bronjournaal/{naam}.rs');cmd[cmd.index('-o')+1]=str(uit/naam)
    t=time.monotonic()
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=60);(uit/f'{naam}-bouw.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(naam,p.stderr)
    p=subprocess.run([str(uit/naam)]+args,capture_output=True,text=True,timeout=90);(uit/f'{naam}.log').write_text(p.stdout+p.stderr)
    resultaten.append({'naam':naam,'code':p.returncode,'seconden':time.monotonic()-t,'bouwopdracht':cmd,'argumenten':args,'binary_sha256':hashlib.sha256((uit/naam).read_bytes()).hexdigest()})
    (uit/'uitkomst.json').write_text(json.dumps(resultaten,indent=2));assert p.returncode==0,(naam,p.stderr)
print(json.dumps(resultaten,indent=2))
