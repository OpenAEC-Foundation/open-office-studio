import json,pathlib,subprocess,shutil,hashlib
r=pathlib.Path.cwd();u=r/'.local/integratiecontrole/journaal-middelen';basis=json.loads((r/'.local/integratiecontrole/bronjournaal/bouw-proef-herhaling.json').read_text())['opdracht'];bron=r/'native/onderzoek/writer-bronjournaal';result=[]
# De nieuwe bron moet nog steeds beide eerder vastgelegde Unicode-afleidingen verwerken.
for naam in ['journaal-unicode','journaal-unicode-revisie']:
    p=r/('.local/integratiecontrole/journaal-unicode/definitief-gewoon-aanvragen.json' if naam=='journaal-unicode' else '.local/integratiecontrole/journaal-unicode/definitief-revisie-aanvragen.json')
    if not p.exists():
        kandidaten=list((r/f'.local/integratiecontrole/{naam}').glob('*.json'))
        raise RuntimeError(str(kandidaten))
    a=subprocess.run([str(u/'geschiedenis'),str(p)],capture_output=True,text=True,timeout=90)
    (u/f'{naam}.log').write_text(a.stdout+a.stderr);assert a.returncode==0,a.stderr
    result.append({'naam':naam,'code':a.returncode,'dataset_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
# Weglaten van bronhashvalidatie moet de corruptie-afkeur aantoonbaar laten falen.
m=u/'mutant';m.mkdir(exist_ok=True);shutil.copyfile(bron/'middelen.rs',m/'middelen.rs');s=(bron/'journaal.rs').read_text();oud=' || sha(&bytes) != a.snapshot_sha256';assert s.count(oud)==1;s=s.replace(oud,'');(m/'journaal.rs').write_text(s)
cmd=basis.copy();cmd[cmd.index('-o')-1]=str(m/'middelen.rs');cmd[cmd.index('-o')+1]=str(m/'middelen');p=subprocess.run(cmd,capture_output=True,text=True,timeout=60);(m/'bouw.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
p=subprocess.run([str(m/'middelen'),str(r/'.local/integratiecontrole/bronhergebruik/aanvraagreeks.json')],capture_output=True,text=True,timeout=90);(m/'proef.log').write_text(p.stdout+p.stderr);assert p.returncode==101 and 'Corruptie mag geen routekeuze zijn: snapshotSha256' in p.stderr,p.stderr
result.append({'naam':'mutant_zonder_hashcontrole','code':p.returncode,'verwacht_afgekeurd':True,'bouwopdracht':cmd})
(u/'aanvullend.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
