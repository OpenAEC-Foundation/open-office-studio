from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/adaptieve-invoer';e=os.environ.copy();e['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+e['PATH'];py='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python'
nieuw=u/'open-office-studio-adaptieve-bundels';oud=r/'.local/integratiecontrole/journaal-profiel/open-office-studio-tabelpagina'
proeven=[('oud-klein-a',oud,u/'kleine-invoer.py',0),('nieuw-klein-a',nieuw,u/'kleine-invoer.py',0),('nieuw-klein-b',nieuw,u/'kleine-invoer.py',0),('oud-klein-b',oud,u/'kleine-invoer.py',0)]
result=[]
for naam,exe,script,schema in proeven:
 e['OFFICE_TEST_JOURNAAL']=str(schema);cmd=[py,str(script),'--programma',str(exe),'--uitvoer',str(u/naam),'--versie','2026.45.52'];start=time.monotonic()
 with (u/(naam+'.log')).open('x') as f:
  p=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=450)
 result.append({'naam':naam,'code':p.returncode,'seconden':time.monotonic()-start,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()});(u/'native-klein.json').write_text(json.dumps(result,indent=2));print(json.dumps(result[-1]),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
