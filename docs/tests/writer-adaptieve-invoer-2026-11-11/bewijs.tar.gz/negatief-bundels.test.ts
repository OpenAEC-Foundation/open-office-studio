/** Voer de echte toelatings-/bundelcallback van de vastgezette SDK uit. */
import { readFileSync } from "node:fs";
import { describe, expect, it, vi } from "vitest";

const bron = readFileSync(".local/integratiecontrole/invoerwachtrij/oude-sdk-index.mjs", "utf8");
const begin = bron.indexOf("U=useCallback((h,H,z=false)=>{"), einde = bron.indexOf(",Se=useCallback", begin);
if (begin < 0 || einde < 0) throw Error("Controleer de teksttoelating na een SDK-update");
const captureVenster = Number(bron.match(/\bzv=(\d+)/)?.[1]);
if (!Number.isFinite(captureVenster)) throw Error("Het bestaande capturevenster is niet gevonden");

function proef(nativeAan = true, compositie = false) {
  let actueel = true;
  let onderbreek!: () => void;
  let nu = 100;
  const taken: (() => Promise<void>)[] = [];
  const positie = { story: "body", paraId: "alinea", offset: 0 };
  const native = vi.fn(async (..._args: unknown[]) => true);
  const context = {
    useCallback: (fn: unknown) => fn, Ue: { current: { reset: vi.fn() } }, u: { insertText: vi.fn(() => ({ range: undefined })), setSelection: vi.fn(), addUndoBoundary: vi.fn() }, n: false,
    Ee: vi.fn(() => false), Nt: vi.fn(), ke: vi.fn(() => ({ anchor: positie, head: positie })),
    g: () => ({}), ea: () => ({ story: "body", start: positie, end: positie }),
    he: { current: new Map() }, G: { current: null }, Wl: () => true, f: false,
    k: nativeAan ? undefined : vi.fn(async () => ({})), _openaecNativeTekst: nativeAan ? native : null, vt: () => undefined, $: () => actueel,
    yt: vi.fn(), dn: vi.fn(), i: compositie ? { current: true } : undefined, kt: { current: null },
    W: (fn: () => Promise<void>) => { onderbreek(); taken.push(fn); }, ct: { current: null }, performance: { now: () => nu }, zv: captureVenster,
  };
  const resetBegin = bron.indexOf("Xt=useCallback(()=>{kt.current=null,ct.current=null"), resetEinde = bron.indexOf(",Yn=useRef", resetBegin);
  if (resetBegin < 0 || resetEinde < 0) throw Error("Controleer de bestaande bundelonderbreking na een SDK-update");
  onderbreek = new Function(...Object.keys(context), `return ${bron.slice(resetBegin + 3, resetEinde)}`)(...Object.values(context));
  const U = new Function(...Object.keys(context), `return ${bron.slice(begin + 2, einde)}`)(...Object.values(context));
  return { U, native, taken, context, onderbreek, sluit() { actueel = false; }, tijd(t: number) { nu = t; }, async klaar() { for (const fn of taken) await fn(); } };
}

describe("oorspronkelijke tijdspan van gewone native invoer", () => {
  it("bundelt snelle invoer met haar eerste en laatste toelatingstijd", async () => {
    const p = proef();
    p.U("A", 100); p.U("B", 120);
    expect(p.taken).toHaveLength(1);
    await p.klaar();
    expect(p.native.mock.calls.map(a => [a[2], a[5]])).toEqual([["AB", [100, 120]]]);
  });

  it("laat een echte pauze als twee bundels bestaan terwijl eerdere invoer nog wacht", async () => {
    const p = proef();
    p.U("A", 100); p.U("B", 1000);
    expect(p.taken).toHaveLength(2);
    await p.klaar();
    expect(p.native.mock.calls.map(a => [a[2], a[5]])).toEqual([["A", [100, 100]], ["B", [1000, 1000]]]);
  });

  it("legt ontbrekende tijd direct bij toelaten vast en niet bij uitvoeren", async () => {
    const p = proef();
    p.tijd(100); p.U("A"); p.tijd(120); p.U("B");
    p.tijd(5000); await p.klaar();
    expect(p.native.mock.calls.map(a => [a[2], a[5]])).toEqual([["AB", [100, 120]]]);
  });

  it("behoudt tijdspans van verdere invoer terwijl het eerste antwoord nog wacht", async () => {
    const p = proef();
    let los!: (v: boolean) => void;
    let gestart!: () => void;
    const begonnen = new Promise<void>(r => { gestart = r; });
    p.native.mockImplementationOnce(() => { gestart(); return new Promise<boolean>(r => { los = r; }); });
    p.U("A", 100);
    const bezig = p.taken.shift()!();
    await begonnen;
    p.U("B", 120); p.U("C", 130); p.U("D", 1000);
    expect(p.taken).toHaveLength(2);
    los(true); await bezig; await p.klaar();
    expect(p.native.mock.calls.map(a => [a[2], a[5]])).toEqual([
      ["A", [100, 100]], ["BC", [120, 130]], ["D", [1000, 1000]],
    ]);
  });
});

describe("bundelen nadat de native wachtrij al gestart is", () => {
  it("neemt nieuwe letters mee vóór het maken van het eerste native verzoek", async () => {
    const p = proef();
    p.U("A", 100); p.U("B", 120);
    const bezig = p.taken.shift()!();
    p.U("C", 130);
    expect(p.native).not.toHaveBeenCalled();
    expect(p.taken).toHaveLength(0);
    await bezig;
    expect(p.native.mock.calls.map(a => [a[2], a[5]])).toEqual([["ABC", [100, 130]]]);
  });

  it("leest geen gesloten sessie na het wachten en ruimt de oude bundel op", async () => {
    const p = proef();
    p.U("A", 100); p.U("B", 104);
    const bezig = p.taken.shift()!();
    p.sluit();
    await bezig;
    expect(p.context.ke).not.toHaveBeenCalled();
    expect(p.native).not.toHaveBeenCalled();
    expect(p.context.kt.current).toBeNull();
  });

  it("voegt tekst na een selectieonderbreking niet aan de eerdere bundel toe", async () => {
    const p = proef();
    p.U("A", 100);
    const bezig = p.taken.shift()!();
    // De bestaande selectie-/opdrachtenroute verbreekt deze bundelreferentie.
    p.onderbreek();
    p.U("B", 120);
    await bezig; await p.klaar();
    expect(p.native.mock.calls.map(a => [a[2], a[5]])).toEqual([["A", [100, 100]], ["B", [120, 120]]]);
  });

  it("laat de oorspronkelijke route zonder native provider direct beginnen", async () => {
    const p = proef(false);
    p.U("A", 100);
    const bezig = p.taken.shift()!();
    expect(p.context.k).toHaveBeenCalledWith("A");
    await bezig;
    expect(p.native).not.toHaveBeenCalled();
  });
});

describe("bestaande invoerpaden buiten gewone native bundels", () => {
  it("verwerkt Unicode direct op het oorspronkelijke pad met UTF-16-posities", async () => {
    const p = proef();
    p.U("é🙂", 100);
    const bezig = p.taken.shift()!();
    expect(p.context.u.insertText).toHaveBeenCalledWith({ story: "body", paraId: "alinea", offset: 0 }, "é🙂", undefined);
    expect(p.context.u.setSelection).toHaveBeenCalledWith({ story: "body", paraId: "alinea", offset: 3 });
    expect(p.context.kt.current).toBeNull();
    await bezig;
    expect(p.native).not.toHaveBeenCalled();
  });

  it("behoudt de eigen ongedaan-maakgrenzen van een compositie zonder bundelwacht", async () => {
    const p = proef(true, true);
    p.U("A", 100, true);
    const bezig = p.taken.shift()!();
    expect(p.native).toHaveBeenCalledTimes(1);
    expect(p.context.kt.current).toBeNull();
    await bezig;
    expect(p.context.u.addUndoBoundary).toHaveBeenCalledTimes(2);
  });
});

describe("alleen bestaande wachtrijbundels kort openhouden", () => {
  it.each([undefined, 1000, 120, 101, 99])("start iedere losse toelating direct, ook bij een snelle voorganger: %s", async tijd => {
    const p = proef();
    if (tijd !== undefined) { p.U("A", 100); await p.klaar(); p.taken.length = 0; p.native.mockClear(); }
    p.U("B", tijd ?? 100);
    const bezig = p.taken.shift()!();
    expect(p.native).toHaveBeenCalledTimes(1);
    await bezig;
  });

  it("verwisselt meerdere tekens uit één toelating niet met wachtrijachterstand", async () => {
    const p = proef();
    p.U("AB", 100);
    const bezig = p.taken.shift()!();
    expect(p.native).toHaveBeenCalledTimes(1);
    expect(p.native.mock.calls[0][2]).toBe("AB");
    await bezig;
  });
});
