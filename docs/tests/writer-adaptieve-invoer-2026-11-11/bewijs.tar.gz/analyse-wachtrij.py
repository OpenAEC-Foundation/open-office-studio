from pathlib import Path
import json,math,bisect,statistics
u=Path('.local/integratiecontrole/adaptieve-invoer');uit={}
def stats(a):
 a=sorted(a);assert a
 return {'aantal':len(a),'min_ms':a[0],'mediaan_ms':statistics.median(a),'p95_ms':a[max(0,math.ceil(len(a)*.95)-1)],'max_ms':a[-1],'tenminste32_ms':sum(v>=32 for v in a),'tenminste100_ms':sum(v>=100 for v in a)}
for naam,doel in [('oud-rijk-wachtrij',' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.'),('oud-klein-wachtrij',' Een korte zin. EINDEPROEF.'),('oud-rijk-fasen',' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.')]:
 p=u/naam/'rapport.json'
 if not p.exists():continue
 r=json.loads(p.read_text());assert r['geslaagd'] and r['wachtrijprobe']['gevonden']==1
 taken=r['wachtrijtaken'];assert all('startMs' in t and 'synchroneTerugkeerMs' in t for t in taken)
 tijden=[t['startMs'] for t in taken];assert tijden==sorted(tijden)
 gewoon=[];tekst=''
 for m in r['native_opdrachten']:
  gewoon.append(m)
  if m.get('caret'):tekst+=m['text']
  assert doel.startswith(tekst)
  if tekst==doel:break
 assert tekst==doel
 gekoppeld=[]
 for m in gewoon:
  i=bisect.bisect_right(tijden,m['fetchStartMs'])-1;assert i>=0;t=taken[i];assert m['antwoordMs']>=m['fetchStartMs']>=t['startMs']
  gekoppeld.append({'taak':t['id'],'aanvraag':m['requestId'],'wachten_tot_start_ms':t['startMs']-t['toelatingMs'],'start_tot_fetch_ms':m['fetchStartMs']-t['startMs'],'ipc_rondreis_ms':m['antwoordMs']-m['fetchStartMs'],'antwoord_tot_volgende_taak_ms':taken[i+1]['startMs']-m['antwoordMs'] if i+1<len(taken) else None})
 a=r['lange_invoer'];uit[naam]={'meting':'Afzonderlijke geïnstrumenteerde diagnose, geen ongestoorde prestatievergelijking','invoer':a,'wachtrijtaken':len(taken),'max_diepte_voor_toelating':max(t['diepte'] for t in taken),'wachten':stats([t['startMs']-t['toelatingMs'] for t in taken]),'synchrone_taakaanroep':stats([t['synchroneTerugkeerMs']-t['startMs'] for t in taken]),'native_aanvragen':len(gewoon),'start_tot_fetch':stats([v['start_tot_fetch_ms'] for v in gekoppeld]),'ipc_rondreis':stats([v['ipc_rondreis_ms'] for v in gekoppeld]),'na_flush_tot_marker_en_twee_frames_ms':a['begin_tot_frame_ms']-a['begin_tot_bron_ms'],'koppeling':gekoppeld,'grenzen':'IPC-rondreis omvat Rust/transport en vertraging van antwoordverwerking door de browser; geen zuivere backend-CPU. Wachttijden overlappen uitvoering van andere taken en mogen niet worden opgeteld tot totale gebruikersvertraging. Tijd tot marker plus2rAFs is geen fysieke paint. Synchrone taakmuurtijd is geen CPUtijd.'}
(u/'wachtrijanalyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for n,a in uit.items():print(n,{k:v for k,v in a.items() if k in ['wachtrijtaken','max_diepte_voor_toelating','wachten','start_tot_fetch','ipc_rondreis','na_flush_tot_marker_en_twee_frames_ms']})
