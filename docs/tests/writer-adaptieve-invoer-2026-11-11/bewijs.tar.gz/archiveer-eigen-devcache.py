from pathlib import Path
import hashlib,json,tarfile,os,stat,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/adaptieve-invoer';d=r/'.local/integratiecontrole/dev-7594/squashfs/squashfs-root';a=u/'eigen-oude-devcache.tar.gz';assert d.is_dir() and not d.is_symlink() and not a.exists()
def meet(p):
 s=p.lstat();v={'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'bytes':s.st_size}
 if p.is_symlink():v.update(soort='link',doel=os.readlink(p))
 elif p.is_file():v.update(soort='bestand',sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 elif p.is_dir():v.update(soort='map')
 else:raise ValueError(str(p))
 return v
leden={str(p.relative_to(r)):meet(p) for p in [d,*sorted(d.rglob('*'))]}
with tarfile.open(a,'w:gz',compresslevel=3) as t:t.add(d,arcname=str(d.relative_to(r)))
gezien=set();proef=None
with tarfile.open(a,'r|gz') as t:
 for lid in t:
  assert lid.name in leden;v=leden[lid.name];gezien.add(lid.name)
  if lid.issym():assert v['soort']=='link' and lid.linkname==v['doel']
  elif lid.islnk():assert v['sha256']==leden[lid.linkname]['sha256']
  elif lid.isfile():
   b=t.extractfile(lid).read();assert hashlib.sha256(b).hexdigest()==v['sha256']
   if proef is None and lid.name.endswith('/usr/bin/open-office-studio'):
    p=u/'herstelde-eigen-devcache-elf';p.write_bytes(b);os.chmod(p,v['mode']);os.utime(p,ns=(v['mtime_ns'],v['mtime_ns']));assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and p.stat().st_mtime_ns==v['mtime_ns'] and stat.S_IMODE(p.stat().st_mode)==v['mode'];p.unlink();proef=lid.name
  else:assert lid.isdir() and v['soort']=='map'
assert gezien==set(leden) and proef
for n,v in leden.items():assert meet(r/n)==v,n
m={'archief':str(a.relative_to(r)),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'leden':leden,'herstelproef':proef,'alle_leden_teruggelezen':True,'status':'geverifieerd_vóór_verwijderen_losse_eigen_cache'};(u/'devcachearchief.json').write_text(json.dumps(m,indent=2));shutil.rmtree(d);m['status']='alleen_losse_eigen_cache_verwijderd_archief_en_download_behouden';(u/'devcachearchief.json').write_text(json.dumps(m,indent=2));print({k:v for k,v in m.items() if k!='leden'});print('vrijGiB',shutil.disk_usage(r).free/1024**3)
