from pathlib import Path
import hashlib,json,shutil,subprocess,os
r=Path.cwd();u=r/'.local/integratiecontrole/adaptieve-invoer';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '2340 passed (2340)' in (u/'volledig-bundels.log').read_text();assert not (u/'typescript-bundels.log').read_text();assert '\nOK\n' in (u/'python-bundels.log').read_text();assert '2 failed | 14 passed (16)' in (u/'negatief-bundels.log').read_text()
p=r/'.local/integratiecontrole/invoerwachtrij/standaardbundelarchief.json';m=json.loads(p.read_text());a=r/m['archief'];assert sha(a)==m['sha256'];d=r/'dist';assert d.is_dir() and not d.is_symlink();bestanden={str(p.relative_to(r)) for p in d.rglob('*') if p.is_file()};assert bestanden==set(m['leden'])
for n,v in m['leden'].items():
 p=r/n;assert not p.is_symlink() and sha(p)==v['sha256']
(u/'vorige-bundel.json').write_text(json.dumps({'manifest':str(r/'.local/integratiecontrole/invoerwachtrij/standaardbundelarchief.json'),'archief':m['archief'],'sha256':m['sha256'],'alle529_losse_bestandshashes_gelijk':True,'status':'oude_standaardbundel_gearchiveerd_en_geverifieerd_vóór_vervangen'},indent=2));shutil.rmtree(d)
e=os.environ.copy();e['PATH']='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback:'+e['PATH']
with (u/'vite.log').open('x') as f:p=subprocess.run(['pnpm','exec','vite','build','--outDir',str(u/'dist')],env=e,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0,'Vitebouw afgekeurd; oude standaardbundel blijft verliesloos gearchiveerd'
raise SystemExit(subprocess.call(['python3',str(u/'bouwen.py')]))
