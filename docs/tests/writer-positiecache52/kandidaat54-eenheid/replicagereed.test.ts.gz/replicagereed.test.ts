import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

// Voer de echte gereedheidscontrole uit de gekoppelde SDK uit, geen nagebouwd algoritme.
const bron = readFileSync(new URL('../../node_modules/@betteroffice/docx-react/dist/index.mjs', import.meta.url), 'utf8');
const begin = 'Zt=useRef(r.replicaReady);';
const einde = 'let Vt=useRef(null)';
const start = bron.indexOf(begin);
if (start < 0 || bron.indexOf(begin, start + 1) !== -1) throw Error('Geen unieke rendercontrole');
const stop = bron.indexOf(einde, start);
if (stop < 0) throw Error('Rendergrens ontbreekt');
const render = new Function('r', 'Zt', 'mt', bron.slice(start + begin.length, stop));
const zoek = 'if(r.experimentalWorkerOpen){let nr=r.replicaReadyRef?.current??r.replicaReady;';
const eerste = bron.indexOf(zoek);
if (eerste < 0 || bron.indexOf(zoek, eerste + 1) !== -1) throw Error('Geen unieke live controle');
const sluit = bron.indexOf('}let ze=Me.current;', eerste);
if (sluit < 0) throw Error('Live grens ontbreekt');
const live = new Function('r', 'Zt', 'mt', bron.slice(eerste, sluit + 1));
function toestand(waarde: boolean, eigenschap: boolean, actueel?: boolean) {
  return { r: { experimentalWorkerOpen: true, replicaReady: eigenschap, replicaReadyRef: actueel === undefined ? undefined : { current: actueel } }, Zt: { current: waarde }, mt: { current: 7 } };
}
function voer(fn: Function, t: ReturnType<typeof toestand>) { fn(t.r, t.Zt, t.mt); }
describe('positiecache gebruikt dezelfde actuele replicagereedheid', () => {
  it('verouderde false-eigenschap verwerpt geen actuele true-cache', () => {
    const t = toestand(true, false, true); voer(render, t); expect(t.Zt.current).toBe(true); expect(t.mt.current).toBe(7);
  });
  it('verouderde true-eigenschap verwerpt geen actuele false-cache', () => {
    const t = toestand(false, true, false); voer(render, t); expect(t.Zt.current).toBe(false); expect(t.mt.current).toBe(7);
  });
  it('echte gereedheidswisseling maakt precies eenmaal ongeldig', () => {
    const t = toestand(false, false, true); voer(render, t); voer(live, t); voer(render, t); expect(t.Zt.current).toBe(true); expect(t.mt.current).toBe(8);
  });
  it('wisseling naar niet-gereed maakt precies eenmaal ongeldig', () => {
    const t = toestand(true, true, false); voer(render, t); voer(live, t); voer(render, t); expect(t.Zt.current).toBe(false); expect(t.mt.current).toBe(8);
  });
  it('live vraag gevolgd door verouderde render blijft dezelfde generatie', () => {
    const t = toestand(false, false, true); voer(live, t); voer(render, t); voer(live, t); expect(t.mt.current).toBe(8);
  });
  it('zonder live ref geldt de eigenschap', () => {
    const t = toestand(false, true); voer(render, t); voer(live, t); expect(t.Zt.current).toBe(true); expect(t.mt.current).toBe(8);
  });
  it('onbepaalde live waarde valt terug op de eigenschap', () => {
    const t = toestand(false, true); Object.assign(t.r, { replicaReadyRef: { current: undefined } }); voer(render, t); expect(t.Zt.current).toBe(true); expect(t.mt.current).toBe(8);
  });
  it('zonder worker wijzigt deze gereedheidsroute de generatie niet', () => {
    const t = toestand(false, true, true); t.r.experimentalWorkerOpen = false; voer(render, t); voer(live, t); expect(t.Zt.current).toBe(false); expect(t.mt.current).toBe(7);
  });
});
