from pathlib import Path
import json,gzip,hashlib,re,collections
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/positiecache52';oud=r/'.local/doorwerk-2026-11-06/cpu52-geijkt/gui';p=json.loads((oud/'profiel.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest();bronnen={}
assert p['programma_sha256']=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039'
for b in p['cpu_scriptbronnen']:
 raw=gzip.decompress((oud/b['bestand']).read_bytes());assert h(raw)==b['sha256'];bronnen[b['url']]=(raw.decode().splitlines(),b)
result=[]
for q in sorted(u.glob('*/profiel.json')):
 d=json.loads(q.read_text());assert d['geslaagd']and d['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True};assert not any(d['fouten_na'].values());m=d['positiemeting'];assert m['gemist']==0 and all(x['meerVerhalen']==0 for x in m['groepen']);regels=m['regels'];taken=[x['taak']for x in regels if x['soort']=='taakbegin'];assert taken==[x['taak']for x in regels if x['soort']=='taakeinde'];assert all(x['goed']for x in regels if x['soort']=='taakeinde');assert m['updates']==len(taken);assert all(x['oorsprong']=='local'for x in regels if x['soort']=='bronupdate');native=[x for x in regels if x['soort']=='nativebegin'];assert sum(x['tekens']for x in native)==351 and len(native)==len(taken)
 starts=[x for x in regels if x['soort']=='cachebegin'];assert len(starts)==1 and starts[0]['waarde']['eigenSessie'];toewijzingen=[x for x in regels if x['soort']=='cachetoewijzing'];per=collections.Counter(x['taak']for x in toewijzingen);assert set(per)==set(taken)and set(per.values())=={2};projecties=[x for x in regels if x['soort']=='projectie'];assert len(projecties)==len(toewijzingen);assert all(x['bezoeken']==x['verhalen']==1537 for x in projecties)
 for a in toewijzingen:
  assert a['index']==0 and a['vorig']['eigenSessie']and a['nieuw']['eigenSessie']and a['nieuw']['root']==a['vorig']['root']=='body';assert a['nieuw']['versie']==a['vorig']['versie']+1
  assert a['nieuw']['projectie']in{x['object']for x in projecties}
 paden=[]
 for a in projecties:
  if not a['stapel']:continue
  details=[]
  for frame in a['stapel'].splitlines():
   match=re.fullmatch(r'(.*?)@(tauri://localhost/assets/[^:]+):(\d+):(\d+)',frame)
   if not match:continue
   naam,url,lijn,kolom=match.groups();lijn=int(lijn);kolom=int(kolom);assert url in bronnen;regelsbron,bron=bronnen[url];raw=regelsbron[lijn-1].encode('utf-16-le');start=(kolom-1)*2
   details.append({'naam':naam,'url':url,'lijn':lijn,'kolom':kolom,'source_sha256':bron['sha256'],'fragment':raw[max(0,start-100):start+500].decode('utf-16-le',errors='replace')})
  paden.append({'taak':a['taak'],'object':a['object'],'kaders':details})
 assert len(paden)==8
 result.append({'ronde':q.parent.name,'native_groepen':len(taken),'bronupdates':m['updates'],'cache_refs':len(starts),'cache_toewijzingen':len(toewijzingen),'cache_per_groep':2,'volledige_projecties':len(projecties),'verhalen_per_projectie':1537,'stapels':paden})
(u/'analyse.json').write_text(json.dumps({'schema':1,'ronden':result,'grens':'De geobserveerde generaties lopen één op per toewijzing. Readiness zelf is niet gelogd; causaliteit wordt getoetst in een afzonderlijke kandidaat. Stacklocaties koppelen aan exacte eigen runtimebytes, kolommen UTF-16. Geen CPU-/FPS- of snelheidsclaim.'},ensure_ascii=False,indent=2)+'\n');print([(x['ronde'],x['native_groepen'],x['cache_toewijzingen'])for x in result])
