import { EditSession } from './kern/docx_edit.js';
declare const sessie: EditSession;
const warm: (story: string, env: string) => void = sessie.warm_story_with_render_env.bind(sessie);
const klaar: void = warm('body', '{}');
// @ts-expect-error De API geeft geen blok-JSON terug.
const blokken: string = sessie.warm_story_with_render_env('body', '{}');
// @ts-expect-error De omgevingsparameter blijft JSON-tekst.
sessie.warm_story_with_render_env('body', {});
void klaar;
void blokken;
