from pathlib import Path
import json,hashlib,shutil,difflib
r=Path.cwd(); p=r/'.local/integratiecontrole/warm-layout-env'; old=r/'.local/integratiecontrole/warm-story'; src=r/'.local/integratiecontrole/font-hergebruik/bron';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();pins=json.loads((old/'bron-hersteld.json').read_text())['bestanden']
for name,h in pins.items():assert sha(r/name)==h
for n in ['engine.rs','wasm.rs','mutation_proof.rs','lib.rs']:
 target=src/'crates/docx-edit/src'/n;shutil.copyfile(target,p/(n+'.voor'));text=(old/(n+'.na')).read_text()
 if n=='wasm.rs':
  anchor='    pub fn warm_story(&self, story: &str, env_json: &str) -> Result<(), JsValue> {'
  assert text.count(anchor)==1
  addition='''    /// Warms with the complete render environment.
    pub fn warm_story_with_render_env(&self, story: &str, env_json: &str) -> Result<(), JsValue> {
        let _fonts = self.fonts.enter();
        let env: crate::bridge::RenderEnv = serde_json::from_str(env_json).map_err(js_err)?;
        self.engine.warm_story(story, &env).map_err(js_err)
    }

'''
  # De nieuwe API krijgt eigen documentatie;de bestaande warm-API houdt de hare.
  pos=text.rfind('    /// Warms resident lowered blocks.',0,text.index(anchor));assert pos>=0
  text=text[:pos]+addition+text[pos:]
 (p/(n+'.na')).write_text(text);(p/(n+'.diff')).write_text(''.join(difflib.unified_diff((p/(n+'.voor')).read_text().splitlines(True),text.splitlines(True),fromfile=n+'.voor',tofile=n+'.na')));(p/(n+'.api.diff')).write_text(''.join(difflib.unified_diff((old/(n+'.na')).read_text().splitlines(True),text.splitlines(True),fromfile=n+'.warm-story',tofile=n+'.na')));target.write_text(text)
for n in ['docx_edit.d.ts','docx_edit_bg.wasm.d.ts']:shutil.copyfile(src/'packages/docx/src/wasm/generated/edit'/n,p/(n+'.voor'))
(p/'bronpinnen.json').write_text(json.dumps({'voor':pins,'na':{n:sha(p/(n+'.na')) for n in ['engine.rs','wasm.rs','mutation_proof.rs','lib.rs']},'basis':'warm-story/*.rs.na;legacy warm-API en B2-cache ongewijzigd;alleen extra complete RenderEnv-API'},indent=2)+'\n')
for n in ['bouw.py','bouw-opdracht.py']:
 s=(old/n).read_text().replace("['editsession_warm_story:function']","['editsession_warm_story:function','editsession_warm_story_with_render_env:function']").replace('Private warm-story-API boven bestaande cachemeetmodule','Private complete RenderEnv-warm-API boven bestaande warm/cachemeetmodule');(p/n).write_text(s)
