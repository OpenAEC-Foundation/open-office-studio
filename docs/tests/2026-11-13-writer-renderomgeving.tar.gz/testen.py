from pathlib import Path
import json,subprocess,hashlib,shutil,difflib,os
r=Path.cwd();p=r/'.local/integratiecontrole/warm-layout-env';src=r/'.local/integratiecontrole/font-hergebruik/bron';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert json.loads((p/'bouw.json').read_text())['code']==0
for n in ['docx_edit.d.ts','docx_edit_bg.wasm.d.ts']:
 f=src/'packages/docx/src/wasm/generated/edit'/n;assert f.read_bytes()==(p/'kern'/n).read_bytes();shutil.copyfile(f,p/(n+'.na'));(p/(n+'.diff')).write_text(''.join(difflib.unified_diff((p/(n+'.voor')).read_text().splitlines(True),f.read_text().splitlines(True),fromfile=n+'.voor',tofile=n+'.na')))
# De bouw is afgerond;alleen eigen proefbron terugzetten,met voorwaarde op de actuele inhoud.
for n in ['engine.rs','wasm.rs','mutation_proof.rs','lib.rs']:
 f=src/'crates/docx-edit/src'/n;assert f.read_bytes()==(p/(n+'.na')).read_bytes();f.write_bytes((p/(n+'.voor')).read_bytes())
for n in ['docx_edit.d.ts','docx_edit_bg.wasm.d.ts']:
 f=src/'packages/docx/src/wasm/generated/edit'/n;assert f.read_bytes()==(p/(n+'.na')).read_bytes();f.write_bytes((p/(n+'.voor')).read_bytes())
pins=json.loads((p/'bronpinnen.json').read_text())['voor']
for f,h in pins.items():assert sha(r/f)==h
(p/'bron-hersteld.json').write_text(json.dumps({'bestanden':pins,'exact_hersteld':True},indent=2)+'\n')
node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';results=[]
def run(name,cmd,env=None):
 with (p/(name+'.log')).open('x') as log:z=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600,env=env or {**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH']})
 results.append({'naam':name,'code':z.returncode,'opdracht':cmd});(p/'testronden.json').write_text(json.dumps(results,indent=2)+'\n');assert z.returncode==0,name
for name in ['proef','secties','mutaties']:run(name,[node,str(p/(name+'.mjs'))])
h=sha(p/'kern/docx_edit_bg.wasm')
for mode in ['warm','koud','zonder-lokaal']:run('corpus-'+mode,[node,str(p/'corpus.mjs'),str(p/'kern/docx_edit_bg.wasm'),h,'corpus-'+mode,mode])
import os
run('corpus-oude-route',[node,str(p/'corpus.mjs'),str(p/'kern/docx_edit_bg.wasm'),h,'corpus-oude-route','warm'],{**os.environ,'WARM':'0'})
run('typen',[str(r/'node_modules/.bin/tsc'),'--noEmit','--strict','--target','ES2022','--module','ESNext','--moduleResolution','Bundler','--skipLibCheck',str(p/'typen.ts')])
print(json.dumps(results))
