from pathlib import Path
import json,subprocess,os,shutil
r=Path.cwd();p=r/'.local/integratiecontrole/warm-layout-env';f=p/'typepad-eerste';f.mkdir();rounds=json.loads((p/'testronden.json').read_text());assert rounds[-1]['code']==127
for n in ['typen.log','testronden.json','testen.py']:shutil.copyfile(p/n,f/n)
shutil.move(p/'typen.log',f/'typen-verplaatst.log')
env={**os.environ,'PATH':'/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH']}
with (p/'typen.log').open('x')as log:z=subprocess.run(rounds[-1]['opdracht'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert z.returncode==0
rounds[-1].update(code=z.returncode,PATH_voorvoegsel='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin');(p/'testronden.json').write_text(json.dumps(rounds,indent=2)+'\n');(p/'typepad-herstel.json').write_text(json.dumps({'eerste_code':127,'reden':'tsc-shell kon node niet vinden;compiler niet gestart','herstel_code':z.returncode,'alleen_gerichte_typetest_herhaald':True,'productcode_ongewijzigd':True},indent=2)+'\n')
s=(p/'testen.py').read_text().replace('env=env)','env=env or {**os.environ,\'PATH\':str(Path(node).parent)+\':\'+os.environ[\'PATH\']})');(p/'testen.py').write_text(s)
