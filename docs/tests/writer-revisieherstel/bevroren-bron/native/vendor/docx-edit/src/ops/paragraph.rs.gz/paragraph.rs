// OpenAEC: gewijzigd voor brongebonden plakbatches en begrensde lezingen (2026-11-04).
//! Paragraph structure and properties: split, merge, attribute deltas, tab
//! stops, indent steps, style application, and paraId maintenance.
//!
//! A paragraph is not a container here. Its text is a plain run of story
//! units, and its identity and properties live on the pilcrow embed that
//! TERMINATES it — so splitting a paragraph is inserting one pilcrow, merging
//! two is removing one, and every property op writes to a pilcrow's map.
//!
//! Two consequences follow. First, splitting has to decide which half keeps
//! the original paraId: the new pilcrow takes it and terminates the FIRST
//! half, while the original pilcrow — now ending the second half — is
//! re-minted. Second, merging has to decide whose properties survive; a plain
//! merge lets the deleted mark's properties and paraId win, so the earlier
//! paragraph's identity carries over. Tracked-change resolution uses the
//! opposite rule, for the reasons its own module docs give.
//!
//! Style resolution stays outside the CRDT. Ops that apply a style take a
//! host-supplied [`ResolvedStyleProjection`] rather than reading `styles.xml`,
//! and reject an unknown style before touching the document.
//!
//! Spacing, indent and tab values are authored OOXML units — twips and
//! line-spacing units — never pixels.

use std::collections::{BTreeMap, HashMap};
use std::sync::Arc;

use yrs::types::Attrs;
use yrs::{Any, Map, MapPrelim, MapRef, Out, ReadTxn, Text, TextRef, TransactionMut};

use crate::format::{PROTECTED_ATTRS, Patch};
use crate::identity::{self, IdAllocator, PARA_ORIGIN, SOURCE_PARA_ID};
use crate::op::{OpError, OpResult, ParaBounds, Receipt, SplitReceipt, para_bounds};
use crate::ops::bookmarks::{Carry, Change};
use crate::ops::{
    Chunk, ChunkKind, adjacent_paragraph_change_revision_id, adjacent_revision_id, adopt_pilcrow,
    block_embed_at, capture_pilcrow, paragraph_content_before, position_chunks,
    revision_id_in_range, snapshot_range, snapshot_ranges,
};
use crate::{
    DEL, EditCtx, EditingDoc, KIND_KEY, PARA_ID, PPR_CHANGE, PPR_DEL, PPR_INS, ParagraphId,
    ParagraphIdOrigin, Position, StoryRange, check_position, insertion_attrs, next_pilcrow,
    revision_value, story_ref,
};

/// The paragraph attributes a style definition owns. Applying a style resets
/// every one of them to the style's value, or clears it when the style has
/// none — an attribute here is never left over from the previous style.
pub const STYLE_CONTROLLED_PARA_ATTRS: [&str; 20] = [
    "alignment",
    "spaceBefore",
    "spaceBeforeLines",
    "spaceAfterLines",
    "beforeAutospacing",
    "afterAutospacing",
    "spaceAfter",
    "lineSpacing",
    "lineSpacingRule",
    "indentLeft",
    "indentRight",
    "indentFirstLine",
    "hangingIndent",
    "contextualSpacing",
    "keepNext",
    "keepLines",
    "widowControl",
    "pageBreakBefore",
    "outlineLevel",
    "defaultTextFormatting",
];

/// The run marks swept from a paragraph's text before the new style's own run
/// formatting is written, so direct formatting from the old style cannot
/// survive the switch.
pub const STYLE_CONTROLLED_MARKS: [&str; 7] = [
    "bold",
    "italic",
    "fontSize",
    "fontFamily",
    "textColor",
    "underline",
    "strike",
];

/// The only paragraph properties an EMPTY second half inherits on split —
/// pressing Enter at the end of a paragraph starts a clean one that keeps the
/// style and vertical rhythm but nothing else, with run defaults rebuilt from
/// the formatting at the caret.
const INHERITED_PARA_ATTRS: [&str; 11] = [
    "defaultTextFormatting",
    "pStyle",
    "lineSpacing",
    "lineSpacingRule",
    "spaceAfter",
    "spaceBefore",
    "spaceBeforeLines",
    "spaceAfterLines",
    "beforeAutospacing",
    "afterAutospacing",
    "contextualSpacing",
];

const BORDERS: &str = "borders";
const TABS: &str = "tabs";
const INDENT_LEFT: &str = "indentLeft";
const DEFAULT_TEXT_FORMATTING: &str = "defaultTextFormatting";

/// Default half-inch indent step in twips.
pub const INDENT_STEP_TWIPS: f64 = 720.0;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MergeDirection {
    /// Delete THIS paragraph's mark, merging it with the following paragraph.
    Forward,
    /// Delete the PREVIOUS paragraph's mark, merging this paragraph into it.
    Backward,
}

/// Which paragraphs an op targets. Every variant is resolved and validated
/// before any mutation, so an unknown id never leaves a partial edit.
#[derive(Clone, Debug, PartialEq)]
pub enum ParaSelector {
    One(ParagraphId),
    /// Resolved in the order given; an unknown id in the list is an error.
    Many(Vec<ParagraphId>),
    /// Every paragraph whose content or mark intersects the range.
    Range(StoryRange),
}

/// One tab stop; `pos` is in twips, `alignment` is the `w:tab` val (`left`, `center`, `right`,
/// `decimal`, `bar`), `leader` the optional leader character name.
#[derive(Clone, Debug, PartialEq)]
pub struct TabStop {
    pub pos: f64,
    pub alignment: String,
    pub leader: Option<String>,
}

impl TabStop {
    fn to_any(&self) -> Any {
        let mut map = HashMap::from([
            ("position".into(), Any::Number(self.pos)),
            ("alignment".into(), Any::from(self.alignment.as_str())),
        ]);
        if let Some(leader) = &self.leader {
            map.insert("leader".into(), Any::from(leader.as_str()));
        }
        Any::Map(Arc::new(map))
    }
}

/// A tri-state paragraph-property delta: [`Patch::Keep`] leaves the current
/// value, [`Patch::Clear`] removes the property, [`Patch::Set`] writes it.
/// Spacing and indent values are authored OOXML units, never pixels.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ParaAttrDelta {
    pub alignment: Patch<String>,
    pub line_spacing: Patch<f64>,
    pub line_spacing_rule: Patch<String>,
    pub space_before: Patch<f64>,
    pub space_after: Patch<f64>,
    pub indent_left: Patch<f64>,
    pub indent_right: Patch<f64>,
    pub indent_first_line: Patch<f64>,
    pub hanging_indent: Patch<f64>,
    pub bidi: Patch<bool>,
    pub tabs: Patch<Vec<TabStop>>,
    /// The paragraph-mark run defaults (`defaultTextFormatting`), as an opaque attr map.
    pub default_text_formatting: Patch<BTreeMap<String, Any>>,
    /// Every paragraph property without a typed field above, written as given;
    /// `None` clears the key. Schema-managed identity keys are rejected.
    pub other: BTreeMap<String, Option<Any>>,
}

/// A style definition already resolved by the host, injected because the
/// `styles.xml` cascade lives outside the CRDT.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ResolvedStyleProjection {
    pub style_id: String,
    /// Host-verified existence. `false` yields [`OpError::UnknownStyle`]
    /// before any mutation.
    pub known: bool,
    /// Values for the [`STYLE_CONTROLLED_PARA_ATTRS`] keys — a missing or null
    /// entry clears that attribute — plus any list attributes when the style
    /// defines numbering.
    pub paragraph_attrs: BTreeMap<String, Any>,
    /// The style's run formatting as story attribute values (`bold`,
    /// `fontSize`, …), applied after the [`STYLE_CONTROLLED_MARKS`] sweep.
    pub run_marks: BTreeMap<String, Any>,
}

struct TargetPara {
    story_id: String,
    story: TextRef,
    bounds: ParaBounds,
    map: MapRef,
}

fn all_targets<T: ReadTxn>(txn: &T) -> Vec<TargetPara> {
    let Some(stories) = txn.get_map(crate::STORIES) else {
        return Vec::new();
    };
    let mut story_ids: Vec<String> = crate::live_stories(&stories, txn)
        .map(|(id, _)| id.to_owned())
        .collect();
    story_ids.sort();
    let mut result = Vec::new();
    for story_id in story_ids {
        let Some(Out::YText(story)) = stories.get(txn, &story_id) else {
            continue;
        };
        let pilcrow_maps: HashMap<u32, MapRef> = crate::pilcrows(&story, txn).into_iter().collect();
        for bounds in para_bounds(&story, txn) {
            if let Some(map) = pilcrow_maps.get(&bounds.pilcrow) {
                result.push(TargetPara {
                    story_id: story_id.clone(),
                    story: story.clone(),
                    bounds,
                    map: map.clone(),
                });
            }
        }
    }
    result
}

/// Resolves a selector to pilcrow targets, validating BEFORE any mutation.
fn resolve_selector<T: ReadTxn>(txn: &T, selector: &ParaSelector) -> OpResult<Vec<TargetPara>> {
    let all = all_targets(txn);
    match selector {
        ParaSelector::One(id) => {
            let target = all
                .into_iter()
                .find(|target| target.bounds.para_id == *id)
                .ok_or_else(|| OpError::UnknownPara(id.clone()))?;
            Ok(vec![target])
        }
        ParaSelector::Many(ids) => {
            let mut by_id: HashMap<String, TargetPara> = all
                .into_iter()
                .map(|target| (target.bounds.para_id.clone(), target))
                .collect();
            ids.iter()
                .map(|id| {
                    by_id
                        .remove(id)
                        .ok_or_else(|| OpError::UnknownPara(id.clone()))
                })
                .collect()
        }
        ParaSelector::Range(range) => {
            if range.end < range.start {
                return Err(OpError::InvalidRange {
                    start: range.start,
                    end: range.end,
                });
            }
            let targets: Vec<TargetPara> = all
                .into_iter()
                .filter(|target| {
                    target.story_id == range.story
                        && target.bounds.start <= range.end
                        && target.bounds.pilcrow >= range.start
                })
                .collect();
            if targets.is_empty() {
                return Err(OpError::UnknownStory(range.story.clone()));
            }
            Ok(targets)
        }
    }
}

fn set_or_remove(txn: &mut TransactionMut<'_>, map: &MapRef, key: &str, value: Option<Any>) {
    match value {
        Some(value) if value != Any::Null => {
            map.insert(txn, key.to_owned(), value);
        }
        _ => {
            map.remove(txn, key);
        }
    }
}

/// Writes a style's paragraph-attribute projection: each
/// [`STYLE_CONTROLLED_PARA_ATTRS`] key is reset to the projection's value or
/// cleared when it has none, and any extra key (list attributes) is applied as
/// given. Errors on a schema-managed identity key.
fn apply_paragraph_attr_projection(
    txn: &mut TransactionMut<'_>,
    map: &MapRef,
    attrs: &BTreeMap<String, Any>,
) -> OpResult<()> {
    for key in STYLE_CONTROLLED_PARA_ATTRS {
        set_or_remove(txn, map, key, attrs.get(key).cloned());
    }
    for (key, value) in attrs {
        if STYLE_CONTROLLED_PARA_ATTRS.contains(&key.as_str()) {
            continue;
        }
        if crate::is_identity_key(key) {
            return Err(OpError::ReservedKey(key.clone()));
        }
        set_or_remove(txn, map, key, Some(value.clone()));
    }
    if let Some(Out::Any(Any::Map(original))) = map.get(txn, "_originalFormatting") {
        let mut original = (*original).clone();
        for key in [
            "spaceBefore",
            "spaceAfter",
            "spaceBeforeLines",
            "spaceAfterLines",
            "beforeAutospacing",
            "afterAutospacing",
        ] {
            match attrs.get(key) {
                Some(value) if *value != Any::Null => {
                    original.insert(key.to_owned(), value.clone());
                }
                _ => {
                    original.remove(key);
                }
            }
        }
        map.insert(txn, "_originalFormatting", Any::Map(Arc::new(original)));
    }
    sync_original_formatting(
        txn,
        map,
        &[],
        &[
            "lineSpacing",
            "lineSpacingRule",
            "indentLeft",
            "indentLeftChars",
            "indentRight",
            "indentRightChars",
            "indentFirstLine",
            "indentFirstLineChars",
            "hangingIndent",
            "hangingIndentChars",
        ],
    );
    Ok(())
}

/// The run defaults a paragraph started at `at` carries, as Word carries the insertion point's
/// formatting: the unit before the caret's, or the mark's own when the paragraph is empty.
fn caret_run_formatting<T: ReadTxn>(
    chunks: &[Chunk],
    at: u32,
    txn: &T,
    props: &[(String, Any)],
) -> Option<Any> {
    let before = chunks
        .iter()
        .find(|chunk| chunk.start < at && at <= chunk.end())
        .filter(|chunk| match &chunk.kind {
            ChunkKind::Pilcrow(_) => false,
            ChunkKind::Embed(Some(map)) => !crate::map_string(map, txn, KIND_KEY)
                .is_some_and(|kind| crate::segments::is_block_embed(&kind)),
            _ => true,
        });
    match before {
        Some(chunk) => crate::seed::mark_run_formatting(&chunk.attrs),
        None => {
            let defaults = props
                .iter()
                .find(|(key, _)| key == DEFAULT_TEXT_FORMATTING)
                .map(|(_, defaults)| crate::seed::mark_run_attrs(defaults))?;
            crate::seed::mark_run_formatting(defaults.iter().map(|(key, value)| (key, value)))
        }
    }
}

impl EditingDoc {
    /// Splits a paragraph by inserting exactly ONE pilcrow at `at`.
    ///
    /// The new pilcrow terminates the FIRST half, carrying the source
    /// paragraph's full properties, its ORIGINAL paraId and its Word
    /// paragraph ID; the original pilcrow is re-minted with a fresh paraId and
    /// a freshly allocated Word paragraph ID and becomes the second half's
    /// mark. What the second half then keeps depends on where the split fell:
    ///
    /// - mid-paragraph: it keeps its own properties;
    /// - at the paragraph end, so the second half is empty: only
    ///   the `INHERITED_PARA_ATTRS` subset survives, with `defaultTextFormatting`
    ///   rebuilt from the run formatting at the caret, so typing continues in it;
    /// - at the end WITH a `next_style`: it switches to that style's
    ///   projection outright instead.
    ///
    /// Paragraph borders are cleared in every case, because Word never
    /// propagates `w:pBdr` across a split. Suggesting mode stamps the inserted
    /// pilcrow `ins` and `pPrIns`, reusing an adjacent revision by the same
    /// author when there is one.
    ///
    /// Errors when `next_style` is not known, before any mutation, and when
    /// `at` does not address a position inside a story.
    pub fn split_paragraph(
        &self,
        ctx: &EditCtx,
        at: Position,
        next_style: Option<&ResolvedStyleProjection>,
    ) -> OpResult<SplitReceipt> {
        let mut txn = self.transact_for(ctx);
        self.split_paragraph_in_transaction(ctx, &mut txn, at, next_style, None)
    }

    pub(crate) fn split_paragraph_in_transaction(
        &self, ctx: &EditCtx, txn: &mut TransactionMut<'_>, at: Position,
        next_style: Option<&ResolvedStyleProjection>, revision_id: Option<String>,
    ) -> OpResult<SplitReceipt> {
        self.split_paragraph_placed_in(ctx, txn, at, next_style, revision_id).map(|(receipt, _)| receipt)
    }

    pub(crate) fn split_paragraph_placed_in(
        &self,
        ctx: &EditCtx,
        txn: &mut TransactionMut<'_>,
        mut at: Position,
        next_style: Option<&ResolvedStyleProjection>,
        revision_id: Option<String>,
    ) -> OpResult<(SplitReceipt, u32)> {
        if let Some(projection) = next_style
            && !projection.known
        {
            return Err(OpError::UnknownStyle(projection.style_id.clone()));
        }
        let story = story_ref(txn, &at.story)?;
        check_position(&story, txn, at.index)?;
        identity::promote_at(self, txn, &at.story, &story, at.index);
        let mut ids = IdAllocator::new(self, txn);
        let second_para_id = ids.session_key(self);
        let chunks = position_chunks(&story, txn, &mut at.index);
        let revision_id = ctx.is_suggesting().then(|| {
            revision_id.map(Ok).unwrap_or_else(|| {
                adjacent_revision_id(&chunks, at.index, crate::INS, &ctx.author)
                    .or_else(|| {
                        adjacent_paragraph_change_revision_id(&chunks, at.index, txn, &ctx.author)
                    })
                    .map(Ok).unwrap_or_else(|| self.next_revision_id())
            })
        }).transpose()?;
        // Alleen een markering precies op de cursor is zonder verdere zoekslag
        // de afsluiting van deze alinea. Elders blijft de oorspronkelijke zoekroute.
        let (orig_index, orig_map) = chunks
            .iter()
            .find_map(|chunk| match &chunk.kind {
                ChunkKind::Pilcrow(map) if chunk.start == at.index => Some((chunk.start, map.clone())),
                _ => None,
            })
            .or_else(|| next_pilcrow(&story, txn, at.index))
            .ok_or(OpError::ExpectedPilcrow {
                story: at.story.clone(),
                index: at.index,
            })?;
        let (first_para_id, mut props) = capture_pilcrow(&orig_map, txn);
        // A mark kept before a pending block carries that block's revision; the new mark does not.
        let block_revisions = if orig_index + 1 < story.len(txn) {
            snapshot_range(&story, txn, orig_index + 1, orig_index + 2)
                .first()
                .and_then(|chunk| chunk.block_revisions(txn))
                .unwrap_or_default()
        } else {
            // Na de laatste markering kan geen volgend blok staan.
            Default::default()
        };
        props.retain(|(key, value)| match key.as_str() {
            PPR_INS => block_revisions[0].as_ref() != Some(value),
            PPR_DEL => block_revisions[1].as_ref() != Some(value),
            _ => true,
        });
        let second_half_empty = orig_index == at.index;

        let ins = revision_id
            .as_ref()
            .map(|id| revision_value(id, &ctx.revision_author()));
        let carry = Carry::capture_at_pilcrow(&story, txn, at.index, &orig_map, None);
        let new_pilcrow = story.insert_embed_with_attributes(
            txn,
            at.index,
            MapPrelim::default(),
            insertion_attrs(ins, None),
        );
        new_pilcrow.insert(txn, KIND_KEY, crate::PILCROW_KIND);
        new_pilcrow.insert(txn, PARA_ID, first_para_id.as_str());
        for (key, value) in &props {
            new_pilcrow.insert(txn, key.clone(), value.clone());
        }
        if let Some(id) = revision_id.as_ref() {
            new_pilcrow.insert(txn, PPR_INS, revision_value(id, &ctx.revision_author()));
        }

        // The original pilcrow now terminates the second half: re-mint its identity, then apply
        // post-split inheritance.
        orig_map.insert(txn, PARA_ID, second_para_id.as_str());
        if second_half_empty {
            if let Some(next) = next_style {
                // A `w:next` switch starts from nothing: drop the source
                // properties before writing the projection.
                for (key, _) in &props {
                    orig_map.remove(txn, key);
                }
                orig_map.insert(txn, "pStyle", next.style_id.as_str());
                apply_paragraph_attr_projection(txn, &orig_map, &next.paragraph_attrs)?;
                orig_map.remove(txn, BORDERS);
            } else {
                // Blank-attr inheritance: keep only the inherited subset; borders fall out of it.
                for (key, _) in &props {
                    if !INHERITED_PARA_ATTRS.contains(&key.as_str()) {
                        orig_map.remove(txn, key);
                    }
                }
                let carried = caret_run_formatting(&chunks, at.index, &*txn, &props);
                set_or_remove(txn, &orig_map, DEFAULT_TEXT_FORMATTING, carried);
            }
        } else {
            // Mid-paragraph split keeps the second half's pPr; Word never propagates w:pBdr.
            orig_map.remove(txn, BORDERS);
        }
        orig_map.remove(txn, SOURCE_PARA_ID);
        orig_map.remove(txn, PARA_ORIGIN);
        ids.bind(txn, &orig_map, &second_para_id, ParagraphIdOrigin::Authored);
        if let Some(carry) = carry {
            carry.apply(
                txn,
                &[Change::Split { at: at.index }],
                &[(at.index, new_pilcrow)],
            );
        }
        Ok((SplitReceipt {
            first_para_id,
            second_para_id,
            revision_ids: revision_id.into_iter().collect(),
        }, at.index + 1))
    }

    /// Merges the paragraph with its neighbour by deleting the boundary
    /// pilcrow. The survivor adopts the deleted mark's properties and paraId,
    /// so the EARLIER paragraph's identity wins.
    ///
    /// Suggesting mode normally retains the mark, stamping it `del` and
    /// `pPrDel`. The exception is backspacing over this same author's still
    /// pending split: that retracts the suggestion, physically removing the
    /// pilcrow rather than authoring a second, contradictory revision.
    ///
    /// The receipt's range is the caret position after the merge. Errors when
    /// the paragraph is unknown, when merging forward from a story's last
    /// paragraph, and when merging backward from its first.
    pub fn merge_paragraphs(
        &self,
        ctx: &EditCtx,
        para: &str,
        direction: MergeDirection,
    ) -> OpResult<Receipt> {
        let mut txn = self.transact_for(ctx);
        let targets = all_targets(&txn);
        let index = targets
            .iter()
            .position(|target| target.bounds.para_id == para)
            .ok_or_else(|| OpError::UnknownPara(para.to_owned()))?;
        let boundary_index = match direction {
            MergeDirection::Forward => {
                let is_last_in_story = targets
                    .get(index + 1)
                    .is_none_or(|next| next.story_id != targets[index].story_id);
                if is_last_in_story {
                    return Err(OpError::CannotMergeFinalParagraph(para.to_owned()));
                }
                index
            }
            MergeDirection::Backward => {
                let has_previous =
                    index > 0 && targets[index - 1].story_id == targets[index].story_id;
                if !has_previous {
                    return Err(OpError::NoParagraphBefore(para.to_owned()));
                }
                index - 1
            }
        };
        let boundary = &targets[boundary_index];
        let survivor = &targets[boundary_index + 1];
        let story = boundary.story.clone();
        let pilcrow_index = boundary.bounds.pilcrow;
        let needs_boundary = block_embed_at(&story, &txn, pilcrow_index + 1)
            && paragraph_content_before(&story, &txn, pilcrow_index)
            && snapshot_range(&story, &txn, pilcrow_index + 1, pilcrow_index + 2)
                .first()
                .and_then(|chunk| chunk.block_revisions(&txn))
                .is_none_or(|revisions| revisions.iter().all(Option::is_none));
        let own_insert = ctx
            .is_suggesting()
            .then(|| paragraph_revision_id(&boundary.map, &txn, PPR_INS, &ctx.author))
            .flatten();
        let revision_id = (ctx.is_suggesting() && own_insert.is_none()).then(|| {
            let chunks = snapshot_range(
                &story,
                &txn,
                pilcrow_index.saturating_sub(1),
                pilcrow_index.saturating_add(1),
            );
            adjacent_revision_id(&chunks, pilcrow_index, DEL, &ctx.author)
                .map(Ok).unwrap_or_else(|| self.next_revision_id())
        }).transpose()?;

        let carry = (revision_id.is_none() && !needs_boundary)
            .then(|| Carry::capture(&story, &txn, pilcrow_index, pilcrow_index + 1, None))
            .flatten();
        if own_insert.is_some() {
            // Backspacing over this author's still-pending split retracts the
            // suggestion itself; it must not author a second pPrDel revision.
            if needs_boundary {
                // The mark stays; every stamp of the retracted revision goes with it.
                for key in [PPR_INS, PPR_DEL] {
                    if paragraph_revision_id(&boundary.map, &txn, key, &ctx.author) == own_insert {
                        boundary.map.remove(&mut txn, key);
                    }
                }
                let stamps = snapshot_range(&story, &txn, pilcrow_index, pilcrow_index + 1)
                    .first()
                    .map(|chunk| chunk.attrs.clone())
                    .unwrap_or_default();
                for key in [crate::INS, DEL] {
                    if stamps
                        .get(key)
                        .and_then(|stamp| super::revision_id_for_author(stamp, &ctx.author))
                        == own_insert
                    {
                        story.format(
                            &mut txn,
                            pilcrow_index,
                            1,
                            Attrs::from([(Arc::from(key), Any::Null)]),
                        );
                    }
                }
            } else {
                let (donor_id, mut donor_props) = capture_pilcrow(&boundary.map, &txn);
                donor_props.retain(|(key, _)| !matches!(key.as_str(), PPR_INS | PPR_DEL));
                story.remove_range(&mut txn, pilcrow_index, 1);
                adopt_pilcrow(&mut txn, &survivor.map, &donor_id, &donor_props);
                if let Some(carry) = carry {
                    carry.removed(&mut txn, pilcrow_index, pilcrow_index + 1);
                }
            }
        } else if let Some(id) = revision_id.as_ref() {
            let revision = revision_value(id, &ctx.revision_author());
            story.format(
                &mut txn,
                pilcrow_index,
                1,
                Attrs::from([(Arc::from(DEL), revision.clone())]),
            );
            boundary.map.insert(&mut txn, PPR_DEL, revision);
        } else if !needs_boundary {
            let (donor_id, donor_props) = capture_pilcrow(&boundary.map, &txn);
            story.remove_range(&mut txn, pilcrow_index, 1);
            adopt_pilcrow(&mut txn, &survivor.map, &donor_id, &donor_props);
            if let Some(carry) = carry {
                carry.removed(&mut txn, pilcrow_index, pilcrow_index + 1);
            }
        }
        let caret = crate::op::loc_range_in_txn(
            &boundary.story_id,
            &story,
            &txn,
            pilcrow_index,
            pilcrow_index,
        )?;
        Ok(Receipt {
            new_para_ids: Vec::new(),
            revision_ids: own_insert.into_iter().chain(revision_id).collect(),
            range: Some(caret),
        })
    }

    /// Applies a tri-state paragraph attribute delta to the selected
    /// paragraphs in one transaction. In suggesting mode a `pPrChange` record
    /// capturing the before and after property maps is appended to every
    /// paragraph the delta actually changed, and the receipt carries its
    /// revision id; a delta that changes nothing stamps nothing. Errors when
    /// the delta names a schema-managed identity key, before any mutation.
    pub fn set_paragraph_attrs(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        delta: &ParaAttrDelta,
    ) -> OpResult<Receipt> {
        self.set_paragraph_attrs_with_restyle(ctx, selector, delta, None)
    }

    /// Applies a paragraph style while preserving direct character formatting.
    pub fn restyle_paragraphs(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        style_id: &str,
        styles: &crate::seed::StyleResolver,
    ) -> OpResult<Receipt> {
        let mut delta = ParaAttrDelta::default();
        delta
            .other
            .insert("pStyle".to_owned(), Some(Any::from(style_id)));
        self.set_paragraph_attrs_with_restyle(ctx, selector, &delta, Some((style_id, styles)))
    }

    fn set_paragraph_attrs_with_restyle(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        delta: &ParaAttrDelta,
        restyle: Option<(&str, &crate::seed::StyleResolver)>,
    ) -> OpResult<Receipt> {
        for key in delta.other.keys() {
            if crate::is_identity_key(key) {
                return Err(OpError::ReservedKey(key.clone()));
            }
        }
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        let mut snapshots = HashMap::new();
        if restyle.is_some() || ctx.is_suggesting() {
            let mut ranges: HashMap<&str, (&TextRef, Vec<(u32, u32)>)> = HashMap::new();
            for target in &targets {
                ranges
                    .entry(target.story_id.as_str())
                    .or_insert_with(|| (&target.story, Vec::new()))
                    .1
                    .push((target.bounds.start, target.bounds.pilcrow + 1));
            }
            for (story_id, (story, mut ranges)) in ranges {
                snapshots.insert(story_id, snapshot_ranges(story, &txn, &mut ranges));
            }
        }
        let revision_id = ctx.is_suggesting().then(|| {
            targets
                .iter()
                .find_map(|target| {
                    revision_id_in_range(
                        paragraph_chunks(&snapshots[target.story_id.as_str()], &target.bounds),
                        target.bounds.start,
                        target.bounds.pilcrow + 1,
                        crate::INS,
                        &ctx.author,
                    )
                })
                .map(Ok).unwrap_or_else(|| self.next_revision_id())
        }).transpose()?;
        let mut changed = false;
        let mut inherited = RestyleInheritanceCache::new();
        for target in &targets {
            let previous = paragraph_formatting(&target.map, &txn);
            if !ctx.is_suggesting()
                && let Some((style_id, styles)) = restyle
            {
                rebase_paragraph_runs(
                    &mut txn,
                    target,
                    paragraph_chunks(&snapshots[target.story_id.as_str()], &target.bounds),
                    style_id,
                    styles,
                    &mut inherited,
                );
            }
            apply_para_delta(&mut txn, &target.map, delta);
            let current = paragraph_formatting(&target.map, &txn);
            if previous != current {
                identity::promote(self, &mut txn, &target.map);
            }
            if let Some(id) = revision_id.as_ref()
                && previous != current
            {
                append_paragraph_property_change(
                    &mut txn,
                    &target.map,
                    id,
                    &ctx.revision_author(),
                    previous,
                    current,
                );
                changed = true;
            }
        }
        Ok(Receipt {
            revision_ids: revision_id.filter(|_| changed).into_iter().collect(),
            ..Receipt::default()
        })
    }

    /// Adds a tab stop to the selected paragraphs, replacing any existing stop
    /// at the same position. Stops stay sorted by position.
    pub fn add_tab_stop(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        stop: &TabStop,
    ) -> OpResult<Receipt> {
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        for target in &targets {
            let mut stops = read_tab_stops(&target.map, &txn);
            stops.retain(|existing| existing_pos(existing) != Some(stop.pos));
            stops.push(stop.to_any());
            stops.sort_by(|a, b| {
                existing_pos(a)
                    .unwrap_or(f64::MAX)
                    .total_cmp(&existing_pos(b).unwrap_or(f64::MAX))
            });
            target
                .map
                .insert(&mut txn, TABS, Any::Array(Arc::from(stops)));
        }
        Ok(Receipt::default())
    }

    /// Removes the tab stop at `pos` twips from the selected paragraphs,
    /// dropping the `tabs` attribute entirely once none are left.
    pub fn remove_tab_stop(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        pos: f64,
    ) -> OpResult<Receipt> {
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        for target in &targets {
            let mut stops = read_tab_stops(&target.map, &txn);
            stops.retain(|existing| existing_pos(existing) != Some(pos));
            if stops.is_empty() {
                target.map.remove(&mut txn, TABS);
            } else {
                target
                    .map
                    .insert(&mut txn, TABS, Any::Array(Arc::from(stops)));
            }
        }
        Ok(Receipt::default())
    }

    /// Increases `indentLeft` by `step` twips, defaulting to
    /// [`INDENT_STEP_TWIPS`].
    pub fn increase_indent(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        step: Option<f64>,
    ) -> OpResult<Receipt> {
        let step = step.unwrap_or(INDENT_STEP_TWIPS);
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        for target in &targets {
            let current = number_prop(&target.map, &txn, INDENT_LEFT).unwrap_or(0.0);
            target
                .map
                .insert(&mut txn, INDENT_LEFT, Any::Number(current + step));
            sync_original_formatting(&mut txn, &target.map, &[INDENT_LEFT], &["indentLeftChars"]);
        }
        Ok(Receipt::default())
    }

    /// Decreases `indentLeft` by `step` twips, defaulting to
    /// [`INDENT_STEP_TWIPS`] and clamping at zero. Reaching zero removes the
    /// attribute, except on a paragraph with direct formatting, which keeps an
    /// explicit zero so a style or list indent does not return on save.
    pub fn decrease_indent(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        step: Option<f64>,
    ) -> OpResult<Receipt> {
        let step = step.unwrap_or(INDENT_STEP_TWIPS);
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        for target in &targets {
            let current = number_prop(&target.map, &txn, INDENT_LEFT).unwrap_or(0.0);
            let next = (current - step).max(0.0);
            let direct = matches!(
                target.map.get(&txn, "_originalFormatting"),
                Some(Out::Any(Any::Map(_)))
            );
            if next > 0.0 || (direct && current != 0.0) {
                target.map.insert(&mut txn, INDENT_LEFT, Any::Number(next));
            } else if direct {
                continue;
            } else {
                target.map.remove(&mut txn, INDENT_LEFT);
            }
            sync_original_formatting(&mut txn, &target.map, &[INDENT_LEFT], &["indentLeftChars"]);
        }
        Ok(Receipt::default())
    }

    /// Sets (or clears) the paragraph-mark run defaults (`defaultTextFormatting`).
    pub fn set_paragraph_default_format(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        formatting: Option<&BTreeMap<String, Any>>,
    ) -> OpResult<Receipt> {
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        for target in &targets {
            match formatting {
                Some(map) if !map.is_empty() => {
                    let value: HashMap<String, Any> =
                        map.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
                    target
                        .map
                        .insert(&mut txn, DEFAULT_TEXT_FORMATTING, Any::Map(Arc::new(value)));
                }
                _ => {
                    target.map.remove(&mut txn, DEFAULT_TEXT_FORMATTING);
                }
            }
        }
        Ok(Receipt::default())
    }

    /// Applies a host-resolved paragraph style in ONE transaction: writes the
    /// style id, resets every [`STYLE_CONTROLLED_PARA_ATTRS`] entry to the
    /// projection's value or clears it, sweeps the [`STYLE_CONTROLLED_MARKS`]
    /// from the paragraph's text, and writes the style's run formats over it.
    ///
    /// Errors before any mutation when the style is not known, and when the
    /// projection's run marks include a protected attribute such as a
    /// hyperlink or a tracked-change stamp.
    pub fn apply_paragraph_style(
        &self,
        ctx: &EditCtx,
        selector: &ParaSelector,
        projection: &ResolvedStyleProjection,
    ) -> OpResult<Receipt> {
        if !projection.known {
            return Err(OpError::UnknownStyle(projection.style_id.clone()));
        }
        for key in projection.run_marks.keys() {
            if PROTECTED_ATTRS.contains(&key.as_str()) {
                return Err(OpError::InvalidFormatValue(format!(
                    "attribute {key:?} is not a formatting attribute"
                )));
            }
        }
        let mut txn = self.transact_for(ctx);
        let targets = resolve_selector(&txn, selector)?;
        for target in &targets {
            target
                .map
                .insert(&mut txn, "pStyle", projection.style_id.as_str());
            apply_paragraph_attr_projection(&mut txn, &target.map, &projection.paragraph_attrs)?;
            let len = target.bounds.len();
            if len > 0 {
                let mut attrs: Attrs = STYLE_CONTROLLED_MARKS
                    .iter()
                    .map(|key| (Arc::from(*key), Any::Null))
                    .collect();
                for (key, value) in &projection.run_marks {
                    attrs.insert(Arc::from(key.as_str()), value.clone());
                }
                target
                    .story
                    .format(&mut txn, target.bounds.start, len, attrs);
            }
        }
        Ok(Receipt::default())
    }

    /// Restores unique paraIds and Word paragraph IDs after divergent replicas
    /// merged or a paragraph was copied: the first occurrence in document
    /// order keeps a duplicated paraId and a later one takes a key derived
    /// from its mark, and a duplicated Word paragraph ID stays with its owner
    /// while the others take fresh ones, identically on every replica.
    /// Applying an update or raw ops already runs this. Returns the
    /// `(old, new)` key pairs.
    pub fn dedupe_para_ids(&self, _now_iso: &str) -> OpResult<Vec<(ParagraphId, ParagraphId)>> {
        Ok(self.repair_paragraph_identities())
    }
}

/// One complete paragraph for [`EditingDoc::insert_paragraph_records`].
pub(crate) struct ParagraphRecord {
    pub text: String,
    /// Pilcrow properties other than the schema identity keys.
    pub properties: Vec<(String, Any)>,
    /// Formatting attributes for the paragraph's text.
    pub run: Vec<(String, Any)>,
}

/// The pilcrow and run changes that apply one resolved paragraph style.
pub(crate) struct StylePlan {
    pub para_id: String,
    pub pilcrow: u32,
    /// `None` removes the key.
    pub properties: Vec<(String, Option<Any>)>,
    /// `(start, len, attrs)` run reformats; a null value clears the attribute.
    pub formats: Vec<(u32, u32, Vec<(String, Any)>)>,
}

impl StylePlan {
    pub fn is_empty(&self) -> bool {
        self.properties.is_empty() && self.formats.is_empty()
    }
}

/// The `_originalFormatting` key of a style-resolved pilcrow key.
fn formatting_key(key: &str) -> &str {
    match key {
        DEFAULT_TEXT_FORMATTING => "runProperties",
        key => key,
    }
}

fn present(value: Option<&Any>) -> Option<&Any> {
    value.filter(|value| !matches!(value, Any::Null | Any::Undefined))
}

fn rebase_attrs(
    current: &BTreeMap<String, Any>,
    old: &BTreeMap<String, Any>,
    new: &BTreeMap<String, Any>,
) -> BTreeMap<String, Any> {
    old.keys()
        .chain(new.keys())
        .filter(|key| !PROTECTED_ATTRS.contains(&key.as_str()))
        .filter_map(|key| {
            let value = present(current.get(key));
            let next = present(new.get(key));
            (value == present(old.get(key)) && value != next)
                .then(|| (key.clone(), next.cloned().unwrap_or(Any::Null)))
        })
        .collect()
}

fn paragraph_chunks<'a>(chunks: &'a [Chunk], bounds: &ParaBounds) -> &'a [Chunk] {
    let start = chunks.partition_point(|chunk| chunk.end() <= bounds.start);
    let end = chunks.partition_point(|chunk| chunk.start <= bounds.pilcrow);
    &chunks[start..end]
}

struct RestyleInheritance {
    previous: BTreeMap<String, Any>,
    current: BTreeMap<String, Any>,
    previous_defaults: BTreeMap<String, Any>,
    current_defaults: BTreeMap<String, Any>,
}

type RestyleInheritanceCache =
    HashMap<(Option<String>, String, Option<String>), RestyleInheritance>;

fn restyle_inheritance<'a>(
    cache: &'a mut RestyleInheritanceCache,
    styles: &crate::seed::StyleResolver,
    previous_style: Option<&str>,
    current_style: &str,
    run_style: Option<&str>,
) -> &'a RestyleInheritance {
    cache
        .entry((
            previous_style.map(str::to_owned),
            current_style.to_owned(),
            run_style.map(str::to_owned),
        ))
        .or_insert_with(|| {
            let inherited = |paragraph_style| {
                crate::seed::payload(styles.run_attrs(paragraph_style, run_style))
                    .unwrap_or_default()
                    .into_iter()
                    .collect()
            };
            RestyleInheritance {
                previous: inherited(previous_style),
                current: inherited(Some(current_style)),
                previous_defaults: styles.default_run_attrs(previous_style, run_style),
                current_defaults: styles.default_run_attrs(Some(current_style), run_style),
            }
        })
}

/// Text, and the inline atoms seeded with their run's resolved marks.
fn carries_run_formatting<T: ReadTxn>(chunk: &Chunk, txn: &T) -> bool {
    match &chunk.kind {
        ChunkKind::Text(_) => true,
        ChunkKind::Embed(Some(map)) => matches!(
            crate::map_string(map, txn, KIND_KEY).as_deref(),
            Some("noteRef" | "field" | "break")
        ),
        _ => false,
    }
}

fn rebase_paragraph_runs(
    txn: &mut TransactionMut<'_>,
    target: &TargetPara,
    chunks: &[Chunk],
    style_id: &str,
    styles: &crate::seed::StyleResolver,
    cache: &mut RestyleInheritanceCache,
) {
    let old_style = crate::map_string(&target.map, txn, "pStyle");
    for chunk in chunks {
        if !carries_run_formatting(chunk, &*txn) {
            continue;
        }
        let run_style = match chunk.attrs.get("runStyle") {
            Some(Any::Map(value)) => match value.get("styleId") {
                Some(Any::String(value)) => Some(value.as_ref()),
                _ => None,
            },
            _ => None,
        };
        let inherited =
            restyle_inheritance(cache, styles, old_style.as_deref(), style_id, run_style);
        let changes = rebase_attrs(&chunk.attrs, &inherited.previous, &inherited.current);
        if !changes.is_empty() {
            let start = chunk.start.max(target.bounds.start);
            let end = chunk.end().min(target.bounds.pilcrow);
            target.story.format(
                txn,
                start,
                end - start,
                changes
                    .into_iter()
                    .map(|(key, value)| (Arc::from(key), value))
                    .collect(),
            );
        }
    }
    let mut defaults: BTreeMap<String, Any> = match target.map.get(txn, DEFAULT_TEXT_FORMATTING) {
        Some(Out::Any(Any::Map(value))) => value
            .iter()
            .map(|(key, value)| (key.clone(), value.clone()))
            .collect(),
        _ => BTreeMap::new(),
    };
    let run_style = match defaults.get("styleId") {
        Some(Any::String(value)) => Some(value.as_ref()),
        _ => None,
    };
    let inherited = restyle_inheritance(cache, styles, old_style.as_deref(), style_id, run_style);
    let changes = rebase_attrs(
        &defaults,
        &inherited.previous_defaults,
        &inherited.current_defaults,
    );
    if changes.is_empty() {
        if defaults.is_empty() {
            target.map.remove(txn, DEFAULT_TEXT_FORMATTING);
        }
        return;
    }
    for (key, value) in changes {
        if value == Any::Null {
            defaults.remove(&key);
        } else {
            defaults.insert(key, value);
        }
    }
    if defaults.is_empty() {
        target.map.remove(txn, DEFAULT_TEXT_FORMATTING);
    } else {
        target.map.insert(
            txn,
            DEFAULT_TEXT_FORMATTING,
            Any::Map(Arc::new(defaults.into_iter().collect())),
        );
    }
}

/// Plans applying `style` to one paragraph: every style-resolved pilcrow key takes the style's
/// value or clears, the source direct formatting drops those keys, the controlled run marks take
/// the style's values, and other run marks that matched the previous style follow the new one.
pub(crate) fn plan_paragraph_style(
    chunks: &[crate::ops::Chunk],
    para_id: &str,
    pilcrow: u32,
    node_start: u32,
    properties: &BTreeMap<String, Any>,
    previous: &crate::seed::StyledParagraph,
    next: &crate::seed::StyledParagraph,
    style_id: &str,
) -> StylePlan {
    let target: HashMap<&str, &Any> = next
        .properties
        .iter()
        .map(|(key, value)| (key.as_str(), value))
        .collect();
    let mut changes = Vec::new();
    for key in crate::seed::style_resolved_keys() {
        let wanted = present(target.get(key).copied());
        if wanted != present(properties.get(key)) {
            changes.push((key.to_owned(), wanted.cloned()));
        }
    }
    if present(properties.get("pStyle")) != Some(&Any::from(style_id)) {
        changes.push(("pStyle".to_owned(), Some(Any::from(style_id))));
    }
    if let Some(Any::Map(original)) = properties.get("_originalFormatting") {
        let mut direct = (**original).clone();
        for key in crate::seed::style_resolved_keys() {
            direct.remove(formatting_key(key));
        }
        direct.insert("styleId".to_owned(), Any::from(style_id));
        if direct != **original {
            changes.push((
                "_originalFormatting".to_owned(),
                Some(Any::Map(Arc::new(direct))),
            ));
        }
    }
    let old_run: HashMap<&str, &Any> = previous
        .run
        .iter()
        .map(|(key, value)| (key.as_str(), value))
        .collect();
    let new_run: HashMap<&str, &Any> = next
        .run
        .iter()
        .map(|(key, value)| (key.as_str(), value))
        .collect();
    let mut keys: Vec<&str> = STYLE_CONTROLLED_MARKS
        .iter()
        .copied()
        .chain(old_run.keys().copied())
        .chain(new_run.keys().copied())
        .filter(|key| !PROTECTED_ATTRS.contains(key))
        .collect();
    keys.sort_unstable();
    keys.dedup();
    let mut formats = Vec::new();
    for chunk in chunks {
        if !matches!(chunk.kind, crate::ops::ChunkKind::Text(_))
            || chunk.start < node_start
            || chunk.end() > pilcrow
        {
            continue;
        }
        let linked = chunk.attr_active(crate::format::HYPERLINK);
        let mut attrs = Vec::new();
        for key in &keys {
            if linked && matches!(*key, "textColor" | "underline") {
                continue;
            }
            let current = present(chunk.attrs.get(*key));
            let follows_style = STYLE_CONTROLLED_MARKS.contains(key)
                || current == present(old_run.get(key).copied());
            let wanted = if follows_style {
                present(new_run.get(key).copied())
            } else {
                current
            };
            if wanted != current {
                attrs.push(((*key).to_owned(), wanted.cloned().unwrap_or(Any::Null)));
            }
        }
        if !attrs.is_empty() {
            formats.push((chunk.start, chunk.len, attrs));
        }
    }
    StylePlan {
        para_id: para_id.to_owned(),
        pilcrow,
        properties: changes,
        formats,
    }
}

impl EditingDoc {
    /// Inserts complete paragraph records at story index `at` in one transaction and returns
    /// their session keys. Each is authored: allocated a key and a claimed Word paragraph ID. An
    /// insertion at or after the final paragraph mark authors into an editor-only final
    /// paragraph, as a split there does. Existing paragraphs keep their identity and properties.
    pub(crate) fn insert_paragraph_records(
        &self,
        story_id: &str,
        at: u32,
        records: &[ParagraphRecord],
    ) -> OpResult<Vec<ParagraphId>> {
        let mut txn = self.transact_for(&EditCtx::local(String::new(), String::new()));
        let story = story_ref(&txn, story_id)?;
        check_position(&story, &txn, at)?;
        if at + 1 >= story.len(&txn) {
            identity::promote_story(self, &mut txn, story_id);
        }
        let mut allocator = IdAllocator::new(self, &txn);
        let mut index = at;
        let mut ids = Vec::with_capacity(records.len());
        for record in records {
            if !record.text.is_empty() {
                let mut attrs: Attrs = record
                    .run
                    .iter()
                    .filter(|(key, _)| !PROTECTED_ATTRS.contains(&key.as_str()))
                    .map(|(key, value)| (Arc::from(key.as_str()), value.clone()))
                    .collect();
                attrs.extend(insertion_attrs(None, None));
                story.insert_with_attributes(&mut txn, index, &record.text, attrs);
                index += crate::ops::utf16_len(&record.text);
            }
            let para_id = allocator.session_key(self);
            let pilcrow = story.insert_embed_with_attributes(
                &mut txn,
                index,
                MapPrelim::default(),
                insertion_attrs(None, None),
            );
            pilcrow.insert(&mut txn, KIND_KEY, crate::PILCROW_KIND);
            pilcrow.insert(&mut txn, PARA_ID, para_id.as_str());
            for (key, value) in &record.properties {
                if !crate::is_identity_key(key) {
                    pilcrow.insert(&mut txn, key.clone(), value.clone());
                }
            }
            allocator.bind(&mut txn, &pilcrow, &para_id, ParagraphIdOrigin::Authored);
            index += 1;
            ids.push(para_id);
        }
        Ok(ids)
    }

    /// Removes the complete paragraph records in `[start, end)` without transferring any
    /// property or identity to a neighbour.
    pub(crate) fn remove_paragraph_records(
        &self,
        story_id: &str,
        start: u32,
        end: u32,
    ) -> OpResult<()> {
        let mut txn = self.transact_for(&EditCtx::local(String::new(), String::new()));
        let story = story_ref(&txn, story_id)?;
        check_position(&story, &txn, end)?;
        let len = end
            .checked_sub(start)
            .ok_or(OpError::InvalidRange { start, end })?;
        story.remove_range(&mut txn, start, len);
        Ok(())
    }

    /// Applies a [`StylePlan`] computed against this state in one transaction.
    pub(crate) fn apply_style_plan(&self, story_id: &str, plan: &StylePlan) -> OpResult<()> {
        let mut txn = self.transact_for(&EditCtx::local(String::new(), String::new()));
        let story = story_ref(&txn, story_id)?;
        let map = crate::pilcrows(&story, &txn)
            .into_iter()
            .find_map(|(index, map)| (index == plan.pilcrow).then_some(map))
            .ok_or(OpError::ExpectedPilcrow {
                story: story_id.to_owned(),
                index: plan.pilcrow,
            })?;
        if crate::map_string(&map, &txn, PARA_ID).as_deref() != Some(plan.para_id.as_str()) {
            return Err(OpError::UnknownPara(plan.para_id.clone()));
        }
        for (key, value) in &plan.properties {
            set_or_remove(&mut txn, &map, key, value.clone());
        }
        for (start, len, attrs) in &plan.formats {
            let attrs: Attrs = attrs
                .iter()
                .map(|(key, value)| (Arc::from(key.as_str()), value.clone()))
                .collect();
            story.format(&mut txn, *start, *len, attrs);
        }
        Ok(())
    }
}

fn paragraph_revision_id<T: ReadTxn>(
    map: &MapRef,
    txn: &T,
    key: &str,
    author: &str,
) -> Option<String> {
    let Some(Out::Any(Any::Map(revision))) = map.get(txn, key) else {
        return None;
    };
    if !matches!(revision.get("author"), Some(Any::String(value)) if value.as_ref() == author) {
        return None;
    }
    match revision.get("id").or_else(|| revision.get("revisionId")) {
        Some(Any::String(id)) => Some(id.to_string()),
        Some(Any::Number(id)) if id.is_finite() => Some(id.to_string()),
        Some(Any::BigInt(id)) => Some(id.to_string()),
        _ => None,
    }
}

fn apply_para_delta(txn: &mut TransactionMut<'_>, map: &MapRef, delta: &ParaAttrDelta) {
    fn apply<T, F: Fn(&T) -> Any>(
        txn: &mut TransactionMut<'_>,
        map: &MapRef,
        key: &str,
        patch: &Patch<T>,
        lower: F,
    ) {
        match patch {
            Patch::Keep => {}
            Patch::Clear => {
                map.remove(txn, key);
            }
            Patch::Set(value) => {
                map.insert(txn, key.to_owned(), lower(value));
            }
        }
    }
    apply(txn, map, "alignment", &delta.alignment, |v| {
        Any::from(v.as_str())
    });
    apply(txn, map, "lineSpacing", &delta.line_spacing, |v| {
        Any::Number(*v)
    });
    apply(txn, map, "lineSpacingRule", &delta.line_spacing_rule, |v| {
        Any::from(v.as_str())
    });
    apply(txn, map, "spaceBefore", &delta.space_before, |v| {
        Any::Number(*v)
    });
    apply(txn, map, "spaceAfter", &delta.space_after, |v| {
        Any::Number(*v)
    });
    for (patch, key, lines_key, auto_key) in [
        (
            &delta.space_before,
            "spaceBefore",
            "spaceBeforeLines",
            "beforeAutospacing",
        ),
        (
            &delta.space_after,
            "spaceAfter",
            "spaceAfterLines",
            "afterAutospacing",
        ),
    ] {
        match patch {
            Patch::Keep => continue,
            Patch::Clear => {
                map.remove(txn, lines_key);
                map.remove(txn, auto_key);
            }
            Patch::Set(_) => {
                map.insert(txn, lines_key, Any::Number(0.0));
                map.insert(txn, auto_key, Any::Bool(false));
            }
        }
        sync_original_formatting(txn, map, &[key, lines_key, auto_key], &[]);
    }
    apply(txn, map, INDENT_LEFT, &delta.indent_left, |v| {
        Any::Number(*v)
    });
    apply(txn, map, "indentRight", &delta.indent_right, |v| {
        Any::Number(*v)
    });
    apply(txn, map, "indentFirstLine", &delta.indent_first_line, |v| {
        Any::Number(*v)
    });
    apply(txn, map, "hangingIndent", &delta.hanging_indent, |v| {
        Any::Number(*v)
    });
    if delta.line_spacing != Patch::Keep || delta.line_spacing_rule != Patch::Keep {
        sync_original_formatting(txn, map, &["lineSpacing", "lineSpacingRule"], &[]);
    }
    if delta.indent_left != Patch::Keep {
        sync_original_formatting(txn, map, &[INDENT_LEFT], &["indentLeftChars"]);
    }
    if delta.indent_right != Patch::Keep {
        sync_original_formatting(txn, map, &["indentRight"], &["indentRightChars"]);
    }
    if delta.indent_first_line == Patch::Clear {
        sync_original_formatting(
            txn,
            map,
            &[],
            &[
                "indentFirstLine",
                "indentFirstLineChars",
                "hangingIndent",
                "hangingIndentChars",
            ],
        );
    }
    apply(txn, map, "bidi", &delta.bidi, |v| Any::Bool(*v));
    apply(txn, map, TABS, &delta.tabs, |stops| {
        Any::Array(Arc::from(
            stops.iter().map(TabStop::to_any).collect::<Vec<_>>(),
        ))
    });
    apply(
        txn,
        map,
        DEFAULT_TEXT_FORMATTING,
        &delta.default_text_formatting,
        |dtf| {
            let value: HashMap<String, Any> =
                dtf.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
            Any::Map(Arc::new(value))
        },
    );
    for (key, value) in &delta.other {
        set_or_remove(txn, map, key, value.clone());
    }
}

/// Mirrors the current values of `keys` into the pilcrow's `_originalFormatting`, the direct
/// formatting a save writes, and drops `dropped` from it.
fn sync_original_formatting(
    txn: &mut TransactionMut<'_>,
    map: &MapRef,
    keys: &[&str],
    dropped: &[&str],
) {
    let Some(Out::Any(Any::Map(original))) = map.get(txn, "_originalFormatting") else {
        return;
    };
    let mut original = (*original).clone();
    for key in keys {
        match map.get(txn, key) {
            Some(Out::Any(value)) if value != Any::Null => {
                original.insert((*key).to_owned(), value);
            }
            _ => {
                original.remove(*key);
            }
        }
    }
    for key in dropped {
        original.remove(*key);
    }
    map.insert(txn, "_originalFormatting", Any::Map(Arc::new(original)));
}

fn paragraph_formatting<T: ReadTxn>(map: &MapRef, txn: &T) -> HashMap<String, Any> {
    map.iter(txn)
        .filter_map(|(key, value)| {
            if crate::is_identity_key(key) || matches!(key.as_ref(), PPR_INS | PPR_DEL | PPR_CHANGE)
            {
                return None;
            }
            match value {
                Out::Any(value) if value != Any::Null => Some((key.to_string(), value)),
                _ => None,
            }
        })
        .collect()
}

/// Appends one `paragraphPropertyChange` record to the pilcrow's `pPrChange`
/// array, holding the revision info plus the complete property maps from
/// before and after — what rejection needs to rewind the paragraph.
fn append_paragraph_property_change(
    txn: &mut TransactionMut<'_>,
    map: &MapRef,
    revision_id: &str,
    author: &crate::Author,
    previous: HashMap<String, Any>,
    current: HashMap<String, Any>,
) {
    let mut changes = match map.get(txn, PPR_CHANGE) {
        Some(Out::Any(Any::Array(changes))) => changes.to_vec(),
        _ => Vec::new(),
    };
    let info = revision_value(revision_id, author);
    changes.push(Any::Map(Arc::new(HashMap::from([
        ("type".to_owned(), Any::from("paragraphPropertyChange")),
        ("info".to_owned(), info),
        (
            "previousFormatting".to_owned(),
            Any::Map(Arc::new(previous)),
        ),
        ("currentFormatting".to_owned(), Any::Map(Arc::new(current))),
    ]))));
    map.insert(txn, PPR_CHANGE, Any::Array(Arc::from(changes)));
}

fn read_tab_stops<T: ReadTxn>(map: &MapRef, txn: &T) -> Vec<Any> {
    match map.get(txn, TABS) {
        Some(Out::Any(Any::Array(stops))) => stops
            .iter()
            .map(|stop| {
                let Any::Map(values) = stop else {
                    return stop.clone();
                };
                let mut values = values.as_ref().clone();
                for (legacy, canonical) in [("pos", "position"), ("val", "alignment")] {
                    if let Some(value) = values.remove(legacy) {
                        values.entry(canonical.to_owned()).or_insert(value);
                    }
                }
                Any::Map(Arc::new(values))
            })
            .collect(),
        _ => Vec::new(),
    }
}

fn existing_pos(stop: &Any) -> Option<f64> {
    let Any::Map(map) = stop else {
        return None;
    };
    match map.get("position").or_else(|| map.get("pos")) {
        Some(Any::Number(pos)) => Some(*pos),
        Some(Any::BigInt(pos)) => Some(*pos as f64),
        _ => None,
    }
}

fn number_prop<T: ReadTxn>(map: &MapRef, txn: &T, key: &str) -> Option<f64> {
    match map.get(txn, key) {
        Some(Out::Any(Any::Number(value))) => Some(value),
        Some(Out::Any(Any::BigInt(value))) => Some(value as f64),
        _ => None,
    }
}
