from pathlib import Path
import gzip,hashlib,json
from PIL import Image,ImageChops
r=Path('.local/doorwerk-2026-11-04/incrementele-invoer'); uit=Path('docs/tests/writer-revisieherstel');uit.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((r/'revisies43-app-bronnen.json').read_text());sha=a['programma_sha256'];assert h((r/'open-office-studio-45.43-revisies').read_bytes())==sha
for n,v in a['bronbestanden'].items():assert h((r/'revisies43-bevroren-bron'/n).read_bytes())==v,n
fun=json.loads((r/'revisies43-proefuitkomsten.json').read_text());metingen=json.loads((r/'revisies43-passieve-uitkomsten.json').read_text());rpc=json.loads((r/'revisies43-rpc-uitkomst.json').read_text());assert len(fun)==10 and len(metingen)==4
p={'schema':1,'versie':'2026.45.43','applicatiebron':a,'bestanden':{},'functioneel':[],'metingen':[],'raster':{},'acceptatie':'Gerichte functionele codecstap; geen snelheids-, native revisie-GUI-, suite- of volledige platformacceptatie. Beide nieuwe fysieke ronden zijn iets trager dan de referentie; de ernstige invoervertraging blijft open.','grenzen':['Alleen eigen Linux-omgeving; geen volledige suite-, FPS-, platform- of migratieacceptatie.','Bronidentiteit komt uit de bevroren 43-bronnen, niet uit latere lokale wijzigingen.']}
def bewaar(src,naam):
 b=src.read_bytes();b=gzip.compress(b,mtime=0) if naam.endswith('.gz') and not src.name.endswith('.gz') else b
 t=uit/naam;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);p['bestanden'][naam]=h(b)
for v in fun:
 assert v['code']==0;d=json.loads((r/v['naam']/'rapport.json').read_text());assert d['geslaagd'] and d['programma_sha256']==sha
 p['functioneel'].append({'naam':v['naam'],'code':v['code'],'seconden':v['seconden']})
for v in metingen:
 assert v['code']==0;d=json.loads((r/v['naam']/'profiel.json').read_text());assert d['geslaagd'];assert d['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True}
 p['metingen'].append({'naam':v['naam'],**{k:d[k] for k in ['getekende_tekst_ms','broncontrole','programma_sha256']}})
ref=Image.open(r/metingen[0]['naam']/'profiel.png').convert('RGB')
for v in metingen:
 im=Image.open(r/v['naam']/'profiel.png').convert('RGB');assert im.size==ref.size
 diff=ImageChops.difference(ref,im);cs=diff.split();mask=ImageChops.lighter(ImageChops.lighter(cs[0],cs[1]),cs[2]);doc=mask.crop((320,208,1138,978));zonder=mask.copy();zonder.paste(0,(491,347,496,366));dc=zonder.crop((320,208,1138,978))
 p['raster'][v['naam']]={'pixels':im.width*im.height-mask.histogram()[0],'bbox':mask.getbbox(),'documentpixels':doc.width*doc.height-doc.histogram()[0],'document_zonder_cursorpixels':dc.width*dc.height-dc.histogram()[0]}
assert rpc['code']==0;d=json.loads((r/rpc['naam']/'profiel.json').read_text());assert d['geslaagd'] and d['programma_sha256']==sha
p['rpc']={k:d[k] for k in ['getekende_tekst_ms','broncontrole'] if k in d};p['rpc']['batches']=len(d['rpcmeting']['aanvragen'])
for v in [*fun,*metingen,rpc]:
 for f in (r/v['naam']).rglob('*'):
  if f.is_file() and f.suffix in ['.json','.log','.png']:bewaar(f,str(f.relative_to(r))+('' if f.suffix=='.png' else '.gz'))
 bewaar(r/(v['naam']+'.log'),v['naam']+'/proef.log.gz')
for f in (r/'revisies43-bevroren-bron').rglob('*'):
 if f.is_file():bewaar(f,'bevroren-bron/'+str(f.relative_to(r/'revisies43-bevroren-bron'))+'.gz')
for n in ['revisies43-app-bronnen.json','revisies43-bouw.log','revisies43-weekversie.log','revisies43-fmt.log','revisies43-proefuitkomsten.json','revisies43-passieve-uitkomsten.json','revisies43-rpc-uitkomst.json','revisies43-vitest.log','revisies43-tsc.log','revisies43-python-na-workflow.log','revisies43-identiteiten-controles.json','revisies43-identiteiten-rusttests.log','revisies43-identiteiten-clippy.log','revisies43-bijectie-tests-definitief.log','revisies43-definitief-randgevallen.log','revisies43-definitief-tekst.log','revisies43-identiteiten-groot.log','revisies43-identiteiten-afwijzingen.log','revisies43-identiteiten-wasm.log','revisies43-strikte-randgevallen.mjs.gz','revisies43-randgevallen.log','revisies43-oude-testcache-opruiming.json','voer-revisies43-proeven.py','voer-revisies43-passieve-metingen.py','meet-passief-doortypen-native.py','meet-rpc-native.py','bewaar-revisies43-proeven.py']:bewaar(r/n,n+('' if n.endswith('.gz') else '.gz'))
for n in ['native/crates/office-writer-plakken/tests/revisies.rs','native/crates/office-writer-plakken/tests/journaal.rs','native/onderzoek/writer-plakbatch/controleer-revisies.mjs','native/onderzoek/writer-plakbatch/revisie-identiteiten.mjs','native/onderzoek/writer-plakbatch/revisie-identiteiten.test.mjs','native/onderzoek/writer-plakbatch/controleer-randgevallen.mjs','scripts/test-writer-rust-tekst-protocol.mjs','.github/workflows/writer-rust-plakbatch.yml']:bewaar(Path(n),'controlebron/'+n+'.gz')
for mapnaam in ['revisies43-definitief-protocol/randgevallen','revisies43-definitief-tekst','revisies43-identiteiten-protocol/afwijzingen','revisies43-identiteiten-protocol/grote-proef','revisies43-identiteiten-wasm','revisies43-protocol/randgevallen']:
 for bron in (r/mapnaam).rglob('*.json'):bewaar(bron,'protocol/'+str(bron.relative_to(r))+'.gz')
for mapnaam in ['revisies43-identiteiten-wasm','revisies43-identiteiten-protocol/grote-proef']:
 for naam in ['drie-auteurs.docx','native.docx']:
  bron=r/mapnaam/naam
  if bron.exists():bewaar(bron,'protocol/'+mapnaam+'/'+naam)
p['native_codec_controles']={'rust':35,'rijke_gevallen':41,'tekstgevallen':15,'afwijzingen':8,'bijectie_tests':7,'groot_128_naar_256_tabellen':True,'drie_auteurs_wasm_en_docx':True,'opmerking':'Nieuwe revisies mogen uitsluitend bijectief hernoemd zijn; bestaande identiteiten, auteurs, rollen, verhalen en bereiken blijven exact. Alle getoetste DOCX-onderdelen blijven bytegelijk. De eerdere strikte afkeuring blijft bewaard.'}
p['proto_sha256']={n:hashlib.sha256(Path('native/target/debug/examples',n).read_bytes()).hexdigest() for n in ['plak_protocol','tekst_protocol']}
p['native_revisie_gui']='Niet aangesloten; twee aanvullende afkeuringen staan in 2026-11-04-writer-native-revisie-ui.json. Geen native auteurgebruikersflow geaccepteerd.'
Path('docs/tests/2026-11-04-writer-revisieherstel.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'bestanden':len(p['bestanden']),'metingen':p['metingen'],'raster':p['raster']},ensure_ascii=False))
