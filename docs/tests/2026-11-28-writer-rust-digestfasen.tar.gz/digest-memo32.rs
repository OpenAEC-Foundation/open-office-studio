use docx_edit::{StorySegment, SegmentContent};
use std::collections::BTreeMap;
use yrs::Any;
fn digest_one(segments: &[StorySegment], memo: &mut Memo) -> u128 {
    use std::hash::{Hash, Hasher};

    /// Two independent word-wise multiply-rotate lanes over the same bytes,
    /// for 128 bits in one walk.
    #[derive(Default)]
    struct Digest {
        low: u64,
        high: u64,
    }
    impl Digest {
        fn add(&mut self, word: u64) {
            self.low = (self.low.rotate_left(5) ^ word).wrapping_mul(0x517c_c1b7_2722_0a95);
            self.high = (self.high ^ word)
                .wrapping_mul(0x9e37_79b9_7f4a_7c15)
                .rotate_left(29);
        }
        fn finish128(&self) -> u128 {
            fn mix(mut value: u64) -> u64 {
                value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
                value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
                value ^ (value >> 31)
            }
            (u128::from(mix(self.high)) << 64) | u128::from(mix(self.low))
        }
    }
    impl Hasher for Digest {
        fn write_usize(&mut self, value: usize) { self.write(&(value as u32).to_le_bytes()); }
        fn write_isize(&mut self, value: isize) { self.write(&(value as i32).to_le_bytes()); }
        fn write(&mut self, bytes: &[u8]) {
            let (words, rest) = bytes.as_chunks::<8>();
            for word in words {
                self.add(u64::from_le_bytes(*word));
            }
            let mut tail = [0u8; 8];
            tail[..rest.len()].copy_from_slice(rest);
            self.add(u64::from_le_bytes(tail) ^ ((bytes.len() as u64) << 56));
        }
        fn finish(&self) -> u64 {
            self.finish128() as u64
        }
    }

    fn any(value: &Any, hasher: &mut Digest, memo: &mut Memo) {
        match value {
            Any::Null => 0u8.hash(hasher),
            Any::Undefined => 1u8.hash(hasher),
            Any::Bool(value) => (2u8, value).hash(hasher),
            Any::Number(value) => (3u8, value.to_bits()).hash(hasher),
            Any::BigInt(value) => (4u8, value).hash(hasher),
            Any::String(value) => (5u8, &**value).hash(hasher),
            Any::Buffer(value) => (6u8, &**value).hash(hasher),
            Any::Array(values) => {
                (7u8, values.len()).hash(hasher);
                for value in values.iter() {
                    any(value, hasher, memo);
                }
            }
            Any::Map(entries) => {
                // Map iteration order is arbitrary, so entries combine commutatively.
                let identity = std::sync::Arc::as_ptr(entries) as usize;
                let combined = if let Some(value) = memo.values.get(&identity) {
                    memo.hits += 1;
                    *value
                } else {
                    memo.misses += 1;
                    let mut value = 0u128;
                    for (key, item) in entries.iter() {
                        let mut entry = Digest::default();
                        key.hash(&mut entry);
                        any(item, &mut entry, memo);
                        value = value.wrapping_add(entry.finish128());
                    }
                    if memo.values.len() < 4096 { memo.values.insert(identity, value); }
                    value
                };
                (8u8, entries.len(), combined).hash(hasher);
            }
        }
    }
    fn map(entries: &BTreeMap<String, Any>, hasher: &mut Digest, memo: &mut Memo) {
        entries.len().hash(hasher);
        for (key, value) in entries {
            key.hash(hasher);
            any(value, hasher, memo);
        }
    }

    let mut hasher = Digest::default();
    segments.len().hash(&mut hasher);
    for segment in segments {
        match &segment.content {
            SegmentContent::Text(text) => (0u8, text).hash(&mut hasher),
            SegmentContent::Pilcrow(properties) => {
                (1u8, &properties.para_id).hash(&mut hasher);
                map(&properties.values, &mut hasher, memo);
            }
            SegmentContent::OtherEmbed { kind, payload } => {
                (2u8, kind).hash(&mut hasher);
                map(payload, &mut hasher, memo);
            }
        }
        map(&segment.attributes, &mut hasher, memo);
    }
    hasher.finish128()
}

#[derive(Default)]
struct Memo { values: std::collections::HashMap<usize,u128>, hits: usize, misses: usize }
pub fn digests(units: &[Vec<StorySegment>]) -> (Vec<u128>,usize,usize) {
    let mut memo = Memo::default();
    let result = units.iter().map(|u|digest_one(u,&mut memo)).collect();
    (result,memo.hits,memo.misses)
}
