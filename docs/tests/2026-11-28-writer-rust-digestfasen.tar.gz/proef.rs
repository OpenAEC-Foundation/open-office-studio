use docx_edit::{EditingDoc, SegmentContent,StorySegment};
use serde_json::{Value,json};
use std::{hint::black_box,time::Instant,path::Path};
mod copied { include!("digest-origineel.rs"); }
mod wasm32 { include!("digest-wasm32.rs"); }
fn ns(t:Instant)->u64 {t.elapsed().as_nanos().try_into().unwrap()}
fn reference(doc:&EditingDoc,story:&str)->Result<Vec<String>,String>{let units=doc.story_segment_units(story).map_err(|e|e.to_string())?;Ok(units.iter().map(|u|format!("{:032x}",docx_edit::segments_digest(u))).collect())}
fn flat_segments(segments:&[StorySegment])->Vec<String>{let mut result=Vec::new();let mut start=0;for(i,s)in segments.iter().enumerate(){if matches!(&s.content,SegmentContent::Pilcrow(_)){result.push(format!("{:032x}",docx_edit::segments_digest(&segments[start..=i])));start=i+1}}if start<segments.len(){result.push(format!("{:032x}",docx_edit::segments_digest(&segments[start..])))}result}
fn flat(doc:&EditingDoc,story:&str)->Result<Vec<String>,String>{let segments=doc.story_segments(story).map_err(|e|e.to_string())?;Ok(flat_segments(&segments))}
fn split_check(samples:&[StorySegment])->usize{
 let text=samples.iter().find(|s|matches!(&s.content,SegmentContent::Text(_))).unwrap().clone();let pil=samples.iter().find(|s|matches!(&s.content,SegmentContent::Pilcrow(_))).unwrap().clone();let embed=samples.iter().find(|s|matches!(&s.content,SegmentContent::OtherEmbed{..})).unwrap().clone();let alphabet=[text,pil,embed];let mut checked=0;
 for len in 0..=4{for mut seed in 0..3usize.pow(len){let mut source=Vec::new();for _ in 0..len{source.push(alphabet[seed%3].clone());seed/=3}let mut units=Vec::new();let mut unit=Vec::new();for s in source.clone(){let closes=matches!(&s.content,SegmentContent::Pilcrow(_));unit.push(s);if closes{units.push(std::mem::take(&mut unit));}}if !unit.is_empty(){units.push(unit)}let expected:Vec<_>=units.iter().map(|u|format!("{:032x}",docx_edit::segments_digest(u))).collect();assert_eq!(expected,flat_segments(&source));checked+=1;}}
 checked
}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let root=std::env::args().nth(1).ok_or("Proefmap ontbreekt")?;let root=Path::new(&root);let data:Value=serde_json::from_slice(&std::fs::read(root.join("orakel.json"))?)?;let mut rows=Vec::new();let mut checked=0;let mut native_width_differences=0;let mut frames=0;let mut timings=Vec::new();let mut split_cases=0;
 for case in data["cases"].as_array().unwrap(){let doc=EditingDoc::new(case["client_id"].as_u64().unwrap());doc.keep_deleted();
  for frame in case["frames"].as_array().unwrap(){doc.apply_update_v1(&std::fs::read(root.join(frame["file"].as_str().unwrap()))?)?;let before=doc.encode_state_as_update_v1();let vector=doc.encode_state_vector_v1();let mut units_total=0;
   for entry in frame["stories"].as_array().unwrap(){let story=entry["story"].as_str().unwrap();let units=doc.story_segment_units(story)?;let expected=entry["digests"].as_array().unwrap();assert_eq!(units.len(),expected.len(),"Eenheidsaantal {} {}",case["name"],story);for(u,e)in units.iter().zip(expected){assert_eq!(copied::segments_digest(u),docx_edit::segments_digest(u));assert_eq!(format!("{:032x}",wasm32::digest_wasm32(u)),e.as_str().unwrap(),"Wasm32-digest {} {}",case["name"],story);if format!("{:032x}",copied::segments_digest(u))!=e.as_str().unwrap(){native_width_differences+=1}checked+=1}assert_eq!(reference(&doc,story)?,flat(&doc,story)?);units_total+=units.len();}
   assert_eq!(reference(&doc,"ontbrekend-verhaal"),flat(&doc,"ontbrekend-verhaal"));assert!(reference(&doc,"ontbrekend-verhaal").is_err());assert_eq!(before,doc.encode_state_as_update_v1());assert_eq!(vector,doc.encode_state_vector_v1());
   rows.push(json!({"case":case["name"],"frame":frame["label"],"stories":frame["stories"].as_array().unwrap().len(),"units":units_total}));frames+=1;
   if case["name"]=="rijk"{
    if split_cases==0{split_cases=split_check(&doc.story_segments("body")?);}
    for round in 0..10{let t=Instant::now();let units=black_box(doc.story_segment_units("body")?);let materialise_ns=ns(t);let t=Instant::now();let hashes:Vec<_>=units.iter().map(|u|docx_edit::segments_digest(black_box(u))).collect();let hash_ns=ns(t);let t=Instant::now();let hex:Vec<_>=hashes.iter().map(|h|format!("{h:032x}")).collect();let hex_ns=ns(t);let t=Instant::now();let encoded=serde_json::to_string(black_box(&hex))?;let json_ns=ns(t);assert_eq!(hex,reference(&doc,"body")?);black_box(encoded);let t=Instant::now();drop(units);let units_drop_ns=ns(t);timings.push(json!({"frame":frame["label"],"round":round,"route":"fasen","materialisatie_ns":materialise_ns,"hash_ns":hash_ns,"hex_ns":hex_ns,"json_ns":json_ns,"units_drop_ns":units_drop_ns}));
     for route in ["A","B","B","A"]{let t=Instant::now();let result=if route=="A"{reference(&doc,"body")?}else{flat(&doc,"body")?};let elapsed=ns(t);assert_eq!(result,hex);timings.push(json!({"frame":frame["label"],"round":round,"route":route,"ns":elapsed}));}
    }
   }
  }
 }
 println!("{}",serde_json::to_string_pretty(&json!({"geslaagd":true,"frames":frames,"synthetische_splits":split_cases,"digests_tegen_wasm32":checked,"native64_afwijkend_van_wasm32":native_width_differences,"pariteit":rows,"metingen":timings,"grens":"Native Rustcomponent op vastgepinde bibliotheek; 32-bit hashbreedte tegen echte Wasm-goldens getoetst. Geen Wasm-kandidaat, desktopmeting of prestatiewinstacceptatie."}))?);Ok(())
}
