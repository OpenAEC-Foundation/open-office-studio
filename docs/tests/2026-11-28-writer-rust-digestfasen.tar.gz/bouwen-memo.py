from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/digest-fasen';cache=r/'.local/integratiecontrole/font-rij-native/target/release/deps';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();libs={'docx_edit':cache/'libdocx_edit.rlib','yrs':cache/'libyrs-07f01d28fbed520f.rlib','serde_json':cache/'libserde_json-2b291618093ba6bc.rlib'};cmd=['/home/aia01/.cargo/bin/rustc','--edition=2024','-C','opt-level=3','-D','warnings','-L','dependency='+str(cache),str(p/'proef-memo.rs'),'-o',str(p/'proef-memo')]
for k,f in libs.items():assert f.exists();cmd+=['--extern',k+'='+str(f)]
result=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(p/'bouwen-memo.log').write_text(result.stdout+result.stderr);(p/'bouw-memo.json').write_text(json.dumps({'code':result.returncode,'opdracht':cmd,'bibliotheken':{str(f):sha(f)for f in libs.values()}},indent=2)+'\n');print(result.returncode,result.stderr[-2000:]);assert result.returncode==0
