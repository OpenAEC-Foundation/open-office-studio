from pathlib import Path
import json,hashlib,stat,ast,subprocess
r=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();refs=json.loads((r/'.local/integratiecontrole/context-kaart-fasen/referenties-nacontrole.json').read_text());assert len(refs)==38
for f,h in refs.items():assert sha(Path(f))==h
old=r/'.local/integratiecontrole/projectie-context-telling-herbouw';pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];assert len(pins)==15
for f,h in pins.items():assert sha(r/f)==h
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
for obj in json.loads((p/'bronpinnen.json').read_text()).values():
 if isinstance(obj,dict)and'pad'in obj:assert sha(Path(obj['pad']))==obj['sha256']
for name in ['bouw.json','bouw-memo.json']:
 build=json.loads((p/name).read_text());assert build['code']==0
 for f,h in build['bibliotheken'].items():assert sha(Path(f))==h
oracle=json.loads((p/'orakel.json').read_text());assert oracle['geslaagd'];frames=0
for case in oracle['cases']:
 for frame in case['frames']:assert sha(p/frame['file'])==frame['sha256'];frames+=1
assert frames==80
for f in p.glob('*.py'):ast.parse(f.read_text())
result={'referenties38_exact':True,'bronpinnen15_exact':True,'standaardbundel529_byte_mode_mtime_exact':True,'native_bibliotheken_exact':True,'orakelframes80_sha_exact':True,'rustc':subprocess.check_output(['/home/aia01/.cargo/bin/rustc','--version'],text=True).strip(),'drivers':{n:sha(p/n)for n in ['proef','proef-memo']},'nieuwe_desktop_of_wasm_bouw':False};(p/'behoud.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
