from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'digest-origineel.rs').read_text();s=s.replace('pub fn segments_digest(segments: &[StorySegment]) -> u128 {','fn digest_one(segments: &[StorySegment], memo: &mut Memo) -> u128 {').replace('fn any(value: &Any, hasher: &mut Digest) {','fn any(value: &Any, hasher: &mut Digest, memo: &mut Memo) {').replace('fn map(entries: &BTreeMap<String, Any>, hasher: &mut Digest) {','fn map(entries: &BTreeMap<String, Any>, hasher: &mut Digest, memo: &mut Memo) {').replace('any(value, hasher);','any(value, hasher, memo);').replace('any(value, &mut entry);','any(value, &mut entry, memo);').replace('map(&properties.values, &mut hasher);','map(&properties.values, &mut hasher, memo);').replace('map(payload, &mut hasher);','map(payload, &mut hasher, memo);').replace('map(&segment.attributes, &mut hasher);','map(&segment.attributes, &mut hasher, memo);')
a='''                let mut combined = 0u128;
                for (key, value) in entries.iter() {
                    let mut entry = Digest::default();
                    key.hash(&mut entry);
                    any(value, &mut entry, memo);
                    combined = combined.wrapping_add(entry.finish128());
                }
'''
b='''                let identity = std::sync::Arc::as_ptr(entries) as usize;
                let combined = if let Some(value) = memo.values.get(&identity) {
                    memo.hits += 1;
                    *value
                } else {
                    memo.misses += 1;
                    let mut value = 0u128;
                    for (key, item) in entries.iter() {
                        let mut entry = Digest::default();
                        key.hash(&mut entry);
                        any(item, &mut entry, memo);
                        value = value.wrapping_add(entry.finish128());
                    }
                    if memo.values.len() < 4096 { memo.values.insert(identity, value); }
                    value
                };
'''
assert s.count(a)==1;s=s.replace(a,b)
s+='''
#[derive(Default)]
struct Memo { values: std::collections::HashMap<usize,u128>, hits: usize, misses: usize }
pub fn digests(units: &[Vec<StorySegment>]) -> (Vec<u128>,usize,usize) {
    let mut memo = Memo::default();
    let result = units.iter().map(|u|digest_one(u,&mut memo)).collect();
    (result,memo.hits,memo.misses)
}
'''
(p/'digest-memo.rs').write_text(s)
s32=s.replace('    impl Hasher for Digest {\n','    impl Hasher for Digest {\n        fn write_usize(&mut self, value: usize) { self.write(&(value as u32).to_le_bytes()); }\n        fn write_isize(&mut self, value: isize) { self.write(&(value as i32).to_le_bytes()); }\n');(p/'digest-memo32.rs').write_text(s32)
source=(p/'proef.rs').read_text();source=source.replace('mod wasm32 { include!("digest-wasm32.rs"); }','mod wasm32 { include!("digest-wasm32.rs"); }\nmod memo { include!("digest-memo.rs"); }\nmod memo32 { include!("digest-memo32.rs"); }')
source=source.replace('for(u,e)in units.iter().zip(expected){','let (memo_native,_,_)=memo::digests(&units);let (memo_wasm,_,_)=memo32::digests(&units);assert_eq!(memo_native,units.iter().map(|u|docx_edit::segments_digest(u)).collect::<Vec<_>>());assert_eq!(memo_wasm.iter().map(|h|format!("{h:032x}")).collect::<Vec<_>>(),expected.iter().map(|x|x.as_str().unwrap().to_string()).collect::<Vec<_>>());for(u,e)in units.iter().zip(expected){')
source=source.replace('let hex_ns=ns(t);let t=Instant::now();','let hex_ns=ns(t);let t=Instant::now();let (memo_hashes,memo_hits,memo_misses)=memo::digests(&units);let memo_hash_ns=ns(t);assert_eq!(memo_hashes,hashes);let t=Instant::now();')
source=source.replace('"units_drop_ns":units_drop_ns}', '"units_drop_ns":units_drop_ns,"memo_hash_ns":memo_hash_ns,"memo_hits":memo_hits,"memo_misses":memo_misses}')
(p/'proef-memo.rs').write_text(source)
