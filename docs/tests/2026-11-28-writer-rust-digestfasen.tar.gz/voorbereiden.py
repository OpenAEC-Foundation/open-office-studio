from pathlib import Path
import hashlib,json
r=Path.cwd();p=r/'.local/integratiecontrole/digest-fasen';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();sdk=r/'.local/integratiecontrole/font-hergebruik/bron/crates/docx-edit/src/lib.rs';native=r/'native/vendor/docx-edit/src/lib.rs'
def extract(f):
 s=f.read_text();a=s.index('pub fn segments_digest(');b=s.index('\n#[derive(',a);return s[a:b]
a=extract(sdk);b=extract(native);assert a==b
(p/'digest-origineel.rs').write_text('use docx_edit::{StorySegment, SegmentContent};\nuse std::collections::BTreeMap;\nuse yrs::Any;\n'+a)
new=a.replace('pub fn segments_digest(', 'pub fn digest_wasm32(');needle='    impl Hasher for Digest {\n';assert new.count(needle)==1;new=new.replace(needle,needle+'        fn write_usize(&mut self, value: usize) { self.write(&(value as u32).to_le_bytes()); }\n        fn write_isize(&mut self, value: isize) { self.write(&(value as i32).to_le_bytes()); }\n')
(p/'digest-wasm32.rs').write_text('use docx_edit::{StorySegment, SegmentContent};\nuse std::collections::BTreeMap;\nuse yrs::Any;\n'+new)
(p/'bronpinnen.json').write_text(json.dumps({'sdk_lib':{'pad':str(sdk),'sha256':sha(sdk)},'native_lib':{'pad':str(native),'sha256':sha(native)},'digestfunctie_exact_gelijk':True,'wasm32_orakel':'Alleen usize/isize-hashschrijfbreedte in kopie op 32 bits vastgezet; moet tegen echte voorraad-Wasm worden bewezen.'},ensure_ascii=False,indent=2)+'\n')
