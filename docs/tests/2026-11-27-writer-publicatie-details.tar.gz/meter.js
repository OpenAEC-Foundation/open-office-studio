const officeTimeline=(()=>{
 let active=null;const wrappers=new WeakMap(),limit=32768;
 const sessionId=(o,s)=>{if(!s)return 0;let id=o.sessions.get(s);if(!id){id=++o.nextSession;o.sessions.set(s,id)}return id};
 const note=(o,kind,phase,id=0,session=0)=>{if(o!==active)return;if(o.rows.length>=limit){o.overflow++;return}o.rows.push({kind,phase,id,session,t:performance.now()})};
 const begin=(phase,session)=>{const o=active;if(!o)return null;const id=++o.next;note(o,'begin',phase,id,sessionId(o,session));return{o,id,phase,session:sessionId(o,session)}};
 const end=token=>{if(token)note(token.o,'end',token.phase,token.id,token.session)};
 const api={begin,end,point(phase,session){const o=active;if(o)note(o,'event',phase,0,sessionId(o,session))},
  span(phase,fn,session){const token=begin(phase,session);try{return fn()}finally{end(token)}},
  wrap(fn,phase){if(!fn)return null;let phases=wrappers.get(fn);if(!phases){phases=new Map();wrappers.set(fn,phases)}if(phases.has(phase))return phases.get(phase);const wrapper=function(...args){const token=begin(phase,args[0]);try{return Promise.resolve(fn.apply(this,args)).then(v=>{end(token);return v},e=>{end(token);throw e})}catch(e){end(token);throw e}};phases.set(phase,wrapper);return wrapper},
  start(){if(active)throw Error('Tijdlijn loopt al');const o={rows:[],overflow:0,next:0,nextSession:0,sessions:new WeakMap(),listeners:[],raf:null};active=o;for(const name of ['keydown','keyup','beforeinput','input']){const fn=()=>note(o,'event',name);window.addEventListener(name,fn,true);o.listeners.push([name,fn])}const raf=()=>{if(active!==o)return;note(o,'event','raf');o.raf=requestAnimationFrame(raf)};o.raf=requestAnimationFrame(raf);return{tag:'publicatie-details-v1',begin:performance.now(),limit}},
  stop(){const o=active;if(!o)return null;active=null;for(const[name,fn]of o.listeners)window.removeEventListener(name,fn,true);if(o.raf!==null)cancelAnimationFrame(o.raf);return{tag:'publicatie-details-v1',rows:o.rows.map(x=>({...x})),overflow:o.overflow,limit,eind:performance.now()}}
 };window.__OPENAEC_INPUT_TIMELINE__=api;return api;
})();
