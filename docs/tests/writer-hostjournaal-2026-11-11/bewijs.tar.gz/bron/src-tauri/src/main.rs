#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use std::{io::Write, path::Path};
mod conversie;
mod database_export;
mod email;
mod herstel;
mod writer_plakken;
mod lettertypen;
mod recent;
mod systeembestanden;
mod taal;
mod updates;
mod vensters;
mod werkbestanden;
mod voorkeuren;

fn lees_bytes(request: &tauri::ipc::Request<'_>) -> Result<Vec<u8>, String> {
    lees_binaire_inhoud(request.body(), false)
}

fn lees_binaire_inhoud(
    inhoud: &tauri::ipc::InvokeBody,
    leeg_toegestaan: bool,
) -> Result<Vec<u8>, String> {
    match inhoud {
        tauri::ipc::InvokeBody::Raw(bytes)
            if (leeg_toegestaan || !bytes.is_empty()) && bytes.len() <= 100 * 1024 * 1024 =>
        {
            Ok(bytes.clone())
        }
        _ => Err(taal::t("errors.file.invalidBody")),
    }
}

#[tauri::command]
async fn converteer_document(
    app: tauri::AppHandle,
    request: tauri::ipc::Request<'_>,
) -> Result<tauri::ipc::Response, String> {
    let bytes = lees_bytes(&request)?;
    let kop = |naam| {
        request
            .headers()
            .get(naam)
            .and_then(|v| v.to_str().ok())
            .map(str::to_owned)
            .ok_or_else(|| taal::t("errors.file.formatInfoMissing"))
    };
    let bron = kop("x-office-bron")?;
    let doel = kop("x-office-doel")?;
    let module = kop("x-office-module")?;
    // Optionele filteropties (CSV, PDF); Rust controleert en bouwt het filterargument zelf.
    let opties = match kop("x-office-opties") {
        Ok(tekst) => conversie::Opties::uit_json(&tekst)?,
        Err(_) => conversie::Opties::default(),
    };
    let instelling = conversie::lees_instelling(&app);
    tauri::async_runtime::spawn_blocking(move || {
        conversie::converteer_met(
            &bytes,
            &bron,
            &doel,
            &module,
            &opties,
            instelling.as_deref(),
        )
        .map(tauri::ipc::Response::new)
    })
    .await
    .map_err(|e| e.to_string())?
}

fn schrijf_atomair(pad: &Path, bytes: &[u8]) -> Result<(), String> {
    let map = pad
        .parent()
        .ok_or_else(|| taal::t("errors.file.targetFolderMissing"))?;
    // Eindigt op .tmp: synchronisatieclients (o.a. de OpenAEC SuperCloud) slaan
    // zulke bestanden over, zodat alleen het definitieve bestand wordt geüpload.
    let mut tijdelijk = tempfile::Builder::new()
        .prefix(".~oos-")
        .suffix(".tmp")
        .tempfile_in(map)
        .map_err(|e| e.to_string())?;
    tijdelijk.write_all(bytes).map_err(|e| e.to_string())?;
    tijdelijk.as_file().sync_all().map_err(|e| e.to_string())?;
    tijdelijk.persist(pad).map_err(|e| e.to_string())?;
    Ok(())
}

/// Bestandsnaam en extensie uit de kop `x-office-naam`; alleen bekende bewaarformaten.
fn bewaarnaam(request: &tauri::ipc::Request<'_>) -> Result<(String, String), String> {
    let naam = request
        .headers()
        .get("x-office-naam")
        .and_then(|v| v.to_str().ok())
        .ok_or_else(|| taal::t("errors.file.nameMissing"))?;
    let naam = percent_encoding::percent_decode_str(naam)
        .decode_utf8()
        .map_err(|_| taal::t("errors.file.nameInvalidChars"))?
        .into_owned();
    let bestandsnaam = Path::new(&naam)
        .file_name()
        .and_then(|s| s.to_str())
        .map(str::to_owned)
        .unwrap_or_else(|| format!("{}.docx", taal::t("dialogs.untitled")));
    let extensie = Path::new(&bestandsnaam)
        .extension()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_lowercase();
    if extensie != "openaec-notities" && !conversie::mag_bewaren(&extensie) {
        return Err(taal::t("errors.file.unsupportedFormat"));
    }
    Ok((bestandsnaam, extensie))
}

/// Native opslagdialoog; het doel komt uitsluitend uit die dialoog, nooit uit een frontendpad.
async fn kies_opslagpad(
    titel: &str,
    bestandsnaam: &str,
    extensie: &str,
) -> Result<Option<std::path::PathBuf>, String> {
    let bestand = rfd::AsyncFileDialog::new()
        .set_title(titel)
        .set_file_name(bestandsnaam)
        .add_filter(taal::t("dialogs.officeFile"), &[extensie])
        .save_file()
        .await;
    let Some(bestand) = bestand else {
        return Ok(None);
    };
    let mut pad = bestand.path().to_path_buf();
    if pad.extension().is_none() {
        pad.set_extension(extensie);
    }
    if pad
        .extension()
        .and_then(|s| s.to_str())
        .map(|s| s.to_lowercase())
        .as_deref()
        != Some(extensie)
    {
        return Err(taal::t("errors.file.extensionMismatch"));
    }
    if pad.exists() {
        let bevestiging = rfd::AsyncMessageDialog::new()
            .set_title(taal::t("dialogs.replaceFile.title"))
            .set_description(taal::t_met(
                "dialogs.replaceFile.message",
                &[("path", &pad.display().to_string())],
            ))
            .set_buttons(rfd::MessageButtons::YesNo)
            .show()
            .await;
        if bevestiging != rfd::MessageDialogResult::Yes {
            return Ok(None);
        }
    }
    Ok(Some(pad))
}

#[tauri::command]
async fn bewaar_kopie(request: tauri::ipc::Request<'_>) -> Result<Option<String>, String> {
    let (bestandsnaam, extensie) = bewaarnaam(&request)?;
    // Een lege Markdownpagina is een geldig tekstbestand; conversie en andere formaten blijven streng.
    let bytes = lees_binaire_inhoud(request.body(), extensie == "md")?;
    let Some(pad) = kies_opslagpad(&taal::t("dialogs.saveCopy"), &bestandsnaam, &extensie).await? else {
        return Ok(None);
    };
    tauri::async_runtime::spawn_blocking(move || {
        schrijf_atomair(&pad, &bytes)?;
        Ok(Some(pad.to_string_lossy().into_owned()))
    })
    .await
    .map_err(|e| e.to_string())?
}

#[cfg(all(test, target_os = "linux"))]
mod klembord_proef;

fn main() {
    // WebKitGTK: vermijd zwarte of achterblijvende canvasbeelden door DMA-BUF.
    // Een expliciete systeeminstelling blijft voorgaan; de compositor blijft aan.
    // Zie https://v2.tauri.app/develop/debug/linux-graphics/.
    #[cfg(target_os = "linux")]
    if std::env::var_os("WEBKIT_DISABLE_DMABUF_RENDERER").is_none() {
        std::env::set_var("WEBKIT_DISABLE_DMABUF_RENDERER", "1");
    }
    // Ook het eerste venster krijgt expliciete klembordtoegang. De automatische
    // configuratieroute biedt die builderoptie niet; behoud alle overige
    // venstereigenschappen en laat bewust uitgeschakelde vensters uitgeschakeld.
    let mut context = tauri::generate_context!();
    let startvensters: Vec<_> = context
        .config_mut()
        .app
        .windows
        .iter_mut()
        .filter(|venster| venster.create)
        .map(|venster| {
            venster.create = false;
            venster.clone()
        })
        .collect();
    tauri::Builder::default()
        // Eerst registreren: een tweede instantie (dubbelklik terwijl de app al
        // draait) geeft haar bestanden door en stopt meteen.
        .plugin(tauri_plugin_single_instance::init(
            |app, argumenten, map| {
                let paden = systeembestanden::startpaden(
                    argumenten.into_iter().map(Into::into),
                    Some(std::path::Path::new(&map)),
                );
                systeembestanden::ontvang(app, paden);
            },
        ))
        // Updates (#26): de plugin controleert handtekeningen; kanaal en bediening in updates.rs.
        .plugin(tauri_plugin_updater::Builder::new().build())
        .plugin(tauri_plugin_clipboard_manager::init())
        .manage(updates::Updates::default())
        .manage(office_writer_plakken::BronVoorraad::default())
        .manage(office_writer_plakken::HostJournaal::default())
        .manage(vensters::Vensters::default())
        .manage(werkbestanden::Werkbestanden::default())
        .manage(recent::Recent::default())
        .manage(herstel::Herstel::default())
        .manage(email::EmailStaat::default())
        .manage(systeembestanden::Systeembestanden::bij_start(
            std::env::args_os(),
        ))
        // Native teksten in de taal van de voorkeuren tot de frontend `zet_taal` meldt.
        .setup(move |app| {
            voorkeuren::zet_begintaal(app.handle());
            for venster in &startvensters {
                tauri::WebviewWindowBuilder::from_config(app.handle(), venster)?
                    .enable_clipboard_access()
                    .build()?;
            }
            Ok(())
        })
        .on_window_event(|venster, gebeurtenis| {
            systeembestanden::bij_venstergebeurtenis(venster, gebeurtenis);
            vensters::bij_venstergebeurtenis(venster, gebeurtenis);
            werkbestanden::bij_venstergebeurtenis(venster, gebeurtenis);
            herstel::bij_venstergebeurtenis(venster, gebeurtenis);
            writer_plakken::bij_venstergebeurtenis(venster, gebeurtenis);
        })
        .invoke_handler(tauri::generate_handler![
            writer_plakken::writer_plakken_voorbereiden,
            writer_plakken::writer_tekst_voorbereiden,
            writer_plakken::writer_bron_vergeten,
            writer_plakken::writer_journaal_mogelijkheden,
            writer_plakken::writer_journaal_openen,
            writer_plakken::writer_journaal_voorbereiden,
            writer_plakken::writer_journaal_vergeten,
            bewaar_kopie,
            lettertypen::systeemlettertypen,
            lettertypen::systeemlettertype,
            database_export::bewaar_database_export,
            vensters::wijzigingsstatus,
            vensters::bevestig_verlaten,
            vensters::bied_overdracht,
            vensters::neem_overdracht,
            vensters::bevestig_overdracht,
            vensters::weiger_overdracht,
            vensters::trek_overdracht_in,
            vensters::sluitverzoek_ontvangen,
            vensters::sluit_venster,
            vensters::meld_tabbladen,
            vensters::open_documenten,
            vensters::activeer_tabblad,
            vensters::nieuw_venster,
            converteer_document,
            systeembestanden::systeembestanden,
            systeembestanden::claim_systeembestand,
            systeembestanden::lees_werkbestand,
            werkbestanden::bewaar_document,
            werkbestanden::bewaar_als,
            werkbestanden::bevestig_formaat,
            werkbestanden::vergeet_werkbestand,
            werkbestanden::kies_bestanden,
            recent::recente_bestanden,
            recent::open_recent,
            recent::zet_recent_vast,
            recent::verwijder_recent,
            recent::wis_recente,
            herstel::herstel_start,
            herstel::herstel_bewaar,
            herstel::herstel_verwijder,
            herstel::herstel_lijst,
            herstel::herstel_lees,
            conversie::conversie_status,
            conversie::kies_conversieprogramma,
            conversie::wis_conversieprogramma,
            voorkeuren::lees_voorkeuren,
            voorkeuren::bewaar_voorkeuren,
            taal::zet_taal,
            updates::update_status,
            updates::controleer_update,
            updates::installeer_update,
            updates::open_releasepagina,
            email::email_accounts,
            email::email_bewaar_account,
            email::email_verwijder_account,
            email::email_stel_configuratie_voor,
            email::email_test,
            email::email_mappen,
            email::email_maak_map,
            email::email_hernoem_map,
            email::email_verwijder_map,
            email::email_berichten,
            email::email_bericht,
            email::email_bijlage,
            email::email_bron,
            email::email_markeer,
            email::email_verplaats,
            email::email_verwijder,
            email::email_verstuur,
            email::email_bewaar_concept,
            email::email_contacten,
            email::email_oauth_status,
            email::email_meld_aan_met_oauth,
            email::email_annuleer_oauth,
            email::email_bewaar_oauth_client,
            email::email_zoek_servers,
            email::bestanden::email_bewaar_bestand,
            email::bestanden::email_open_extern,
            email::bestanden::email_externe_inhoud,
            email::bestanden::email_open_link
        ])
        .build(context)
        .expect("De kantooromgeving kon niet starten")
        .run(|_app, gebeurtenis| match gebeurtenis {
            // Tijdelijk geopende e-mailbijlagen opruimen bij afsluiten.
            tauri::RunEvent::Exit => email::bestanden::ruim_tijdelijk_op(),
            // macOS geeft gekoppelde bestanden als gebeurtenis, niet als argument.
            #[cfg(any(target_os = "macos", target_os = "ios"))]
            tauri::RunEvent::Opened { urls } => {
                let paden = urls
                    .into_iter()
                    .filter_map(|url| url.to_file_path().ok())
                    .filter(|pad| pad.is_file())
                    .collect();
                systeembestanden::ontvang(_app, paden);
            }
            _ => {}
        });
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bewaart_lege_markdown_zonder_oude_inhoud_achter_te_laten() {
        let invoer = tauri::ipc::InvokeBody::Raw(Vec::new());
        assert!(lees_binaire_inhoud(&invoer, false).is_err());
        let bytes = lees_binaire_inhoud(&invoer, true).unwrap();
        let map = tempfile::tempdir().unwrap();
        let pad = map.path().join("lege-pagina.md");
        std::fs::write(&pad, b"oude inhoud").unwrap();
        schrijf_atomair(&pad, &bytes).unwrap();
        assert!(std::fs::read(&pad).unwrap().is_empty());
        assert!(lees_binaire_inhoud(
            &tauri::ipc::InvokeBody::Json(serde_json::json!("geen binaire inhoud")),
            true
        )
        .is_err());
    }
    #[test]
    fn vervangt_bestand_volledig() {
        let map = tempfile::tempdir().unwrap();
        let pad = map.path().join("test.docx");
        std::fs::write(&pad, b"oude langere inhoud").unwrap();
        schrijf_atomair(&pad, b"nieuw").unwrap();
        assert_eq!(std::fs::read(&pad).unwrap(), b"nieuw");
        assert_eq!(std::fs::read_dir(map.path()).unwrap().count(), 1);
    }
    #[test]
    fn tijdelijk_bestand_eindigt_op_tmp() {
        let map = tempfile::tempdir().unwrap();
        let tijdelijk = tempfile::Builder::new()
            .prefix(".~oos-")
            .suffix(".tmp")
            .tempfile_in(map.path())
            .unwrap();
        let naam = tijdelijk.path().file_name().unwrap().to_str().unwrap().to_owned();
        assert!(naam.starts_with(".~oos-") && naam.ends_with(".tmp"), "{naam}");
    }
    #[test]
    fn fout_laat_bestaande_inhoud_met_rust() {
        let map = tempfile::tempdir().unwrap();
        let origineel = map.path().join("origineel.docx");
        std::fs::write(&origineel, b"behouden").unwrap();
        assert!(schrijf_atomair(&map.path().join("ontbreekt/test.docx"), b"nieuw").is_err());
        assert_eq!(std::fs::read(origineel).unwrap(), b"behouden");
    }
}
