from pathlib import Path
import subprocess,json,os,time
os.environ.update(CARGO_PKG_NAME='open-office-studio')
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-host';cache=r.parent/'Open-Office-Studio/.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release'
r1=subprocess.run(['python3',str(u/'testen.py')]);assert r1.returncode==0
for modus in ['aan','uit']:
 c=next(v['opdracht'] for v in json.loads((u/'controles.json').read_text()) if v['naam']=='lib-'+modus);c[0]='/home/aia01/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/clippy-driver';c[-1]=str(u/f'clippy-{modus}.rmeta');c+=['--emit=metadata','-D','warnings'];t=time.monotonic();p=subprocess.run(c,capture_output=True,text=True,timeout=120);(u/f'clippy-{modus}.log').write_text(p.stdout+p.stderr);(u/f'clippy-{modus}.json').write_text(json.dumps({'opdracht':c,'code':p.returncode,'seconden':time.monotonic()-t},indent=2));print('Clippy',modus,p.returncode,flush=True);assert p.returncode==0,p.stderr
 libs=json.loads((u/'tauri-pinnen.json').read_text());c=['/home/aia01/.cargo/bin/rustc','--edition=2021','--crate-name','tauri_registratie','-L','dependency='+str(cache/'deps'),'-L','dependency='+str(u),'-L','dependency='+str(u/modus)]
 for k,v in libs.items():c+=['--extern',k+'='+v]
 c+=['--extern','office_writer_plakken='+str(u/modus/'liboffice_writer_plakken.rlib'),str(u/'tauri-registratie.rs'),'--emit=metadata','-D','warnings','-o',str(u/f'tauri-{modus}.rmeta')];p=subprocess.run(c,capture_output=True,text=True,timeout=120);(u/f'tauri-{modus}.log').write_text(p.stdout+p.stderr);(u/f'tauri-{modus}.json').write_text(json.dumps({'opdracht':c,'code':p.returncode},indent=2));print('Tauri',modus,p.returncode,flush=True);assert p.returncode==0,p.stderr
