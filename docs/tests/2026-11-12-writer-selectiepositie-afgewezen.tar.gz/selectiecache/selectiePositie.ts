/** Alleen Loc→display heeft geen volledige tabel-/trefferprojectie nodig. */
import { createYrsLocProjectionFromOutline, yrsLocToProjectedDisplayPosition } from "@betteroffice/docx/yrs";

type Argumenten = Parameters<typeof yrsLocToProjectedDisplayPosition>;
type Omtrek = Parameters<typeof createYrsLocProjectionFromOutline>[0];
type Bron = Argumenten[0] & { oosPositionOutline?: (root: string) => Omtrek | "legacy" | "fallback" };
type Stand = { versie: number; gereed: unknown };
type Levensduur = { eigenaar: object; lees: () => Stand };
const kaarten = new WeakMap<object, Stand & { bron: Bron; verhaal: string; kaart: ReturnType<typeof createYrsLocProjectionFromOutline> }>();

export function selectiePositie(bron: Bron, volledig: Argumenten[1], loc: Argumenten[2], root?: Argumenten[3], invoerkaart?: Argumenten[4], leven?: Levensduur) {
  return yrsLocToProjectedDisplayPosition(bron, (verhaal) => {
    if (!bron.hasStory(verhaal)) return volledig(verhaal);
    if (!bron.oosPositionOutline) return volledig(verhaal);
    const voor = leven?.lees(), oud = leven && kaarten.get(leven.eigenaar);
    if (voor && oud?.bron === bron && oud.verhaal === verhaal && oud.versie === voor.versie && Object.is(oud.gereed, voor.gereed)) return oud.kaart;
    const omtrek = bron.oosPositionOutline?.(verhaal);
    // De kern kan voor een onbekende structuur de oude route verlangen.
    if (!omtrek || typeof omtrek !== "object") return volledig(verhaal);
    const kaart = createYrsLocProjectionFromOutline(omtrek), na = leven?.lees();
    // Gebruik de bestaande editor-epoch, niet de openbare documentversie:
    // ook Undo, bewaaradoptie en replicaovergangen trekken oud werk in.
    if (voor && na && leven) {
      if (voor.versie !== na.versie || !Object.is(voor.gereed, na.gereed)) return volledig(verhaal);
      kaarten.set(leven.eigenaar, { ...na, bron, verhaal, kaart });
    }
    return kaart;
  }, loc, root, invoerkaart);
}
