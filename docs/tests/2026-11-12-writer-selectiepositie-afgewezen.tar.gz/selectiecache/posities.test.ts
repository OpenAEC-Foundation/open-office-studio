import { readFileSync,writeFileSync } from 'node:fs';
import { expect,it } from 'vitest';
import {selectiePositie} from '../../../src/tekst/gedeeld/selectiePositie';
import { createYrsSession,createYrsPositionProjection,createYrsInputPositionMap,yrsLocToDisplayPosition,createYrsLocProjectionFromOutline } from '@betteroffice/docx/yrs';

it('vergelijkt compacte Rust-posities met de bestaande volledige kaart op echte bronnen',async()=>{
 const uit=[];
 for(const bestand of ['public/templates/nieuw.docx','docs/voorbeelden/Ontwerpnotitie.docx','docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx']){
  const s=await createYrsSession();
  try{
   s.openDocx(readFileSync(bestand),true);
   let epoch=0,lezingen=0;const bron=Object.create(s);Object.defineProperty(bron,'oosPositionOutline',{value:(root:string)=>{lezingen++;return (s as any).oosPositionOutline(root)}});
   const leven={eigenaar:{},lees:()=>({versie:epoch,gereed:true})};
   expect(typeof (s as any).oosPositionOutline).toBe('function');
   for(const stap of ['oorspronkelijk','unicode','undo','redo']){
    epoch++;
    if(stap==='unicode'){
     s.beginUndoCapture();s.setUndoCaptureMode('manual');s.addUndoBoundary();
     const p=s.paragraphSpans('body').at(-1)!;s.insertText({story:'body',paraId:p.paraId,offset:p.length},' 😀e\u0301 einde');s.addUndoBoundary();
    }else if(stap==='undo')s.undo();else if(stap==='redo')s.redo();
    const begin=performance.now();const outline=(s as any).oosPositionOutline('body');const rustMs=performance.now()-begin;
    expect(typeof outline).toBe('object');const compact=createYrsLocProjectionFromOutline(outline);
    const start=performance.now();const volledig=createYrsPositionProjection(s,'body')!;const jsMs=performance.now()-start;
    let punten=0,platteVerschillen=0;
    for(const story of Object.keys(outline)){
     const spans=s.paragraphSpans(story),plat=createYrsInputPositionMap(story,spans);
     for(const p of spans){
      for(const offset of [...new Set([0,1,Math.floor(p.length/2),p.length,p.length+1])]){
       const loc={story,paraId:p.paraId,offset};const oud=volledig.positionForLoc(loc);
       expect(compact.positionForLoc(loc),JSON.stringify({bestand,stap,loc})).toBe(oud);punten++;
       if(story==='body'&&yrsLocToDisplayPosition(plat,loc)!==oud)platteVerschillen++;
      }
     }
    }
    const body=s.paragraphSpans('body');let routePunten=0;const voorLezingen=lezingen;
    for(const p of [body[0],body.at(-1)!])for(const offset of [0,p.length]){const loc={story:'body',paraId:p.paraId,offset};expect(selectiePositie(bron,()=>volledig,loc,'body',undefined,leven)).toBe(volledig.positionForLoc(loc));routePunten++;}
    expect(lezingen-voorLezingen).toBe(1);
    uit.push({bestand,stap,punten,routePunten,kaartlezingen:lezingen-voorLezingen,platteVerschillen,rustMs,jsMs});
   }
  }finally{s.destroy()}
 }
 writeFileSync('.local/integratiecontrole/selectiecache/posities.json',JSON.stringify(uit,null,2)+'\n');
});
