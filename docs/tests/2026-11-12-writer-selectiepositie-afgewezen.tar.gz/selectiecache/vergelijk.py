from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/selectiecache';basis=r.parent/'Open-Office-Studio'
python=basis/'.local/doorwerk-2026-11-02/gui-python/bin/python';env=os.environ.copy();env['PATH']=str(basis/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];env.pop('OFFICE_TEST_JOURNAAL',None)
apps={'referentie':r/'.local/integratiecontrole/bewaarprojectie-ci/open-office-studio-ci-statusfout','kandidaat':u/'open-office-studio-selectiecache'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(apps['referentie'])=='8d67e9e495008f7dd7542082214410b0f5322c459bfcf297eccd8d31fa76f567'
volgorde=[(soort,j+1,app) for soort in ['klein','rijk'] for j,app in enumerate(['referentie','kandidaat','kandidaat','referentie'])]
plan={'vooraf_bepaalde_volgorde':volgorde,'programma_sha256':{n:sha(p) for n,p in apps.items()},'helpers':{n:sha(u/('proef-'+n+'.py')) for n in ['klein','rijk']},'geen_profiler':True,'gewone_invoer_antwoordvertraging_ms':0}
(u/'vergelijkplan.json').write_text(json.dumps(plan,indent=2)+'\n');uitslagen=[]
for soort,j,app in volgorde:
 naam=f'{soort}-{j}-{app}';cmd=[str(python),str(u/('proef-'+soort+'.py')),'--programma',str(apps[app]),'--versie','2026.45.52','--uitvoer',str(u/naam)]
 env['OFFICE_PROEF_COMPACTE_SELECTIE']='1' if app=='kandidaat' else '0'
 print('Begin '+naam,flush=True);begin=time.monotonic()
 with (u/(naam+'.log')).open('x') as log:
  try:code=subprocess.run(['timeout','450',*cmd],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
  except Exception as e:log.write(repr(e));code=-1
 v={'naam':naam,'code':code,'seconden':time.monotonic()-begin};uitslagen.append(v);(u/'vergelijkuitslagen.json').write_text(json.dumps(uitslagen,indent=2)+'\n');print(json.dumps(v),flush=True)
 if code:raise SystemExit('Vaste reeks onderbroken wegens afkeuring; resterende rondes niet uitgevoerd.')
