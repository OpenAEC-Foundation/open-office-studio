import {readFileSync,writeFileSync} from 'node:fs';
import {expect,it} from 'vitest';
import {createYrsSession,createYrsPositionProjection} from '@betteroffice/docx/yrs';
import {selectiePositie} from '../../../src/tekst/gedeeld/selectiePositie';
it('behoudt alle posities na nesten, samenvoegen, splitsen en rijen wijzigen',async()=>{
 const s=await createYrsSession();
 try{
  s.openDocx(readFileSync('public/templates/nieuw.docx'),true);
  const paraId=s.paragraphSpans('body')[0].paraId,at={story:'body',tableIndex:0,row:0,column:0};
  const tabel=s.insertTable({story:'body',paraId,offset:0},3,2);
  for(const [i,story]of tabel.createdStoryIds.entries())s.insertText({story,paraId:s.paragraphSpans(story)[0].paraId,offset:0},`Cel ${i}😀`);
  let epoch=0,lezingen=0;const proxy=Object.create(s),leven={eigenaar:{},lees:()=>({versie:epoch,gereed:true})};
  Object.defineProperty(proxy,'oosPositionOutline',{value:(root:string)=>{lezingen++;return(s as any).oosPositionOutline(root)}});
  const uit=[];
  for(const stap of ['begin','genest','samengevoegd','gesplitst','rij-erbij','rij-weg']){
   if(stap==='genest'){const story=tabel.createdStoryIds.at(-1)!;s.insertTable({story,paraId:s.paragraphSpans(story)[0].paraId,offset:0},1,1);}
   if(stap==='samengevoegd')s.mergeCells({anchor:at,head:{...at,column:1}});
   if(stap==='gesplitst')s.splitCell(at,1,2);
   if(stap==='rij-erbij')s.insertRow({...at,row:1},'above');
   if(stap==='rij-weg')s.deleteRow({anchor:{...at,row:1},head:{...at,row:1,column:1}});
   epoch++;const voor=lezingen,oud=createYrsPositionProjection(s,'body')!;
   expect(oud.allTables()).toHaveLength(stap==='begin'?1:2);
   const outline=(s as any).oosPositionOutline('body');expect(typeof outline).toBe('object');let punten=0;
   for(const story of Object.keys(outline))for(const p of s.paragraphSpans(story))for(let offset=0;offset<=p.length+1;offset++){
    const loc={story,paraId:p.paraId,offset};expect(selectiePositie(proxy,()=>oud,loc,'body',undefined,leven),JSON.stringify({stap,loc})).toBe(oud.positionForLoc(loc));punten++;
   }
   expect(lezingen-voor).toBe(1);uit.push({stap,punten,tabellen:oud.allTables().length,kaartlezingen:lezingen-voor});
  }
  writeFileSync('.local/integratiecontrole/selectiecache/structuren.json',JSON.stringify(uit,null,2)+'\n');
 }finally{s.destroy()}
});
