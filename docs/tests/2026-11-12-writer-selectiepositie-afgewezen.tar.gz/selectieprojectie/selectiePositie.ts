/** Alleen Loc→display heeft geen volledige tabel-/trefferprojectie nodig. */
import { createYrsLocProjectionFromOutline, yrsLocToProjectedDisplayPosition } from "@betteroffice/docx/yrs";

type Argumenten = Parameters<typeof yrsLocToProjectedDisplayPosition>;
type Omtrek = Parameters<typeof createYrsLocProjectionFromOutline>[0];
type Bron = Argumenten[0] & { oosPositionOutline?: (root: string) => Omtrek | "legacy" | "fallback" };

export function selectiePositie(bron: Bron, volledig: Argumenten[1], loc: Argumenten[2], root?: Argumenten[3], invoerkaart?: Argumenten[4]) {
  return yrsLocToProjectedDisplayPosition(bron, (verhaal) => {
    if (!bron.hasStory(verhaal)) return volledig(verhaal);
    const omtrek = bron.oosPositionOutline?.(verhaal);
    // De kern kan voor een onbekende structuur de oude route verlangen.
    // Geen cache: elk verzoek leest de huidige sessie en bron, ook na Undo,
    // workeradoptie of herladen met dezelfde openbare versie-identiteit.
    return omtrek && typeof omtrek === "object"
      ? createYrsLocProjectionFromOutline(omtrek)
      : volledig(verhaal);
  }, loc, root, invoerkaart);
}
