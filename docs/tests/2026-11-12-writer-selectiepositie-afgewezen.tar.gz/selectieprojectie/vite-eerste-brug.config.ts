import { mergeConfig } from 'vite';
import basis from '../../../vite.config';
const config = mergeConfig(basis, {
  plugins: [{name:'alleen-onderzoek-compacte-posities',enforce:'pre',transform(bron:string,id:string){
    if(!/\/@betteroffice\/docx\/dist\/chunk-N5NWITJ6\.mjs(?:\?.*)?$/.test(id))return;
    const anker='paragraphSpans:t=>JSON.parse(e$1.paragraph_spans(t)),';
    if(bron.split(anker).length!==2)throw Error('Onderzoeksanker gewijzigd');
    return {code:bron.replace(anker,anker+'oosPositionOutline:t=>JSON.parse(e$1.geometry_position_outline_json(t)),'),map:null};
  }}],
  test:{include:['.local/integratiecontrole/selectieprojectie/*.test.ts'],exclude:['**/node_modules/**'],fileParallelism:false,server:{deps:{inline:[/@betteroffice\/docx/]}}},
});

config.test!.exclude=["**/node_modules/**"];
export default config;
