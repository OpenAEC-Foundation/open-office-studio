import { readFileSync } from "node:fs";
import { expect, it, vi } from "vitest";
import { herstelPositieOmtrek, herstelSelectiePositie } from "../../../scripts/tekstengine-compatibiliteit";
import { selectiePositie } from "./selectiePositie";

const loc = { story: "body", paraId: "p", offset: 2 };
const omtrek = (start = 10) => ({ body: { contentStart: 0, size: 20, paragraphs: [{ paraId: "p", displayStart: start, length: 4, leading: 0 }] } });
const kaart = () => ({ story: "body", paragraphs: [{ paraId: "p", displayStart: 0, length: 4 }] });
function proef() {
  const bron = { hasStory: () => true, paragraphSpans: vi.fn(() => []), oosPositionOutline: vi.fn(() => omtrek()) };
  const oud = vi.fn(() => ({ positionForLoc: vi.fn(() => 99) }));
  return { bron, oud };
}
it("gebruikt de compacte absolute positie zonder volledige projectie", () => {
  const p = proef(); expect(selectiePositie(p.bron, p.oud, loc, "body", kaart)).toBe(13);
  expect(p.bron.oosPositionOutline).toHaveBeenCalledExactlyOnceWith("body"); expect(p.oud).not.toHaveBeenCalled();
  expect(p.bron.paragraphSpans).not.toHaveBeenCalled();
});
it.each(["legacy", "fallback"] as const)("behoudt de volledige route bij kernantwoord %s", (antwoord) => {
  const p = proef(); const bron = { ...p.bron, oosPositionOutline: () => antwoord };
  expect(selectiePositie(bron, p.oud, loc, "body", kaart)).toBe(99); expect(p.oud).toHaveBeenCalledExactlyOnceWith("body");
});
it("behoudt de oude route zonder nieuwe kernmethode", () => {
  const p = proef(); expect(selectiePositie({ hasStory: () => true, paragraphSpans: () => [] }, p.oud, loc, "body", kaart)).toBe(99);
});
it("laat een ontbrekend actief hoofdverhaal aan de oorspronkelijke terugvalroute", () => {
  const p = proef(); p.bron.hasStory = () => false;
  expect(selectiePositie(p.bron, p.oud, { ...loc, story: "fn:1" }, "hf:ontbreekt", kaart)).toBe(99);
  expect(p.bron.oosPositionOutline).not.toHaveBeenCalled(); expect(p.oud).toHaveBeenCalledExactlyOnceWith("hf:ontbreekt");
});
it("leest een verse omtrek na bronwijziging of wisselen van eigenaar", () => {
  const p = proef(); expect(selectiePositie(p.bron, p.oud, loc, "body", kaart)).toBe(13);
  p.bron.oosPositionOutline.mockReturnValue(omtrek(20));
  expect(selectiePositie(p.bron, p.oud, loc, "body", kaart)).toBe(23);
  const ander = proef(); expect(selectiePositie(ander.bron, ander.oud, loc, "body", kaart)).toBe(13);
  expect(p.bron.oosPositionOutline).toHaveBeenCalledTimes(2);
});
it("bouwt geen projectie zonder geldige invoerkaart en verbergt kernfouten niet", () => {
  const p = proef(); expect(selectiePositie(p.bron, p.oud, loc, "body", () => null)).toBeNull();
  expect(p.bron.oosPositionOutline).not.toHaveBeenCalled(); expect(p.oud).not.toHaveBeenCalled();
  p.bron.oosPositionOutline.mockImplementation(() => { throw new Error("Bron gesloten"); });
  expect(() => selectiePositie(p.bron, p.oud, loc, "body", kaart)).toThrow("Bron gesloten");
});
it("bewaakt beide exacte aansluitingen en de binding van de kernmethode", () => {
  const engine = readFileSync("node_modules/@betteroffice/docx-react/dist/index.mjs", "utf8");
  const kern = readFileSync("node_modules/@betteroffice/docx/dist/chunk-N5NWITJ6.mjs", "utf8");
  expect(herstelSelectiePositie(engine)).toContain("oosSelectiePositie(I,E.current,T,yt,r.inputPositionMap)");
  const aangepast = herstelPositieOmtrek(kern);
  const tekst = aangepast.match(/oosPositionOutline:t=>JSON.parse\(e\$1.geometry_position_outline_json\(t\)\)/)![0];
  const core = { marker: true, geometry_position_outline_json(this: { marker: boolean }, story: string) { expect(this.marker).toBe(true); return JSON.stringify({ story }); } };
  const brug = new Function("e$1", `return ({${tekst}})`)(core);
  expect(brug.oosPositionOutline("body")).toEqual({ story: "body" });
  for (const [fn, bron] of [[herstelSelectiePositie, engine], [herstelPositieOmtrek, kern]] as const) {
    expect(() => fn("andere kern")).toThrow(); expect(() => fn(bron + bron)).toThrow();
  }
});
