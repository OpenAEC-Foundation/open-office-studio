from pathlib import Path
import os,subprocess,json,time
r=Path.cwd();u=r/'.local/integratiecontrole/selectieprojectie';root=r.parent/'Open-Office-Studio';env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];env['OFFICE_PLAK_LEESOBSERVATIE']='0'
python=str(root/'.local/doorwerk-2026-11-02/gui-python/bin/python');app=str(u/'open-office-studio-selectieprojectie')
plan=[('tabel', 'scripts/test-writer-tabelgrepen-native.py', []),('herstelkopie','scripts/test-writer-rijk-plakken-native.py',['--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken'])];uit=[]
for naam,script,extra in plan:
 cmd=[python,script,'--programma',app,'--versie','2026.45.52',*extra,'--uitvoer',str(u/naam)];begin=time.monotonic()
 with (u/(naam+'.log')).open('x') as log:code=subprocess.run(['timeout','450',*cmd],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 uit.append({'naam':naam,'code':code,'seconden':time.monotonic()-begin,'cmd':cmd});(u/'extra-native.json').write_text(json.dumps(uit,indent=2)+'\n');print(json.dumps(uit[-1]),flush=True)
 if code:raise SystemExit(code)
