import { mergeConfig } from 'vite';
import basis from '../../../vite.config';
const config=mergeConfig(basis,{test:{include:['.local/integratiecontrole/selectieprojectie/*.test.ts'],fileParallelism:false,server:{deps:{inline:[/@betteroffice\/docx/]}}}});
config.test!.exclude=['**/node_modules/**'];
export default config;
