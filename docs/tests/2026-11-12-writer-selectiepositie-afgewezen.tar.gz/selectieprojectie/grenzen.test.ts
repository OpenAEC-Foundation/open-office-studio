import {readFileSync,writeFileSync} from 'node:fs';
import {expect,it} from 'vitest';
import {createYrsSession,createYrsPositionProjection,createYrsLocProjectionFromOutline} from '@betteroffice/docx/yrs';
it.each(['sdt','pageBreak','columnBreak','blockSdt'])('controleert echte %s-grenzen met handmatig bepaalde posities',async(kind)=>{
 const s=await createYrsSession();
 try{
  s.openDocx(readFileSync('public/templates/nieuw.docx'),true);const id=s.paragraphSpans('body')[0].paraId;
  s.insertText({story:'body',paraId:id,offset:0},'AB');
  if(kind==='blockSdt')s.createStory('control','CD');
  s.applyRawOps('body',[{op:'insertEmbed',index:kind==='sdt'?1:0,kind,payload:kind==='sdt'?{content:[{kind:'text',text:'😀e\u0301'}]}:kind==='blockSdt'?{story:'control'}:{}}]);
  const outline=(s as any).oosPositionOutline('body'),kaart=createYrsLocProjectionFromOutline(outline),oud=createYrsPositionProjection(s,'body')!;
  // Inline: A(1)+SDT(open1+UTF16inhoud4+sluit1)+B(1). Blok-SDT:
  // open1 + kind-alinea(CD+2=4) + sluit1 =6; losse breuk is1.
  const verwacht=kind==='sdt'?[1,2,8,9]:kind==='blockSdt'?[7,7,8,9]:[2,2,3,4];
  for(const [offset,pos]of verwacht.entries()){
   const loc={story:'body',paraId:id,offset};expect(oud.positionForLoc(loc)).toBe(pos);expect(kaart.positionForLoc(loc)).toBe(pos);
  }
  writeFileSync('.local/integratiecontrole/selectieprojectie/grens-'+kind+'.json',JSON.stringify({kind,outline,verwacht},null,2)+'\n');
 }finally{s.destroy()}
});
it.each(['hf:proef','fn:1','en:1'])('behoudt actieve %s-posities en onderliggende tabelcellen',async(root)=>{
 const s=await createYrsSession();
 try{
  s.openDocx(readFileSync('public/templates/nieuw.docx'),true);s.createStory(root,'AB');
  const paraId=s.paragraphSpans(root)[0].paraId,table=s.insertTable({story:root,paraId,offset:0},1,1);
  const compact=createYrsLocProjectionFromOutline((s as any).oosPositionOutline(root)),oud=createYrsPositionProjection(s,root)!;
  // Een lege 1x1-tabel:2tabel+2rij+2cel+2legealinea=8posities.
  const grens={story:root,paraId,offset:1};expect(oud.positionForLoc(grens)).toBe(9);expect(compact.positionForLoc(grens)).toBe(9);
  const child=table.createdStoryIds[0],p=s.paragraphSpans(child)[0];const cel={story:child,paraId:p.paraId,offset:0};
  expect(oud.positionForLoc(cel)).toBe(4);expect(compact.positionForLoc(cel)).toBe(4);
 }finally{s.destroy()}
});
