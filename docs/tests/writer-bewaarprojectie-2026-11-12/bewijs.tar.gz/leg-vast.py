from pathlib import Path
import hashlib,json,tarfile,shutil,subprocess
p=Path(__file__).resolve().parent
root=Path.cwd()
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
controles=json.loads((p/'controles.json').read_text());assert len(controles)==4 and all(r['exitcode']==0 for r in controles)
assert '2389 passed' in (p/'frontend.log').read_text()
assert 'Ran 127 tests' in (p/'python.log').read_text()
manifest=json.loads((p/'standaard-dist.json').read_text())
nu={str(f.relative_to('dist')):{'sha256':sha(f),'mode':f.stat().st_mode,'mtime_ns':f.stat().st_mtime_ns} for f in Path('dist').rglob('*') if f.is_file()}
assert manifest==nu
refs=json.loads((p/'referenties.json').read_text());assert all(sha(f)==h for f,h in refs.items())
bron=json.loads((p/'bronhashes.json').read_text());assert all(sha(f)==h for f,h in bron.items())
(p/'eindcontrole.json').write_text(json.dumps({'standaard_dist_exact':len(nu),'vaste_referenties_exact':len(refs),'bronhashes_exact':True,'vrije_bytes':shutil.disk_usage('.').free,'native_startgrens_bytes':int(3.1*1024**3),'native_bouw_gestart':False},indent=2)+'\n')
files=['gericht.log','frontend.log','typescript.log','python.log','migratie.log','webbouw.log','controles.json','bronhashes.json','referenties.json','standaard-dist.json','eindcontrole.json','leg-vast.py']
files += ['scripts/tekstengine-compatibiliteit.ts','src/tekst/gedeeld/bewaarProjectie.ts','src/tekst/gedeeld/bewaarProjectie.test.ts']
archief=Path('docs/tests/writer-bewaarprojectie-2026-11-12/bewijs.tar.gz');archief.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(archief,'w:gz') as t:
 for f in files:
  src=root/f if '/' in f else p/f
  t.add(src,arcname=f,recursive=False)
with tarfile.open(archief) as t:
 assert len(t.getmembers())==len(files)
 for m in t:
  src=root/m.name if '/' in m.name else p/m.name
  assert t.extractfile(m).read()==src.read_bytes()
rapport={'onderwerp':'Gerichte uitgestelde Writer-projectie tijdens bewaaradoptie','bronbasis':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'productwijziging':True,'wijzigingen':['Alleen remote projecties met actieve oosBewaarUpdate-markering naar een microtaak verplaatst; gewone remote updates blijven direct.','Nieuwe updates maken ouder wachtend werk ongeldig; renderbinding en layoutopruiming bewaken sessie en levensduur.','Bestaande workerguard en zichtbare projectiefouten behouden; vastgezet engineanker faalt bij afwijkende bron.'],'controles':{'gericht':{'bestanden':2,'tests':20,'geslaagd':True},'frontend':{'bestanden':232,'tests':2389,'geslaagd':True},'overig':controles,'referenties':8,'standaard_dist':529},'bewijs':{'pad':str(archief),'sha256':sha(archief),'bytes':archief.stat().st_size,'bestanden':len(files),'teruggelezen_bytegelijk':True},'grenzen':['Deterministische tegenproef voert de oorspronkelijke enginecallback uit met een gesimuleerde uitleenblokkering; geen lokale reproductie van de echte Wasm-paniek.','Hooklevensduur getest met gecontroleerde React-haken; geen echte React-DOM-integratieproef in deze stap.','Geen lokale native kandidaatbouw wegens vrije ruimte onder bestaande startgrens; geen grens verlaagd of gebruikersdata/referentie verwijderd.','Geen nieuwe native GUI-, visuele-, latency-, pakket-, platform- of migratieacceptatie. De eerdere Linux-afkeuring blijft staan.','Desktopmatrix moet na push op deze ontwikkelbranch worden gestart; resultaten nog niet bekend. Geen reguliere release gewijzigd.']}
Path('docs/tests/2026-11-12-writer-bewaarprojectie.json').write_text(json.dumps(rapport,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(rapport['bewijs']))
