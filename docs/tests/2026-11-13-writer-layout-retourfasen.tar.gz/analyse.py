from pathlib import Path
import json,hashlib,statistics,ast,subprocess
from zipfile import ZipFile
from xml.etree import ElementTree as ET
r=Path.cwd();p=r/'.local/integratiecontrole/layout-retourfasen';old=r/'.local/integratiecontrole/warm-layout-request';read=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();n=read(p/'native-functie/rapport.json');assert n['geslaagd'];c=read(p/'proef.json');assert c['geslaagd']and len(c['ronden'])==4 and all(len(x['stappen'])==9 for x in c['ronden']);assert c['wasm_sha256']==n['runtime_wasm']['sha256'];assert n['programma_sha256']==sha(old/'open-office-studio-warm-layout-request')
workers=[];rows=[]
for x in n['werkers_binnen_eind']:
 v=x['antwoord']['result']['result']['value'];e=v['uitvoering'];assert not e['overflow']and not e['errors']and e['restored'];assert v['berichten']['hersteld'];workers.append({'werker':x['werker'],'probe':e});rows+=e['rows']
assert rows and all(x['layoutMs']is not None and x['retourMs']is not None for x in rows)
assert len(n['uitvoeringspunten'])==len(n['uitvoeringspunten_verwijderd'])==2
assert all(x.get('result')=={}for x in n['uitvoeringspunten_verwijderd'])
for x in n['uitvoeringspunten']:assert len(x['antwoord']['result']['locations'])==(0 if x['werker']['name']=='spelling'else 1)
def stats(v):return{'aantal':len(v),'som_ms':sum(v),'mediaan_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)}
a={'native_werkers':workers,'native_layout_zonder_retour':stats([x['layoutMs']for x in rows]),'native_retour_uitlezen':stats([x['retourMs']for x in rows]),'native_grens':'Eerste oorspronkelijke retainedJSON-call installeert wrapper en blijft ongewijzigd;alleen volgende calls gesplitst. Geen vergelijking van totale snelheid of zuivere CPU. Fontscope eindigt na layout vóór retained_layout_json;componentbytes/frames exact en nativefunctie geslaagd.','component_ronden':[]}
for x in c['ronden']:
 warm=x['stappen'][1:];a['component_ronden'].append({'nummer':x['nummer'],'eerste':x['eerste'],'koud':x['stappen'][0],'warm_volledig':stats([s['volledig_ms']for s in warm]),'warm_layout_zonder_retour':stats([s['layout_zonder_retour_ms']for s in warm]),'warm_retour_uitlezen':stats([s['retour_uitlezen_ms']for s in warm])})
(p/'analyse.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
refs=read(old/'referenties-nacontrole.json');assert len(refs)==23
for f,h in refs.items():assert sha(Path(f))==h
expected=read(old/'standaardbundel.json');actual={str(f.relative_to(r/'dist')):{'sha256':sha(f),'mode':f.stat().st_mode&0o777,'mtime_ns':f.stat().st_mtime_ns}for f in(r/'dist').rglob('*')if f.is_file()};assert actual==expected and len(actual)==529
pins=read(old/'behoud.json')['sdk_vendor_npm_exact'];source=read(old/'bron-hersteld.json')['bestanden']
for f,h in dict(pins,**source).items():assert sha(r/f)==h
scripts=[];node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
for f in p.glob('*.py'):ast.parse(f.read_text());scripts.append({'pad':f.name,'controle':'Python AST','code':0})
for f in list(p.glob('*.mjs'))+list(p.glob('*.js')):
 z=subprocess.run([node,'--check',str(f)],capture_output=True);assert z.returncode==0,(f,z.stderr);scripts.append({'pad':f.name,'controle':'node --check','code':0})
f=p/'native-functie/Ontwerpnotitie.docx';assert sha(f)==n['bewaring_sha256'];parts={}
with ZipFile(f)as z:
 assert z.testzip()is None
 for name in z.namelist():
  b=z.read(name)
  if name.endswith(('.xml','.rels')):ET.fromstring(b)
  parts[name]=hashlib.sha256(b).hexdigest()
 root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(x.text or''for x in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128 and units==91423
with ZipFile(old/'native-functie/Ontwerpnotitie.docx')as z:previous={name:hashlib.sha256(z.read(name)).hexdigest()for name in z.namelist()}
assert set(parts)==set(previous);diff=[name for name in parts if parts[name]!=previous[name]];assert set(diff)<={'docProps/core.xml'}
(p/'documentcontrole.json').write_text(json.dumps({'sha256':sha(f),'zip_crc_xml':True,'tabellen':tables,'utf16':units,'verschil_met_vorige_zelfde_ELF':diff},indent=2)+'\n');(p/'behoud.json').write_text(json.dumps({'elf_referenties_exact':refs,'standaardbundel_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':pins,'canonieke_bron_exact':source,'scripts':scripts},indent=2)+'\n');print(json.dumps({k:a[k]for k in ['native_layout_zonder_retour','native_retour_uitlezen']}))
