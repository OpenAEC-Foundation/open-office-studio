from pathlib import Path
import json,gzip,hashlib,collections
p=Path(__file__).resolve().parent;n=p/'native-functie';r=json.loads((n/'rapport.json').read_text());events=json.loads(gzip.decompress((n/'profielen.json.gz').read_bytes()));complete=[x for x in events if x.get('method')=='ScriptProfiler.trackingComplete'];assert len(complete)==1;samples=complete[0]['params']['samples']['stackTraces'];assert len(samples)==r['profiel_samples'];sources={}
for b in r['scriptbronnen']:
 raw=gzip.decompress((n/b['bestand']).read_bytes());assert hashlib.sha256(raw).hexdigest()==b['sha256'];sources[b['url']]=raw.decode()
counts=collections.Counter();paths=collections.Counter()
for sample in samples:
 names=[f['name']for f in sample['stackFrames']]
 for name in ['buildStory','storySegmentUnitDigests','tablePayload','readParagraphs','paragraphs','dee','iL','targetAt']:
  if name in names:counts[name]+=1
 if 'buildStory'in names:
  i=names.index('buildStory');paths[tuple(names[i:i+9])]+=1
contexts=[]
for name in ['sY','iY','lY','dee','iL']:
 f=next(f for s in samples for f in s['stackFrames']if f['name']==name);line=sources[f['url']].split('\n')[f['line']-1].encode('utf-16-le');c=f['column']-1;context=line[max(0,c-35)*2:(c+1100)*2].decode('utf-16-le',errors='replace');contexts.append({'frame':f,'context':context})
for name,anchor in [('sY','this.buildStory(n,0,0)'),('iY','new sY'),('lY','positionForLoc'),('dee','geometry:'),('iL','displayPositionToYrsLoc')]:assert anchor in next(x['context']for x in contexts if x['frame']['name']==name),(name,anchor)
out={'samples':len(samples),'stacklidmaatschap':dict(counts),'buildStory_paden':[{'namen':list(k),'samples':v}for k,v in paths.most_common()],'broncontext':contexts,'grenzen':['Overlappende stacklidmaatschappen;geen exclusieve CPU,tijdpercentages of aanroepaantallen.','Profielvenster begint na verzenden,maar vóór laatste ontvangen keyup;geen uitsluitend invoerstaart.','Positieprojectie/herbouw en tabelgrepen zichtbaar;geen oorzaakbewijs of toestemming om selectie/grepen te laten vervallen.']};(p/'profiel.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(dict(counts))
