import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {pathToFileURL} from 'node:url';
const out=path.resolve('.local/integratiecontrole/layout-retourfasen'),base=path.resolve('.local/integratiecontrole/warm-layout-request'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const wasm=fs.readFileSync(path.join(base,'kern/docx_edit_bg.wasm'));const mod=await import(pathToFileURL(path.join(base,'kern/docx_edit.js')).href);await mod.default({module_or_path:wasm});
const fixture=fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx');const font=fs.readFileSync('.local/integratiecontrole/font-hergebruik/bron/crates/ooxml-text/tests/fonts/LiberationSans-Regular.ttf');
const capture=JSON.parse(fs.readFileSync(path.join(base,'aanvragen.json')));const incoming=capture.regels.find(x=>x.richting==='verzending'&&x.type==='sync');const reqValue=JSON.parse(capture.omgevingen[incoming.env.layoutrequest].json);
const seed=new mod.EditSession(6401);seed.open_docx(fixture,true);const state=seed.encode_state(),para=JSON.parse(seed.read_paragraphs_json('{"story":"body","view":"accepted"}')).paragraphs.at(-1);seed.free();
const texts=[' Een proef',' met woorden',' en spaties.',' Ω',' العربية',' 漢字',' 🙂',' extra'];
const report={geslaagd:false,wasm_sha256:sha(wasm),fixture_sha256:sha(fixture),font_sha256:sha(font),request_bron:'warm-layout-request/aanvragen.json,eerste sync;measurement voor deze gecontroleerde fontregistratie vervangen',ronden:[],grenzen:['Losse Node/Wasm-componentproef;geen native desktop/GUI/visuele/snelheidsacceptatie.','retained_layout_json-klok bevat Rust-serialisatie en Wasm→JS-stringretour;geen zuivere CPU of apart transportpercentage.','Geen volledige aanvraagreplay:één echte request met gecontroleerde fonts en eigen acht tekstmutaties.']};
let seq=6402;
function create(){const s=new mod.EditSession(seq++);s.open_docx(fixture,false);s.load(state);s.set_local_lowering(true);s.clear_measure_fonts();const fid=s.register_measure_font(font);return{s,fid};}
function timed(f){const t=performance.now();const v=f();return{ms:performance.now()-t,v};}
try{
 for(let round=0;round<4;round++){
  const aa=create(),bb=create();assert.equal(aa.fid,bb.fid);const a=aa.s,b=bb.s;const source=new mod.EditSession(seq++);source.open_docx(fixture,false);source.load(state);
  const request=JSON.stringify({...reqValue,measurement:{fontChains:{'liberation sans|0|0':[aa.fid]},defaults:{fontSize:11,fontFamily:'Liberation Sans'}}});
  const roundReport={nummer:round+1,eerste:round===0||round===3?'volledig':'gesplitst',request:JSON.parse(request),stappen:[]};report.ronden.push(roundReport);
  try{
   let offset=para.text.length;
   for(let step=-1;step<texts.length;step++){
    if(step>=0){const v=source.encode_state_vector();source.edit_text_resident('body',para.paraId,offset,para.paraId,offset,texts[step]);const diff=source.encode_diff(v);a.apply_update_with_inference(diff);b.apply_update_with_inference(diff);offset+=texts[step].length;}
    assert.deepEqual(a.encode_state(),b.encode_state());assert.deepEqual(a.encode_state_vector(),b.encode_state_vector());const stateA=a.encode_state(),stateB=b.encode_state(),va=a.version(),vb=b.version();
    const fa=a.layout_font_requirements_json(request),fb=b.layout_font_requirements_json(request);assert.equal(fa,fb);a.warm_story_for_region_layout('body',request);b.warm_story_for_region_layout('body',request);
    let full,layout,serial;
    const runFull=()=>{full=timed(()=>a.layout_document_with_regions_retained_json(request));};
    const runSplit=()=>{layout=timed(()=>b.layout_document_with_regions_retained(request));assert.equal(layout.v,undefined);serial=timed(()=>b.retained_layout_json());};
    if(roundReport.eerste==='volledig'){runFull();runSplit();}else{runSplit();runFull();}
    assert.equal(full.v,serial.v);assert.equal(a.retained_layout_json(),full.v);assert.equal(b.retained_layout_json(),serial.v);
    assert.deepEqual(a.encode_state(),stateA);assert.deepEqual(b.encode_state(),stateB);assert.equal(a.version(),va);assert.equal(b.version(),vb);assert.deepEqual(a.encode_state_vector(),b.encode_state_vector());
    const frameA=a.build_display_list_frame('{}',0),frameB=b.build_display_list_frame('{}',0);assert.deepEqual(frameA,frameB);
    const parsed=JSON.parse(full.v);const row={stap:step,tekst:step<0?'koud':texts[step],volledig_ms:full.ms,layout_zonder_retour_ms:layout.ms,retour_uitlezen_ms:serial.ms,layout_json_bytes:Buffer.byteLength(full.v),layout_sha256:sha(full.v),frame_sha256:sha(frameA),paginas:parsed.layout.pages.length,fragmenten:parsed.layout.pages.reduce((n,x)=>n+x.fragments.length,0),staat_vector_versie_font_retour_frame_exact:true};roundReport.stappen.push(row);
   }
  }finally{a.free();b.free();source.free();}
 }
 report.geslaagd=true;
}catch(e){report.fout=String(e);throw e;}finally{fs.writeFileSync(path.join(out,'proef.json'),JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({geslaagd:report.geslaagd,ronden:report.ronden.map(r=>({nummer:r.nummer,stappen:r.stappen.length,warm_layout_ms:r.stappen.slice(1).reduce((n,s)=>n+s.layout_zonder_retour_ms,0),warm_retour_ms:r.stappen.slice(1).reduce((n,s)=>n+s.retour_uitlezen_ms,0),warm_volledig_ms:r.stappen.slice(1).reduce((n,s)=>n+s.volledig_ms,0)}))}));
