from pathlib import Path
import subprocess,time,json,os,signal
r=Path.cwd();p=r/'.local/integratiecontrole/digest-spans';cmd=['/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','node_modules/vitest/vitest.mjs','run','--maxWorkers=2'];start=time.monotonic()
with(p/'office-tests.log').open('x')as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll()is None:
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:print('OFFICE ACTIEF',round(time.monotonic()-start),flush=True)
  if time.monotonic()-start>600 and proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=20)
result={'procescode':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd,'standaard_vendor_kern':True};(p/'suite-uitkomst.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert proc.returncode==0
