from pathlib import Path
import subprocess,os,json,hashlib,shutil,time,signal
r=Path.cwd();p=r/'.local/integratiecontrole/digest-spans';old=p.parent/'digest-actueel';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert subprocess.check_output(['git','status','--porcelain'])==b''
refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==44
for f,h in refs.items():assert sha(Path(f))==h,f
assert json.loads((p/'callback-veilig.json').read_text())['geslaagd'];assert json.loads((p/'spans-randen.json').read_text())['geslaagd'];assert json.loads((p/'randen.json').read_text())['geslaagd'];dist=p/'dist-kandidaat';assert dist.exists();files={str(f.relative_to(dist)):sha(f)for f in dist.rglob('*')if f.is_file()};assert len(files)==529;assert [h for f,h in files.items()if'docx_edit_bg'in f]==[sha(p/'kandidaat/docx_edit_bg.wasm')];(p/'bundel-kandidaat.json').write_text(json.dumps(files,indent=2)+'\n')
assert (p/'dist-basis').exists();base=json.loads((old/'desktop.json').read_text())[1];assert base['variant']=='kandidaat';assert sha(p/'open-office-studio-spans-basis')==base['sha256'];target=p/'native-target';assert target.exists()
config={'build':{'frontendDist':str(dist)}};env={**os.environ,'TAURI_CONFIG':json.dumps(config),'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']};cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];start=time.monotonic()
with(p/'native-bouw.log').open('x')as log:
 proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll()is None:
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:print('NATIVE ACTIEF',round(time.monotonic()-start),flush=True)
  if time.monotonic()-start>1200 or shutil.disk_usage(p).free<10*1024**3:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=30);break
assert proc.returncode==0;out=p/'open-office-studio-spans-veilig';shutil.copy2(target/'release/open-office-studio',out);rows=[{'variant':'basis','code':0,'overgenomen_uit':base['programma'],'programma':str(p/'open-office-studio-spans-basis'),'sha256':base['sha256'],'grens':'Bestaande actuele native referentie ongewijzigd; geen nieuwe basiscompilatie.'},{'variant':'kandidaat','code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd,'TAURI_CONFIG':config,'programma':str(out),'sha256':sha(out)}];(p/'desktop.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows),flush=True)
