from pathlib import Path
p=Path('.local/integratiecontrole/digest-spans');old=p.parent/'digest-productie'
for name in ['contract.mjs','randen.mjs','callback.mjs','pariteit.mjs']:
 s=(old/name).read_text().replace('digest-productie','digest-spans')
 if name=='pariteit.mjs':
  needle='for(const story of ids){const values=';assert s.count(needle)==1
  s=s.replace(needle,"for(const story of ids){const spans=sessions.map(s=>s.paragraph_spans(story));assert.equal(spans[1],spans[0],`${caseName}/${phase}/${story}/spans-basis`);assert.equal(spans[2],spans[0],`${caseName}/${phase}/${story}/spans-kandidaat`);const values=")
  needle='const segments=sessions.map';assert s.count(needle)==1
  s=s.replace(needle,"for(const s of sessions)assert.equal(s.paragraph_spans(story),spans[0],'spans na digests');const segments=sessions.map")
  s=s.replace("Geen DOCX-export, native app, GUI of alle mogelijke metadata-APIs.","ParagraphSpans vóór en na digests op alle stories exact. Geen DOCX-export, native app, GUI of alle mogelijke metadata-APIs.")
 if name=='randen.mjs':
  s=s.replace("const resolvedDigests=source.story_segment_unit_digests('body');", "const resolvedSpans=source.paragraph_spans('body');const resolvedDigests=source.story_segment_unit_digests('body');")
  s=s.replace("const initial=s.story_segment_unit_digests('body'),", "const initialSpans=s.paragraph_spans('body');const initial=s.story_segment_unit_digests('body'),")
  s=s.replace("assert.equal(s.story_segment_unit_digests('body'),initial);", "assert.equal(s.paragraph_spans('body'),initialSpans);assert.equal(s.story_segment_unit_digests('body'),initial);")
  s=s.replace("assert.throws(()=>s.story_segment_unit_digests('onbekend'));", "assert.throws(()=>s.paragraph_spans('onbekend'));assert.throws(()=>s.story_segment_unit_digests('onbekend'));")
  s=s.replace("assert.equal(s.story_segment_unit_digests('body'),resolvedDigests);", "assert.equal(s.paragraph_spans('body'),resolvedSpans);assert.equal(s.story_segment_unit_digests('body'),resolvedDigests);")
  s=s.replace("assert.equal(s.story_segment_unit_digests('body'),source.story_segment_unit_digests('body'));", "assert.equal(s.paragraph_spans('body'),source.paragraph_spans('body'));assert.equal(s.story_segment_unit_digests('body'),source.story_segment_unit_digests('body'));")
  s=s.replace("assert.throws(()=>empty.story_segment_unit_digests('body'));", "assert.throws(()=>empty.paragraph_spans('body'));assert.throws(()=>empty.story_segment_unit_digests('body'));")
  s=s.replace("assert.equal(empty.story_segment_unit_digests('body'),fresh.story_segment_unit_digests('body'));", "assert.equal(empty.paragraph_spans('body'),fresh.paragraph_spans('body'));assert.equal(empty.story_segment_unit_digests('body'),fresh.story_segment_unit_digests('body'));")
 (p/name).write_text(s)
