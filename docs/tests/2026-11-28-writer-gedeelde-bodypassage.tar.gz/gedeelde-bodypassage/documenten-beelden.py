from pathlib import Path,PurePosixPath
import json,hashlib
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();docs={};pixels=[]
for label in ['a-een','b-een','b-twee','a-twee','schema3-a','schema3-b']:
 d=p/('native-'+label);r=json.loads((d/'rapport.json').read_text());assert r['geslaagd'];f=d/'Ontwerpnotitie.docx';assert sha(f)==r['bewaring_sha256'];parts={}
 with ZipFile(f)as z:
  names=z.namelist();assert len(names)==len(set(names));assert z.testzip()is None
  for n in names:
   q=PurePosixPath(n);assert not q.is_absolute()and'..'not in q.parts and'\\'not in n
   data=z.read(n)
   if n.endswith(('.xml','.rels')):ET.fromstring(data)
   parts[n]=hashlib.sha256(data).hexdigest()
  root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(n.text or''for n in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128==r['bewaarde_tabellen_exact']
 docs[label]={'sha256':sha(f),'tabellen':tables,'utf16':units,'part_hashes':parts}
for label in ['b-een','b-twee','a-twee','schema3-a','schema3-b']:
 for name in ['invoer-redo.png','snel-getypt-bewaard.png','nieuw-na-laat-antwoord.png']:
  a=Image.open(p/'native-a-een'/name).convert('RGB');b=Image.open(p/('native-'+label)/name).convert('RGB');assert a.size==b.size;diff=ImageChops.difference(a,b);bbox=diff.getbbox();count=0 if bbox is None else sum(any(c)for c in diff.crop(bbox).getdata());pixels.append({'label':label,'beeld':name,'verschillende_pixels':count,'bbox':bbox})
reference=docs['a-een']['part_hashes'];differences={label:[n for n in sorted(set(reference)|set(v['part_hashes']))if reference.get(n)!=v['part_hashes'].get(n)]for label,v in docs.items()}
result={'documenten':docs,'verschillende_onderdelen':differences,'beelden':pixels,'exacte_beeldparen':sum(x['verschillende_pixels']==0 for x in pixels),'grens':'Drie vaste screenshots per functieronde, hele pixels zonder masker; geen volledige document-/glyph-/platformvisualisatie.'};(p/'documenten-beelden.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'documenten':len(docs),'beelden':len(pixels),'exact':result['exacte_beeldparen'],'verschillende_onderdelen':differences}))
def core(f):
 with ZipFile(f)as z:return {n.tag:{'text':n.text,'attrs':n.attrib}for n in ET.fromstring(z.read('docProps/core.xml'))}
a=core(p/'native-a-een/Ontwerpnotitie.docx');changes={}
for label in ['b-een','b-twee','a-twee','schema3-a','schema3-b']:
 b=core(p/('native-'+label)/'Ontwerpnotitie.docx');changes[label]=[k for k in set(a)|set(b)if a.get(k)!=b.get(k)];assert set(changes[label])=={'{http://purl.org/dc/terms/}modified'}
old=p.parent/'font-rij-native/native-rijk-a-een/Ontwerpnotitie.docx'
with ZipFile(old)as z:parts={n:hashlib.sha256(z.read(n)).hexdigest()for n in z.namelist()}
now=result['documenten']['a-een']['part_hashes'];changed=sorted(n for n in set(parts)|set(now)if parts.get(n)!=now.get(n));assert changed==['docProps/core.xml']
result['core_verschillen']=changes;result['historische_voorraad_export']={'pad':str(old),'sha256':sha(old),'programma_sha256':'ee89c80e91be3a96fe47430b0e85d4093dde2bc160c0b10c872aa9733ce153bd','verschillende_onderdelen':changed,'grens':'Bestaande voorraadexport met dezelfde rijke helper; geen nieuwe voorraadprestatiemeting.'};(p/'documenten-beelden.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
