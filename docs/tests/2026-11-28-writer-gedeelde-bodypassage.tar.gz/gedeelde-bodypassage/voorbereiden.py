from pathlib import Path
import json,hashlib,shutil,difflib
r=Path.cwd();old=r/'.local/integratiecontrole/digest-productie';p=r/'.local/integratiecontrole/digest-spans';src=p/'bron';assert not src.exists();src.mkdir();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();names=list(json.loads((old/'bron-voor.json').read_text()))+['crates/docx-edit/src/digest_cache.rs'];before={}
for name in names:
 f=old/'bron'/name;out=src/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,out);before[name]=sha(out)
(p/'bron-voor.json').write_text(json.dumps(before,indent=2)+'\n');cache=src/'crates/docx-edit/src/digest_cache.rs';s=cache.read_text();needle='    pub fn apply(&mut self, doc: &EditingDoc, bytes: &[u8]) -> Result<(), String> {';assert s.count(needle)==1
new='''    pub fn paragraph_spans(
        &mut self,
        doc: &EditingDoc,
    ) -> Result<Option<Vec<(String, u32)>>, String> {
        self.bind(doc);
        let _pin = doc.yrs_doc().transact();
        let epoch = doc.committed_epoch();
        let Some(entry) = self.entry.as_ref().filter(|e| e.epoch == epoch) else {
            return Ok(None);
        };
        if entry.bounds.iter().any(|b| b.para.is_none()) {
            return Ok(None);
        }
        if entry.dirty.is_some() {
            self.get(doc)?;
        }
        Ok(self.entry.as_ref().filter(|e| e.epoch == epoch && e.dirty.is_none()).and_then(|e| {
            e.bounds.iter().map(|b| {
                Some((b.para.clone()?, b.end.checked_sub(b.start)?.checked_sub(1)?))
            }).collect()
        }))
    }
''';cache.write_text(s.replace(needle,new+needle));wasm=src/'crates/docx-edit/src/wasm.rs';s=wasm.read_text();needle='    pub fn paragraph_spans(&self, story: &str) -> Result<String, JsValue> {\n';assert s.count(needle)==1
new='''        if story == "body" {
            if let Some(spans) = self.unit_digest_cache.borrow_mut()
                .paragraph_spans(self.engine.doc()).map_err(js_err)? {
                let items: Vec<Value> = spans.into_iter()
                    .map(|(para_id, length)| json!({"paraId": para_id, "length": length}))
                    .collect();
                return serde_json::to_string(&items).map_err(js_err);
            }
        }
''';wasm.write_text(s.replace(needle,needle+new));patch=''
for name in ['crates/docx-edit/src/digest_cache.rs','crates/docx-edit/src/wasm.rs']:
 patch+=''.join(difflib.unified_diff((old/'bron'/name).read_text().splitlines(True),(src/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(p/'gedeelde-spans.patch').write_text(patch);(p/'bron-na.json').write_text(json.dumps({n:sha(src/n)for n in names},indent=2)+'\n');print(json.dumps({'bronbestanden':len(names),'gewijzigd':2,'patch_sha256':sha(p/'gedeelde-spans.patch')}))
