from pathlib import Path
import json,hashlib,stat
r=Path.cwd();p=r/'.local/integratiecontrole/digest-spans';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();old=p.parent/'digest-actueel';refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==44
for file in ['open-office-studio-spans-basis','open-office-studio-spans-kandidaat','eerste-variant/open-office-studio-spans-kandidaat','open-office-studio-spans-veilig']:refs[str(p/file)]=sha(p/file)
assert len(refs)==48
for f,h in refs.items():assert sha(Path(f))==h,f
assert sha(p/'open-office-studio-spans-basis')=='ff3c93e8b40c8f7c554451120ad6237dc9ca33a43861981c3c1b3cf05b1c8e76'
assert sha(p/'open-office-studio-spans-kandidaat')==sha(p/'eerste-variant/open-office-studio-spans-kandidaat')=='5a82fdeb041d18a94e1c47446bf381ef7affddd27da80e2eba6361c8bbe98744'
assert sha(p/'open-office-studio-spans-veilig')=='061b19f15628f803bf772ece68f3a4bb2d2b09e34012b04524d220500c00e849'
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
manifest=json.loads((p/'bron-voor.json').read_text())
for f,h in manifest.items():assert sha(p.parent/'digest-productie/bron'/f)==h,f
changed=[f for f,h in manifest.items()if sha(p/'bron'/f)!=h];assert sorted(changed)==['crates/docx-edit/src/digest_cache.rs','crates/docx-edit/src/wasm.rs']
pins=json.loads((p.parent/'projectie-context-telling-herbouw/behoud.json').read_text())['sdk_vendor_canonieke_bron_exact']
for f,h in pins.items():
 if f!='vendor/tekstengine/docx_edit_bg.wasm':assert sha(r/f)==h,f
meta=json.loads((r/'patches/tekstengine-digestcache.json').read_text());assert sha(r/'vendor/tekstengine/docx_edit_bg.wasm')==meta['wasmSha256'];assert sha(p/'basis/docx_edit_bg.wasm')==meta['vorigeWasmSha256'];assert sha(p.parent/'digest-productie/basis/docx_edit_bg.wasm')==meta['basisWasmSha256']
bundle=json.loads((p.parent/'projectie-context-telling-herbouw/standaardbundel.json').read_text())
for f,v in bundle.items():
 q=r/'dist'/f;s=q.stat();assert sha(q)==v['sha256']and stat.S_IMODE(s.st_mode)==v['mode']and s.st_mtime_ns==v['mtime_ns'],f
out={'referentiepaden48_sha256_exact':True,'standaarddist529_byte_mode_mtime_exact':len(bundle)==529,'canonieke_bronpinnen14_exact':len(pins)==15,'eerdere_schone_kernbron4418_exact':len(manifest)==4418,'nieuwe_kernbron_alleen_twee_bestanden_gewijzigd':changed,'vendor_overgang':{'oud':meta['vorigeWasmSha256'],'nieuw':meta['wasmSha256'],'eerdere_actieve_kern_exact_bewaard':str(p/'basis/docx_edit_bg.wasm'),'oudere_voorraadkern_exact_bewaard':str(p.parent/'digest-productie/basis/docx_edit_bg.wasm')},'grens':'48 paden omvatten bytegelijke kopie van de basis en bewaarde eerste proefvariant; geen 48 unieke of functioneel geaccepteerde uitgaven. Vendor bewust gewijzigd; niet alle 15 oorspronkelijke bronpinnen onveranderd. Standaarddist en eerdere referenties niet vervangen.'};(p/'behoud.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if isinstance(v,bool)}))
