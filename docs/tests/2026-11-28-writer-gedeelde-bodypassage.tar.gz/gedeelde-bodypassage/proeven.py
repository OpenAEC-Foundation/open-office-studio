from pathlib import Path
import subprocess,time,json,os,signal
r=Path.cwd();p=r/'.local/integratiecontrole/digest-spans';node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';results=[]
for name in ['contract','spans-randen','randen','callback','callback-veilig','pariteit']:
 start=time.monotonic();print('START',name,flush=True)
 with(p/(name+'.log')).open('x')as log:
  proc=subprocess.Popen([node,str(p/(name+'.mjs'))],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print('ACTIEF',name,round(time.monotonic()-start),flush=True)
   if time.monotonic()-start>600 and proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=20)
 row={'proef':name,'code':proc.returncode,'seconden':time.monotonic()-start};results.append(row);(p/'proeven.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert proc.returncode==0,name
