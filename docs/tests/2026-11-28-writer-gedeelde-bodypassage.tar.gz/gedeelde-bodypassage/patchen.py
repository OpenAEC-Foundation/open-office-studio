from pathlib import Path
import subprocess,hashlib,difflib,json,shutil
r=Path.cwd();p=r/'.local/integratiecontrole/digest-spans';old=p.parent/'digest-productie';basis=p/'patch-basis';assert not basis.exists();names=['crates/docx-edit/src/engine.rs','crates/docx-edit/src/lib.rs','crates/docx-edit/src/wasm.rs','crates/docx-edit/src/digest_cache.rs'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();manifest=json.loads((old/'bron-voor.json').read_text())
for name in names:
 f=basis/name;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/'bron'/name,f)
res=subprocess.run(['patch','-p1','--reverse','--fuzz=0','--batch','-i',str((old/'cache.patch').resolve())],cwd=basis,capture_output=True,text=True);assert res.returncode==0,res.stdout+res.stderr
for name in names[:-1]:assert sha(basis/name)==manifest[name]
assert not(basis/names[-1]).exists();patch=''
for name in names[1:]:
 f=basis/name;patch+=''.join(difflib.unified_diff(f.read_text().splitlines(True)if f.exists()else[],(p/'bron'/name).read_text().splitlines(True),fromfile='a/'+name if f.exists()else'/dev/null',tofile='b/'+name))
(p/'cache.patch').write_text(patch);res=subprocess.run(['patch','-p1','--fuzz=0','--batch','-i',str((p/'cache.patch').resolve())],cwd=basis,capture_output=True,text=True);assert res.returncode==0,res.stdout+res.stderr
for name in names:assert sha(basis/name)==sha(p/'bron'/name)
(p/'patch-herhaal.json').write_text(json.dumps({'geslaagd':True,'fuzz':0,'basis_nootbron_exact':True,'gecombineerde_cachepatch_sha256':sha(p/'cache.patch'),'wijziging_ten_opzichte_van_actieve_cache':sha(p/'gedeelde-spans.patch'),'bestanden':{name:sha(basis/name)for name in names}},indent=2)+'\n');print('Gecombineerde patch exact, zonder fuzz, gereproduceerd.')
