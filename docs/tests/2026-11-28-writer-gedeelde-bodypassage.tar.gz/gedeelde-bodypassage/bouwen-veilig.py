from pathlib import Path
import os,subprocess,json,time,shutil,signal,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/digest-spans';src=p/'bron';old=r/'.local/integratiecontrole/digest-productie';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();target=p/'wasm-target';assert target.exists();assert sha(p/'basis/docx_edit_bg.wasm')==json.loads((r/'patches/tekstengine-digestcache.json').read_text())['wasmSha256'];out=p/'kandidaat';out.mkdir(exist_ok=True);assert not any(out.iterdir());env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true'};tools=r/'.local/integratiecontrole/font-hergebruik/gereedschap';results=[]
commands=[('cargo',['cargo','build','-p','betteroffice-docx-edit','--lib','--features','wasm,tiff,metafile,heap-stats','--target','wasm32-unknown-unknown','--release','--locked']),('bindgen',[str(tools/'bindgen/wasm-bindgen'),'--target','web','--out-name','docx_edit','--out-dir',str(out),str(target/'wasm32-unknown-unknown/release/docx_edit.wasm')]),('opt',[str(tools/'binaryen/bin/wasm-opt'),'-O3',str(out/'docx_edit_bg.wasm'),'-o',str(out/'docx_edit_bg-opt.wasm')])]
for name,cmd in commands:
 start=time.monotonic()
 with(p/(name+'.log')).open('x')as log:
  proc=subprocess.Popen(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);(p/'actief.json').write_text(json.dumps({'fase':name,'pid':proc.pid})+'\n')
  while proc.poll()is None:
   time.sleep(1)
   if time.monotonic()-start>900 or shutil.disk_usage(p).free<10*1024**3:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=20);break
 row={'fase':name,'code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd};results.append(row);(p/'bouwen.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);assert proc.returncode==0
 if name=='bindgen':shutil.copyfile(out/'docx_edit_bg.wasm',out/'docx_edit_bg-ongeoptimaliseerd.wasm')
(out/'docx_edit_bg-opt.wasm').replace(out/'docx_edit_bg.wasm');(p/'actief.json').write_text('{"status":"klaar"}\n');print(json.dumps({'wasm_sha256':sha(out/'docx_edit_bg.wasm'),'bytes':(out/'docx_edit_bg.wasm').stat().st_size}),flush=True)
