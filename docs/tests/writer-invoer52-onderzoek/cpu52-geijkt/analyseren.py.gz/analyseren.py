from pathlib import Path
import json,gzip,hashlib,collections
u=Path(__file__).resolve().parent;r=json.loads((u/'gui/profiel.json').read_text());assert r['geslaagd']and r['broncontrole']=={'verhalen':1537,'alinea_en_celteksten':3329,'exact':True};assert not any(r['fouten_na'].values());assert r['cpu_kalibratie']['leaf_eerst']and r['cpu_kalibratie']['aantal']>0
c=json.loads((u/'gui/cpu.json').read_text());assert c['fout']is None and c['bytes']<=16*1024*1024
compleet=[m for m in c['berichten']if m['method']=='ScriptProfiler.trackingComplete'];assert len(compleet)==1
tr=compleet[0]['params']['samples']['stackTraces'];assert tr
bronnen={}
for b in r['cpu_scriptbronnen']:
 data=gzip.decompress((u/'gui'/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256'];bronnen[b['url']]=data.decode().splitlines()
def kader(f):return(f['name'],f['url'],f['line'],f['column'])
top=collections.Counter();inclusief=collections.Counter()
for s in tr:
 fs=s['stackFrames']
 if fs:top[kader(fs[0])]+=1
 inclusief.update(set(kader(f)for f in fs))
def detail(k,n):
 naam,url,lijn,kolom=k;uit={'aantal':n,'naam':naam,'url':url,'lijn':lijn,'kolom':kolom}
 if url in bronnen and lijn>0 and kolom>0:
  # WebKit-kolommen tellen UTF-16-code-eenheden, ook bij niet-BMP-tekens.
  raw=bronnen[url][lijn-1].encode('utf-16-le');start=(kolom-1)*2
  uit['bronfragment']=raw[max(0,start-120):start+360].decode('utf-16-le',errors='replace')
 return uit
uit={'schema':1,'samples':len(tr),'sampletijdstempels':sorted(set(s['timestamp']for s in tr)),'stackkalibratie':r['cpu_kalibratie'],'scriptbronnen':r['cpu_scriptbronnen'],'top':[detail(k,n)for k,n in top.most_common(25)],'inclusief':[detail(k,n)for k,n in inclusief.most_common(35)],'grens':'Gekalibreerde hoofdthreadsamples met exacte eigen scriptbytes; geen CPU-seconden/-percentage, worker-/nativeprofiel, FPS of snelheidsvergelijking.'}
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print('Monsters',len(tr),'kalibratie',r['cpu_kalibratie']['aantal'])
for item in uit['top'][:8]:print(item['aantal'],item['naam'],item.get('bronfragment','')[:240])
for naam in ['buildStory','readStories','getClientRects','paragraphSpans','getDocument']:
 print('inclusief',naam,sum(n for k,n in inclusief.items()if k[0]==naam))
