"""Neem uitsluitend ScriptProfiler-metadata van de eigen testpagina op."""
import asyncio,json,time
from gui.webkit_inspector import Inspector as Basis
class Ontvanger:
 def __init__(self,ws,eigenaar):self.ws=ws;self.e=eigenaar
 async def send(self,*args,**kwargs):return await self.ws.send(*args,**kwargs)
 async def close(self,*args,**kwargs):return await self.ws.close(*args,**kwargs)
 async def recv(self,*args,**kwargs):
  raw=await self.ws.recv(*args,**kwargs)
  try:
   b=json.loads(raw)
   if b.get('method')=='Target.dispatchMessageFromTarget' and b['params'].get('targetId')==self.e.target:
    m=json.loads(b['params']['message'])
    if m.get('method','').startswith('ScriptProfiler.'):
     n=len(b['params']['message']);self.e.cpu_bytes+=n
     if self.e.cpu_bytes>16*1024*1024:self.e.cpu_fout='CPU-opname overschrijdt 16 MiB'
     else:self.e.cpu.append(m)
  except Exception as fout:self.e.cpu_fout=repr(fout)
  return raw
class Inspector(Basis):
 async def begin_cpu(self):
  self.cpu=[];self.cpu_bytes=0;self.cpu_fout=None;self.ws=Ontvanger(self.ws,self)
  r=await self.command('ScriptProfiler.startTracking',{'includeSamples':True})
  if r.get('error'):raise RuntimeError(r)
 async def eind_cpu(self):
  r=await self.command('ScriptProfiler.stopTracking')
  if r.get('error'):raise RuntimeError(r)
  eind=time.monotonic()+10
  while not any(m['method']=='ScriptProfiler.trackingComplete'for m in self.cpu):
   if time.monotonic()>eind:raise RuntimeError('Geen volledige CPU-opname')
   await self.ev('true');await asyncio.sleep(.02)
  if self.cpu_fout:raise RuntimeError(self.cpu_fout)
  self.ws=self.ws.ws
  return {'schema':1,'bytes':self.cpu_bytes,'fout':self.cpu_fout,'berichten':self.cpu,'grens':'Alleen eigen hoofdthread; geen profiel van native Rust of documentworker. Instrumentatie beïnvloedt de uitvoering.'}
