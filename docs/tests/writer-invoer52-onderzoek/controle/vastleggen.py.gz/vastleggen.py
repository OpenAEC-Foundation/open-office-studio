from pathlib import Path
import gzip,hashlib,json,shutil
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/ci52-afgesloten';out=r/'docs/tests/writer-invoer52-onderzoek';out.mkdir(exist_ok=False);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def lees(p):return json.loads(p.read_text())
def bewaar(p,naam):
 q=out/str(naam);q.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.gz':shutil.copyfile(p,q)
 else:q=q.with_name(q.name+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for f in sorted(u.iterdir()):
 if f.is_file()and f.suffix in ['.json','.py','.mjs','.log']:bewaar(f,'controle/'+f.name)
for f in sorted((u/'geheugen').rglob('*')):
 if f.is_file()and f.suffix in ['.json','.log','.png']:bewaar(f,'ci-geheugen/'+str(f.relative_to(u/'geheugen')))
for map in ['wachtrij52','guireplay52','cpu52','cpu52-ingebouwd','cpu52-geijkt']:
 root=r/'.local/doorwerk-2026-11-06'/map
 for f in sorted(root.rglob('*')):
  if f.is_file()and f.suffix in ['.json','.log','.png','.py','.mjs','.gz']:
   naam=str(f.relative_to(root))
   if map=='cpu52'and naam=='analyse.json':naam='analyse-ONGEIJKTE-BLADKEUZE.json'
   bewaar(f,map+'/'+naam)
q=lees(r/'.local/doorwerk-2026-11-06/wachtrij52/analyse.json');rep=lees(r/'.local/doorwerk-2026-11-06/guireplay52/herhaling/rapport.json');cpu=lees(r/'.local/doorwerk-2026-11-06/cpu52-geijkt/analyse.json');assert rep['geslaagd'];assert cpu['stackkalibratie']['leaf_eerst'];assert q['broncontrole']['exact']
ed=lees(u/'edities.json');mem=lees(u/'geheugen.json');assert ed['conclusion']==mem['conclusion']=='success'
ci={}
for naam in ['normaal','herhalen','spelling','bewaren']:
 d=lees(u/'geheugen'/naam/'rapport.json');assert d['geslaagd'];ci[naam]={'geslaagd':True,'programma_sha256':d['programma_sha256']}
 if 'native_leesaanroepen'in d:
  a=d['native_leesaanroepen'];assert a['layoutDocumentWithRegionsRetainedJson']['calls']==a['layoutFontRequirementsJson']['calls']==0;ci[naam]['native_leesaanroepen']=a
 if 'vervolginvoer'in d:
  v=d['vervolginvoer'];assert v['bron_exact']and v['structuur_exact']and v['onderbreekbaar'];ci[naam]['vervolginvoer']=v
ra=sum(x['native_ns']for x in rep['ronden']if x['naam'].startswith('cache'))/sum(x['native_ns']for x in rep['ronden']if x['naam'].startswith('referentie'))
d={'schema':1,'datum':'2026-11-06','appversie':'2026.45.52','productiecode_gewijzigd':False}
d['afgesloten_ci']={'edities':{'run':42222572441,'bron':ed['headSha'],'conclusie':'success','taken':[{'naam':j['name'],'conclusie':j['conclusion']}for j in ed['jobs']],'geheugen':{'run':42230626693,'bron':mem['headSha'],'conclusie':'success','artifact':13510881613,'proeven':ci},'grens':'Zeven edities gebouwd op drie platforms; geen volledige functiedekking. Publiceren overgeslagen. Eerdere afkeuringen blijven oorzaak-open.'}
d['wachtrijmeting']=q
d['kernherhaling']={'groepen':rep['groepen'],'bronbytes':rep['bronbytes'],'ronden':rep['ronden'],'cache_referentie_wandtijdratio':ra,'besluit':'Alle twintig werkelijke aanvragen/antwoorden, 1.537 verhalen/3.329 teksten, opmaak/identiteiten/selectie, Undo/Redo, veertien DOCX-onderdelen en heropende teksten exact. Circa 21,5% minder geïsoleerde kernwandtijd; geen desktopwinst. De eerder afgekeurde cache wordt niet gepromoveerd.'}
d['cpu_onderzoek']={'samples':cpu['samples'],'tijdstempels':cpu['sampletijdstempels'],'kalibratie':cpu['stackkalibratie'],'monsters_per_familie':cpu['monsters_per_familie'],'getDocument_aanroepers':cpu['getDocument_aanroepers'],'scriptbronnen':cpu['scriptbronnen'],'bevinding':'Alle 426 samples met getDocument hebben als aanroeper de geregistreerde opslagcallback in editors-dj6Nk6Hy.js, regel 72 kolom 189256. De exacte eigen bundlebytes tonen de getDocument-gereedheidscontrole vóór de opslagvergrendeling. Dit is een onnodige volledige documentprojectie als alleen gereedheid nodig is. Andere bronprojecties (onder meer buildStory) blijven afzonderlijke kosten.','grens':'Samples zijn geen CPU-seconden of -percentage. Alle tijdstempels zijn nul; geen fase-/FPS-/worker- of native-CPU-attributie. Stackrichting op de werkelijke runtime geijkt: 90 geneste voorbeelden, bovenste actieve frame eerst; bronkolommen als UTF-16 geïnterpreteerd.','protocolbron':'https://raw.githubusercontent.com/WebKit/WebKit/main/Source/JavaScriptCore/inspector/protocol/ScriptProfiler.json'}
d['afkeuringen']=['Eerste losse CPU-analyse koos het laatste frame zonder ijking als blad; als ONGEIJKTE-BLADKEUZE behouden en niet als bevinding gebruikt. Gekalibreerde analyse gebruikt het eerste frame.','De oorspronkelijke passieve rasterhelper weigert profileringsmodus expliciet. Die poging strandt op de bestaande guard; eigen verzender/app worden gestopt. Guard en canonieke helper zijn niet gewijzigd.','Afzonderlijke CPU-afgeleide gebruikt dezelfde rastervoorwaarde uitsluitend als begrensd einde van invoer, zonder snelheidsacceptatie. Haar legacy profiel_actief=false-vlag betreft de ingebouwde profiler; eigen ScriptProfiler-data staan apart in cpu.json/cpu-kalibratie.json.']
d['grenzen']=['Geen nieuwe apppatch, installatie, versie, officiële release of issue-/migratieafsluiting.','Oude leenfout/lege venster, zwarte rechthoek, incidentele sluitfout en eerdere workertraps blijven open.','Geen cachewinst in de desktop, algemene snelheids-/FPS- of volledige UI-pariteitsclaim.','Resterende wachtrij- en verfwandtijden zijn geïnstrumenteerd en gebruiken deels verschillende klokken; geen rechtstreekse vergelijking met eerdere passieve ABBA.']
d['volgende_stap']='Toets de apart voorbereide 45.53-kandidaat die alleen de geregistreerde Writer-opslaggereedheidscontrole vervangt door een sessiecheck. Productiebranch blijft 45.52 totdat bouw, onafhankelijke bewaring/heropening, GUI- en passende referentie-/beeldproeven aantoonbaar slagen. Onderzoek daarnaast de resterende story-/positiemapprojecties; zet de eerder afgekeurde encodercache niet op basis van alleen kernwinst terug aan.'
d['bestanden']={str(f.relative_to(r)):h(f)for f in sorted(out.rglob('*'))if f.is_file()}
(r/'docs/tests/2026-11-06-writer-invoer52-onderzoek.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('Voltooid onderzoeksbewijs',len(d['bestanden']))
