from pathlib import Path
import json,hashlib,re
r=Path.cwd();p=r/'.local/integratiecontrole/projectie-uitvoering';base=r/'.local/integratiecontrole/warm-layout-request/dist/assets';sites=[
('factory','index-DtZ2IWH9.js','function iY(e,t,n){','return e.hasStory(t)',"({reader:P.id(e),root:t,source:P.id(n),sourceSession:P.id(n?.session)})"),
('construct','index-DtZ2IWH9.js','sY=class{constructor(t,n,r){','Xe(this,',"({reader:P.id(t),root:n,source:P.id(r),sourceSession:P.id(r?.session)})"),
('geometry','index-DtZ2IWH9.js','function fY(e,t,n="body"){','let r=new Map',"({reader:P.id(e),version:t,root:n,outlineSupported:typeof e.positionOutline==='function'})"),
('editor-cache','editors-bODdYQ4o.js','let ce=Ot.current;if(ce?.version===Mt.current','if(ce?.version===Mt.current',"({cacheRef:P.id(Ot),session:P.id(z),root:oe,projectionVersion:Mt.current,replicaReady:r.replicaReadyRef?.current??r.replicaReady,cacheVersion:ce?.version??null,cacheRoot:ce?.rootStory??null,cacheSession:P.id(ce?.session),hit:ce?.version===Mt.current&&ce.session===z&&ce.rootStory===oe})"),
('invalidate-direct','editors-bODdYQ4o.js','An=u.useCallback(oe=>{r.publishDirectInput(oe),Mt.current+=1}','Mt.current+=1',"({cacheRef:P.id(Ot),session:P.id(r.session),projectionVersion:Mt.current,stories:oe??null})"),
('invalidate-layout','editors-bODdYQ4o.js','Pr=u.useCallback((oe,z)=>{Mt.current+=1','Mt.current+=1',"({cacheRef:P.id(Ot),session:P.id(r.session),projectionVersion:Mt.current,origin:oe,inWorker:z??null})")]
config=[];pins={}
for tag,name,anchor,start,data in sites:
 f=base/name;s=f.read_text();pins[name]=hashlib.sha256(f.read_bytes()).hexdigest();assert s.count(anchor)==1,(tag,s.count(anchor));offset=s.index(start,s.index(anchor));assert offset-s.index(anchor)<180;prefix=s[:offset];line=prefix.count('\n');last=prefix.rfind('\n');column=len(prefix[last+1:].encode('utf-16-le'))//2;action='try{let P=window._officeProjectionProbe;P.note('+json.dumps(tag)+','+data+')}catch{window._officeProjectionProbe.error()}';config.append({'tag':tag,'anchor':anchor,'lineNumber':line,'columnNumber':column,'urlRegex':re.escape(name),'options':{'autoContinue':True,'actions':[{'type':'evaluate','data':action}]}})
config=[x for x in config if x['tag'] in ['factory','construct','geometry']]
(p/'punten.json').write_text(json.dumps({'bronpinnen':pins,'punten':config},indent=2)+'\n')
s=(r/'.local/integratiecontrole/warm-layout-request/native-proef.py').read_text();anchor="                r['profiel_begin'] = await p.command('ScriptProfiler.startTracking', {'includeSamples': True})";assert s.count(anchor)==1
start='''                r['projectie_start'] = await p.ev((REPO / '.local/integratiecontrole/projectie-uitvoering/collector.js').read_text())
                enabled = await p.command('Debugger.enable')
                assert not enabled.get('error'), enabled
                enabled = await p.command('Debugger.setBreakpointsActive', {'active': True})
                assert not enabled.get('error'), enabled
                r['projectie_punten'] = []
                for punt in json.loads((REPO / '.local/integratiecontrole/projectie-uitvoering/punten.json').read_text())['punten']:
                    params = {k:v for k,v in punt.items() if k not in ['tag','anchor']}
                    antwoord = await p.command('Debugger.setBreakpointByUrl', params)
                    assert not antwoord.get('error'), antwoord
                    r['projectie_punten'].append({'punt':punt,'antwoord':antwoord})
''';s=s.replace(anchor,start+anchor)
anchor="                r['profiel_eind_klok'] = await p.ev('performance.now()')";assert s.count(anchor)==1
end='''                r['projectie_verwijderd'] = []
                for punt in r['projectie_punten']:
                    antwoord = await p.command('Debugger.removeBreakpoint', {'breakpointId':punt['antwoord']['result']['breakpointId']})
                    assert not antwoord.get('error'), antwoord
                    r['projectie_verwijderd'].append(antwoord)
                antwoord = await p.command('Debugger.disable')
                assert not antwoord.get('error'), antwoord
                r['projectie_eind'] = await p.ev('_officeProjectionProbe.stop()')
''';s=s.replace(anchor,end+anchor);(p/'native-proef.py').write_text(s)
