from pathlib import Path
import json,hashlib,ast,subprocess,gzip
from zipfile import ZipFile
from xml.etree import ElementTree as ET
r=Path.cwd();p=r/'.local/integratiecontrole/projectie-uitvoering';old=r/'.local/integratiecontrole/warm-layout-request';read=lambda n:json.loads(n.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();a=read(p/'analyse.json');n=read(p/'native-zonder-debugger/rapport.json');assert n['geslaagd']and all(not x for x in n['fouten'].values());assert len(a['constructies_per_bronversie'])==70 and all(x['aantal']==2 for x in a['constructies_per_bronversie']);assert a['tellingen']['construct']==140 and a['editor_cache']['hits']==82438 and a['editor_cache']['misses']==140;assert n['projectie_eind']['overflow']==0 and n['projectie_eind']['errors']==0;assert read(p/'collector-proef.json')['geslaagd'];assert read(p/'native-loggrens/rapport.json')['geslaagd']
refs=read(old/'referenties-nacontrole.json');assert len(refs)==23
for f,h in refs.items():assert sha(Path(f))==h
new=p/'open-office-studio-projectie-telling';assert sha(new)==read(p/'desktop.json')['programma_sha256']==n['programma_sha256'];refs[str(new)]=sha(new);(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
expected=read(old/'standaardbundel.json');actual={str(f.relative_to(r/'dist')):{'sha256':sha(f),'mode':f.stat().st_mode&0o777,'mtime_ns':f.stat().st_mtime_ns}for f in(r/'dist').rglob('*')if f.is_file()};assert actual==expected and len(actual)==529
pins=read(old/'behoud.json')['sdk_vendor_npm_exact'];source=read(old/'bron-hersteld.json')['bestanden']
for f,h in dict(pins,**source).items():assert sha(r/f)==h
assert n['runtime_wasm']['sha256']==read(p/'bundel.json')['wasm_ongewijzigd']=='5a705ce9e4f29b29619868049f29bb93a045887257e7a547464a9d636c09f00d'
for item in n['scriptbronnen']:
 raw=gzip.decompress((p/'native-zonder-debugger'/item['bestand']).read_bytes());assert hashlib.sha256(raw).hexdigest()==item['sha256']
 for change in read(p/'bundel.json')['wijzigingen']:
  if item['url'].endswith('/'+change['bestand']):assert item['sha256']==change['na_sha256']
scripts=[];node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
for f in p.glob('*.py'):ast.parse(f.read_text());scripts.append({'pad':f.name,'controle':'Python AST','code':0})
for f in list(p.glob('*.mjs'))+list(p.glob('*.js')):
 z=subprocess.run([node,'--check',str(f)],capture_output=True);assert z.returncode==0,(f,z.stderr);scripts.append({'pad':f.name,'controle':'node --check','code':0})
documents=[]
for folder in ['native-loggrens','native-zonder-debugger']:
 rr=read(p/folder/'rapport.json');f=p/folder/'Ontwerpnotitie.docx';assert sha(f)==rr['bewaring_sha256'];parts={}
 with ZipFile(f)as z:
  assert z.testzip()is None
  for name in z.namelist():
   b=z.read(name)
   if name.endswith(('.xml','.rels')):ET.fromstring(b)
   parts[name]=hashlib.sha256(b).hexdigest()
  root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(x.text or''for x in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128 and units==91423
 with ZipFile(old/'native-functie/Ontwerpnotitie.docx')as z:previous={name:hashlib.sha256(z.read(name)).hexdigest()for name in z.namelist()}
 assert set(parts)==set(previous);diff=[name for name in parts if parts[name]!=previous[name]];assert set(diff)<={'docProps/core.xml'};documents.append({'map':folder,'sha256':sha(f),'zip_crc_xml':True,'tabellen':tables,'utf16':units,'verschil_met_vorige_ELF9c290f4e':diff})
(p/'documentcontrole.json').write_text(json.dumps(documents,indent=2)+'\n');(p/'behoud.json').write_text(json.dumps({'elf_referenties_exact':refs,'bestaande_elfs':23,'nieuwe_meet_ELF':1,'standaardbundel_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':pins,'canonieke_bron_exact':source,'scripts':scripts},indent=2)+'\n');print('BEHOUD24ELF/529/6;DOCX2x128/91423;140constructies/70bronversies')
