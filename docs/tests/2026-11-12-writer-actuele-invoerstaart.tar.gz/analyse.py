"""Controleer actuele native opname tegen eigen bronbytes en vaste runtime."""
from pathlib import Path
import collections,gzip,hashlib,json,zipfile,xml.etree.ElementTree as ET
u=Path(__file__).resolve().parent;p=u/'opname';r=json.loads((p/'rapport.json').read_text())
assert r['geslaagd'] and not any(r['fouten'].values()) and r['schema']==2
assert r['programma_sha256']=='8d67e9e495008f7dd7542082214410b0f5322c459bfcf297eccd8d31fa76f567'
assert r['bewaarde_tabellen_exact']==128 and r['stack_kalibratie']['leaf_eerst']
tekst=' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.'
prefix='';opdrachten=[]
for m in r['native_opdrachten']:
 opdrachten.append(m)
 if m.get('caret'):prefix+=m['text']
 assert tekst.startswith(prefix)
 if prefix==tekst:break
assert prefix==tekst and all(m['bronbinding'] and m['gereed'] and not m.get('vertragingMs') and not m['wacht'] for m in opdrachten)
bronnen={}
for b in r['scriptbronnen']:
 data=gzip.decompress((p/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256'];bronnen[b['url']]=data.decode()
ev=json.load(gzip.open(p/'profielen.json.gz','rt'));klaar=[e for e in ev if e.get('method')=='ScriptProfiler.trackingComplete'];assert len(klaar)==1
monsters=klaar[0]['params']['samples']['stackTraces'];assert len(monsters)==r['profiel_samples']
herkenning={'tabelgrepen':('dee','editors-EW2ZgGN5.js',48,20281,'function dee({context:'),'tabelbeelden':('iL','editors-EW2ZgGN5.js',34,11711,'function iL('),'tabel_van_cel':('wk','editors-EW2ZgGN5.js',34,7363,'function wk(')}
for titel,(fn,bestand,line,col,anker) in herkenning.items():
 bron=next(v for k,v in bronnen.items() if k.endswith('/'+bestand));assert anker in bron.split('\n')[line-1][max(0,col-80):col+180]
telling=collections.Counter()
for m in monsters:
 fs=m['stackFrames'];namen=[f['name'] for f in fs]
 for titel,(fn,bestand,line,col,_) in herkenning.items():
  if any(f['name']==fn and f.get('url','').endswith('/'+bestand) and f.get('line')==line and f.get('column')==col for f in fs):telling[titel]+=1
 for fn in ['readParagraphs','tablePayload','storySegmentUnitDigests','buildStory','wasm-stub']:
  if fn in namen:telling[fn]+=1
 if 'tablePayload' in namen and 'dee' in namen:telling['tablePayload_via_tabelgrepen']+=1
assert telling['tablePayload_via_tabelgrepen']==telling['tablePayload']==1054
with zipfile.ZipFile(p/'Ontwerpnotitie.docx') as z:
 assert z.testzip() is None
 doc=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};assert len(doc.findall('.//w:tbl',ns))==128
uit={'geslaagd':True,'programma_sha256':r['programma_sha256'],'samples':len(monsters),'profielvenster_ms':r['profiel_eind_klok']-r['profiel_begin_klok'],'invoer':r['lange_invoer'],'stacklidmaatschap':dict(telling),'scriptbronnen':r['scriptbronnen'],'gewone_native_opdrachten':len(opdrachten),'bewaarde_tabellen_exact':128,'docx_sha256':hashlib.sha256((p/'Ontwerpnotitie.docx').read_bytes()).hexdigest(),'fouten':r['fouten'],'grenzen':['Een geprofileerde ronde, geen prestatievergelijking of acceptatie.','Profiel begint na verzenden van toetsen; WebKit ontvangt nog toetsen tijdens profielvenster. Dus niet uitsluitend na laatste ontvangen keyup.','Stacklidmaatschappen overlappen en zijn geen CPU-tijdpercentages.','Renderlijst en twee rAFs bewijzen geen fysieke schermpaint.','Bewaarde DOCX onafhankelijk op ZIP-integriteit en tabelaantal gecontroleerd; geen afzonderlijke GUI-heropening.']}
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:uit[k] for k in ['geslaagd','samples','profielvenster_ms','stacklidmaatschap','gewone_native_opdrachten']},ensure_ascii=False))
