from pathlib import Path
import json,time,subprocess
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';pid=2010029;start=time.monotonic()
while Path('/proc/'+str(pid)+'/cmdline').exists():
 data=Path('/proc/'+str(pid)+'/cmdline').read_bytes()
 if b'digest-productie/pariteit.mjs'not in data:break
 assert time.monotonic()-start<600;time.sleep(1)
d=json.loads((p/'pariteit.json').read_text());assert d['geslaagd']and len(d['vergelijkingen'])==166;assert (p/'pariteit-uitvoer.log').read_text().splitlines()[-1].startswith('{"rows":166,')
rows=json.loads((p/'vervolg.json').read_text());assert len(rows)==3;rows.append({'fase':'pariteit','code':None,'resultaat_gecontroleerd':True,'bevestiging':'Eindrapport en eindregel van bestaande proef gecontroleerd. Supervisor beëindigd vóór desktopbouw om buitenste SIGKILL-timeout te verwijderen; proef zelf liep door. Proces-exitcode daarna niet meer beschikbaar.'});(p/'vervolg.json').write_text(json.dumps(rows,indent=2)+'\n');s=(p/'vervolg.py').read_text().replace("r['code']==0 for r in results", "(r['code']==0 or r.get('resultaat_gecontroleerd')) for r in results");(p/'vervolg.py').write_text(s);print('Bestaande pariteitsproef zonder herhaling gevalideerd; hervatten',flush=True);raise SystemExit(subprocess.run(['python3',str(p/'vervolg.py')],cwd=r).returncode)
