from pathlib import Path
import subprocess,hashlib,difflib,json,shutil
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';basis=p/'patch-basis';assert not basis.exists();canonical=r/'.local/integratiecontrole/font-hergebruik/bron';names=['crates/docx-edit/src/engine.rs','crates/docx-edit/src/lib.rs','crates/docx-edit/src/wasm.rs'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();manifest=json.loads((p/'bron-voor.json').read_text())
for name in names:
 f=basis/name;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(canonical/name,f)
result=subprocess.run(['patch','-p1','--reverse','--fuzz=0','--batch','-i',str((p/'verschil-proefbron.patch').resolve())],cwd=basis,capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
for name in names:assert sha(basis/name)==manifest[name]
patch=''
for name in ['crates/docx-edit/src/lib.rs','crates/docx-edit/src/wasm.rs','crates/docx-edit/src/digest_cache.rs']:
 f=basis/name;a=f.read_text().splitlines(True)if f.exists()else[];patch+=''.join(difflib.unified_diff(a,(p/'bron'/name).read_text().splitlines(True),fromfile='a/'+name if f.exists()else'/dev/null',tofile='b/'+name))
(p/'cache.patch').write_text(patch);result=subprocess.run(['patch','-p1','--fuzz=0','--batch','-i',str((p/'cache.patch').resolve())],cwd=basis,capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
for name in names+['crates/docx-edit/src/digest_cache.rs']:assert sha(basis/name)==sha(p/'bron'/name)
(p/'patch-herhaal.json').write_text(json.dumps({'geslaagd':True,'fuzz':0,'voorraad_bronfiles_exact':True,'cachepatch_sha256':sha(p/'cache.patch'),'bestanden':{name:sha(basis/name)for name in names+['crates/docx-edit/src/digest_cache.rs']},'extra_proefinstrumentatie':False},indent=2)+'\n');print('Vaste bron en schone cachepatch exact gereproduceerd, geen fuzz')
