from pathlib import Path
import json,subprocess,time
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';start=time.monotonic()
while json.loads((p/'actief.json').read_text()).get('status')!='klaar':
 assert time.monotonic()-start<240;time.sleep(1)
steps=[('contract',[node,str(p/'contract.mjs')]),('randen',[node,str(p/'randen.mjs')]),('callback',[node,str(p/'callback.mjs')]),('pariteit',[node,str(p/'pariteit.mjs')]),('desktop-bouw',['python3',str(p/'bouwen-desktop.py')]),('wasm-meting',[node,str(p/'meten.mjs')]),('native-ABBA',['python3',str(p/'native-ronden.py')]),('documenten-beelden',['/usr/bin/python3',str(p/'documenten-beelden.py')])]
results=json.loads((p/'vervolg.json').read_text())if(p/'vervolg.json').exists()else[]
for name,cmd in steps:
 if any(r['fase']==name and (r['code']==0 or r.get('resultaat_gecontroleerd')) for r in results):continue
 print('START',name,flush=True);(p/'vervolg-actief.json').write_text(json.dumps({'fase':name})+'\n');start=time.monotonic()
 with(p/(name+'-uitvoer.log')).open('w')as log:result=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=None if name=="desktop-bouw" else 1200)
 item={'fase':name,'code':result.returncode,'seconden':time.monotonic()-start,'opdracht':cmd};results.append(item);(p/'vervolg.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(item),flush=True);assert result.returncode==0,name
(p/'vervolg-actief.json').write_text('{"status":"klaar"}\n')
