from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,signal,stat,fcntl
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in()).throw(KeyboardInterrupt()))
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();lock=(p/'desktop-bouwslot').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert subprocess.check_output(['git','status','--porcelain'])==b''
refs=json.loads((r/'.local/integratiecontrole/digest-kern/referenties-nacontrole.json').read_text());assert len(refs)==40
bundle=json.loads((r/'.local/integratiecontrole/projectie-context-telling-herbouw/standaardbundel.json').read_text())
def check():
 for f,h in refs.items():assert sha(Path(f))==h
 for f,v in bundle.items():
  q=r/'dist'/f;assert sha(q)==v['sha256'] and stat.S_IMODE(q.stat().st_mode)==v['mode'] and q.stat().st_mtime_ns==v['mtime_ns']
check();target=p/'native-target';assert not target.exists();shutil.copytree(r/'.local/integratiecontrole/font-rij-native/target',target);results=[]
for mode in ['basis','kandidaat']:
 dist=p/('dist-'+mode);shutil.copytree(r/'.local/integratiecontrole/projectie-context/dist',dist)
 wasm=dist/'assets/docx_edit_bg-ONvZFP_n.wasm';assert sha(wasm)=='737ee8c99492796e91a8775c35bb2cf3ef008857219f88f57b64c69a7744f9d9';shutil.copyfile(p/mode/'docx_edit_bg.wasm',wasm)
 initial=r/'.local/integratiecontrole/projectie-context/dist';files={str(f.relative_to(initial)):sha(f)for f in initial.rglob('*')if f.is_file()};changed=[str(f.relative_to(dist))for f in dist.rglob('*')if f.is_file()and sha(f)!=files[str(f.relative_to(dist))]];assert changed==([] if mode=='basis' else ['assets/docx_edit_bg-ONvZFP_n.wasm'])
 assert not(p/'standaarddist').exists();(r/'dist').rename(p/'standaarddist');dist.rename(r/'dist');start=time.monotonic();proc=None;result={}
 try:
  cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];env={**os.environ,'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']}
  with(p/('desktop-'+mode+'.log')).open('x')as log:
   proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);(p/'desktop-actief.json').write_text(json.dumps({'pid':proc.pid,'fase':mode,'standaarddist':str(p/'standaarddist')})+'\n')
   while proc.poll()is None:
    time.sleep(1)
    if time.monotonic()-start>1500 or shutil.disk_usage(p).free<10*1024**3:
     os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=20);break
  result={'variant':mode,'code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':cmd,'gewijzigde_assets':changed}
  assert proc.returncode==0
  out=p/('open-office-studio-digest-'+mode);shutil.copy2(target/'release/open-office-studio',out);result.update(programma=str(out),sha256=sha(out))
 finally:
  if proc is not None and proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=20)
  (r/'dist').rename(dist);(p/'standaarddist').rename(r/'dist');check();results.append(result);(p/'desktop.json').write_text(json.dumps(results,indent=2)+'\n');(p/'desktop-actief.json').write_text('{"standaarddist_hersteld":true}\n')
print(json.dumps(results))
