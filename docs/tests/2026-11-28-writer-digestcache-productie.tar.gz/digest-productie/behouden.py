from pathlib import Path
import json,hashlib,stat
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
refs=json.loads((r/'.local/integratiecontrole/digest-kern/referenties-nacontrole.json').read_text())
assert len(refs)==40
for v in json.loads((p/'desktop.json').read_text()):refs[v['programma']]=v['sha256']
assert len(refs)==42
for f,h in refs.items():assert sha(Path(f))==h,f
(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
pins=json.loads((r/'.local/integratiecontrole/projectie-context-telling-herbouw/behoud.json').read_text())['sdk_vendor_canonieke_bron_exact']
for f,h in pins.items():assert sha(r/f)==h,f
bundle=json.loads((r/'.local/integratiecontrole/projectie-context-telling-herbouw/standaardbundel.json').read_text())
for f,v in bundle.items():
 q=r/'dist'/f; s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],f
before=json.loads((p/'bron-voor.json').read_text()); changed=[]
for f,h in before.items():
 if sha(p/'bron'/f)!=h:changed.append(f)
assert sorted(changed)==['crates/docx-edit/src/lib.rs','crates/docx-edit/src/wasm.rs']
extra=[str(f.relative_to(p/'bron'))for f in (p/'bron').rglob('*')if f.is_file()and str(f.relative_to(p/'bron'))not in before and not any(v.startswith('target') for v in f.relative_to(p/'bron').parts)]
assert extra==['crates/docx-edit/src/digest_cache.rs'],extra
out={'referentiepaden42_exact':True,'bronpinnen15_exact':len(pins)==15,'standaarddist529_byte_mode_mtime_exact':len(bundle)==529,'kernbron':{'gewijzigd':changed,'nieuw':extra},'sdk_vendor_canonieke_bron_exact':pins,'visueel_bekeken':['native-b-een/snel-getypt-bewaard.png','native-a-twee/nieuw-na-laat-antwoord.png','native-a-een/nieuw-na-laat-antwoord.png'],'visuele_bevinding':'Bewaarbeeld en beide nieuw-documentbeelden bekeken; de 36 verschillende pixels zijn de knipperende caret. Geen brede visuele acceptatie.'}
(p/'behoud.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n'); print(json.dumps({k:v for k,v in out.items()if k!='sdk_vendor_canonieke_bron_exact'},ensure_ascii=False))
