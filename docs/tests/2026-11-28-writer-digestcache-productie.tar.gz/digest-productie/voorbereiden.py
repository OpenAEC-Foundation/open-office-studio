from pathlib import Path
import json,hashlib,tarfile,subprocess,difflib
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';meta=json.loads((r/'patches/tekstengine-nootnummering.json').read_text());archive=r/'.local/integratiecontrole/font-hergebruik/bron.tar.gz';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert sha(archive)==meta['bronarchiefSha256'];dst=p/'bron';assert not dst.exists();dst.mkdir()
with tarfile.open(archive)as tar:
 for m in tar:
  parts=Path(m.name).parts
  if len(parts)<2:continue
  rel=Path(*parts[1:]);assert not rel.is_absolute()and'..'not in rel.parts
  if m.isdir():(dst/rel).mkdir(parents=True,exist_ok=True)
  elif m.isfile():
   f=dst/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(tar.extractfile(m).read())
patch=r/'patches'/meta['patch'];assert sha(patch)==meta['patchSha256'];result=subprocess.run(['patch','-p1','--fuzz=0','--batch','-i',str(patch)],cwd=dst,capture_output=True,text=True);(p/'nootpatch.log').write_text(result.stdout+result.stderr);assert result.returncode==0
before={str(f.relative_to(dst)):sha(f)for f in dst.rglob('*')if f.is_file()};(p/'bron-voor.json').write_text(json.dumps(before,indent=2)+'\n')
old=r/'.local/integratiecontrole/font-hergebruik/bron';changes=[];diff=''
for f in sorted((dst/'crates').rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(dst);other=old/rel
 if not other.exists()or sha(f)!=sha(other):
  changes.append(str(rel))
  if f.suffix=='.rs'and other.exists():diff+=''.join(difflib.unified_diff(f.read_text().splitlines(True),other.read_text().splitlines(True),fromfile='vast/'+str(rel),tofile='proef/'+str(rel)))
new=[str(f.relative_to(old))for f in (old/'crates').rglob('*')if f.is_file()and not(dst/f.relative_to(old)).exists()];(p/'verschil-proefbron.patch').write_text(diff);(p/'bronvergelijking.json').write_text(json.dumps({'bronarchief':sha(archive),'nootpatch':sha(patch),'gewijzigd_in_proefbron':changes,'extra_in_proefbron':new,'vaste_bronbestanden':len(before),'Cargo_lock_gelijk':sha(dst/'Cargo.lock')==sha(old/'Cargo.lock')},indent=2)+'\n');print((p/'bronvergelijking.json').read_text())
