from pathlib import Path
import json,hashlib,statistics,tarfile,gzip,io
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';out=r/'docs/tests/2026-11-28-writer-digestcache-productie.json';archive=out.with_suffix('.tar.gz')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda f:json.loads((p/f).read_text())
assert read('cli-volledig.json')['code']==0
cache=json.loads((r/'patches/tekstengine-digestcache.json').read_text())
assert sha(p/'cli-volledig-uit/docx_edit_bg.wasm')==cache['wasmSha256']
assert sha(p/'cli-volledig-uit/docx_layout_bg.wasm')==sha(r/'vendor/tekstengine/docx_layout_bg.wasm')
before=read('bron-voor.json');candidate={f:sha(p/'bron'/f)for f in before};candidate['crates/docx-edit/src/digest_cache.rs']=sha(p/'bron/crates/docx-edit/src/digest_cache.rs')
for f,h in candidate.items():assert sha(p/'cli-volledig-bron'/f)==h,f
(p/'cli-broncontrole.json').write_text(json.dumps({'bronbestanden_exact':len(candidate),'edit_sha256':sha(p/'cli-volledig-uit/docx_edit_bg.wasm'),'layout_sha256':sha(p/'cli-volledig-uit/docx_layout_bg.wasm'),'procescode':0},indent=2)+'\n')
rows=read('metingen.json')['metingen'];wasm=[]
for frame in sorted({x['frame']for x in rows}):
 a=statistics.median(x['ms']for x in rows if x['frame']==frame and x['mode']=='A');b=statistics.median(x['ms']for x in rows if x['frame']==frame and x['mode']=='B');wasm.append({'frame':frame,'A_ms':a,'B_ms':b,'B_A':b/a})
rounds=read('native-ronden.json');a=[x['invoer']['wall_begin_tot_frame_ms']for x in rounds if x['variant']=='basis'];b=[x['invoer']['wall_begin_tot_frame_ms']for x in rounds if x['variant']=='kandidaat']
assert all(x['geslaagd'] and x['code']==0 for x in rounds)
assert '231 passed | 1 skipped' in (p/'office-tests.log').read_text() and '2388 passed | 4 skipped' in (p/'office-tests.log').read_text()
assert (p/'typecheck.log').read_text()==''
(p/'suite-uitkomst.json').write_text(json.dumps({'office':{'procescode':0,'bestanden_geslaagd':231,'bestanden_overgeslagen':1,'tests_geslaagd':2388,'tests_overgeslagen':4,'kandidaat_via':'OOS_NOOT_WASM','opdracht':'node node_modules/vitest/vitest.mjs run --maxWorkers=2'},'typescript':{'procescode':0,'opdracht':'node node_modules/typescript/bin/tsc --noEmit'},'py_compile':{'procescode':0,'bestand':'scripts/bouw-tekstkern.py'},'grens':'Geen CI, volledige SDK-testset, installer of andere platformvariant.'},indent=2)+'\n')
files=[f for f in p.iterdir()if f.is_file()and f.suffix in ['.json','.py','.mjs','.js','.rs','.patch','.log']]
for folder in ['native-a-een','native-b-een','native-b-twee','native-a-twee','route-een','route-basis']:
 files.extend(f for f in (p/folder).rglob('*')if f.is_file()and f.suffix in ['.json','.png','.docx','.js','.log'])
files.extend((p/'cli-volledig-uit/bouw.json',))
manifest={str(f.relative_to(p)):sha(f)for f in sorted(set(files))}
# Alleen bewijs en recept; grote uitvoerbare referenties blijven lokaal vastgepind.
with archive.open('wb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for f in sorted(set(files)):
    info=tar.gettarinfo(str(f),arcname='digest-productie/'+str(f.relative_to(p)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with f.open('rb')as stream:tar.addfile(info,stream)
   data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('digest-productie/MANIFEST.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
report={'datum':'2026-11-28','basis_integratie':'a0fa5d1c','basis_hoofdbranch':'63ed5f2a','besluit':'Schone cachepatch en optioneel bouwpad getest en vastgelegd; standaardproductkern blijft 737ee8c. Writer-vertraging niet opgelost en geen issue gesloten.',
'wijziging':'Nieuwe drie-bestandenpatch zonder oude meetinstrumentatie, begrensde bodydigestcache rond echte apply_local_update; alleen bewezen enkele tekstinvoeging promoveert. Alle units worden bij dirty lezing nog gematerialiseerd; onzekere mutaties vallen volledig terug. Geen Arc-/unitpointercache over epochs. Optionele --digestcache, --alleen-voorbereiden en strikte bron-/patch-/uitvoerchecksumcontroles in bestaand bouwscript.',
'bron':read('bronvergelijking.json'),'exacte_voorraadherbouw':read('voorraad-reproductie.json'),'bouwrecept':read('recept-test.json'),'volledige_optiebuild':read('cli-volledig.json'),'cli_broncontrole':read('cli-broncontrole.json'),'metadata':cache,
'wasm':{'pariteit_toestanden':166,'storyvergelijkingen':127660,'digestvergelijkingen':276398,'cases':31,'bron_en_vectoren_per_leesstap_exact':True,'grens':'7 historische orakeltoestanden zonder lokale Undo verschillen in bronhistorie van de lokale Undo-proef; geen cacheafwijking, zie afzonderlijk Undo-bronbewijs. Baseline/kandidaat en echte voorraad sluiten aan op de bestaande pariteitrapporten. Geen brede reentrantie tijdens actieve Yrs-transactie getest.','randen':read('randen.json'),'callback':read('callback.json'),'component_ABBA_96_metingen':wasm},
'native':{'bouw':read('desktop.json'),'volgorde':'ABBA','A_ms':a,'B_ms':b,'A_mediaan_ms':statistics.median(a),'B_mediaan_ms':statistics.median(b),'verschil_ms':statistics.median(b)-statistics.median(a),'verschil_procent':100*(statistics.median(b)/statistics.median(a)-1),'grens':'Eén groep met twee per variant; bereiken overlappen. Geen algemene snelheidsclaim. XTest tot renderlijst plus twee rAFs, geen fysieke schermpaint. Zelfde bestaande private projectie-contextfrontend als ee89, niet een nieuwe standaardfrontend-/releaseacceptatie. Linux x86_64 release, writer-bronjournaal/schema2; andere edities/schema3/platforms niet getoetst.','gerichte_route':{'A':read('route-basis-analyse.json'),'B':read('route-analyse.json'),'grens':'Extra diagnostische rondes, niet poolen met gewone ABBA. Vensters omvatten JS/Wasm/serialisatie, geen exclusieve Rust-CPU of gemeten promotietelling.'}},
'documenten_en_beelden':read('documenten-beelden.json'),'behoud':read('behoud.json'),'suites':read('suite-uitkomst.json'),
'correcties':['Pariteitsproces na gecontroleerd stoppen supervisor zelfstandig voltooid; exitcode niet beschikbaar, finale JSON plus alle 166 eindresultaten en terminalmarker gecontroleerd (vervolg.json).','Eerste behoudhelper nam target-wasm ten onrechte mee als bron; filter gecorrigeerd, uiteindelijke broncontrole groen.'],
'niet_gecontroleerd':['Geen productactivatie of volledige productiefrontend/native heracceptatie.','Geen complete SDK-suite, CI, Windows/macOS, installers, andere edities/releases of schema3.','Geen volledige document-/glyph-/platformvisualisatie of volledige Writer-functiedekking.'],
'vervolg':'Integreer kandidaat eerst in een eigen actuele standaardfrontend/native proef met dezelfde bron- en verliesloosheidscontracten. Blijf totale invoer-/selectievertraging onderzoeken; paragraphSpans-body is nog circa 480 ms in de gerichte route. Geen Databasewerk vóór de hogere prioriteiten.',
'archief':{'pad':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'bestanden':len(manifest),'inhoud':'Scripts, bronpatch, schone kernbestanden, manifests, logs, 4 native rapporten/documenten/beelden, 2 diagnostische routerapporten en CLI-bouwbewijzen; geen grote ELF-/Wasm-/targetkopieën.','afhankelijkheden':'Vastgepind bronarchief en gereedschap uit bestaand nootbouwrecept; eerdere digestfasen/orakels en native helpers uit voorgaande bewijsarchieven. Lokale absolute paden zijn provenance, geen draagbare uitvoeropdrachten.'}}
out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'bewijs':str(out),'archief_sha256':sha(archive),'bestanden':len(manifest),'bytes':archive.stat().st_size}))
