from pathlib import Path
import re,subprocess,json,shutil
r=Path.cwd();p=r/'.local/integratiecontrole/digest-productie';src=p/'bron';old=r/'.local/integratiecontrole/digest-kern';s=(old/'digest_cache.rs').read_text()
for n in ['promotions','full','hits']:s=re.sub(r'    pub '+n+r': usize,\n','',s);s=re.sub(r'            '+n+r': 0,\n','',s)
s=s.replace('    pub rejected: Vec<Vec<String>>,\n','').replace('            rejected: Vec::new(),\n','').replace('                self.hits += 1;\n','').replace('        let mut promoted = false;\n','').replace('                    promoted = true;\n','')
s=s.replace('''        if promoted {
            self.promotions += 1
        } else {
            self.full += 1
        }
''','')
s=s.replace('''            if self.rejected.len() < 4096 {
                self.rejected
                    .push(state.reasons.iter().map(|x| x.to_string()).collect());
            }
''','')
start=s.index('            txn.get_map("stories").map(');end=s.index('\n        };',start)
s=s[:start]+'''            txn.get_map("stories").map(|map| {
                map.observe_deep(move |txn, events| {
                    let mut state = recorded.lock().unwrap();
                    for event in events.iter() {
                        let Event::Text(event) = event else {
                            state.reasons.insert("non_text");
                            continue;
                        };
                        state.events = state.events.saturating_add(1);
                        let path = event.path();
                        if path.len() != 1 || !matches!(path.front(), Some(PathSegment::Key(key)) if key.as_ref() == "body") {
                            state.reasons.insert("other_story");
                        }
                        let mut index = 0u32;
                        for delta in event.delta(txn) {
                            match delta {
                                Delta::Retain(len, attrs) => {
                                    if attrs.is_some() { state.reasons.insert("format"); }
                                    index = index.saturating_add(*len);
                                }
                                Delta::Deleted(_) => { state.reasons.insert("delete"); }
                                Delta::Inserted(Out::Any(Any::String(text)), attrs) => {
                                    state.inserts = state.inserts.saturating_add(1);
                                    let len = text.encode_utf16().count();
                                    if len == 0 || len > 4096 || text.chars().any(|c| matches!(c, '\\r' | '\\n')) {
                                        state.reasons.insert("text_boundary");
                                    }
                                    if state.inserts == 1 { state.start = Some(index); state.len = len as u32; }
                                    if let Some(attrs) = attrs {
                                        if attrs.len() > 32 || attrs.keys().any(|key| key.len() > 128 || matches!(key.as_ref(), "ins" | "del" | "rPrIns" | "rPrDel" | "moveFrom" | "moveTo")) {
                                            state.reasons.insert("attributes");
                                        }
                                    }
                                    index = index.saturating_add(len as u32);
                                }
                                Delta::Inserted(_, _) => { state.reasons.insert("embed"); }
                            }
                        }
                    }
                })
            })'''+s[end:]
assert not any(x in s for x in ['self.promotions','self.full','self.hits','self.rejected','promoted']);(p/'digest_cache.rs').write_text(s);subprocess.run(['/home/aia01/.cargo/bin/rustfmt','--edition','2024',str(p/'digest_cache.rs')],check=True)
base=(src/'crates/docx-edit/src/wasm.rs').read_text();oldbase=(old/'bron/crates/docx-edit/src/wasm.rs').read_text();needle='    last_apply_profile_json: RefCell<String>,';assert base.count(needle)==1;base=base.replace(needle,needle+'\n    unit_digest_cache: RefCell<crate::digest_cache::Cache>,');needle='            last_apply_profile_json: RefCell::new("{}".to_owned()),';assert base.count(needle)==1;base=base.replace(needle,needle+'\n            unit_digest_cache: RefCell::new(crate::digest_cache::Cache::new(crate::segments_digest)),')
a='''        self.engine
            .doc()
            .apply_local_update_v1(update)
            .map_err(js_err)''';b='''        self.unit_digest_cache
            .borrow_mut()
            .apply(self.engine.doc(), update)
            .map_err(js_err)''';assert base.count(a)==1;base=base.replace(a,b)
a='''        let units = self
            .engine
            .doc()
            .story_segment_units(story)
            .map_err(js_err)?;
        let digests: Vec<String> = units
            .iter()
            .map(|unit| format!("{:032x}", crate::segments_digest(unit)))
            .collect();''';b='''        let values = if story == "body" {
            self.unit_digest_cache.borrow_mut().get(self.engine.doc()).map_err(js_err)?
        } else {
            self.engine.doc().story_segment_units(story).map_err(js_err)?
                .iter().map(|unit| crate::segments_digest(unit)).collect()
        };
        let digests: Vec<String> = values.iter().map(|value| format!("{value:032x}")).collect();''';assert base.count(a)==1;base=base.replace(a,b);(p/'wasm-kandidaat.rs').write_text(base)
base=(src/'crates/docx-edit/src/lib.rs').read_text();(p/'lib-kandidaat.rs').write_text(base+'\n#[cfg(feature = "wasm")]\nmod digest_cache;\n')
shutil.copytree(old/'bron/target-wasm',src/'target-wasm');build=(old/'bouwen.py').read_text().replace('integratiecontrole/digest-kern','integratiecontrole/digest-productie');(p/'bouwen.py').write_text(build);print('Productieproef zonder meetinstrumentatie en counters voorbereid')
