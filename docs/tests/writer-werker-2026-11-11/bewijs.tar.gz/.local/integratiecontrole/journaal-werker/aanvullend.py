from pathlib import Path
import subprocess,json,shutil,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-werker';s=r/'native/onderzoek/writer-bronjournaal';basis=json.loads((u/'bouw.json').read_text())['opdracht'];uit=[]
for naam,oud,nieuw,test in [('wachtrij_twee','mpsc::sync_channel::<Opdracht>(1)','mpsc::sync_channel::<Opdracht>(2)','kanaal_bevat_een_wachtende_opdracht_en_behoudt_volgorde'),('zonder_late_antwoordcontrole','if !self.binnen.actief.load(Ordering::Acquire) {\n            return Err(self.gestopt());\n        }\n        r','r','vergeten_na_berekening_weigert_reeds_verzonden_antwoord')]:
 m=u/naam;m.mkdir(exist_ok=True)
 for f in ['journaal.rs','adapter.rs','werker.rs','werkerproef.rs']:shutil.copyfile(s/f,m/f)
 p=m/'werker.rs';v=p.read_text();assert v.count(oud)==1,(naam,v.count(oud));p.write_text(v.replace(oud,nieuw));c=basis.copy();c[c.index('-o')-1]=str(m/'werkerproef.rs');c[c.index('-o')+1]=str(m/'proef');p=subprocess.run(c,capture_output=True,text=True,timeout=60);(m/'bouw.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 p=subprocess.run([str(m/'proef'),'--exact',test],capture_output=True,text=True,timeout=15);(m/'proef.log').write_text(p.stdout+p.stderr);assert p.returncode==101 and 'FAILED' in p.stdout,(p.returncode,p.stdout,p.stderr);uit.append({'naam':naam,'code':p.returncode,'verwacht_afgekeurd':True,'test':test,'bouwopdracht':c,'binary_sha256':hashlib.sha256((m/'proef').read_bytes()).hexdigest()})
# Gewone bouw en uitvoering zonder cfg(test), dus zonder klok/paniek-/antwoordhooks.
rook=u/'rook.rs';code='\n'.join(f'#[path = "{s/f}"] mod {f[:-3]};' for f in ['journaal.rs','adapter.rs','werker.rs'])
code+='''
use base64::{Engine as _, engine::general_purpose::STANDARD};
fn main(){
 let d=docx_journal::EditingDoc::new(21);d.create_story_with_paragraph_id("body","p0","Begin","Normal","left").unwrap();let b=d.encode_state_as_update_v1();
 let w=werker::Werker::nieuw(true,adapter::Binding{eigenaar:"eigen".into(),document:"proef".into(),levensduur:1}).unwrap();
 let a=serde_json::from_value(serde_json::json!({"schema":3,"requestId":"rook","documentId":"proef","sourceVersion":"een","sourceVector":STANDARD.encode(d.encode_state_vector_v1()),"snapshotSha256":office_writer_plakken::snapshot_sha256(&b),"snapshot":STANDARD.encode(b),"clientId":21,"position":{"story":"body","paraId":"p0","offset":5},"text":"x"})).unwrap();let r=w.bereid(1,a).unwrap();assert_eq!(r["route"],"gereed");assert_eq!(r["caret"]["offset"],6);assert!(w.bytes()>0);w.vergeet();println!("Niet-testbouw: eigen tekstbewerking en cursor gecontroleerd");
}
''';rook.write_text(code);c=basis.copy();c.remove('--test');c[c.index('-o')-1]=str(rook);c[c.index('-o')+1]=str(u/'rook');p=subprocess.run(c,capture_output=True,text=True,timeout=60);(u/'rook-bouw.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr;p=subprocess.run([str(u/'rook')],capture_output=True,text=True,timeout=15);(u/'rook.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr;uit.append({'naam':'zonder_testhooks','code':p.returncode,'bouwopdracht':c,'binary_sha256':hashlib.sha256((u/'rook').read_bytes()).hexdigest()});(u/'aanvullend.json').write_text(json.dumps(uit,indent=2));print(json.dumps(uit,indent=2))
