#[path = "/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/native/onderzoek/writer-bronjournaal/journaal.rs"] mod journaal;
#[path = "/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/native/onderzoek/writer-bronjournaal/adapter.rs"] mod adapter;
#[path = "/home/aia01/Documenten/GitHub/Open-Office-Studio-integratie-2026-11-06/native/onderzoek/writer-bronjournaal/werker.rs"] mod werker;
use base64::{Engine as _, engine::general_purpose::STANDARD};
fn main(){
 let d=docx_journal::EditingDoc::new(21);d.create_story_with_paragraph_id("body","p0","Begin","Normal","left").unwrap();let b=d.encode_state_as_update_v1();
 let w=werker::Werker::nieuw(true,adapter::Binding{eigenaar:"eigen".into(),document:"proef".into(),levensduur:1}).unwrap();
 let a=serde_json::from_value(serde_json::json!({"schema":3,"requestId":"rook","documentId":"proef","sourceVersion":"een","sourceVector":STANDARD.encode(d.encode_state_vector_v1()),"snapshotSha256":office_writer_plakken::snapshot_sha256(&b),"snapshot":STANDARD.encode(b),"clientId":21,"position":{"story":"body","paraId":"p0","offset":5},"text":"x"})).unwrap();let r=w.bereid(1,a).unwrap();assert_eq!(r["route"],"gereed");assert_eq!(r["caret"]["offset"],6);assert!(w.bytes()>0);w.vergeet();println!("Niet-testbouw: eigen tekstbewerking en cursor gecontroleerd");
}
