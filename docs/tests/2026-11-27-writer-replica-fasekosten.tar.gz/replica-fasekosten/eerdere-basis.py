from pathlib import Path
import json,collections,hashlib
p=Path(__file__).resolve().parent;b=p.parent/'font-native-kernroute';out={}
for name in ['native','herhaling']:
 d=json.loads((b/name/'rapport.json').read_text());v=d['fasen_eind'][0]['result']['result']['value'];tasks={};sums=collections.Counter();counts=collections.Counter();unpaired=[]
 for e in v['regels']:
  if e['soort']in ['taak.begin','taak.einde']:tasks.setdefault(e['id'],{})[e['soort']]=e
 for i,t in tasks.items():
  assert 'taak.begin'in t;k=t['taak.begin']['type'];counts[k]+=1
  if 'taak.einde'not in t:unpaired.append({'id':i,'type':k,'begin':t['taak.begin']['tijd']});continue
  sums[k]+=t['taak.einde']['tijd']-t['taak.begin']['tijd']
 assert d['script_sha256']==hashlib.sha256((p/'proef.py').read_bytes()).hexdigest()
 out[name]={'taakstarts':dict(counts),'afgesloten_taken_ms_som':dict(sums),'open_bij_loggerstop':unpaired,'script_sha256':d['script_sha256'],'bronrapport_sha256':hashlib.sha256((b/name/'rapport.json').read_bytes()).hexdigest()}
result={'basis':out,'eerste_analyse_afgekeurd':'Een onbegrensde totalisatie trof een taak zonder einde vóór loggerstop. Geen eindtijd of nulwaarde ingevuld; open taak nu expliciet apart en som alleen afgesloten vensters.','grens':'Eerdere twee diagnostische referentieronden met exact hetzelfde harnas en invoer, geen nieuwe afwisselende gewone ABBA. Verschillende Wasm en aanvullende meetuitlezing bij de variant; geen causaal bewijs of snelheidsacceptatie. Taken kunnen asynchroon wachten en overlappen; sommen niet als CPU-tijd of onafhankelijke invoervertraging optellen.'};(p/'eerdere-basisvergelijking.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
