from pathlib import Path
import json,collections
p=Path(__file__).resolve().parent;a=json.loads((p/'basis.json').read_text());b=json.loads((p/'klok.json').read_text());assert a['geslaagd']and b['geslaagd'];assert len(a['gevallen'])==len(b['gevallen'])==30;phases=collections.Counter();updates=0;timed=0
for x,y in zip(a['gevallen'],b['gevallen']):
 assert x['kind']==y['kind']and len(x['stappen'])==len(y['stappen'])
 for u,v in zip(x['stappen'],y['stappen']):
  updates+=1
  for k in ['verwacht','error','staat_sha256','font_sha256','blokken_sha256']:assert u[k]==v[k],(x['kind'],k)
  for k in ['accepted','cache_recorded']:assert u['proof'].get(k)==v['proof'].get(k),(x['kind'],k)
  marks=v['proof'].get('fasekosten')
  if marks:
   timed+=1;assert [m[0]for m in marks]==['begin','prepare','watch','apply','finish','record','proof_value'];assert all(l[1]<=r[1]for l,r in zip(marks,marks[1:]));phases.update({r[0]:r[1]-l[1]for l,r in zip(marks,marks[1:])})
assert updates==43
result={'geslaagd':True,'gevallen':30,'updates':updates,'getimede_geslaagde_updates':timed,'fases_ms_som':dict(phases),'pariteit':'Vaste updatebytes, verwachte inference/errors, staat/vector/body, marges/metadata, fontvereisten en volledige blokken in beide modules tegen hetzelfde bestaande corpus getoetst. Accepted/cache_recorded gelijk.','grens':'Componentproef in Node, geen native tijdvergelijking of volledige opmaak-/visuele dekking.'};(p/'corpusvergelijking.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
