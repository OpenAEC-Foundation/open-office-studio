from pathlib import Path
import json,collections,statistics
p=Path(__file__).resolve().parent;out={}
for name in ['native','herhaling']:
 d=json.loads((p/name/'rapport.json').read_text());assert d['geslaagd'];raw=d['fasen_eind'][0]['result']['result']['value'];assert raw['overgeslagen']==0;ev=raw['regels'];tasks={}
 for e in ev:
  if e['soort']in ['taak.begin','taak.einde']:tasks.setdefault(e['id'],{})[e['soort']]=e
 taaktijden=collections.Counter();taakaantallen=collections.Counter()
 for t in tasks.values():
  soort=t['taak.begin']['type'];taaktijden[soort]+=t['taak.einde']['tijd']-t['taak.begin']['tijd'];taakaantallen[soort]+=1
 updates=raw['updates'];ids={x['id']for x in updates};assert len(ids)==len(updates);expected={i for i,t in tasks.items()if t['taak.begin']['type']=='applyUpdate'};assert ids==expected
 phases=collections.Counter();accepted=0;cached=0;reasons=collections.Counter();rows=[]
 for x in updates:
  v=x['profile'];marks=v['fasekosten'];assert [m[0]for m in marks]==['begin','prepare','watch','apply','finish','record','proof_value'];assert all(a[1]<=b[1]for a,b in zip(marks,marks[1:]));t=tasks[x['id']];assert t['taak.begin']['tijd']<=marks[0][1]<=marks[-1][1]<=t['taak.einde']['tijd'];cost={b[0]:b[1]-a[1]for a,b in zip(marks,marks[1:])};phases.update(cost);accepted+=bool(v['accepted']);cached+=bool(v['cache_recorded']);reasons.update(v['observed']['reasons']);rows.append({'id':x['id'],'accepted':v['accepted'],'cache_recorded':v['cache_recorded'],'redenen':v['observed']['reasons'],'fases_ms':cost,'hele_taak_ms':t['taak.einde']['tijd']-t['taak.begin']['tijd']})
 fonts=raw['kern'];routes=collections.Counter();font_ms=0;resident_ms=0
 fb={e['id']:e['tijd']for e in ev if e['soort']=='font.begin'};fe={e['id']:e['tijd']for e in ev if e['soort']=='font.einde'};assert len(fonts)==len(fb)==len(fe)and {x['id']for x in fonts}==set(fb)==set(fe)
 for x in fonts:
  m=x['marks'];assert m[0][0]=='begin'and m[-1][0]=='json';assert all(a[1]<=b[1]for a,b in zip(m,m[1:]));assert fb[x['id']]<=m[0][1]<=m[-1][1]<=fe[x['id']];font_ms+=m[-1][1]-m[0][1]
  for a,b in zip(m,m[1:]):
   if a[0].startswith('route_'):routes[a[0]]+=1
   if a[0]=='story_begin':resident_ms+=b[1]-a[1]
 out[name]={'taken_ms_som':dict(taaktijden),'taakaantallen':dict(taakaantallen),'updates':len(updates),'accepted':accepted,'cache_recorded':cached,'redenen':dict(reasons),'fases_ms_som':dict(phases),'hele_update_taken_ms_som':sum(x['hele_taak_ms']for x in rows),'fontaantal':len(fonts),'font_routes':dict(routes),'font_rust_ms_som':font_ms,'font_resident_ms_som':resident_ms,'ruwe_updates':rows,'grens':'Geïnstrumenteerde verstreken tijd op eerder afgewezen variant; geen nieuwe snelheidsacceptatie. Finish omvat het observercertificaat en indexlezingen, geen losse subfasen daarvan.'}
(p/'analyse.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({n:{k:v for k,v in d.items()if k!='ruwe_updates'}for n,d in out.items()},ensure_ascii=False))
