from pathlib import Path
import json,collections,statistics,hashlib
p=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
d=json.loads((p/'proef.json').read_text());u=json.loads((p/'proef-undo.json').read_text());o=json.loads((p.parent/'digest-fasen/orakel.json').read_text())
assert d['digest_en_leesinvarianten_geslaagd'] and d['toestanden']==80 and len(d['gevallen'])==31 and d['documentwissels_en_foutpad']==3
assert u['digest_en_leesinvarianten_geslaagd'] and u['toestanden']==7
phases=collections.Counter();reject=collections.Counter()
for row,case in zip(d['gevallen'],o['cases']):
 assert row['case']==case['name'];n=len(case['frames']);undos=row['undo_redo']
 assert len(row['replica_bytes'])==n+2*undos
 for i,r in enumerate(row['replica_bytes']):phases[('invoer' if i<n else 'undo' if i<n+undos else 'redo',r['kandidaat'],r['twee_referenties'])]+=1
 for reasons in row['afwijzingen']:reject.update(reasons)
assert phases[('invoer',True,True)]==80
measure=[]
for frame in range(1,7):
 rows=[r for r in u['metingen']if r['frame']==frame];a=[r['ns']/1e6 for r in rows if r['mode']=='A'];b=[r['ns']/1e6 for r in rows if r['mode']=='B'];assert len(a)==len(b)==8
 measure.append({'frame':frame,'A_ms':statistics.median(a),'B_ms':statistics.median(b),'B_A':statistics.median(b)/statistics.median(a)})
result={'toestanden':80,'reeksen':31,'bodydigests_wasm32':sum(len(story['digests'])for case in o['cases']for frame in case['frames']for story in frame['stories']if story['story']=='body'),'promoties':sum(x['promoties']for x in d['gevallen']),'undo_redo_paren':sum(x['undo_redo']for x in d['gevallen']),'documentwissels_en_ongeldige_update':3,'replica_bytevergelijkingen':[{'fase':k[0],'kandidaat':k[1],'twee_referenties':k[2],'aantal':v}for k,v in phases.items()],'afwijzingen':dict(reject),'met_undo_manager_ABBA':measure,'zonder_undo_benchmark_alleen_verkennend':True,'niet_bewezen':['oorzaak van bronbyteverschillen tussen onafhankelijke instanties na Undo/Redo','Wasm-integratie en JS-grens','desktopinvoerwinst','visuele acceptatie','pending buffer nog aanwezig tijdens aanvraag','overige platforms en releasevarianten'],'bronnen':{'orakel':sha(p.parent/'digest-fasen/orakel.json'),'vorig_archief':sha(p.parents[2]/'docs/tests/2026-11-28-writer-rust-digestfasen.tar.gz')}}
(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
