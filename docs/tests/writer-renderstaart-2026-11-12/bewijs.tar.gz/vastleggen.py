from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path.cwd();u=r/'.local/integratiecontrole/renderstaart'
assert 'Ran 127 tests' in (u/'python-tests.log').read_text() and '\nOK\n' in (u/'python-tests.log').read_text()
shutil.copyfile(r/'.local/integratiecontrole/adaptieve-invoer/wachtrij-probe.js',u/'wachtrij-probe.js')
bestanden=[p for p in u.rglob('*') if p.is_file() and p.suffix not in ['.pyc'] and '__pycache__' not in p.parts]
# Eigen diagnosebestanden, geen ELF, cache, installatie of gebruikersdocumenten.
assert all(p.stat().st_size<15*1024*1024 for p in bestanden)
for p in bestanden:assert not p.read_bytes().startswith(b'\x7fELF'),p
uit=r/'docs/tests/writer-renderstaart-2026-11-12';uit.mkdir(exist_ok=False)
arch=uit/'bewijs.tar.gz'
with tarfile.open(arch,'w:gz') as t:
 for p in sorted(bestanden):t.add(p,arcname=p.relative_to(u),recursive=False)
with tarfile.open(arch) as t:
 for m in t:
  assert m.isfile() and '..' not in Path(m.name).parts
  assert t.extractfile(m).read()==(u/m.name).read_bytes()
a=json.loads((u/'analyse.json').read_text());ci=json.loads((u/'native-ci.json').read_text())
rapport={
 'schema':1,'datum':'2026-11-12','status':'Hoofdthreadroutes in twee echte rijke invoerproeven vastgelegd; geen productwijziging of snelheidsacceptatie.',
 'ontwikkelbron':'4e1e22f5f99c4c112e164a5b5620f36bc57402f0','runtimebron':'0a43e8c603d8f7053081a23f7c78d268f8bae91c',
 'programma_sha256':'7afdfb82ac07c31ef1e086598e4573c9695d1e6d4b72a91ec822c30bd128aa8f',
 'proef':'Eigen 65-pagina-/128-tabellenbron, 1052 echte xdotool-tekens met delay 2. ScriptProfiler begint na het verzenden van de toetsen en omvat nog ongeveer25s invoerachterstand plus renderstaart. Geen kunstmatige antwoordvertraging tijdens de gewone invoer.',
 'opnamen':{n:{k:v for k,v in x.items() if k not in ['stacks','wasmgrenzen','scriptbronnen']} for n,x in a.items()},
 'bevindingen':[
  'In beide opnamen komen alle tablePayload-samples via TabelGrepen → tabelBeelden → tabelankers → tabelVanCel. Dit is een concrete te onderzoeken hoofdthreadroute, geen bewijs van de totale oorzaak.',
  'De volledige story-positieprojectie blijft zichtbaar in de SDK-selectiesynchronisatie, met storySegmentUnitDigests en paragraphSpans in de opname. Bestaande levensduur-, bron-, versie-, Undo- en selectiecontroles blijven behouden.',
  'De meeste readParagraphs-stacks missen hogere aanroepers; die zijn niet aan een component toegeschreven.',
  'De actuele fragmentroute filtert tabelankers al op zichtbare tabelidentiteiten. Deze opname bewijst dus niet dat alle verre tabellen worden uitgelezen. Cross-page ankers en terugval bij ontbrekende tabelidentiteiten blijven nodig.'
 ],
 'functioneel':['Beide volledige proeven geslaagd, nul GUI-/engine-/consolefouten.','Gewone invoer, volledige verhaal-/opmaakstand en Undo/Redo exact gecontroleerd.','Afzonderlijke vastgehouden echte antwoorden: typen/selecteren/vervangen/bewaren; 128 tabellen en opgeslagen hoofdtekst onafhankelijk uit DOCX exact teruggelezen.','Niet opslaan en nieuw document vóór laat antwoord; oud antwoord wijzigt gesloten sessie, opgeslagen bestand en nieuwe tekst niet.'],
 'visueel':{'bekeken':['opname-a/invoer-redo.png','opname-b/snel-getypt-bewaard.png','opname-b/nieuw-na-laat-antwoord.png'],'beschikbaar':'Alle zes screenshots in bewijsarchief. Geen pixelgelijkheid of volledige visuele dekking geclaimd.'},
 'controles':['127 Python-tests geslaagd.','Analyse valideert programmahash, gewone brongebonden aanvragen zonder antwoordvertraging, exacte profilerbronnen, niet-lege profielresultaten en source-locaties.','Tweede opname:90 geneste kalibratiesamples bevestigen leaf-first stackvolgorde. Eerste opname heeft geen eigen kalibratie en wordt voor stacklidmaatschap gebruikt.','Vijf vaste ELF-referenties opnieuw bytegelijk gecontroleerd.','Migratiecontrole meldt nog10 open acceptatiegebieden.'],
 'native_ci':{'url':ci['url'],'bron':ci['headSha'],'status_bij_peiling':ci['status'],'banen':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']],'grens':'Nieuwe golden encodercontrole geslaagd op Linux, macOS en Windows. Linux/macOS complete banen en conversie groen; Windows releasebuild inmiddels geslaagd, verpakken op latere peiling nog actief. Geen desktop-GUI- of editieacceptatie voor deze bron.'},
 'grenzen':['Geen runtime-, SDK-, standaardbundel-, installatie- of databasewijziging. Geen issue gesloten.','Profielinstrumentatie beïnvloedt timing; geen vergelijking met onbespiede productie of bewijs van winst. Stacklidmaatschappen overlappen en zijn geen CPU-tijdpercentages.','Keyup is ontvangst in WebKit, niet hardwaretijd; renderlijst plus twee rAFs is geen fysieke paint/FPS.','Geen volledige frontend-/workspace-/vendor-suite lokaal herhaald, geen schema3-GUI, fysieke IME, opgeslagen DOCX opnieuw via GUI geopend, alle edities of platformen aanvaard.'],
 'vervolg':'Onderzoek de herhaalde tabelPayload-herlezing bij gewone tekst buiten tabellen: alleen veilig hergebruik bij bewezen ongewijzigde tabelinhoud, met harde invalidatie voor echte tabel-/cel-/remote-/Undo-/sessiewijzigingen. Vergelijk daarna de echte app functioneel en visueel; behoud cross-page ankers. Volledige positieprojectie apart blijven volgen.',
 'bewijs':{'pad':str(arch.relative_to(r)),'sha256':hashlib.sha256(arch.read_bytes()).hexdigest(),'bytes':arch.stat().st_size,'bestanden':len(bestanden),'elk_lid_bytegelijk_geverifieerd':True},
 'herhalen':'Exacte gemeten proef-a.py/proef.py in archief. Basishelper en inspector uit ontwikkelbron; wachtrij-probe.js komt bytegelijk uit .local/integratiecontrole/adaptieve-invoer en moet daar bij replay worden teruggezet. Alleen eigen tijdelijke profielen/documentkopieën gebruiken.'
}
(r/'docs/tests/2026-11-12-writer-renderstaart.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rapport['bewijs']))
