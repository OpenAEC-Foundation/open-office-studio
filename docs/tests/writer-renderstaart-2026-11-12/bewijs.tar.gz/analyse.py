"""Controleer profiel, exacte bronbinding en gewone invoer zonder productwijziging."""
from pathlib import Path
import collections, gzip, hashlib, json
u=Path(__file__).resolve().parent
uit={}
for naam in ['opname-a','opname-b']:
 p=u/naam;r=json.loads((p/'rapport.json').read_text())
 assert r['geslaagd'] and not any(r['fouten'].values()) and r['schema']==2
 assert r['programma_sha256']=='7afdfb82ac07c31ef1e086598e4573c9695d1e6d4b72a91ec822c30bd128aa8f'
 assert r['bewaarde_tabellen_exact']==128
 tekst=' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.'
 prefix='';opdrachten=[]
 for m in r['native_opdrachten']:
  opdrachten.append(m)
  if m.get('caret'):prefix+=m['text']
  assert tekst.startswith(prefix)
  if prefix==tekst:break
 assert prefix==tekst and all(m['bronbinding'] and m['gereed'] and not m.get('vertragingMs') and not m['wacht'] for m in opdrachten)
 ev=json.load(gzip.open(p/'profielen.json.gz','rt'))
 klaar=[e for e in ev if e.get('method')=='ScriptProfiler.trackingComplete'];assert len(klaar)==1
 monsters=klaar[0]['params']['samples']['stackTraces'];assert len(monsters)==r['profiel_samples']
 bronnen={}
 for b in r['scriptbronnen']:
  data=gzip.decompress((p/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256']
  bronnen[b['url']]=data.decode()
 telling=collections.Counter();stacks=collections.Counter();wasmgrenzen=collections.Counter()
 herkenning={'tabelgrepen':('ree','editors-2CdTQbCm.js',48,20311),'tabelbeelden':('sL','editors-2CdTQbCm.js',34,9220),'tabelankers':('kE','index-DX35Amhc.js',141,147710),'storyprojectie':('buildStory','index-DX35Amhc.js',223,6766)}
 # Namen alleen koppelen aan bronbytes uit precies de gemeten ELF.
 for titel,(fn,bestand,line,col) in herkenning.items():
  bron=next(v for k,v in bronnen.items() if k.endswith('/'+bestand));regel=bron.split('\n')[line-1]
  fragment=regel[max(0,col-60):col+130]
  assert fn in fragment,(titel,fragment)
 for m in monsters:
  fs=m['stackFrames'];namen=[f['name'] for f in fs]
  for titel,(fn,bestand,line,col) in herkenning.items():
   if any(f['name']==fn and f.get('url','').endswith('/'+bestand) and f.get('line')==line and f.get('column')==col for f in fs):telling[titel]+=1
  for fn in ['readParagraphs','paragraphSpans','tablePayload','storySegmentUnitDigests']:
   if fn in namen:telling[fn]+=1
  if 'tablePayload' in namen and 'ree' in namen:telling['tablePayload_via_tabelgrepen']+=1
  if 'readParagraphs' in namen:
   i=namen.index('readParagraphs')
   if i==len(namen)-1:telling['readParagraphs_zonder_hogere_aanroeper']+=1
  for fn in ['buildStory','tablePayload']:
   if fn in namen:
    i=namen.index(fn)
    stacks[(fn,tuple((f['name'],f.get('url',''),f.get('line'),f.get('column')) for f in fs[i:i+8]))]+=1
  if 'wasm-stub' in namen:
   i=namen.index('wasm-stub');wasmgrenzen[tuple(f['name'] for f in fs[i+1:i+4])]+=1
 assert telling['tabelgrepen'] and telling['storyprojectie'] and telling['tablePayload_via_tabelgrepen']
 if naam=='opname-b':assert r['stack_kalibratie']['leaf_eerst'] and r['stack_kalibratie']['aantal']>0
 uit[naam]={'geslaagd':True,'invoer':r['lange_invoer'],'profielvenster_ms':r['profiel_eind_klok']-r['profiel_begin_klok'],'samples':len(monsters),'gewone_native_opdrachten':len(opdrachten),'stacklidmaatschap':dict(telling),'stacks':stacks.most_common(12),'wasmgrenzen':wasmgrenzen.most_common(15),'scriptbronnen':r['scriptbronnen'],'stack_kalibratie':r.get('stack_kalibratie'),'undo_groepen':r['undo_groepen_lange_invoer'],'bewaarde_tabellen_exact':r['bewaarde_tabellen_exact'],'fouten':r['fouten']}
(u/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
for n,r in uit.items():print(n,json.dumps({k:r[k] for k in ['samples','profielvenster_ms','gewone_native_opdrachten','stacklidmaatschap']},ensure_ascii=False))
print('Geen CPU-tijdpercentages; lidmaatschappen overlappen. ReadParagraphs zonder hoger kader blijft niet toegeschreven.')
