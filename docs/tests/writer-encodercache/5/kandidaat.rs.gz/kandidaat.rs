use std::collections::BTreeMap;

use serde_json::{Map, Number, Value};
use yrs::any::{F64_MAX_SAFE_INTEGER, F64_MIN_SAFE_INTEGER};
use yrs::block::{BLOCK_GC_REF_NUMBER, BLOCK_ITEM_DELETED_REF_NUMBER, HAS_PARENT_SUB};
use yrs::encoding::write::Write;
use yrs::updates::decoder::Decode;
use yrs::updates::encoder::{Encode, Encoder, EncoderV1};
use yrs::{Any, ClientID, ID, ReadTxn, StateVector, Update};

pub(crate) struct DeterministicEncoderV1<'a>(EncoderV1,Option<&'a mut WaardeCache>);

impl DeterministicEncoderV1<'_> {
    fn new() -> Self {
        Self(EncoderV1::new(),None)
    }
}

impl Write for DeterministicEncoderV1<'_> {
    fn write_all(&mut self, buf: &[u8]) {
        self.0.write_all(buf);
    }

    fn write_u8(&mut self, value: u8) {
        self.0.write_u8(value);
    }
}

impl Encoder for DeterministicEncoderV1<'_> {
    fn to_vec(self) -> Vec<u8> {
        self.0.to_vec()
    }

    fn reset_ds_cur_val(&mut self) {
        self.0.reset_ds_cur_val();
    }

    fn write_ds_clock(&mut self, clock: u32) {
        self.0.write_ds_clock(clock);
    }

    fn write_ds_len(&mut self, len: u32) {
        self.0.write_ds_len(len);
    }

    fn write_left_id(&mut self, id: &ID) {
        self.0.write_left_id(id);
    }

    fn write_right_id(&mut self, id: &ID) {
        self.0.write_right_id(id);
    }

    fn write_client(&mut self, client: ClientID) {
        self.0.write_client(client);
    }

    fn write_info(&mut self, info: u8) {
        self.0.write_info(info);
    }

    fn write_parent_info(&mut self, is_y_key: bool) {
        self.0.write_parent_info(is_y_key);
    }

    fn write_type_ref(&mut self, info: u8) {
        self.0.write_type_ref(info);
    }

    fn write_len(&mut self, len: u32) {
        self.0.write_len(len);
    }

    fn write_any(&mut self, any: &Any) {
        if let Some(cache)=self.1.as_mut() {cache.schrijf(any,false,&mut self.0);} else {encode_any(any,self);}
    }

    fn write_json(&mut self, any: &Any) {
        if let Some(cache)=self.1.as_mut() {cache.schrijf(any,true,&mut self.0);} else {self.write_string(&serde_json::to_string(&json_value(any)).unwrap());}
    }

    fn write_key(&mut self, string: &str) {
        self.0.write_key(string);
    }
}

#[derive(Default)]
struct CountingEncoderV1 {
    len: usize,
    info: u8,
    unstable_json: bool,
    root_sequence: bool,
    tombstone_len: u64,
    deleted_len: u64,
}

impl Write for CountingEncoderV1 {
    fn write_all(&mut self, buf: &[u8]) {
        self.len += buf.len();
    }

    fn write_u8(&mut self, _: u8) {
        self.len += 1;
    }
}

impl Encoder for CountingEncoderV1 {
    fn to_vec(self) -> Vec<u8> {
        unreachable!("a counting encoder has no byte buffer")
    }

    fn reset_ds_cur_val(&mut self) {}

    fn write_ds_clock(&mut self, clock: u32) {
        self.write_var(clock);
    }

    fn write_ds_len(&mut self, len: u32) {
        self.deleted_len += u64::from(len);
        self.write_var(len);
    }

    fn write_left_id(&mut self, id: &ID) {
        self.write_var(id.client.get());
        self.write_var(id.clock);
    }

    fn write_right_id(&mut self, id: &ID) {
        self.write_left_id(id);
    }

    fn write_client(&mut self, client: ClientID) {
        self.write_var(client.get());
    }

    fn write_info(&mut self, info: u8) {
        self.info = info;
        self.write_u8(info);
    }

    fn write_parent_info(&mut self, is_y_key: bool) {
        self.root_sequence |= is_y_key && self.info & HAS_PARENT_SUB == 0;
        self.write_var(u32::from(is_y_key));
    }

    fn write_type_ref(&mut self, info: u8) {
        self.write_u8(info);
    }

    fn write_len(&mut self, len: u32) {
        if self.info == BLOCK_GC_REF_NUMBER || self.info & 0x1F == BLOCK_ITEM_DELETED_REF_NUMBER {
            self.tombstone_len += u64::from(len);
        }
        self.write_var(len);
    }

    fn write_any(&mut self, any: &Any) {
        encode_any(any, self);
    }

    fn write_json(&mut self, any: &Any) {
        let json = serde_json::to_string(&json_value(any)).unwrap();
        self.write_string(&json);
        if !self.unstable_json && !json_stable_fast(any) && !json_stable(any, &json) {
            self.unstable_json = true;
        }
    }

    fn write_key(&mut self, key: &str) {
        self.write_string(key);
    }
}

/// Returns None for pending data, unstable JSON values, root sequence content, or deleted content
/// a fork would collect; a fork that `keeps_deleted`, as one of a replica with an undo history
/// does, collects none.
pub(crate) fn fork_state_len_v1<T: ReadTxn>(txn: &T, keeps_deleted: bool) -> Option<usize> {
    let store = txn.store();
    if store.pending_update().is_some() || store.pending_ds().is_some() {
        return None;
    }
    let mut encoder = CountingEncoderV1::default();
    txn.encode_state_as_update(&StateVector::default(), &mut encoder);
    (!encoder.unstable_json
        && !encoder.root_sequence
        && (keeps_deleted || encoder.tombstone_len == encoder.deleted_len))
        .then_some(encoder.len)
}

pub(crate) fn encode_state_as_update_v1<T: ReadTxn>(
    txn: &T,
    state_vector: &StateVector,
) -> Vec<u8> {
    let integrated = encode_state(txn, state_vector);
    let store = txn.store();
    if store.pending_update().is_none() && store.pending_ds().is_none() {
        return integrated;
    }

    let mut updates = vec![Update::decode_v1(&integrated).unwrap()];
    if let Some(pending) = store.pending_update() {
        let mut encoder = DeterministicEncoderV1::new();
        pending.update.encode(&mut encoder);
        updates.push(Update::decode_v1(&encoder.to_vec()).unwrap());
    }
    if let Some(pending) = store.pending_ds() {
        let mut encoder = DeterministicEncoderV1::new();
        encoder.write_var(0_u32);
        pending.encode(&mut encoder);
        updates.push(Update::decode_v1(&encoder.to_vec()).unwrap());
    }

    let merged = Update::merge_updates(updates);
    let mut encoder = DeterministicEncoderV1::new();
    merged.encode(&mut encoder);
    encoder.to_vec()
}

pub(crate) fn encode_diff_v1<T: ReadTxn>(txn: &T, state_vector: &StateVector) -> Vec<u8> {
    let mut encoder = DeterministicEncoderV1::new();
    txn.encode_diff(state_vector, &mut encoder);
    encoder.to_vec()
}

fn encode_state<T: ReadTxn>(txn: &T, state_vector: &StateVector) -> Vec<u8> {
    let mut encoder = DeterministicEncoderV1::new();
    txn.encode_state_as_update(state_vector, &mut encoder);
    encoder.to_vec()
}

fn encode_any<W: Write>(any: &Any, encoder: &mut W) {
    match any {
        Any::Undefined => encoder.write_u8(127),
        Any::Null => encoder.write_u8(126),
        Any::Bool(value) => encoder.write_u8(if *value { 120 } else { 121 }),
        Any::String(value) => {
            encoder.write_u8(119);
            encoder.write_string(value);
        }
        Any::Number(value) => {
            let truncated = value.trunc();
            if truncated == *value
                && (F64_MIN_SAFE_INTEGER..=F64_MAX_SAFE_INTEGER).contains(&truncated)
            {
                encoder.write_u8(125);
                encoder.write_var(truncated as i64);
            } else if ((*value as f32) as f64) == *value {
                encoder.write_u8(124);
                encoder.write_f32(*value as f32);
            } else {
                encoder.write_u8(123);
                encoder.write_f64(*value);
            }
        }
        Any::BigInt(value) => {
            encoder.write_u8(122);
            encoder.write_i64(*value);
        }
        Any::Array(values) => {
            encoder.write_u8(117);
            encoder.write_var(values.len() as u64);
            for value in values.iter() {
                encode_any(value, encoder);
            }
        }
        Any::Map(values) => {
            encoder.write_u8(118);
            encoder.write_var(values.len() as u64);
            let sorted: BTreeMap<_, _> = values.iter().collect();
            for (key, value) in sorted {
                encoder.write_string(key);
                encode_any(value, encoder);
            }
        }
        Any::Buffer(value) => {
            encoder.write_u8(116);
            encoder.write_buf(value);
        }
    }
}

fn json_stable_fast(any: &Any) -> bool {
    json_stable_fast_at(any, 0)
}

fn json_stable_fast_at(any: &Any, depth: usize) -> bool {
    match any {
        Any::Null | Any::Bool(_) => true,
        Any::String(value) => value
            .chars()
            .all(|ch| !ch.is_control() && ch != '"' && ch != '\\'),
        Any::Number(value) => {
            value.abs() < 2_147_483_648.0
                && value.trunc() == *value
                && (*value != 0.0 || !value.is_sign_negative())
        }
        Any::Array(values) => {
            depth < 32 && values.iter().all(|v| json_stable_fast_at(v, depth + 1))
        }
        Any::Map(values) => {
            depth < 32 && values.values().all(|v| json_stable_fast_at(v, depth + 1))
        }
        _ => false,
    }
}

fn json_stable(any: &Any, json: &str) -> bool {
    let Ok(round_trip) = Any::from_json(json) else {
        return false;
    };
    let mut original = Vec::new();
    let mut decoded = Vec::new();
    encode_any(any, &mut original);
    encode_any(&round_trip, &mut decoded);
    original == decoded
}

fn json_value(any: &Any) -> Value {
    match any {
        Any::Null | Any::Undefined => Value::Null,
        Any::Bool(value) => Value::Bool(*value),
        Any::Number(value) if *value as i64 as f64 == *value => {
            Value::Number(Number::from(*value as i64))
        }
        Any::Number(value) => Number::from_f64(*value)
            .map(Value::Number)
            .unwrap_or(Value::Null),
        Any::BigInt(value) => Value::Number(Number::from(*value)),
        Any::String(value) => Value::String(value.to_string()),
        Any::Buffer(value) => Value::Array(
            value
                .iter()
                .map(|byte| Value::Number(Number::from(*byte)))
                .collect(),
        ),
        Any::Array(values) => Value::Array(values.iter().map(json_value).collect()),
        Any::Map(values) => {
            let sorted: BTreeMap<_, _> = values
                .iter()
                .map(|(key, value)| (key.clone(), json_value(value)))
                .collect();
            Value::Object(sorted.into_iter().collect::<Map<_, _>>())
        }
    }
}


// Alleen een afzonderlijke proef: geen globale opslag of wijziging van de app.
use std::{mem::size_of, sync::Arc};
struct CacheWaarde { sleutel: (u8, usize, usize), _eigenaar: Any, bytes: Vec<u8>, gewicht: usize }
struct WaardeCache { plaatsen: Box<[Option<CacheWaarde>]>, gebruikt: usize, grens: usize, treffers: usize, missers: usize }
impl WaardeCache {
    fn nieuw(grens: usize) -> Self {
        let aantal = (grens / size_of::<Option<CacheWaarde>>() / 8).min(16384);
        let plaatsen = (0..aantal).map(|_| None).collect::<Vec<_>>().into_boxed_slice();
        Self { gebruikt: plaatsen.len()*size_of::<Option<CacheWaarde>>(), plaatsen, grens, treffers: 0, missers: 0 }
    }
    fn sleutel(a: &Any, json: bool) -> Option<(u8,usize,usize)> {
        match a {
            Any::Map(m) => Some((u8::from(json)*2, Arc::as_ptr(m) as usize, 0)),
            Any::Array(v) => Some((u8::from(json)*2+1, v.as_ptr() as usize, v.len())),
            _ => None,
        }
    }
    // Boekhoudgewicht, geen claim over allocator-/proces-RSS. Gedeelde
    // subwaarden worden bewust opnieuw geteld; onderliggende capaciteit telt mee.
    fn gewicht(a: &Any) -> usize {
        let extra = match a {
            Any::Map(m) => 64usize.saturating_add(m.capacity().saturating_mul(size_of::<(String,Any)>()+32))
                .saturating_add(m.iter().fold(0usize, |n,(k,v)| n.saturating_add(k.capacity()).saturating_add(Self::gewicht(v)))),
            Any::Array(v) => 32usize.saturating_add(v.len().saturating_mul(size_of::<Any>()))
                .saturating_add(v.iter().fold(0usize, |n,v| n.saturating_add(Self::gewicht(v)))),
            Any::String(s) => 32usize.saturating_add(s.len()),
            Any::Buffer(b) => 32usize.saturating_add(b.len()),
            _ => 0,
        }; extra
    }
    fn schrijf<W: Write>(&mut self, a: &Any, json: bool, uit: &mut W) {
        let Some(sleutel) = Self::sleutel(a,json) else { schrijf_ongewijzigd(a,json,uit); return; };
        if self.plaatsen.is_empty() { schrijf_ongewijzigd(a,json,uit); return; }
        let begin = (sleutel.1.rotate_right(4) ^ sleutel.2.wrapping_mul(31) ^ usize::from(sleutel.0).wrapping_mul(997)) % self.plaatsen.len();
        // Begrensd zoeken voorkomt kwadratische vertraging bij een volle index.
        let mut leeg = None;
        for stap in 0..16.min(self.plaatsen.len()) {
            let i = (begin+stap)%self.plaatsen.len();
            match &self.plaatsen[i] {
                Some(v) if v.sleutel == sleutel => { self.treffers+=1; uit.write_all(&v.bytes); return; },
                None => { leeg=Some(i); break; }, _=>{},
            }
        }
        self.missers+=1;
        let Some(i) = leeg else { schrijf_ongewijzigd(a,json,uit); return; };
        let mut bytes = Vec::new(); schrijf_ongewijzigd(a,json,&mut bytes);
        let gewicht = bytes.capacity().saturating_add(Self::gewicht(a));
        uit.write_all(&bytes);
        if gewicht <= self.grens.saturating_sub(self.gebruikt) {
            self.gebruikt+=gewicht;
            self.plaatsen[i]=Some(CacheWaarde { sleutel, _eigenaar:a.clone(), bytes, gewicht });
        }
    }
}
fn schrijf_ongewijzigd<W: Write>(a:&Any,json:bool,uit:&mut W) {
    if json { uit.write_string(&serde_json::to_string(&json_value(a)).unwrap()); }
    else { encode_any(a,uit); }
}
// De cache kan uitsluitend met zijn eigen replica worden gebruikt. Nieuwe bron
// betekent een nieuw object, ook als tekst en clientnummer toevallig gelijk zijn.
pub struct ProefReplica { doc: docx_edit::EditingDoc, cache: WaardeCache }
impl ProefReplica {
    pub fn nieuw(bytes:&[u8],grens:usize)->Self {
        use yrs::Transact;
        let doc=docx_edit::EditingDoc::new(20264562); doc.keep_deleted();
        doc.yrs_doc().transact_mut().apply_update(Update::decode_v1(bytes).unwrap()).unwrap();
        Self {doc,cache:WaardeCache::nieuw(grens)}
    }
    pub fn snapshot(&mut self)->Vec<u8> {
        use yrs::Transact;
        let txn=self.doc.yrs_doc().transact();
        // Deze eerste proef beperkt zich tot geïntegreerde bronnen. Geen
        // alternatieve samenvoegroute of herinterpretatie van pending updates.
        assert!(txn.store().pending_update().is_none() && txn.store().pending_ds().is_none());
        let mut encoder=DeterministicEncoderV1(EncoderV1::new(),Some(&mut self.cache));
        txn.encode_state_as_update(&StateVector::default(),&mut encoder); encoder.to_vec()
    }
    pub fn cijfers(&self)->(usize,usize,usize,usize) {(self.cache.gebruikt,self.cache.grens,self.cache.treffers,self.cache.missers)}
}
#[cfg(test)]
mod cacheproeven {
    use super::*;
    #[test]
    fn vormen_mutaties_en_sterke_eigendom() {
        use std::collections::HashMap;
        let mut cache=WaardeCache::nieuw(1024*1024);
        let mut a=Any::Map(Arc::new(HashMap::from([("eigen".into(),Any::Array(Arc::from([Any::from("eerste"),Any::Null])))])));
        for json in [false,true,false,true] {
            let mut verwacht=Vec::new(); schrijf_ongewijzigd(&a,json,&mut verwacht);
            let mut uit=Vec::new();cache.schrijf(&a,json,&mut uit);assert_eq!(uit,verwacht);
        }
        assert_eq!(cache.treffers,2);
        let oud=WaardeCache::sleutel(&a,false);
        if let Any::Map(m)=&mut a {Arc::make_mut(m).insert("eigen".into(),Any::from("veranderd"));}
        assert_ne!(oud,WaardeCache::sleutel(&a,false));
        for json in [true,false] { let mut uit=Vec::new();cache.schrijf(&a,json,&mut uit);let mut verwacht=Vec::new();schrijf_ongewijzigd(&a,json,&mut verwacht);assert_eq!(uit,verwacht); }
        assert!(cache.gebruikt<=cache.grens);
        assert_eq!(cache.gebruikt,cache.plaatsen.len()*size_of::<Option<CacheWaarde>>()+cache.plaatsen.iter().flatten().map(|v|v.gewicht).sum::<usize>());
    }
    #[test]
    fn nul_kleine_en_volle_grens_blijven_exact() {
        for grens in [0,1,128,1024,8192] {
            let mut cache=WaardeCache::nieuw(grens);
            for i in 0..300 {
                let a=Any::Array(Arc::from([Any::from(format!("waarde-{i}")),Any::Number(i as f64)]));
                for json in [false,true] { let mut verwacht=Vec::new();schrijf_ongewijzigd(&a,json,&mut verwacht);for _ in 0..2 {let mut uit=Vec::new();cache.schrijf(&a,json,&mut uit);assert_eq!(uit,verwacht);} }
                assert!(cache.gebruikt<=grens);
            }
        }
    }
}
#[cfg(test)]
mod replicaproeven {
    use super::*;
    use yrs::{Map,Text,Transact};
    #[test]
    fn twee_eigenaren_mutaties_en_externe_updates_blijven_exact() {
        let origineel=docx_edit::EditingDoc::new(77);origineel.keep_deleted();
        let basis=origineel.encode_state_as_update_v1();
        let mut a=ProefReplica::nieuw(&basis,1024*1024);
        let mut b=ProefReplica::nieuw(&basis,1024*1024);
        let tekst=a.doc.yrs_doc().get_or_insert_text("eigen proeftekst");
        let kaart=a.doc.yrs_doc().get_or_insert_map("eigen proefwaarden");
        for i in 0..20 {
            tekst.insert(&mut a.doc.yrs_doc().transact_mut(),0,"nieuwe woorden ");
            if i%2==0 {tekst.remove_range(&mut a.doc.yrs_doc().transact_mut(),0,2);}
            kaart.insert(&mut a.doc.yrs_doc().transact_mut(),"genest",Any::Array(Arc::from([Any::from(format!("waarde-{i}")),Any::Null])));
            for _ in 0..2 {assert_eq!(a.snapshot(),a.doc.encode_state_as_update_v1());}
            assert_eq!(b.snapshot(),basis,"Een andere eigenaar mag niet veranderen");
            assert!(a.cache.gebruikt<=a.cache.grens);
        }
        let peer=yrs::Doc::new();
        peer.transact_mut().apply_update(Update::decode_v1(&a.snapshot()).unwrap()).unwrap();
        peer.get_or_insert_text("eigen proeftekst").insert(&mut peer.transact_mut(),0,"extern ");
        let extern_bytes=peer.transact().encode_state_as_update_v1(&StateVector::default());
        a.doc.yrs_doc().transact_mut().apply_update(Update::decode_v1(&extern_bytes).unwrap()).unwrap();
        assert_eq!(a.snapshot(),a.doc.encode_state_as_update_v1());
        assert_eq!(b.snapshot(),basis);
        let nieuw=ProefReplica::nieuw(&a.snapshot(),1024*1024);
        assert_eq!(nieuw.cache.treffers,0,"Nieuwe bron krijgt een koude cache");
    }
}
