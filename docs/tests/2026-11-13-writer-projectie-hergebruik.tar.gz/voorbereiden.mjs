import fs from'node:fs';import path from'node:path';import ts from'typescript';import assert from'node:assert/strict';import crypto from'node:crypto';
const p='.local/integratiecontrole/projectie-hergebruik/',base='.local/integratiecontrole/font-hergebruik/bron/';const pins={};fs.mkdirSync(p+'modules',{recursive:true});
for(const [source,name]of [['packages/docx/src/yrs/sessionInternals.ts','sessionInternals'],['packages/docx/src/yrs/inputPositionMap.ts','inputPositionMap'],['packages/docx/src/yrs/yrsPositionProjection.ts','yrsPositionProjection'],['packages/docx-react/src/components/DocxEditor/internals/yrsStorySegmentCache.ts','yrsStorySegmentCache']]){
 const raw=fs.readFileSync(base+source,'utf8');pins[source]=crypto.createHash('sha256').update(raw).digest('hex');let out=ts.transpileModule(raw,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText.replaceAll("'./sessionInternals'","'./sessionInternals.mjs'").replaceAll("'./inputPositionMap'","'./inputPositionMap.mjs'").replaceAll("'../hooks/pageBuildScheduler'","'./pageBuildScheduler.mjs'");fs.writeFileSync(p+'modules/'+name+'.mjs',out);
}
fs.writeFileSync(p+'modules/pageBuildScheduler.mjs',"export function scheduleIdleWork(){return {cancel(){}}}\n");
const file='packages/docx-react/src/components/DocxEditor/PagedEditor.tsx',raw=fs.readFileSync(base+file,'utf8');pins[file]=crypto.createHash('sha256').update(raw).digest('hex');const tree=ts.createSourceFile(file,raw,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);let arrow;function walk(n){if(ts.isVariableDeclaration(n)&&n.name.getText(tree)==='getYrsPositionProjection'){assert(!arrow);arrow=n.initializer.arguments[0].getText(tree);}ts.forEachChild(n,walk);}walk(tree);assert(arrow);
let changed=arrow;function replace(a,b){assert.equal(changed.split(a).length-1,1,a);changed=changed.replace(a,b);}
replace('const cached = yrsPositionProjectionCacheRef.current;',`const cached = yrsPositionProjectionCacheRef.current;
        const projectionReady = !yrsCore.experimentalWorkerOpen || (yrsCore.replicaReadyRef?.current ?? yrsCore.replicaReady);
        const projectionGeneration = yrsCore.sessionGeneration;
        const currentSegmentSource = yrsStorySegmentsRef.current;`);
replace('cached.rootStory === rootStory\n        )','cached.rootStory === rootStory &&\n          cached.generation === projectionGeneration &&\n          cached.ready === projectionReady &&\n          cached.segmentSource === currentSegmentSource &&\n          !currentSegmentSource?.disposed &&\n          !yrsCore.opening && !yrsCore.previewing\n        )');
replace('const segments = currentStorySegments(session);',`if (cached && rootStory === 'body' && cached.rootStory === rootStory && cached.session === session &&
          yrsCore.experimentalWorkerOpen && projectionReady === true && cached.ready === true &&
          Number.isSafeInteger(projectionGeneration) && cached.generation === projectionGeneration &&
          cached.segmentSource === currentSegmentSource && currentSegmentSource?.session === session &&
          !currentSegmentSource.disposed && !yrsCore.opening && !yrsCore.previewing &&
          typeof cached.sourceVersion === 'string' && cached.sourceVersion === session.version()) {
          cached.version = yrsProjectionVersionRef.current;
          return cached.projection;
        }
        const segments = currentStorySegments(session);`);
replace('          rootStory,\n          projection,','          rootStory,\n          projection,\n          sourceVersion: session.version(),\n          generation: projectionGeneration,\n          ready: projectionReady,\n          segmentSource: segments,');
fs.writeFileSync(p+'callback-voor.ts',arrow+'\n');fs.writeFileSync(p+'callback-na.ts',changed+'\n');
for(const [name,code]of [['voor',arrow],['na',changed]]){let out=ts.transpileModule('const callback = '+code+';', {compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;fs.writeFileSync(p+'callback-'+name+'.js',out+'\nreturn callback;\n');}
fs.writeFileSync(p+'bronpinnen.json',JSON.stringify({bestanden:pins,idle:'Gecontroleerde planner;registreert geen echte browseridlewerkzaamheden. Overige vier modules uit ongewijzigde bron getranspileerd.'},null,2)+'\n');
