(rootStory: string): YrsPositionProjection | null => {
        const session = yrsCore.session;
        if (!session || !session.hasStory(rootStory)) return null;
        if (yrsCore.experimentalWorkerOpen) {
          const ready = yrsCore.replicaReadyRef?.current ?? yrsCore.replicaReady;
          if (projectionReplicaReadyRef.current !== ready) {
            projectionReplicaReadyRef.current = ready;
            yrsProjectionVersionRef.current += 1;
          }
        }
        const cached = yrsPositionProjectionCacheRef.current;
        if (
          cached?.version === yrsProjectionVersionRef.current &&
          cached.session === session &&
          cached.rootStory === rootStory
        ) {
          return cached.projection;
        }
        const segments = currentStorySegments(session);
        const projection = createYrsPositionProjection(session, rootStory, segments);
        segments.scheduleDigests();
        if (!projection) return null;
        yrsPositionProjectionCacheRef.current = {
          version: yrsProjectionVersionRef.current,
          session,
          rootStory,
          projection,
        };
        return projection;
      }
