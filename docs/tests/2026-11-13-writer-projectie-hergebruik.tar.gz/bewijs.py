from pathlib import Path
import hashlib, io, json, tarfile

r = Path.cwd()
p = r / '.local/integratiecontrole/projectie-hergebruik'
out = r / 'docs/tests'
label = '2026-11-13-writer-projectie-hergebruik'
read = lambda name: json.loads((p / name).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
rounds = read('native-ronden.json')
assert len(rounds) == 8 and all(x['geslaagd'] and x['code'] == 0 for x in rounds)
component = read('proef-geaccepteerde-kern.json')
assert component['geslaagd'] and len(component['corpus']) == 30
assert sum(len(x['stappen']) for x in component['corpus']) == 43
assert read('snelle-cache-grens.json')['geslaagd']
assert len(read('documenten-beelden.json')['documenten']) == 8
files = [f for f in sorted(p.rglob('*')) if f.is_file()
         and not set(f.relative_to(p).parts) & {'dist', 'standaarddist', '__pycache__'}
         and not f.name.startswith('open-office-studio')
         and f.name != 'PagedEditor-kandidaat.tsx']
manifest = {str(f.relative_to(p)): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in files}
archive = out / (label + '.tar.gz')
with tarfile.open(archive, 'w:gz', compresslevel=6) as t:
    for f in files:
        t.add(f, arcname=str(f.relative_to(p)), recursive=False)
    b = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json')
    info.size = len(b)
    t.addfile(info, io.BytesIO(b))
with tarfile.open(archive) as t:
    assert set(t.getnames()) == set(manifest) | {'manifest.json'}
    for name, item in manifest.items():
        b = t.extractfile(name).read()
        assert len(b) == item['bytes'] and hashlib.sha256(b).hexdigest() == item['sha256']
report = {
    'datum': '2026-11-13', 'basis_integratie': '27b3c6ac', 'basis_hoofdbranch': 'e1d03854',
    'productbron': '41e7000198f89d992e1059e9715636a44b39d21a',
    'besluit': 'Private hergebruikskandidaat verbetert beide rijke native ronden, maar wordt niet ongewijzigd overgenomen: tijdens opening/preview gaat de bestaande snelle cache verloren. Geen productfix of volledige snelheids-/stabiliteitsacceptatie.',
    'implementatie': 'Bestaande volledige bodyprojectie alleen na gewijzigde handmatige projectieteller hergebruiken bij gelijke sessie, generatie, gereedheid, segmentcache en bronversie; geen version()-lezing op huidige normale cachehits. Header en ontbrekende stories behouden oorspronkelijke route. Extra generation/ready/segment/opening/preview-voorwaarden op snelle hit en expliciete React-afhankelijkheden. Alleen editors-JS op geaccepteerde acb770-bundel gewijzigd; geen warm-route/R(k)/Wasm-wijziging.',
    'variant': {'desktop': read('desktop.json'), 'bundel': read('bundel.json'),
                'bronpinnen': read('bronpinnen.json'), 'diff_grenzen': read('diff-grenzen.json'),
                'platform': 'Linux x86_64 release2026.45.52, writer-bronjournaal, runtimeschema2; eigen X11/DBus/XDG-profielen en eigen fixtures.'},
    'component_geaccepteerde_kern': component,
    'component_private_kern': read('proef.json'),
    'afgekeurde_regelinvoer': read('afgekeurd-regelinvoer.json'),
    'afkeuring_uitleg': 'Eerste harness gebruikte raw edit_text_resident voor U+000B; die API weigert dat. Gecorrigeerde proef gebruikt echte insert_line_break. Geen kandidaatregressie uit deze harnessfout afgeleid; ruwe afkeuring behouden.',
    'snelle_cache_grens': read('snelle-cache-grens.json'),
    'native_abba': rounds,
    'documenten_en_beelden': read('documenten-beelden.json'),
    'pakketvergelijking': read('pakketvergelijking.json'),
    'beeldbeoordeling': read('beeldbeoordeling.json'),
    'behoud': read('behoud.json'), 'scriptcontroles': read('scriptcontroles.json'),
    'grenzen': [
        'Werkelijke volledige projectie en segmentcache uit vastgepinde bron, echte Rust/Wasm. Adapter storiesChangedSince invalideert alle stories bij versiewijziging; browseridle/digestplanner gecontroleerd uitgeschakeld. Geen volledige React/SDK-proef. Native Linux gebruikt wel echte adapter/planning.',
        'Negen rijke toestanden controleren alle node/target/blockBoundary-posities en alle locaties/offsets, tabellen, Unicode, emoji, combining, CJK, Arabisch en regelovergang. Corpus: alle nodeposities, alle locaties/offsets en targets elke31 plus aanwezige nodes. Exacte staat/versie en verwachte inferentie/fout behouden.',
        'Dertig corpusgevallen met43 echte updates omvatten onder meer structuur, opmaak, remote, meerdere auteurs, pending/reject en koptekst. Geen nieuwe uitputtende geneste/samengevoegde/gesplitste-tabellen-,handoff- of React-rerenderproef. Native Undo/Redo en selectie wel in alle8 ronden.',
        'ABBA zonder gelijktijdige bouw/componentproeven/profielopname. Wandklok vanaf fysieke verzending omvat wachttijd voor keyupontvangst; renderlijst+twee rAFs is geen fysieke schermpaint. Twee ronden per variant/corpus, geen algemene causale snelheidstoewijzing.',
        'Aanvullende grensproef toont bij opening=true en previewing=true elk16 constructies voor16 vragen zonder invalidatie, tegenover1 bij referentie. Dit is gecontroleerde componenttoestand, geen native openingbenchmark; kandidaat niet ongewijzigd accepteren.',
        'Acht DOCX onafhankelijk SHA/ZIP/CRC/alle XML/relaties/tabellen/UTF16 gecontroleerd. Binnen klein/rijk verschillen pakketleden uitsluitend in core.xml. Van18 vaste beeldparen10 pixelgelijk, andere verschillen ongewijzigd bewaard; drie geselecteerde beelden bekeken, geen volledige visuele acceptatie.'
    ],
    'niet_gecontroleerd': [
        'Geen productiepatch, SDK/vendorwijziging, volledige React-/TypeScript/frontend/Python-productsuite of product-CI. Linux-featurebouw en gerichte script/component/nativecontroles wel uitgevoerd.',
        'Geen Windows/macOS, installers, andere edities/features/schema/releasevarianten, volledige IME/accessibility/alle document- of visuele dekking.',
        'Bestaande geheugen-/RefCell-fouten en migratiegebieden blijven open. Geen issue gesloten.'
    ],
    'vervolg': 'Behoud ook tijdens opening/preview de bestaande snelle cache op een volledig gelijke context; sluit alleen het extra hergebruik na invalidatie uit. Toets herhaalde hits en overgangen zonder/met invalidatie, verse React-coreobjecten/dependencies en echte replica-/sessieoverdracht, plus geneste/gesplitste tabellen. Bouw vervolgens aparte gecorrigeerde kandidaat en herhaal native kort/rijk ABBA tegen acb770 vóór productie-integratie en volledige productsuites. Geen hoofdthread-Debugger. R(k)-correctie apart; Database laatst.',
    'bewijs': {'pad': str(archive.relative_to(r)), 'sha256': sha(archive),
               'bytes': archive.stat().st_size, 'bestanden': len(files),
               'alle_leden_byteexact_gecontroleerd': True,
               'uitsluiting': 'Geen ELF/Wasm/dist of volledige upstream PagedEditor. Wel gerichte diff/callbacks, vier getranspileerde echte modules, gecontroleerde idleplanner, scripts/logs/afkeuringen/corpusupdates/DOCX/PNG en bron-/bouw-/referentiepinnen.'}
}
(out / (label + '.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['bewijs']))
