const callback = (rootStory) => {
    const session = yrsCore.session;
    if (!session || !session.hasStory(rootStory))
        return null;
    if (yrsCore.experimentalWorkerOpen) {
        const ready = yrsCore.replicaReadyRef?.current ?? yrsCore.replicaReady;
        if (projectionReplicaReadyRef.current !== ready) {
            projectionReplicaReadyRef.current = ready;
            yrsProjectionVersionRef.current += 1;
        }
    }
    const cached = yrsPositionProjectionCacheRef.current;
    const projectionReady = !yrsCore.experimentalWorkerOpen || (yrsCore.replicaReadyRef?.current ?? yrsCore.replicaReady);
    const projectionGeneration = yrsCore.sessionGeneration;
    const currentSegmentSource = yrsStorySegmentsRef.current;
    if (cached?.version === yrsProjectionVersionRef.current &&
        cached.session === session &&
        cached.rootStory === rootStory &&
        cached.generation === projectionGeneration &&
        cached.ready === projectionReady &&
        cached.segmentSource === currentSegmentSource &&
        !currentSegmentSource?.disposed &&
        !yrsCore.opening && !yrsCore.previewing) {
        return cached.projection;
    }
    if (cached && rootStory === 'body' && cached.rootStory === rootStory && cached.session === session &&
        yrsCore.experimentalWorkerOpen && projectionReady === true && cached.ready === true &&
        Number.isSafeInteger(projectionGeneration) && cached.generation === projectionGeneration &&
        cached.segmentSource === currentSegmentSource && currentSegmentSource?.session === session &&
        !currentSegmentSource.disposed && !yrsCore.opening && !yrsCore.previewing &&
        typeof cached.sourceVersion === 'string' && cached.sourceVersion === session.version()) {
        cached.version = yrsProjectionVersionRef.current;
        return cached.projection;
    }
    const segments = currentStorySegments(session);
    const projection = createYrsPositionProjection(session, rootStory, segments);
    segments.scheduleDigests();
    if (!projection)
        return null;
    yrsPositionProjectionCacheRef.current = {
        version: yrsProjectionVersionRef.current,
        session,
        rootStory,
        projection,
        sourceVersion: session.version(),
        generation: projectionGeneration,
        ready: projectionReady,
        segmentSource: segments,
    };
    return projection;
};

return callback;
