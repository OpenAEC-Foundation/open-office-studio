from pathlib import Path
import json,hashlib
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();docs={};pixels=[]
for d in sorted(p.glob('native-*')):
 if not d.is_dir()or not(d/'rapport.json').exists():continue
 r=json.load(open(d/'rapport.json'));assert r['geslaagd'],d;f=d/'Ontwerpnotitie.docx';assert sha(f)==r['bewaring_sha256'];parts={}
 with ZipFile(f)as z:
  assert z.testzip()is None
  for n in z.namelist():
   data=z.read(n)
   if n.endswith(('.xml','.rels')):ET.fromstring(data)
   parts[n]=hashlib.sha256(data).hexdigest()
  root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(n.text or''for n in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2
  assert tables==r['bewaarde_tabellen_exact']
 docs[d.name]={'sha256':sha(f),'tabellen':tables,'utf16':units,'part_hashes':parts}
for kind in ['klein','rijk']:
 base=p/('native-'+kind+'-a-een')
 for label in ['b-een','b-twee','a-twee']:
  d=p/('native-'+kind+'-'+label)
  for n in ['invoer-redo.png','snel-getypt-bewaard.png','nieuw-na-laat-antwoord.png']:
   a=Image.open(base/n).convert('RGB');b=Image.open(d/n).convert('RGB');assert a.size==b.size;diff=ImageChops.difference(a,b);bbox=diff.getbbox();count=0 if bbox is None else sum(any(c)for c in diff.crop(bbox).getdata());pixels.append({'referentie':str((base/n).relative_to(p)),'vergeleken':str((d/n).relative_to(p)),'verschillende_pixels':count,'bbox':bbox})
r={'documenten':docs,'beelden':pixels,'gehele_beelden_exact':sum(x['verschillende_pixels']==0 for x in pixels),'grenzen':'Alleen drie vaste screenshots per functieronde. Bbox/pixels zonder wegmaskeren; geen algemene visual-/glyph-/platformacceptatie.'};(p/'documenten-beelden.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'docx':len(docs),'pixelparen':len(pixels),'exact':r['gehele_beelden_exact']}))
