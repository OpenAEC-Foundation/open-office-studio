(oe) => {
    const z = r.session;
    if (!z || !z.hasStory(oe))
        return null;
    if (r.experimentalWorkerOpen) {
        const ready = r.replicaReadyRef?.current ?? r.replicaReady;
        if (dn.current !== ready) {
            dn.current = ready;
            Mt.current += 1;
        }
    }
    const ce = Ot.current;
    const projectionReady = !r.experimentalWorkerOpen || (r.replicaReadyRef?.current ?? r.replicaReady);
    const projectionGeneration = r.sessionGeneration;
    const currentSegmentSource = Tt.current;
    if (ce?.version === Mt.current &&
        ce.session === z &&
        ce.rootStory === oe &&
        ce.generation === projectionGeneration &&
        ce.ready === projectionReady &&
        ce.segmentSource === currentSegmentSource &&
        !currentSegmentSource?.disposed &&
        !r.opening && !r.previewing) {
        return ce.projection;
    }
    if (ce && oe === 'body' && ce.rootStory === oe && ce.session === z &&
        r.experimentalWorkerOpen && projectionReady === true && ce.ready === true &&
        Number.isSafeInteger(projectionGeneration) && ce.generation === projectionGeneration &&
        ce.segmentSource === currentSegmentSource && currentSegmentSource?.session === z &&
        !currentSegmentSource.disposed && !r.opening && !r.previewing &&
        typeof ce.sourceVersion === 'string' && ce.sourceVersion === z.version()) {
        ce.version = Mt.current;
        return ce.projection;
    }
    const Re = A(z);
    const rt = uO(z, oe, Re);
    Re.scheduleDigests();
    if (!rt)
        return null;
    Ot.current = {
        version: Mt.current,
        session: z,
        rootStory: oe,
        projection: rt,
        sourceVersion: z.version(),
        generation: projectionGeneration,
        ready: projectionReady,
        segmentSource: Re,
    };
    return rt;
}
