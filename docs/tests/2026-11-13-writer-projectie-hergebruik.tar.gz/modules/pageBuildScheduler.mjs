export function scheduleIdleWork(){return {cancel(){}}}
