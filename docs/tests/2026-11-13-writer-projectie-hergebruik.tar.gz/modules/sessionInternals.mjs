/** Engine operations the package runs on sessions it creates itself; not public API. */
const registry = new WeakMap();
/** Returns the session's opened source package when available. @internal */
export function sessionSourcePackage(session) {
    return registry.get(session)?.sourcePackage() ?? null;
}
export function sessionMaterializedSource(session) {
    return registry.get(session)?.materializedSource() ?? session.materializeDocx?.() ?? null;
}
/** The opened source's note separator keys when available. @internal */
export function sessionSourceNoteSeparators(session) {
    return registry.get(session)?.sourceNoteSeparators() ?? null;
}
export function registerSessionInternals(session, internals) {
    registry.set(session, internals);
}
export function sessionInternals(session) {
    const internals = registry.get(session);
    if (!internals)
        throw new Error('the session was not created by createYrsSession');
    return internals;
}
/** @internal */
export function headerFooterStory(session, rId) {
    const canonical = session && registry.get(session)?.headerFooterAliases().get(rId);
    return `hf:${canonical || rId}`;
}
/** The relationship ids whose bands show `rId`'s story. @internal */
export function headerFooterDisplayRIds(session, rId) {
    return routedHeaderFooterRIds(registry.get(session)?.headerFooterAliases(), rId);
}
/** `rId`'s canonical relationship id and every alias `aliases` routes to it. @internal */
export function routedHeaderFooterRIds(aliases, rId) {
    const canonical = aliases?.get(rId) ?? rId;
    return [canonical, ...[...(aliases ?? [])].flatMap(([alias, owner]) => owner === canonical ? [alias] : [])];
}
