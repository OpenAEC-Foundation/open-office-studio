"""Bestaande native controles op de eigen desktopkandidaat; geen gebruikersprofiel."""
from pathlib import Path
import json,os,subprocess,time,hashlib
from voorbereiden import REPO,LOKAAL
m=json.loads((LOKAAL/'gebouwd.json').read_text());programma=Path(m['programma'])
assert hashlib.sha256(programma.read_bytes()).hexdigest()==m['programma_sha256']
assert json.loads((LOKAAL/'bouwacceptatie.json').read_text())['geslaagd']
gui=json.loads((LOKAAL/'gui/uitkomsten.json').read_text());assert len(gui)==4 and all(r['code']==0 for r in gui)
env=os.environ.copy();env['PATH']=str(REPO/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+str(Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin')+':'+env['PATH']
python=REPO/'.local/doorwerk-2026-11-02/gui-python/bin/python';uit=LOKAAL/'vervolg';uit.mkdir(exist_ok=False);resultaten=[]
for naam,script,args in [
 ('tekst-selectie','scripts/test-writer-rust-tekst-native.py',[]),
 ('lang-herstel','scripts/test-writer-lang-native.py',['--verwacht-rust-tekst','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--herstelstart','--geheugenrondes','20','--geheugen-gc','--workerbron','--verwacht-incrementele-bron']),
 ('rijk-plakken','scripts/test-writer-rijk-plakken-native.py',['--rondes','8','--bewaar-na-ronde','7','--maxduur','180','--vereis-rust-plakken']),
 ('bewaren-verwerpen','scripts/test-writer-rust-plakken-volgorde-native.py',[]),
 ('lijsten','scripts/test-writer-lijsten-native.py',[]),
]:
    cmd=[str(python),script,'--programma',str(programma),'--versie','2026.45.50','--uitvoer',str(uit/naam),*args]
    print('START',naam,flush=True);begin=time.monotonic()
    with (uit/(naam+'.log')).open('w')as log:p=subprocess.run(cmd,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    resultaten.append({'naam':naam,'code':p.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd,'script_sha256':hashlib.sha256((REPO/script).read_bytes()).hexdigest()});(uit/'rapport.json').write_text(json.dumps(resultaten,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
