use docx_edit::{EditingDoc, EditCtx, LocRange, Position, prepare_confirmed_clipboard_fragment_cached};
use serde_json::json;
use std::{time::Instant,hint::black_box};
fn main()->Result<(),Box<dyn std::error::Error>>{
 let root=std::path::PathBuf::from(std::env::args().nth(1).ok_or("Proefmap ontbreekt")?);
 let bytes=std::fs::read(root.join("bron.bin"))?;
 let doc=EditingDoc::new(3525307561);doc.keep_deleted();doc.apply_update_v1(&bytes)?;
 let source=doc.encode_state_as_update_v1();let vector=doc.encode_state_vector_v1();
 let at=doc.loc_at(&Position::new("body",0))?;
 let mut rows=Vec::new();
 for round in 0..24 {
  let t=Instant::now();let snapshot=black_box(doc.encode_state_as_update_v1());let snapshot_ns=t.elapsed().as_nanos();assert_eq!(snapshot,source);
  let t=Instant::now();let loc=doc.loc_at(&Position::new("body",0))?;let locate_ns=t.elapsed().as_nanos();assert_eq!(loc.story,at.story);assert_eq!(loc.para,at.para);assert_eq!(loc.offset,at.offset);
  rows.push(json!({"ronde":round,"bron_serialisatie_ns":snapshot_ns,"locatie_ns":locate_ns}));
 }
 assert_eq!(doc.encode_state_vector_v1(),vector);
 let mut cached=None;let mut base=None;let mut update=source.clone();let mut expected=vector.clone();let mut cursor=at;let mut batches=Vec::new();
 for round in 0..24 {
  let t=Instant::now();let result=prepare_confirmed_clipboard_fragment_cached(cached.take(),base.as_deref(),&update,3525307561,&expected,&LocRange{start:cursor.clone(),end:cursor.clone()},&json!({"paragraphs":[{"text":" proef"}]}),&EditCtx::local("", ""),64*1024*1024)?;let total=t.elapsed().as_nanos();
  let t=Instant::now();let full=prepare_confirmed_clipboard_fragment_cached(None,None,&doc.encode_state_as_update_v1(),3525307561,&expected,&LocRange{start:cursor.clone(),end:cursor.clone()},&json!({"paragraphs":[{"text":" proef"}]}),&EditCtx::local("", ""),64*1024*1024)?;let full_ns=t.elapsed().as_nanos();
  assert_eq!(full.snapshot,result.snapshot);assert_eq!(full.vector,result.vector);assert_eq!(full.batch.update,result.batch.update);assert_eq!(full.batch.caret.story,result.batch.caret.story);assert_eq!(full.batch.caret.para,result.batch.caret.para);assert_eq!(full.batch.caret.offset,result.batch.caret.offset);
  assert_eq!(result.reused,round!=0);
  assert_eq!(result.snapshot,doc.encode_state_as_update_v1());assert_eq!(result.vector,doc.encode_state_vector_v1());
  doc.apply_update_v1(&result.batch.update)?;
  expected=doc.encode_state_vector_v1();cursor=result.batch.caret;update=result.batch.update;base=Some(result.snapshot);cached=Some(result.replica);
  batches.push(json!({"ronde":round,"hergebruikt":round!=0,"voorbereiding_ns":total,"volledige_route_inclusief_frontendbron_ns":full_ns,"deltabytes":update.len()}));
 }
 println!("{}",serde_json::to_string_pretty(&json!({"bronbytes":source.len(),"lezingen":rows,"batches":batches,"bronbehoud":true}))?);Ok(())
}
