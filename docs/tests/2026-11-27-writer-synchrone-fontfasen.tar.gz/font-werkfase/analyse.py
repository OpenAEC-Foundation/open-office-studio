from pathlib import Path
import json,collections,statistics,hashlib,math
p=Path(__file__).resolve().parent;out={}
for name in ['native','native-met-transport']:
 d=json.loads((p/name/'rapport.json').read_text());assert d['geslaagd'];raw=d['fasen_eind'][0]['result']['result']['value'];assert raw['overgeslagen']==0;events=raw['regels'];tasks={};starts={};phases=collections.defaultdict(list)
 for e in events:
  kind=e['soort'];i=e['id']
  if kind in ['ontvangst','taak.begin','taak.einde']:
   key={'ontvangst':'ontvangst','taak.begin':'begin','taak.einde':'eind'}[kind];row=tasks.setdefault(i,{});assert key not in row;row[key]=e
  elif kind.endswith('.begin'):
   key=(kind[:-6],i);assert key not in starts;starts[key]=e
  elif kind.endswith('.einde'):
   key=(kind[:-6],i);begin=starts.pop(key);assert e['tijd']>=begin['tijd'];phases[key[0]].append({'id':i,'begin':begin['tijd'],'eind':e['tijd'],'ms':e['tijd']-begin['tijd']})
 assert not starts;assert all(set(t)=={'ontvangst','begin','eind'}for t in tasks.values());assert all(t['ontvangst']['tijd']<=t['begin']['tijd']<=t['eind']['tijd']for t in tasks.values());fonts=phases['font'];fonttasks={i:t for i,t in tasks.items()if t['begin']['type']=='fontRequirements'};assert len(fonttasks)==len(fonts);assert {x['id']for x in fonts}==set(fonttasks);assert all(fonttasks[x['id']]['begin']['tijd']<=x['begin']<=x['eind']<=fonttasks[x['id']]['eind']['tijd']for x in fonts)
 inner=d['binnen_eind'][0]['result']['result']['value'];assert inner['hersteld']and inner['overgeslagen']==0;sent={}
 for x in inner['regels']:
  if x['richting']=='verzending'and x.get('id')in fonttasks:assert x['id']not in sent;sent[x['id']]=x
 assert len(sent)==len(fonts)
 samples=[]
 for x in d['klok_voor']+d['klok_na']:
  w=x['werker']['result']['result']['value'];l=x['links'];rr=x['rechts'];assert l['now']<=rr['now'];samples.append({'offset_min_ms':l['now']-w['now'],'offset_max_ms':rr['now']-w['now'],'origin_delta_ms':w['origin']-l['origin']})
 lo=max(x['offset_min_ms']for x in samples);hi=min(x['offset_max_ms']for x in samples);assert lo<=hi;assert all(lo<=x['origin_delta_ms']<=hi for x in samples)
 rows=[]
 for f in fonts:
  t=fonttasks[f['id']];rows.append({**f,'worker_ontvangst':t['ontvangst']['tijd'],'taak_begin':t['begin']['tijd'],'taak_eind':t['eind']['tijd'],'antwoord_verzonden':sent[f['id']]['tijd'],'interne_wacht_ms':t['begin']['tijd']-t['ontvangst']['tijd'],'taak_ms':t['eind']['tijd']-t['begin']['tijd']})
 result={'geslaagd':True,'fontaantal':len(fonts),'font_synchroon_ms':{'som':sum(x['ms']for x in fonts),'mediaan':statistics.median(x['ms']for x in fonts),'min':min(x['ms']for x in fonts),'max':max(x['ms']for x in fonts)},'fonttaak_ms_som':sum(x['taak_ms']for x in rows),'interne_wacht_ms_som':sum(x['interne_wacht_ms']for x in rows),'taaktypen':dict(collections.Counter(t['begin']['type']for t in tasks.values())),'alle_taken':tasks,'fontvensters':rows,'klokinterval':{'offset_min_ms':lo,'offset_max_ms':hi,'breedte_ms':hi-lo,'samples':samples},'lange_invoer_diagnostisch':d['lange_invoer']}
 if 'transport_eind'in d:
  tr=d['transport_eind'];assert tr['hersteld']and tr['overgeslagen']==0;mainfonts=[x for x in tr['regels']if x.get('richting')=='verzending'and x.get('type')=='fontRequirements'];assert len(mainfonts)==len(fonts);assert len({x['werker']for x in mainfonts})==1;byid={x['id']:x for x in mainfonts};assert set(byid)==set(fonttasks);replies={x['id']:x for x in tr['regels']if x['richting']=='ontvangst'and x.get('requirements')};assert set(replies)==set(fonttasks);inputs={x['layoutInput']for x in mainfonts};assert len(inputs)==1;inp=next(iter(inputs));assert '"reservationSets"'not in inp;assert len(inp)==1634
  for row in rows:
   send=byid[row['id']]['tijd'];recv=replies[row['id']]['tijd'];row['main_send']=send;row['main_antwoord']=recv;row['rondreis_ms']=recv-send;row['voor_worker_ontvangst_interval_ms']=[row['worker_ontvangst']+lo-send,row['worker_ontvangst']+hi-send];row['na_worker_antwoord_interval_ms']=[recv-row['antwoord_verzonden']-hi,recv-row['antwoord_verzonden']-lo]
  start=d['invoer_start_klok'];frame=start+d['lange_invoer']['begin_tot_frame_ms'];last=max(x['eind']for x in rows);result['input']={'tekens':len(inp),'sha256':hashlib.sha256(inp.encode()).hexdigest(),'reservationSets_aanwezig':False};result['rondreis_ms_som']=sum(x['rondreis_ms']for x in rows);result['voor_worker_ontvangst_ms_som_interval']=[sum(x['voor_worker_ontvangst_interval_ms'][0]for x in rows),sum(x['voor_worker_ontvangst_interval_ms'][1]for x in rows)];result['na_worker_antwoord_ms_som_interval']=[sum(x['na_worker_antwoord_interval_ms'][0]for x in rows),sum(x['na_worker_antwoord_interval_ms'][1]for x in rows)];result['laatste_font_tot_renderdetectie_ms_interval']=[frame-last-hi,frame-last-lo]
 out[name]=result
(p/'analyse.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:{x:v[x]for x in ['fontaantal','font_synchroon_ms','fonttaak_ms_som','interne_wacht_ms_som','klokinterval']if x!='klokinterval'} for k,v in out.items()}));print(json.dumps({k:out['native-met-transport'][k]for k in ['voor_worker_ontvangst_ms_som_interval','na_worker_antwoord_ms_som_interval','laatste_font_tot_renderdetectie_ms_interval','rondreis_ms_som','input']}))
