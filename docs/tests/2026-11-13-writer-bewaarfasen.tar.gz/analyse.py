from pathlib import Path
import json,hashlib,collections
from zipfile import ZipFile
from xml.etree import ElementTree as ET
p=Path(__file__).resolve().parent
uit={}
for naam in ['opname','opname-refscan']:
 q=p/naam
 if not (q/'rapport.json').exists():continue
 r=json.load(open(q/'rapport.json'));t=r.get('publicatietijdlijn',{});regels=t.get('regels',[])
 fases=[]
 for x in regels:
  if x['soort'].startswith(('api.','geregistreerd.')):fases.append({**x,'duur_ms':x['einde']-x['begin']})
 doc=q/'Ontwerpnotitie.docx'
 with ZipFile(doc) as z:
  assert z.testzip() is None
  xml=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
  teksten=''.join(x.text or '' for x in xml.findall('.//w:t',ns));tabellen=len(xml.findall('.//w:tbl',ns))
  assert tabellen==128 and len(teksten.encode('utf-16-le'))//2==91423
  assert hashlib.sha256(doc.read_bytes()).hexdigest()==r['bewaring_sha256']
 uit[naam]={'geslaagd':r['geslaagd'],'invoer':r['lange_invoer'],'fases':fases,'probe':{k:v for k,v in t.items() if k not in ['regels','leesgroepen','aanroepers']},'tellingen':dict(collections.Counter(x['soort'] for x in regels)),'docx':{'sha256':r['bewaring_sha256'],'tabellen':tabellen,'tekens_utf16':len(teksten.encode('utf-16-le'))//2},'stappen':r['stappen']}
(p/'analyse.json').write_text(json.dumps(uit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(uit,ensure_ascii=False,indent=2))
