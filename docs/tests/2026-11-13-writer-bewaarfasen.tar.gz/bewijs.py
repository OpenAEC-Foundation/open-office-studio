from pathlib import Path
import hashlib,json,stat,tarfile
p=Path(__file__).resolve().parent;repo=p.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
refs=json.load(open(repo/'.local/integratiecontrole/bewaar-groepen/referenties-nacontrole.json'))
refs[str(repo/'.local/integratiecontrole/bewaar-groepen/open-office-studio-bewaar-groepen')]='b6162e59e9c2dfdfcb98eb85d1b731ba52d2d4ee97f3a6429b6106a6127c3421'
for f,h in refs.items():assert sha(Path(f))==h,f
bundel=json.load(open(repo/'.local/integratiecontrole/bewaar-groepen/standaardbundel.json'))
for f,v in bundel.items():
 q=repo/'dist'/f;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],f
assert len([x for x in (repo/'dist').rglob('*') if x.is_file()])==len(bundel)
sdk=repo/'node_modules/@betteroffice/docx-react/dist/index.mjs';assert sha(sdk)=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
(p/'behoud.json').write_text(json.dumps({'referenties':refs,'standaardbundel_exact':len(bundel),'sdk_sha256':sha(sdk),'geen_productwijziging':True},indent=2)+'\n')
for f in ['src/editors.tsx','src/tekst/info/opslaan.ts','src/tekst/info/docprops.ts']:
 (p/Path(f).name).write_bytes((repo/f).read_bytes())
(p/'wachtrij-probe.js').write_bytes((repo/'.local/integratiecontrole/adaptieve-invoer/wachtrij-probe.js').read_bytes())
archive=repo/'docs/tests/2026-11-13-writer-bewaarfasen.tar.gz'
files=[f for f in p.rglob('*') if f.is_file()]
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(files):t.add(f,arcname=f.relative_to(p),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(files)
 for m in members:assert m.isfile() and sha(p/m.name)==hashlib.sha256(t.extractfile(m).read()).hexdigest()
anal=json.load(open(p/'analyse.json'))
r={'datum':'2026-11-13','basis_integratie':'a3c051fb79e06bb206820a8fec7f50d4aad878c5','productbron':'41e7000198f89d992e1059e9715636a44b39d21a','programma_sha256':'acb77036935feed425b7c81a5dbd2ef796ffcb4307db96c9845aa6dd8b70c958','besluit':'Diagnose afgerond, geen productfix. SDK-save is in deze opname het grootste verstreken bewaarvenster; werkEigenschappenBij is niet de volledige oorzaak. Geen issue/migratie/platform/releaseacceptatie.','metingen':anal,'uitsplitsing_ms':{'voor_eerste_flush':204,'eerste_flush':195,'sdk_save':3133,'na_sdk_save_tot_bewaarresultaat':782,'geregistreerd_totaal':4314,'na_bewaarresultaat_tot_renderlijst_plus_twee_raf':860,'test_flush_binnen_sdk_venster':377},'lezingen':{'sdk_venster':{'alineas':1,'storylezingen':50,'story_synchroon_ms':120},'na_sdk_venster':{'alineas':769,'synchroon_ms':600,'eerste_ms':34499,'laatste_ms':35107}},'grenzen':['Twee diagnostische native Linux schema-2-functieronden op eigen kopie, geen onbeïnvloede snelheidsvergelijking.','Eerste probe volgt openbare API-refs maar mist werkelijk gebruikte save/flushref. Alleen geregistreerd totaal 4134ms gemeten; niet als volledige fase-uitsplitsing geteld. Tweede volgt ook bewaarrefs uit React-ouders; 72refs, geen grensoverschrijding, alle wrappers hersteld.','SDK-save omvat wachten, nieuwe invoer en renderwerk; de afzonderlijke test-flush van377ms overlapt dat venster en mag niet worden opgeteld. Geen exclusieve CPU-tijden.','782ms na SDK-save omvat eigenschapswerk, 769 alinealezingen en scheduling. ZIP/XML niet afzonderlijk geïsoleerd; adoptie niet apart gemeten.','Promise-identiteit/this/argumenten/uitzonderingen behouden; extra Promise-settleobserver kan microtasks en rejectionboekhouding beïnvloeden.','Samplertijden niet geschikt voor CPU-tijdlijn; eerdere nul-timestampbeperking blijft gelden.','18 actuele transparantie-/opruim-/grenscontroles groen. Geen volledige frontend/TS/Python/build/CI opnieuw: uitsluitend private diagnose en bewijsdocs, productbron ongewijzigd.','Beide DOCX onafhankelijk SHA/ZIP/CRC/XML gecontroleerd:128tabellen/91423UTF16. Tweede bewaarbeeld bekeken: documenttekst/tabellen/lint zichtbaar; geen volledige65pagina- of pixelacceptatie.'],'behoud':json.load(open(p/'behoud.json')),'vervolg':'Meet binnen de werkelijk gebruikte SDK-save-ref de interne flush/worker-save/metadata/adoptiegrenzen op dezelfde acb770, zonder extra enginelezingen. Scheid wachttijd van synchroon werk; source-/versie-/bewaargrenzen behouden. Pas daarna gerichte wijziging met vaste korte/rijke ABBA-ronden. Geheugenfouten en tien migratiegebieden blijven open, Database laatst.','bewijs':{'pad':str(archive.relative_to(repo)),'sha256':sha(archive),'bytes':archive.stat().st_size,'reguliere_leden':len(files),'alle_leden_byteexact_gecontroleerd':True}}
(repo/'docs/tests/2026-11-13-writer-bewaarfasen.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r['bewijs']))
