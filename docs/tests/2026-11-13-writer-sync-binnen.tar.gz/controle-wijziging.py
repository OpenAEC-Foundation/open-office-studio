from pathlib import Path
import json,gzip,hashlib
p=Path(__file__).resolve().parent;before=gzip.decompress((p/'werker-voor.js.gz').read_bytes()).decode();after=gzip.decompress((p/'werker-na.js.gz').read_bytes()).decode();s=before
for x in json.load(open(p/'wijzigingen.json')):assert s.count(x['voor'])==1;s=s.replace(x['voor'],x['na'],1)
assert s==after==(p/'dist/assets/chunk-Q7OC7M5Q-BzppsI5m.js').read_text();r={'vier_vervangingen_exact':True,'voor_sha256':hashlib.sha256(before.encode()).hexdigest(),'na_sha256':hashlib.sha256(after.encode()).hexdigest(),'geen_verdere_js_verandering':True};(p/'wijzigingscontrole.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
