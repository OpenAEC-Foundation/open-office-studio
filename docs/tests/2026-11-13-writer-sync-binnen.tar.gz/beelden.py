from pathlib import Path
import json
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent;baseline=p.parent/'replica-kosten/native-b-een';out=[]
for a,b in [(p/'opname',p/'herhaling'),(baseline,p/'opname'),(baseline,p/'herhaling')]:
 for n in ['invoer-redo.png','snel-getypt-bewaard.png','nieuw-na-laat-antwoord.png']:
  x=Image.open(a/n).convert('RGB');y=Image.open(b/n).convert('RGB');assert x.size==y.size;d=ImageChops.difference(x,y);box=d.getbbox();count=0 if box is None else sum(any(c)for c in d.crop(box).getdata());out.append({'referentie':str((a/n).relative_to(p.parent)),'vergeleken':str((b/n).relative_to(p.parent)),'bbox':box,'verschillende_pixels':count})
r={'paren':out,'exact':sum(x['verschillende_pixels']==0 for x in out),'grens':'Gehele beelden zonder maskers;drie vaste momenten,geen volledige visuele acceptatie.'};(p/'beelden.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
