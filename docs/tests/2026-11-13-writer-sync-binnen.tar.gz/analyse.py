from pathlib import Path
import json,hashlib,collections,statistics
from zipfile import ZipFile
from xml.etree import ElementTree as ET
p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();out={};docs={}
for name in ['opname','herhaling']:
 r=json.load(open(p/name/'rapport.json'));assert r['geslaagd']and r['schema']==2 and all(not v for v in r['fouten'].values());raw=r['fasen_eind'][0]['result']['result']['value'];assert raw['overgeslagen']==0;beg={};spans=collections.defaultdict(list)
 for x in raw['regels']:
  if x['soort'].endswith('.begin'):k=(x['soort'][:-6],x['id']);assert k not in beg;beg[k]=x
  elif x['soort'].endswith('.einde'):
   k=(x['soort'][:-6],x['id']);b=beg.pop(k);spans[k[0]+'/'+str(x['type'])].append({'id':x['id'],'begin':b['tijd'],'eind':x['tijd'],'ms':x['tijd']-b['tijd']})
 assert not beg
 parents={x['id']:x for x in spans['taak/sync']};children={};residual=[]
 for id,par in parents.items():
  parts=[]
  for phase in ['sync.fg','sync.ea','sync.frame','sync.reply']:
   rows=[x for x in spans[phase+'/sync']if x['id']==id];assert len(rows)==1,(name,id,phase);x=rows[0];assert par['begin']<=x['begin']<=x['eind']<=par['eind'];parts.append(x)
  parts.sort(key=lambda x:x['begin']);assert all(x['eind']<=y['begin']for x,y in zip(parts,parts[1:]));children[id]=parts;residual.append({'id':id,'ms':par['ms']-sum(x['ms']for x in parts)})
 assert all(x['ms']>=-0.000001 for x in residual)
 stats={k:{'aantal':len(v),'som_ms':sum(x['ms']for x in v),'mediaan_ms':statistics.median(x['ms']for x in v),'min_ms':min(x['ms']for x in v),'max_ms':max(x['ms']for x in v)}for k,v in spans.items()};total=stats['taak/sync']['som_ms']
 for k,v in stats.items():
  if k.startswith('sync.'):v['deel_sync_procent']=v['som_ms']/total*100
 doc=p/name/'Ontwerpnotitie.docx';assert sha(doc)==r['bewaring_sha256'];parts={}
 with ZipFile(doc)as z:
  assert z.testzip()is None
  for n in z.namelist():
   data=z.read(n)
   if n.endswith(('.xml','.rels')):ET.fromstring(data)
   parts[n]=hashlib.sha256(data).hexdigest()
  root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};text=''.join(x.text or''for x in root.findall('.//w:t',ns));tables=len(root.findall('.//w:tbl',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128==r['bewaarde_tabellen_exact']and units==91423
 docs[name]={'sha256':sha(doc),'tabellen':tables,'utf16':units,'pakketdelen':parts};out[name]={'geslaagd':True,'runtime_wasm':r['runtime_wasm'],'invoer':r['lange_invoer'],'sommen':stats,'fasen':dict(spans),'residu':residual,'residu_som_ms':sum(x['ms']for x in residual),'kindfasen_eenmaal_binnen_sync_en_zonder_overlap':True,'geen_logverlies':True,'fouten':r['fouten']}
base=docs['opname']['pakketdelen']
for n,d in docs.items():d['verschillende_pakketdelen_vs_opname']=[k for k in set(base)|set(d['pakketdelen'])if base.get(k)!=d['pakketdelen'].get(k)]
result={'ronden':out,'documenten':docs,'grenzen':'Klokken zijn verstreken Worker-tijd,geen exclusieve CPU. Ea bevat ook hydratatie/media/fonts/bronvoorbereiding/selectie;geen bewijs welk intern onderdeel domineert. Frameklok omvat Oa(extras) en frame-API. Fg is de buitenste fontbasiscontrole;0ms is onder meetresolutie,geen bewijs van nulwerk. Niet bovenliggende taak en kindfasen optellen.'};(p/'analyse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for n,v in out.items():print(n,{k:(x['aantal'],round(x['som_ms'],2),round(x.get('deel_sync_procent',0),2))for k,x in v['sommen'].items()if k.startswith('sync.')or k=='taak/sync'},'residu',v['residu_som_ms'])
