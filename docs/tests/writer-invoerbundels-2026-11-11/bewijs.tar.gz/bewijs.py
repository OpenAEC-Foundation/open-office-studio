from pathlib import Path
from zipfile import ZipFile
from PIL import Image,ImageChops
import json,hashlib,subprocess,tarfile
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-coalesceren';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();verwacht=' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.'
status=subprocess.check_output(['git','status','--porcelain'],text=True);assert all(l in ['?? docs/tests/2026-11-11-writer-invoerbundels.json','?? docs/tests/writer-invoerbundels-2026-11-11/'] for l in status.splitlines())
resultaten={}
for naam,pad in [('referentie2',u/'referentie2'),('kandidaat2',u/'kandidaat2'),('diagnose16',u/'diagnose16'),('kandidaat3_zonder_vertraging',r/'.local/integratiecontrole/journaal-profiel/kandidaat3')]:
 x=json.loads((pad/'rapport.json').read_text());assert x['geslaagd'] and x['bewaarde_tabellen_exact']==128 and len(x['stappen'])==3 and not any(x['fouten'].values())
 aanvragen=[];tekst=''
 for m in x['native_opdrachten']:
  if len(tekst)==len(verwacht):break
  aanvragen.append(m)
  if m.get('caret'):tekst+=m['text']
 assert tekst==verwacht
 vertraging=16 if naam=='diagnose16' else 0
 assert all(m['vertragingMs']==vertraging and m['gereed'] and m['bronbinding'] for m in aanvragen)
 resultaten[naam]={'programma_sha256':x['programma_sha256'],'script_sha256':x['script_sha256'],'schema':x['schema'],'antwoordvertraging_ms':vertraging,'meting':x['lange_invoer'],'gewone_invoer_ipc_aanvragen':len(aanvragen),'gewone_invoer_voorstellen_met_caret':sum(bool(m.get('caret')) for m in aanvragen),'gewone_invoer_zonder_caret':sum(not m.get('caret') for m in aanvragen),'undo_groepen':x['undo_groepen_lange_invoer'],'bewaarde_tabellen_exact':128,'stappen':x['stappen'],'fouten':x['fouten']}
# Eerdere native3vergelijking compleet meeleveren, inclusief één volledig-bronverzoek.
import shutil
shutil.copytree(r/'.local/integratiecontrole/journaal-profiel/kandidaat3',u/'vorige-kandidaat3',dirs_exist_ok=True)
beelden={}
for naam in ['invoer-redo','snel-getypt-bewaard','nieuw-na-laat-antwoord']:
 a=Image.open(u/'kandidaat2'/(naam+'.png')).convert('RGB');b=Image.open(u/'referentie2'/(naam+'.png')).convert('RGB');d=ImageChops.difference(a,b);beelden[naam]={'bbox':d.getbbox(),'afwijkende_pixels':sum(v!=(0,0,0) for v in d.getdata())}
with ZipFile(u/'kandidaat2/Ontwerpnotitie.docx') as a,ZipFile(u/'referentie2/Ontwerpnotitie.docx') as b:
 assert set(a.namelist())==set(b.namelist());pakket={'onderdelen':len(a.namelist()),'verschillend':[n for n in a.namelist() if a.read(n)!=b.read(n)]};assert a.read('word/document.xml')==b.read('word/document.xml')
ci={}
for naam in ['linux-dev','desktop-ci']:
 x=json.loads((u/(naam+'.json')).read_text());assert x['conclusion']=='success' and x['headSha']=='0a43e8c603d8f7053081a23f7c78d268f8bae91c';ci[naam]={'bron':x['headSha'],'uitslag':x['conclusion'],'taken':[{k:j[k] for k in ['name','conclusion']} for j in x['jobs']]}
(u/'vergelijking.json').write_text(json.dumps({'resultaten':resultaten,'beelden':beelden,'pakket':pakket},indent=2))
d=r/'docs/tests/writer-invoerbundels-2026-11-11';d.mkdir(parents=True,exist_ok=True);a=d/'bewijs.tar.gz';leden={}
with tarfile.open(a,'w:gz') as t:
 for p in u.rglob('*'):
  if p.is_file() and p.suffix in ['.py','.json','.log','.png','.docx']:
   n=str(p.relative_to(u));t.add(p,arcname=n);leden[n]=sha(p)
 p=r/'scripts/test-writer-rijk-invoer-native.py';t.add(p,arcname='bron/'+p.name);leden['bron/'+p.name]=sha(p)
with tarfile.open(a,'r:gz') as t:
 for n,h in leden.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
rapport={'datum':'2026-11-11','appbron':'0a43e8c603d8f7053081a23f7c78d268f8bae91c','geen_productwijziging':True,'methode':'Eigen rijke128tabellen/65pbron,1052fysiekeASCII-tekens2msinterval. Opeenvolgende eigen Xvfb/DBus-profielen. Verse omgekeerde vergelijking: eerst referentie16f, daarna tabelpaginakandidaat7af. Daarna dezelfde7afELF/schema3 met uitsluitend16mskunstmatige antwoordvertraging; geen product- of SDK-bestand aangepast.','resultaten':resultaten,'conclusie_gewone_route':'Omgekeerd paar:27078msreferentie tegenover26327mskandidaat, circa2,8%korter; eerderepaar28345/24325ms. Geen vaste14%winst of statistische acceptatie. Ernstige vertraging blijft open.','conclusie_diagnose':'Met kunstmatig16mslater terugbezorgen van echte antwoorden:167nativeaanvragen en28593ms, tegenover309aanvragen en42899msin eerdere ongestoorde schema3proef. Dit ondersteunt verder onderzoek naar batching/publicatiefrequentie. Geen causale scheiding van alle hoofdthread-/werkerkosten, geen productversnelling geclaimd.','telling':'Gewone invoer afgezonderd vóór de latere vastgehouden-antwoordenproeven. Voorstellen met caret reconstrueren exact1052tekens. In het ongestoorde schema3geval staat één antwoord zonder caret vóór een opnieuw aangeboden tekstdeel; beide requests meegeteld, tekst niet dubbelgeteld. Aanvragen niet als bewezen toegepaste mutaties gelabeld.','behoud':'Alle positieve rondes slagen op exact herstel van storySegments/Undo/Redo,128bewaarde tabelXML-structuren, nativebindings, selecteren/vervangen/bewaren tijdens vastgehouden antwoord en verwerpen met laat antwoord.','visueel':'Diagnose16-invoerbeeld bekeken: tekst met EINDEPROEF en tabellen leesbaar; geen volledige pixelacceptatie.','pakketvergelijking':pakket,'beelden':beelden,'ci':ci,'linux_download':{'run':43087891072,'url':'https://github.com/OpenAEC-Foundation/open-office-studio/actions/runs/43087891072','artifact':'Open-Office-Studio-Dev-Linux-x86_64-56','artifact_id':13889111351,'artifact_bytes':154578898,'uitpakken':'Download de artifactZIP in GitHub; pak ZIP en meegeleverd tar.gz uit. Start ./start-dev.sh zonder sudo; indien FUSE ontbreekt APPIMAGE_EXTRACT_AND_RUN=1 ./start-dev.sh. Lees ook de meegeleverde instructies.','scope':'CI bouwde de werkelijke AppImage, controleerde en verpakte die met een eigen dev-profiel en updater uitgeschakeld. AppRun-controle volgens de geslaagde workflow en huidige scripts/verpak-dev-linux.py; FUSE-mount niet als gecontroleerd geclaimd. Geen nieuwe stabiele release.','lokale_download_grens':'Twee pogingen het aparte GUI-bewijsartifact13888986698 te downloaden gavenHTTP502. --log van de run gaf0bytes. Geen lokaal gedownloade AppImage of GUI-archive als geverifieerd geclaimd; CI-uitslag en artifactmetadata wel viaAPI gecontroleerd.'},'grenzen':['Eén nieuw paar en één16msdiagnose; onvoldoende voor algemene snelheids- of volledige functieacceptatie.','Kunstmatige transportwachttijd mag niet als productoptimalisatie worden uitgebracht op basis van deze proef. Onderzoek bundelen vóór werktoelating, met expliciete flush en correcte sessieafhandeling.','Nieuwe software, voorkeuren, gebruikersdocumenten en geïnstalleerde app niet gewijzigd. Experimentele journaalroute blijft uit.','Beelden ongecorrigeerd vermeld; geen volledige pixel-, platform-GUI-,7editie- of Rust-migratieacceptatie.'], 'volgende_stap':'Prototypeer begrensd bundelen bij de bestaande SDK-invoerwachtrij vóór het nemen van de batchtekst; normale typinglatency apart bewaken. Queue telt reeds pending zodat flush/Save/selection/close wachten. Na wachten eigenaar/sessie opnieuw controleren en oude batchreferentie opruimen. Geen rAF-wacht gebruiken die verborgen tabs kan ophouden. Bewaak eerste/laatste fysieke invoertijd, IME/Unicodepad, pauzegrenzen, selectie-/verwerp/lateantwoorden. Eerst betekenisvolle extracted-queue-tests, dan rijke/fysieke native vergelijking op2/3 en kleine-doclatency.','bewijs':{'pad':str(a.relative_to(r)),'sha256':sha(a),'bytes':a.stat().st_size,'leden':len(leden)}}
(r/'docs/tests/2026-11-11-writer-invoerbundels.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'beelden':beelden,'pakket':pakket,'bewijs':rapport['bewijs']}))
