from pathlib import Path
import os,json,time,subprocess
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-coalesceren';p=u/'kandidaat2/rapport.json'
for _ in range(950):
 if p.exists():break
 time.sleep(1)
assert json.loads(p.read_text())['geslaagd']
env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];env['OFFICE_TEST_JOURNAAL']='1'
with (u/'diagnose16.log').open('w') as log:p=subprocess.run(['/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python',str(u/'proef-antwoord16.py'),'--programma',str(r/'.local/integratiecontrole/journaal-profiel/open-office-studio-tabelpagina'),'--uitvoer',str(u/'diagnose16'),'--versie','2026.45.52'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450)
x=json.loads((u/'diagnose16/rapport.json').read_text());print('diagnose16',p.returncode,x.get('lange_invoer'),len(x.get('native_opdrachten',[])),x.get('fout'),flush=True);assert p.returncode==0 and x['geslaagd']
