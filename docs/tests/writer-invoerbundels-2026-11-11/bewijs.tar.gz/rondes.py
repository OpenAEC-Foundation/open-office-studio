from pathlib import Path
import os,json,subprocess
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-coalesceren';env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH'];env['OFFICE_TEST_JOURNAAL']='0';python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python'
for naam,rel in [('referentie2','.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal'),('kandidaat2','.local/integratiecontrole/journaal-profiel/open-office-studio-tabelpagina')]:
 with (u/(naam+'.log')).open('w') as log:p=subprocess.run([python,str(r/'scripts/test-writer-rijk-invoer-native.py'),'--programma',str(r/rel),'--uitvoer',str(u/naam),'--versie','2026.45.52'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450)
 x=json.loads((u/naam/'rapport.json').read_text());print(naam,p.returncode,x.get('lange_invoer'),flush=True);assert p.returncode==0 and x['geslaagd']
