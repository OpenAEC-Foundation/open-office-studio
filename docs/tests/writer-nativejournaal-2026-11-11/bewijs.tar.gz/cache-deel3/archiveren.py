from pathlib import Path
import gzip,hashlib,json,os,shutil,stat,time
r=Path.cwd();d=r/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release';u=r/'.local/cargo-cache-archief-2026-11-11-deel3';rij=[]
for p in (d/'deps').glob('open_office_studio-*'):
 s=p.stat();pin=d/'.fingerprint'/p.name.replace('open_office_studio-','open-office-studio-')/'bin-open-office-studio.json'
 if p.is_file() and not p.is_symlink() and s.st_size>90_000_000 and s.st_nlink==1 and pin.exists():rij.append((s.st_mtime,p,pin))
uit=[]
for _,p,pin in sorted(rij)[:22]:
 if shutil.disk_usage(r).free<200*1024**2:raise RuntimeError('Te weinig werkruimte voor verliesloos archiveren')
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:
    assert (proc/'exe').resolve()!=p.resolve(),'Cachebinary draait nog'
    assert str(p) not in (proc/'maps').read_text(),'Cachebinary is nog gemapt'
   except (PermissionError,FileNotFoundError,ProcessLookupError):pass
 s=p.stat();digest=hashlib.sha256();a=u/(p.name+'.gz');assert not a.exists()
 with p.open('rb') as bron,gzip.open(a,'wb',compresslevel=6) as doel:
  while b:=bron.read(1024**2):digest.update(b);doel.write(b)
 h=hashlib.sha256()
 with gzip.open(a,'rb') as f:
  while b:=f.read(1024**2):h.update(b)
 assert h.hexdigest()==digest.hexdigest();nu=p.stat();assert (nu.st_ino,nu.st_size,nu.st_mtime_ns,nu.st_nlink)==(s.st_ino,s.st_size,s.st_mtime_ns,1)
 v={'cachepad':str(p.relative_to(r)),'archief':str(a.relative_to(r)),'bytes':s.st_size,'archief_bytes':a.stat().st_size,'sha256':h.hexdigest(),'modus':stat.S_IMODE(s.st_mode),'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'cargo_fingerprint':str(pin.relative_to(r)),'fingerprint_sha256':hashlib.sha256(pin.read_bytes()).hexdigest(),'teruggelezen_bytehash_gelijk':True};uit.append(v);(u/'manifest.json').write_text(json.dumps({'uitsluitend_eigen_cargo_cache':True,'broncode_rlibs_gebruikersdata_en_ref_elFs_buiten_cache_niet_gewijzigd':True,'bestanden':uit,'vrije_gib':shutil.disk_usage(r).free/1024**3},indent=2));p.unlink();print(len(uit),p.name,round(shutil.disk_usage(r).free/1024**3,2),flush=True)
