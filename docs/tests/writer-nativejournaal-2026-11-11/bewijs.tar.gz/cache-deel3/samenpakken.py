from pathlib import Path
import json,subprocess,tarfile,gzip,hashlib,shutil
r=Path.cwd();u=r/'.local/cargo-cache-archief-2026-11-11-deel3';j=json.loads((u/'manifest.json').read_text());(u/'manifest-gzip.json').write_text(json.dumps(j,indent=2));a=u/'oude-bouwcache.tar.zst';assert not a.exists();p=subprocess.Popen(['/usr/bin/zstd','--long=27','-12','-T1','-o',str(a)],stdin=subprocess.PIPE,stderr=(u/'zstd.log').open('w'),start_new_session=True)
with tarfile.open(fileobj=p.stdin,mode='w|') as t:
 for v in j['bestanden']:
  info=tarfile.TarInfo(Path(v['cachepad']).name);info.size=v['bytes'];info.mode=v['modus'];info.mtime=v['mtime_ns']/10**9
  with gzip.open(r/v['archief'],'rb') as bron:t.addfile(info,bron)
p.stdin.close();assert p.wait(timeout=300)==0
p=subprocess.Popen(['/usr/bin/zstd','--long=27','-dc',str(a)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);pinnen={Path(v['cachepad']).name:v for v in j['bestanden']};gezien=set()
with tarfile.open(fileobj=p.stdout,mode='r|') as t:
 for info in t:
  v=pinnen[info.name];h=hashlib.sha256();f=t.extractfile(info)
  while b:=f.read(1024**2):h.update(b)
  assert h.hexdigest()==v['sha256'] and info.size==v['bytes'];gezien.add(info.name)
assert p.wait(timeout=30)==0;assert gezien==set(pinnen)
j['gezamenlijk_archief']={'pad':str(a.relative_to(r)),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'alle_binaire_hashes_teruggelezen':True,'aantal':len(j['bestanden'])}
for v in j['bestanden']:
 (r/v['archief']).unlink();v['archief']=str(a.relative_to(r));v['lid']=Path(v['cachepad']).name
j['vrije_gib']=shutil.disk_usage(r).free/1024**3;(u/'manifest.json').write_text(json.dumps(j,indent=2));print(json.dumps({'archief_bytes':a.stat().st_size,'vrije_gib':j['vrije_gib']},indent=2))
