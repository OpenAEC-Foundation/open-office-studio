"""Begrensde eigen featurebouw; geen installatie of functionele acceptatie."""
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,re
r=Path.cwd();root=r.parent/'Open-Office-Studio';u=r/'.local/integratiecontrole/journaal-desktop';f=r/'.local/integratiecontrole/journaal-frontend';target=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='4c13723b0f5dec055ea79e1dfb1be3629f5c9bb9';assert not subprocess.check_output(['git','status','--porcelain'])
assert '2325 passed (2325)' in (f/'volledig.log').read_text();assert (f/'typescript.log').read_text()=='';assert '\nOK\n' in (f/'python.log').read_text()
refs={root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/open-office-studio-45.52-autocorrectie':'98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039',r/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding':'c88c5d82f1b0b44bf1279645a6b3e930dc8f302e5e3f7bec57605b8d2df42c59'}
for p,h in refs.items():assert sha(p)==h
manifest=json.loads((f/'bundelpinnen.json').read_text())
for n,h in manifest.items():assert sha(f/'dist'/n)==h
assert not (u/'dist-voor-bouw').exists();(r/'dist').rename(u/'dist-voor-bouw');shutil.copytree(f/'dist',r/'dist')
assert {str(p.relative_to(r/'dist')):sha(p) for p in (r/'dist').rglob('*') if p.is_file()}==manifest
vrij=shutil.disk_usage(r).free;assert vrij>3.75*1024**3,'Onvoldoende ruimte voor de begrensde herbouw'
# De algemene oude 6-GiB-startmarge blijft voor een brede herbouw gelden.
# Deze beperkte herbouw stopt óók bij een onverwacht vuil afhankelijkheidspakket;
# de absolute 3-GiB-grens tijdens uitvoering is niet verlaagd.
toegestaan={'betteroffice-docx-edit','office-writer-plakken','open-office-studio','yrs'}
env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true')
c=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];begin=time.monotonic();reden=None
with (u/'desktop.log').open('x') as log:
 p=subprocess.Popen(c,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (u/'actief.json').write_text(json.dumps({'status':'bouwen','supervisor_pid':os.getpid(),'bouw_pid':p.pid,'head':head,'opdracht':c,'vrije_bytes_start':vrij,'startgrens_gib':3.75,'stopgrens_gib':3,'alleen_toegestane_herbouw':sorted(toegestaan)},indent=2))
 while p.poll() is None:
  time.sleep(2);tekst=(u/'desktop.log').read_text(errors='replace');herbouw=set(re.findall(r'^\s*Compiling ([^ ]+)',tekst,re.M));onverwacht=herbouw-toegestaan
  if onverwacht or shutil.disk_usage(r).free<3*1024**3 or time.monotonic()-begin>2400:
   reden='Eigen bouw gestopt: '+('onverwachte herbouw '+str(sorted(onverwacht)) if onverwacht else 'vrije ruimte onder 3 GiB of tijd boven 40 minuten')
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
result={'code':p.returncode,'reden':reden,'head':head,'opdracht':c,'seconden':time.monotonic()-begin,'vrije_bytes_start':vrij,'vrije_bytes_eind':shutil.disk_usage(r).free,'herbouw':sorted(set(re.findall(r'^\s*Compiling ([^ ]+)',(u/'desktop.log').read_text(errors='replace'),re.M))),'geen_installer':True,'geen_gui_acceptatie':True,'dist_pinnen':manifest}
for q,h in refs.items():assert sha(q)==h
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head;assert not subprocess.check_output(['git','status','--porcelain'])
if p.returncode==0:
 exe=u/'open-office-studio-4c13723b-journaal';assert not exe.exists();shutil.copy2(target/'release/open-office-studio',exe);result.update(programma=str(exe),programma_sha256=sha(exe))
(u/'desktop.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(u/'actief.json').write_text(json.dumps({'status':'klaar' if p.returncode==0 else 'afgekeurd','resultaat':result},ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='dist_pinnen'},ensure_ascii=False),flush=True)
raise SystemExit(p.returncode)
