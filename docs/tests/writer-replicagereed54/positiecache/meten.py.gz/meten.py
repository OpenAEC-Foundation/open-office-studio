from pathlib import Path
import os,json,hashlib,subprocess
r=Path.cwd();u=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-06/replicagereed54/positiecache');template=r/'native/onderzoek/writer-desktopcache/meten.py';js=r/'native/onderzoek/writer-positiemeting/meting.js';rij=r/'native/onderzoek/writer-wachtrijmeting/meting.js';exe=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-06/replicagereed54/open-office-studio-45.54-replicagereed');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(exe)=='fcfefb13b51a0fdcb29b7b9b80dd3529bb2a1e9b298ecfd21599de2edb942640'
s=template.read_text().replace('REPO = Path(__file__).resolve().parents[3]',f'REPO = Path({str(r)!r})');mark='            begin = time.monotonic()\n';assert s.count(mark)==1;s=s.replace(mark,'            await p.ev('+repr(rij.read_text()+'\n'+js.read_text()+'\nwindow._positieMeting=plaatsPositiemeting(window,zoekEigenInvoerrij(window),api().getEditorRef().getYrsSession(),zoekEigenProjectiePrototype(window,api().getEditorRef().getYrsSession()),zoekEigenProjectieRefs(window,api().getEditorRef().getYrsSession()));true')+')\n'+mark);mark="            r['invoer_en_inspectie_ms'] =";assert s.count(mark)==1;s=s.replace(mark,"            r['positiemeting'] = await p.ev('_positieMeting.stop()')\n"+mark);helper=u/'fysieke-proef.py';helper.write_text(s)
tekst=json.loads((r/'.local/doorwerk-2026-11-04/incrementele-invoer/doortypen-38-zonder-profiel/profiel.json').read_text())['invoertekst'];env=os.environ.copy();env['PATH']=str(r/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':'+env['PATH'];result=[]
for naam in ['eerste','herhaling']:
 druk=[]
 for p in Path('/proc').glob('[0-9]*/comm'):
  try:
   n=p.read_text().strip()
   if n in ['cargo','rustc','rust-lld','ld.lld','cc']or n.startswith('node (vitest'):druk.append(n)
  except OSError:pass
 assert not druk,druk
 cmd=[str(r/'.local/doorwerk-2026-11-02/gui-python/bin/python'),str(helper),'--zonder-profiel','--programma',str(exe),'--versie','2026.45.54','--bron',str(r/'docs/tests/writer-doortypen/bron.docx'),'--paginas','129','--tekst',tekst,'--uitvoer',str(u/naam)]
 with(u/(naam+'.log')).open('x')as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 result.append({'naam':naam,'code':p.returncode,'opdracht':cmd,'programma_sha256':sha(exe),'template_sha256':sha(template),'helper_sha256':sha(helper),'meting_sha256':sha(js),'rijzoeker_sha256':sha(rij),'achtergrond_bij_start':druk});(u/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print(naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
