from pathlib import Path
import os,io,tarfile,subprocess,json,hashlib,shutil
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/replicagereed54';b=u/'bron';assert not b.exists();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert commit.startswith('48a75af8');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();basis={}
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',commit])))as t:
 t.extractall(b,filter='data')
 for f in t:
  if f.isfile():basis[f.name]=h(b/f.name)
mod=b/'node_modules';mod.mkdir()
for p in(r/'node_modules').iterdir():
 if p.name in ['@betteroffice','.cache']or p.name.startswith('.vite'):continue
 (mod/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
(mod/'@betteroffice').mkdir()
for p in(r/'node_modules/@betteroffice').iterdir():
 if p.name=='docx-react':shutil.copytree(p.resolve(),mod/'@betteroffice/docx-react')
 else:(mod/'@betteroffice'/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
assert not(mod/'@betteroffice/docx-react/dist/index.mjs').samefile(r/'node_modules/@betteroffice/docx-react/dist/index.mjs')
sdk=mod/'@betteroffice/docx-react/dist/index.mjs';assert h(sdk)=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb';sdkvoor={str(p.relative_to(mod/'@betteroffice/docx-react')):h(p)for p in(mod/'@betteroffice/docx-react').rglob('*')if p.is_file()}
test='src/tekst/replicagereed.test.ts';(b/test).write_bytes((u/'replicagereed.test.ts').read_bytes());node=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';env=os.environ.copy();env['PATH']=str(node.parent)+':'+env['PATH']
with(u/'regressie-oud.log').open('x')as log:p=subprocess.run([str(node),'node_modules/vitest/vitest.mjs','run',test],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==1 and 'verouderde false-eigenschap' in(u/'regressie-oud.log').read_text();a='r.experimentalWorkerOpen&&Zt.current!==r.replicaReady&&(Zt.current=r.replicaReady,mt.current+=1);';nieuw='let _openaecProjectieGereed=r.replicaReadyRef?.current??r.replicaReady;r.experimentalWorkerOpen&&Zt.current!==_openaecProjectieGereed&&(Zt.current=_openaecProjectieGereed,mt.current+=1);';s=sdk.read_text();assert s.count(a)==1;sdk.write_text(s.replace(a,nieuw));patch=b/'patches/@betteroffice__docx-react@0.5.1.patch';oudhash=h(patch);regels=patch.read_text().splitlines(keepends=True);treffers=[i for i,l in enumerate(regels)if l.startswith('+')and a in l];assert len(treffers)==1;regels[treffers[0]]=regels[treffers[0]].replace(a,nieuw);patch.write_text(''.join(regels));lock=b/'pnpm-lock.yaml';s=lock.read_text();assert s.count(oudhash)>=2;lock.write_text(s.replace(oudhash,h(patch)))
subprocess.run([str(node),'scripts/weekversie.mjs','2026-11-06','54'],cwd=b,env=env,check=True)
f=b/'src-tauri/tauri.conf.json';c=json.loads(f.read_text());c['build']['beforeBuildCommand']='python3 '+str(u/'voorbouw.py');f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
# Reeds bestaande proefdata alleen lezen, geen geïmporteerde bronbestanden wijzigen.
(b/'.local').mkdir();(b/'.local/corpus').symlink_to((r/'.local/corpus').resolve(),target_is_directory=True)
wijzig={k:h(b/k)for k,v in basis.items()if h(b/k)!=v};assert set(wijzig)=={'patches/@betteroffice__docx-react@0.5.1.patch','pnpm-lock.yaml','package.json','versie.json','src-tauri/tauri.conf.json','src-tauri/Cargo.toml','src-tauri/Cargo.lock','apps/database-studio/src-tauri/tauri.conf.json','apps/database-studio/src-tauri/Cargo.toml','apps/database-studio/src-tauri/Cargo.lock'}
(u/'bronnen.json').write_text(json.dumps({'basis':commit,'bestanden':basis,'wijzigingen':wijzig,'toegevoegd':{test:h(b/test)},'sdk_voor':sdkvoor,'sdk_sha256':h(sdk),'oude_regressie_code':p.returncode},indent=2)+'\n');assert h(r/'node_modules/@betteroffice/docx-react/dist/index.mjs')=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb';print('Afzonderlijke 45.54-kandidaat voorbereid; root-SDK ongewijzigd')
