from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib
u=Path(__file__).resolve().parent;ref=u/'gui-abba/referentie-a/profiel.png';beeld=Image.open(ref).convert('RGB');r=[]
for p in sorted((u/'gui-abba').glob('*/profiel.png')):
 b=Image.open(p).convert('RGB');assert b.size==beeld.size==(1440,1000);diff=ImageChops.difference(beeld,b);ruw=diff.getbbox();pixels=diff.load()
 for x in range(491,496):
  for y in range(347,366):pixels[x,y]=(0,0,0)
 doc=diff.crop((320,210,1140,950)).getbbox();assert doc is None;r.append({'bestand':str(p.relative_to(u)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ruw_verschil_bbox':ruw,'document_verschil_bbox':doc})
assert len(r)==4;(u/'beeldvergelijking.json').write_text(json.dumps({'roi':[320,210,1140,950],'cursorzone':[491,347,496,366],'beelden':r,'grens':'Vier statische eindbeelden van één bron op Linux. Geen volledige UI-, thema-, dialoog- of animatieacceptatie.'},indent=2)+'\n')
