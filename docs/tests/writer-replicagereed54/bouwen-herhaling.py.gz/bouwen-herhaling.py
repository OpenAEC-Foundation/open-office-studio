from pathlib import Path
import os,subprocess,json,time,shutil,signal
from controleer import controleer,BRON,UIT,sha
r=UIT.parents[2];m=controleer();node=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';target=r/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target';assert target.is_dir()
referentie=r/'.local/doorwerk-2026-11-06/autocorrectie-invoer/open-office-studio-45.52-autocorrectie';assert sha(referentie)=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039'
env=os.environ.copy();env.update(PATH=str(node.parent)+':'+str(Path.home()/'.cargo/bin')+':'+env['PATH'],CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true')
rapport=[json.loads((UIT/"bouwen.json").read_text())[0]]
poorten=[('assets',[str(node),'scripts/kopieer-assets.mjs']),('frontend',[str(node),'node_modules/vitest/vitest.mjs','run','--maxWorkers=2','--minWorkers=1']),('typescript',[str(node),'node_modules/typescript/bin/tsc','--noEmit']),('engines',[str(node),'scripts/test-kantoor-engines.mjs']),('opdrachten',[str(node),'scripts/test-opdrachten.mjs']),('weekversie',[str(node),'scripts/controleer-weekversie.mjs']),('python',['python3','-m','unittest','discover','-s','tests','-v']),('desktop',[str(node),'node_modules/@tauri-apps/cli/tauri.js','build','--no-bundle'])]
for naam,cmd in poorten:
 if naam=='assets':continue
 controleer();assert shutil.disk_usage(r).free>6*1024**3,'Onvoldoende vrije bouwruimte'
 print('START',naam,flush=True);begin=time.monotonic();reden=None
 with(UIT/(naam+'-herhaling.log')).open('x')as log:
  p=subprocess.Popen(cmd,cwd=BRON,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);bericht=begin+30
  while p.poll()is None:
   time.sleep(5)
   if shutil.disk_usage(r).free<3*1024**3:
    reden='Eigen bouw gestopt bij minder dan 3 GiB vrije ruimte';os.killpg(p.pid,signal.SIGTERM);p.wait();break
   if time.monotonic()>=bericht:print('LOOPT',naam,round(time.monotonic()-begin),'s',flush=True);bericht=time.monotonic()+30
 rapport.append({'naam':naam,'code':p.returncode,'reden':reden,'seconden':time.monotonic()-begin,'opdracht':cmd});(UIT/'bouwen-herhaling.json').write_text(json.dumps(rapport,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
controleer();assert sha(referentie)=='98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039'
exe=UIT/'open-office-studio-45.54-replicagereed';assert not exe.exists();shutil.copy2(target/'release/open-office-studio',exe)
(UIT/'gebouwd.json').write_text(json.dumps({'versie':'2026.45.54','programma':str(exe),'programma_sha256':sha(exe),'sdk_sha256':m['sdk_sha256'],'hergebruikte_target':str(target),'geen_gui_acceptatie':True},indent=2)+'\n');print('45.54 gebouwd; nog geen GUI- of platformacceptatie',flush=True)
