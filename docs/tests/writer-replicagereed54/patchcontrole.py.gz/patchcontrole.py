from pathlib import Path
import shutil,subprocess,json,hashlib
u=Path(__file__).resolve().parent;b=u/'bron';p=u/'patchcontrole';assert not p.exists();sdk=b/'node_modules/@betteroffice/docx-react';shutil.copytree(sdk,p);patch=b/'patches/@betteroffice__docx-react@0.5.1.patch';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();voor={str(f.relative_to(p)):sha(f)for f in p.rglob('*')if f.is_file()};codes=[]
with(u/'patchcontrole.log').open('x')as log:
 for args in [['init','-q'],['apply','--reverse','--check',str(patch)],['apply','--reverse',str(patch)],['apply','--check',str(patch)],['apply',str(patch)]]:
  c=subprocess.run(['git',*args],cwd=p,stdout=log,stderr=subprocess.STDOUT);codes.append(c.returncode)
  assert c.returncode==0,args
na={str(f.relative_to(p)):sha(f)for f in p.rglob('*')if f.is_file()and'.git'not in f.parts};assert voor==na
(u/'patchcontrole.json').write_text(json.dumps({'geslaagd':True,'patch_sha256':sha(patch),'codes':codes,'sdk_bestanden':voor,'terug_en_vooruit_bytegelijk':True},indent=2)+'\n');print('SDK-patch terug en vooruit exact toegepast op',len(voor),'bestanden')
