#!/usr/bin/env python3
"""Native plakgebeurtenis met twee auteurs en fysiek verwerpen via revisiekaarten.

Eigen bron/profiel/venster. ClipboardEvent via de echte wijzigingsmodus; de
RPC-fixture geeft elke aanvraag een eigen auteursnaam. Geen bewijs van het
systeemklembord, auteursinstellingen, volledige revisieflow of invoersnelheid.
"""
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
from xml.etree import ElementTree as ET
from zipfile import ZipFile

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('basis', REPO / 'scripts/test-writer-lang-native.py')
basis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(basis)


async def proef(a):
    from Xlib import X, display
    from PIL import Image
    from gui.webkit_inspector import Inspector
    a.uitvoer.mkdir(parents=True, exist_ok=False)
    bron = a.uitvoer / 'Ontwerpnotitie.docx'
    shutil.copyfile(REPO / 'docs/voorbeelden/Ontwerpnotitie.docx', bron)
    cfg = Path(os.environ['XDG_CONFIG_HOME']) / 'org.openaec.office-studio'
    cfg.mkdir(parents=True)
    (cfg / 'voorkeuren.json').write_text(json.dumps({'taal': 'en', 'thema': 'forge', 'updates': {'automatisch': False}}))
    subprocess.run(['dbus-update-activation-environment', 'DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME'], check=True)
    d = display.Display()
    log = (a.uitvoer / 'programma.log').open('w')
    app = subprocess.Popen([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    r = {'geslaagd': False, 'versie': a.versie, 'programma_sha256': hashlib.sha256(a.programma.read_bytes()).hexdigest(), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'stappen': [], 'grenzen': __doc__}
    v = None

    def stop():
        if app.poll() is None:
            try:
                os.killpg(app.pid, signal.SIGTERM)
                app.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(app.pid, signal.SIGKILL)
                app.wait(timeout=10)
            except ProcessLookupError:
                pass

    timer = threading.Timer(360, stop)
    timer.daemon = True
    timer.start()

    def beeld(naam):
        g = v.get_geometry()
        raw = v.get_image(0, 0, g.width, g.height, X.ZPixmap, 0xffffffff)
        Image.frombytes('RGB', (g.width, g.height), raw.data, 'raw', 'BGRX').save(a.uitvoer / (naam + '.png'))

    async def toets(p, *toetsen, leeg=True):
        vanaf = await p.ev('_toetsen.length')
        subprocess.run(['xdotool', 'key', '--clearmodifiers', *toetsen], check=True)
        laatste = {'left': 'arrowleft', 'right': 'arrowright'}.get(toetsen[-1].split('+')[-1].lower(), toetsen[-1].split('+')[-1].lower())
        await p.run('let eind=performance.now()+10000;while(!_toetsen.slice(' + str(vanaf) + ').includes(' + json.dumps(laatste) + ')){if(performance.now()>eind)throw Error("Toets niet ontvangen");await new Promise(r=>setTimeout(r,20))}return true;')
        if leeg:
            await p.run('await api().flushPendingInput();return true;')

    async def klik(p, expressie):
        xy = await p.ev('(()=>{let e=' + expressie + ';if(!e)throw Error("Geen knop");let r=e.getBoundingClientRect();return{x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)}})()')
        subprocess.run(['xdotool', 'mousemove', '--window', str(v.id), str(xy['x']), str(xy['y']), 'click', '1'], check=True)

    try:
        eind = time.monotonic()+60
        while v is None and time.monotonic() < eind:
            assert app.poll() is None
            for w in d.screen().root.query_tree().children:
                pid = w.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
                if w.get_attributes().map_state == X.IsViewable and pid is not None and int(pid.value[0]) == app.pid:
                    v = w
                    break
            await asyncio.sleep(.1)
        assert v, 'Geen eigen venster'
        pid_prop = v.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
        pid = int(pid_prop.value[0])
        werkelijk = Path(f'/proc/{pid}/exe').read_bytes()
        assert werkelijk.startswith(b'\x7fELF')
        r['startprogramma_sha256'] = r['programma_sha256']
        r['programma_sha256'] = hashlib.sha256(werkelijk).hexdigest()
        v.configure(x=0, y=0, width=1440, height=1000)
        v.set_input_focus(X.RevertToParent, X.CurrentTime)
        d.sync()
        await asyncio.sleep(12)
        async with Inspector(int(os.environ['OFFICE_PROEF_HTTP'])) as p:
            try:
                await p.run("window.api=()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return null;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next){let v=s.memoizedState?.current;if(v?.getEditorRef&&v.commands)return v}return null};let eind=performance.now()+60000;while(!api()?.getEditorRef()?.getYrsSession()){if(performance.now()>eind)throw Error('Geen sessie');await new Promise(r=>setTimeout(r,100))}await api().flushPendingInput();return true;")
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|version');") == a.versie
                assert await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|identifier');") == 'org.openaec.office-studio'
                await p.begin_foutbewaking()
                await p.ev("""(() => {
                  window.sessie=()=>api().getEditorRef().getYrsSession();
                  window.alleTeksten=()=>Object.fromEntries(sessie().storyIds().sort().map(id=>[id,sessie().paragraphs(id).map(p=>p.text)]));
                  window._origineel=alleTeksten();window._revisiesRpc=[];
                  const oud=window.fetch,doel=window.__TAURI_INTERNALS__.convertFileSrc('writer_plakken_voorbereiden','ipc');
                  window.fetch=async function(url,args,...rest){if(String(url)!==doel)return oud.call(this,url,args,...rest);
                    const body=JSON.parse(args.body),aanvraag=body.aanvraag;if(!aanvraag.author)throw Error('Geen actieve wijzigingsregistratie');aanvraag.author.name=window._fixtureAuteur;const response=await oud.call(this,url,{...args,body:JSON.stringify(body)},...rest),json=response.json.bind(response);
                    response.json=async()=>{const uit=await json();_revisiesRpc.push({auteur:aanvraag.author?.name,bronbinding:['schema','requestId','documentId','sourceVersion','snapshotSha256','clientId'].every(k=>uit[k]===aanvraag[k])});return uit};return response;};
                  return true;
                })()""")
                await p.run("const r=await api().commands.execute('editingMode',{mode:'suggesting'});if(!r.ok)throw Error(r.failure?.message??'Geen wijzigingsmodus');await new Promise(requestAnimationFrame);await new Promise(requestAnimationFrame);return true;")
                for auteur, laatste, tekst in [('Auteur A', False, 'NATIVE-A '), ('Auteur B', True, 'NATIVE-B ')]:
                    await p.run("window._fixtureAuteur="+json.dumps(auteur)+";const e=api().getEditorRef(),s=sessie(),p="+('s.paragraphs("body").at(-1)' if laatste else 's.paragraphs("body")[0]')+";e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:p.paraId,offset:0}));api().focus();const veld=document.querySelector('textarea[data-testid=\"yrs-input\"][data-yrs-story=\"body\"]'),data=new DataTransfer();data.setData('text/plain',"+json.dumps(tekst)+");const ev=new ClipboardEvent('paste',{clipboardData:data,bubbles:true,cancelable:true});veld.dispatchEvent(ev);if(!ev.defaultPrevented)throw Error('Plakgebeurtenis niet verwerkt');await api().flushPendingInput();return true;")
                await p.run("await api().flushPendingInput();if(!api().commands.getState('commentsSidebar').active)await api().commands.execute('commentsSidebar',null);return true;")
                r['revisies']=await p.ev("sessie().listRevisions().filter(r=>r.author==='Auteur A'||r.author==='Auteur B')")
                assert len(r['revisies']) == 2 and len({x['revisionId'] for x in r['revisies']}) == 2
                assert all(x['revisionId'].startswith('openaec-revision-v1:') for x in r['revisies'])
                await p.run("let eind=performance.now()+30000;while(!['Auteur A','Auteur B'].every(a=>Array.from(document.querySelectorAll('.docx-tracked-change-card')).some(c=>c.textContent.includes(a)))){if(performance.now()>eind)throw Error('Geen twee zichtbare revisiekaarten');await new Promise(r=>setTimeout(r,50))}return true;")
                r['kaarten']=await p.ev("Array.from(document.querySelectorAll('.docx-tracked-change-card')).map(c=>({tekst:c.textContent,knoppen:Array.from(c.querySelectorAll('button')).map(b=>({titel:b.title,aria:b.getAttribute('aria-label'),tekst:b.textContent}))}))")
                beeld('twee-native-auteurs')
                for auteur in ['Auteur A', 'Auteur B']:
                    knop="(()=>{let c=Array.from(document.querySelectorAll('.docx-tracked-change-card')).find(c=>c.textContent.includes("+json.dumps(auteur)+"));return c&&Array.from(c.querySelectorAll('button')).find(b=>/Reject/.test([b.title,b.getAttribute('aria-label'),b.textContent].join(' ')))})()"
                    await klik(p,knop)
                    await p.run("let eind=performance.now()+30000;while(sessie().listRevisions().some(r=>r.author==="+json.dumps(auteur)+")){if(performance.now()>eind)throw Error('Revisie niet verworpen');await new Promise(r=>setTimeout(r,50))}await api().flushPendingInput();return true;")
                    assert await p.ev("sessie().paragraphs('body')[0].text===_origineel.body[0]")
                    if auteur == 'Auteur A':
                        assert await p.ev("sessie().paragraphs('body').at(-1).text.startsWith('NATIVE-B ')")
                    r['stappen'].append(auteur+' fysiek verworpen zonder de andere auteur te wissen')
                assert await p.ev('JSON.stringify(alleTeksten())===JSON.stringify(_origineel)')
                r['native_opdrachten']=await p.ev('_revisiesRpc')
                assert len(r['native_opdrachten']) == 2 and all(x['bronbinding'] for x in r['native_opdrachten'])
                r['fouten']=await p.fouten()
                assert not any(r['fouten'].values())
                beeld('native-revisies-verworpen')
                r['geslaagd']=True
            finally:
                try:
                    r['diagnose']=await p.ev("({revisies:window.sessie?.()?.listRevisions(),kaarten:Array.from(document.querySelectorAll('.docx-tracked-change-card')).map(c=>c.textContent)})")
                except Exception as diagnosefout:
                    r['diagnosefout']=str(diagnosefout)

    except Exception as fout:
        r['fout'] = repr(fout)
        if 'p' in locals():
            r['console_bij_afkeuring'] = p.consoleberichten
        if v and app.poll() is None:
            try:
                beeld('afgekeurd')
            except Exception as beeldfout:
                r['beeldfout'] = repr(beeldfout)
        raise
    finally:
        timer.cancel()
        stop()
        d.close()
        log.close()
        (a.uitvoer / 'rapport.json').write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
    return 0


basis.proef = proef
basis.__file__ = str(Path(__file__).resolve())
if __name__ == '__main__':
    raise SystemExit(basis.main())
