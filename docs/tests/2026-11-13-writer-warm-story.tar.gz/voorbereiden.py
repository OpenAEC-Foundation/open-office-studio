from pathlib import Path
import json,hashlib,shutil
r=Path.cwd();p=r/'.local/integratiecontrole/warm-story';src=r/'.local/integratiecontrole/font-hergebruik/bron';old=r/'.local/integratiecontrole/replica-fontcache';pins=json.load(open(old/'bron-hersteld.json'))['bestanden'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();records={}
for n,h in pins.items():
 f=src/'crates/docx-edit/src'/n;assert sha(f)==h;shutil.copyfile(f,p/(n+'.voor'));f.write_bytes((old/(n+'.na')).read_bytes());records[n]={'voor':h,'basis_cache':sha(f)}
f=src/'crates/docx-edit/src/engine.rs';s=f.read_text();anchor='    /// Serializes resident lowered blocks.\n';assert s.count(anchor)==1;s=s.replace(anchor,'    pub fn warm_story(&self, story: &str, env: &RenderEnv) -> Result<(), BridgeError> {\n        self.with_resident_story(story, env, |_| ())\n    }\n\n'+anchor);f.write_text(s)
f=src/'crates/docx-edit/src/wasm.rs';s=f.read_text();anchor='    pub fn yrs_blocks_for_story(&self, story: &str, env_json: &str) -> Result<String, JsValue> {';assert s.count(anchor)==1;s=s.replace(anchor,'    pub fn warm_story(&self, story: &str, env_json: &str) -> Result<(), JsValue> {\n        let _fonts = self.fonts.enter();\n        let env = parse_render_env(env_json)?;\n        self.engine.warm_story(story, &env).map_err(js_err)\n    }\n\n'+anchor);f.write_text(s)
for n in pins:
 f=src/'crates/docx-edit/src'/n;shutil.copyfile(f,p/(n+'.na'));records[n]['na']=sha(f)
for n in ['docx_edit.d.ts','docx_edit_bg.wasm.d.ts']:
 f=src/'packages/docx/src/wasm/generated/edit'/n;shutil.copyfile(f,p/(n+'.voor'))
(p/'bronpinnen.json').write_text(json.dumps(records,indent=2)+'\n')
