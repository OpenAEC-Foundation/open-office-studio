from pathlib import Path
import json
p=Path(__file__).resolve().parent;corpus={}
for n in ['corpus-warm','corpus-koud','corpus-zonder-lokaal','corpus-oude-route','corpus-oude-kern-fallback']:
 r=json.load(open(p/(n+'.json')));assert r['geslaagd'];steps=[s for c in r['gevallen']for s in c['stappen']];corpus[n]={'geslaagd':True,'gevallen':len(r['gevallen']),'updates':len(steps),'wasm_sha256':r['wasm_sha256'],'modus':r['mode']}
e=json.load(open(p/'env-proef.json'));m=json.load(open(p/'omgevingswissel.json'))
r={'corpus':corpus,'env_story':{'geslaagd':e['geslaagd'],'gevallen':len(e['gevallen']),'stories':len(e['stories'])},'omgevingswissel':{'geslaagd':m['geslaagd'],'stappen':len(m['stappen']),'routes':[[x['route']for x in s['metingen']]for s in m['stappen']]},'native_omgevingen':json.load(open(p/'omgevingen.json')),'compat_model':json.load(open(p/'compat-omgeving.json'))}
(p/'component-samenvatting.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
