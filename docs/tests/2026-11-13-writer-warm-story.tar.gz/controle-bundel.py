from pathlib import Path
import gzip,json,hashlib
p=Path(__file__).resolve().parent;s=gzip.decompress((p/'werker-voor.js.gz').read_bytes()).decode();before=s
for x in json.load(open(p/'bundelwijzigingen.json')):assert s.count(x['voor'])==1;s=s.replace(x['voor'],x['na'],1)
assert s==gzip.decompress((p/'werker-na.js.gz').read_bytes()).decode()==(p/'dist/assets/chunk-Q7OC7M5Q-BzppsI5m.js').read_text();r={'exacte_vervangingen':4,'voor_sha256':hashlib.sha256(before.encode()).hexdigest(),'na_sha256':hashlib.sha256(s.encode()).hexdigest(),'getypeerde_API':json.load(open(p/'kern/bouw.json'))};(p/'bundelcontrole.json').write_text(json.dumps(r,indent=2)+'\n');print('bundelreplay groen')
