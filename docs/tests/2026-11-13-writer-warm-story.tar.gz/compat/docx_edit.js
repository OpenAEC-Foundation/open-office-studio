/* @ts-self-types="./docx_edit.d.ts" */

/**
 * One yrs replica of the DOCX editing model, held for a JS host.
 *
 * Owns the [`EditingDoc`] plus the (single) JS update observer. The JS facade
 * multiplexes its own listener set over that one callback.
 */
export class EditSession {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EditSessionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_editsession_free(ptr, 0);
    }
    /**
     * Accepts tracked changes: pending insertions become plain content,
     * pending deletions are carried out; `pPrIns` marks clear so the split
     * stays, `pPrDel` marks join with the following paragraph, whose own
     * properties survive.
     *
     * `target_json` is either `{"revisionId": string}`, resolving that one
     * coalesced revision wherever it appears in any story, or
     * `{"story","startPara","startOffset","endPara","endOffset"}`, resolving
     * every tracked change overlapping that range regardless of revision id.
     * Receipt: `{"revisionIds": [string, …]}` — the ids actually resolved, in
     * resolution order and deduplicated. Resolving applies a revision rather
     * than authoring one, so it never stamps a new revision and ignores
     * suggesting mode. Errors on an empty range and on a `revisionId` that
     * matches nothing.
     * @param {string} target_json
     * @returns {string}
     */
    accept_change(target_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(target_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_accept_change(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Adds a comment anchored to one or more ranges. `ranges_json`:
     * `[{"story","startPara","startOffset","endPara","endOffset"}, …]`;
     * `body_json` is any JSON value, stored as given. The anchors are sticky,
     * so they follow the text they cover, and the comment lives outside the
     * story rather than as an attribute on it. Receipt: `{"commentId"}` — a
     * freshly minted id. Errors when `ranges_json` is not an array of
     * well-formed ranges, or is empty.
     * @param {string} ranges_json
     * @param {string} author
     * @param {string} date
     * @param {string} body_json
     * @returns {string}
     */
    add_comment(ranges_json, author, date, body_json) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(ranges_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(author, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(body_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_add_comment(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Closes the current undo capture without adding an empty step.
     */
    add_undo_boundary() {
        wasm.editsession_add_undo_boundary(this.__wbg_ptr);
    }
    /**
     * Deletes up to `count` characters at this session's collapsed selection,
     * lays out once, and returns the resulting binary `FrameDelta`.
     * `direction` is `"backward"` or `"forward"`; a surrogate pair is removed
     * whole. At a paragraph boundary a deletion merges with the neighbouring
     * paragraph instead. Deleting stops early at the document start or end,
     * before a second paragraph merge, or at a paragraph the resident state
     * cannot absorb; [`EditSession::resident_deleted_units`] reports how many
     * were removed.
     *
     * Errors on an unknown `direction`, a zero `count`, when
     * `expected_frame_epoch` is not a non-negative safe integer, under the
     * same selection and readiness conditions as [`EditSession::apply_input`],
     * and when there is no character to delete in that direction.
     * @param {string} direction
     * @param {number} expected_frame_epoch
     * @param {number} count
     * @returns {Uint8Array}
     */
    apply_delete(direction, expected_frame_epoch, count) {
        const ptr0 = passStringToWasm0(direction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_delete(this.__wbg_ptr, ptr0, len0, expected_frame_epoch, count);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Instrumented twin of [`EditSession::apply_delete`]: identical arguments,
     * result and error contract, but it also records stage timings for
     * [`EditSession::apply_input_profile_json`].
     * @param {string} direction
     * @param {number} expected_frame_epoch
     * @param {number} count
     * @returns {Uint8Array}
     */
    apply_delete_profiled(direction, expected_frame_epoch, count) {
        const ptr0 = passStringToWasm0(direction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_delete_profiled(this.__wbg_ptr, ptr0, len0, expected_frame_epoch, count);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Applies an edit batch all-or-nothing:
     * `{"ok":true,"baseVersion","version","applied","source","changedStories",
     * "receipts"}`. An applied batch commits one transaction; `history`
     * `"separate"` makes it exactly one undo step.
     * @param {string} request
     * @returns {string}
     */
    apply_edits_json(request) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_apply_edits_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Applies an update another replica of this document committed for a host batch.
     * It commits outside undo history and notifies as a local change.
     * @param {Uint8Array} update
     */
    apply_host_update(update) {
        const ptr0 = passArray8ToWasm0(update, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_host_update(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies one ordinary insertion at this session's collapsed selection
     * and returns the resulting binary `FrameDelta`. The inserted text
     * inherits the formatting at the caret; selection, measurement inputs,
     * pagination checkpoints and display state all stay resident, so nothing
     * but the frame crosses the boundary.
     *
     * Errors when `text` is empty or contains `\r`/`\n`, when
     * `expected_frame_epoch` is not a non-negative safe integer, when there is
     * no resident selection or it no longer resolves, when the selection is
     * not collapsed, or when the resident layout state cannot absorb an edit
     * in that paragraph. The caller must then run the full layout path.
     * @param {string} text
     * @param {number} expected_frame_epoch
     * @returns {Uint8Array}
     */
    apply_input(text, expected_frame_epoch) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_input(this.__wbg_ptr, ptr0, len0, expected_frame_epoch);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Stage timings of the last profiled apply, in milliseconds:
     * `{"selectionMs","editMs","lowerMs","measureMs","paginateMs",
     * "displayInputMs","displayBuildMs","displayFinalizeMs","displayMs",
     * "encodeMs"}`. `{}` before the first profiled call.
     * @returns {string}
     */
    apply_input_profile_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_apply_input_profile_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Instrumented twin of [`EditSession::apply_input`]: identical arguments,
     * result and error contract, but it also records stage timings for
     * [`EditSession::apply_input_profile_json`]. Separate so the ordinary
     * input path pays no timer calls.
     * @param {string} text
     * @param {number} expected_frame_epoch
     * @returns {Uint8Array}
     */
    apply_input_profiled(text, expected_frame_epoch) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_input_profiled(this.__wbg_ptr, ptr0, len0, expected_frame_epoch);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Applies an update produced by this document's dedicated local worker.
     * The local origin lets the main replica's UndoManager retain ownership of
     * the edit; remote/collaboration updates must use `apply_update` instead.
     * @param {Uint8Array} update
     */
    apply_local_update(update) {
        const ptr0 = passArray8ToWasm0(update, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_local_update(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies a paragraph style and rebases inherited character formatting, preserving direct
     * formatting. Without a source package, only `pStyle` changes.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string} style_id
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     */
    apply_paragraph_style(story, start_para, start_offset, end_para, end_offset, style_id, author_name, author_date) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(style_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        var ptr5 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len5 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_paragraph_style(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3, ptr4, len4, ptr5, len5);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies a batch of raw story mutations in ONE transaction. Unlike every
     * other op here these carry no user intent: indices are story-global
     * UTF-16 units, not Locs, and nothing is inferred or stamped on the
     * caller's behalf. `ops_json` is an array of:
     *
     * - `{"op":"insert","index","text"?,"attrs"?}`
     * - `{"op":"delete","index","len"}`
     * - `{"op":"format","index","len","attrs"?}`
     * - `{"op":"insertEmbed","index","kind"?,"payload"?,"attrs"?}`
     * - `{"op":"setEmbedAttr","index","key","value"?}`
     * - `{"op":"setComment","id","ranges":[[start,end], …],"author"?,"date"?,"body"?}`
     * - `{"op":"removeComment","id"}`
     *
     * Each op's `index`, and each `setComment` range, is read against the
     * story state AFTER every preceding op in the batch. `attrs` and
     * `payload` are JSON objects written verbatim, so tracked-change stamps
     * travel inside `attrs`; comments are keyed by the given id and anchored
     * sticky. Errors on an unknown `"op"`, a missing or negative `"index"`,
     * or a missing required field, and leaves the story untouched — parsing
     * completes before the transaction opens.
     * @param {string} story
     * @param {string} ops_json
     */
    apply_raw_ops(story, ops_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(ops_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_raw_ops(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies seed raw operations with deterministic item ordering.
     * @param {string} story
     * @param {string} ops_json
     */
    apply_seed_raw_ops(story, ops_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(ops_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_seed_raw_ops(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies the ordered updates of one sync in a single remote transaction,
     * so the result matches [`EditSession::apply_update`] on the whole diff.
     * Errors on a non-`Uint8Array` entry or a malformed or oversized update,
     * before applying any.
     * @param {Array<any>} updates
     */
    apply_update_chunks(updates) {
        const ret = wasm.editsession_apply_update_chunks(this.__wbg_ptr, updates);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies a remote or incremental yrs v1 update. It commits without a
     * local origin, so this replica's undo manager never claims it. Errors on
     * a malformed update.
     * @param {Uint8Array} update
     */
    apply_update(update) {
        const ptr0 = passArray8ToWasm0(update, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_apply_update(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * [`EditSession::apply_update`] plus an inference about where the peer
     * that authored it is typing, for caret presence. Returns
     * `{"clientId","story","paraId","endOffset"}` for the end of that peer's
     * last text insertion, or `"null"` when the update carries work from more
     * than one client, ends in a non-text insertion, or inserts nothing.
     * Errors on a malformed update.
     * @param {Uint8Array} update
     * @returns {string}
     */
    apply_update_with_inference(update) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passArray8ToWasm0(update, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_apply_update_with_inference(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Starts a new opening of the document; see [`EditingDoc::begin_opening`].
     * @param {string | null} [generation]
     */
    begin_opening(generation) {
        var ptr0 = isLikeNone(generation) ? 0 : passStringToWasm0(generation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.editsession_begin_opening(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Begins `layout_document_with_regions_retained_json` as a pass measured a
     * step at a time; see `EngineSession::begin_region_layout`. Returns the
     * progress JSON, with `layoutJson` once the pass is complete.
     * @param {string} input
     * @returns {string}
     */
    begin_region_layout(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_begin_region_layout(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Until the matching `end_shared_reads`, committed reads share story projections of each document state.
     */
    begin_shared_reads() {
        wasm.editsession_begin_shared_reads(this.__wbg_ptr);
    }
    /**
     * @param {Uint8Array} state
     * @param {Uint8Array} metadata
     * @param {Uint8Array | null} [source]
     */
    bootstrap_peer(state, metadata, source) {
        const ptr0 = passArray8ToWasm0(state, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(metadata, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(source) ? 0 : passArray8ToWasm0(source, wasm.__wbindgen_malloc);
        var len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_bootstrap_peer(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Display-only input JSON in, one binary `FrameDelta` v1 out (exposed as
     * a transferable `Uint8Array`). `expected_frame_epoch` is the epoch of the
     * frame the caller currently holds; pass `0` for the first frame. A
     * mismatch makes the engine emit a full frame instead of a delta, and the
     * returned frame's epoch is always greater than `expected_frame_epoch`. Errors
     * unless the epoch is a non-negative safe integer, and on build failure.
     * @param {string} input
     * @param {number} expected_frame_epoch
     * @returns {Uint8Array}
     */
    build_display_list_frame(input, expected_frame_epoch) {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_build_display_list_frame(this.__wbg_ptr, ptr0, len0, expected_frame_epoch);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * `{ measured, options, layout }` JSON in, `DisplayList` JSON out, built
     * against the same resident font store this session measures with.
     * @param {string} input
     * @returns {string}
     */
    build_display_list_json(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_build_display_list_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Build the listed pages that are still unbuilt and return a FrameDelta
     * v1 carrying them; `expected_frame_epoch` works as for
     * [`Self::build_display_list_frame`].
     * @param {Uint32Array} pages
     * @param {number} expected_frame_epoch
     * @returns {Uint8Array}
     */
    build_display_pages_frame(pages, expected_frame_epoch) {
        const ptr0 = passArray32ToWasm0(pages, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_build_display_pages_frame(this.__wbg_ptr, ptr0, len0, expected_frame_epoch);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Whether [`EditSession::redo`] would reapply something.
     * @returns {boolean}
     */
    can_redo() {
        const ret = wasm.editsession_can_redo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Whether [`EditSession::undo`] would revert something.
     * @returns {boolean}
     */
    can_undo() {
        const ret = wasm.editsession_can_undo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * The current local cell selection as a [`TableRange`], or `"null"`
     * before one is set. An endpoint whose cell was deleted clamps to a
     * surviving nearby cell. Errors when the table itself no longer resolves.
     * @returns {string}
     */
    cell_selection() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_cell_selection(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {string | undefined}
     */
    clear_cell_selection() {
        const ret = wasm.editsession_clear_cell_selection(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Removes the authored `value` from the content-control embed carrying
     * `embed_id`, leaving the control and its content in place: it never
     * erases a text control's text. Errors when no embed has that id.
     * @param {string} embed_id
     */
    clear_content_control_value(embed_id) {
        const ptr0 = passStringToWasm0(embed_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_clear_content_control_value(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Clears every direct run-formatting attribute over `[start, end)`.
     * Protected attributes — hyperlinks and tracked-change stamps — survive,
     * as do paragraph properties.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     */
    clear_formatting(story, start_para, start_offset, end_para, end_offset) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_clear_formatting(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Drops every registered measurement font (ids restart at zero) and
     * invalidates the retained paragraph measurement templates, so the next
     * edit must pass back through the full layout path.
     */
    clear_measure_fonts() {
        wasm.editsession_clear_measure_fonts(this.__wbg_ptr);
    }
    /**
     * Clears the pinned input span.
     */
    clear_undo_input_time() {
        wasm.editsession_clear_undo_input_time(this.__wbg_ptr);
    }
    /**
     * Stops queueing and discards anything not yet drained.
     */
    clear_update_event_observation() {
        wasm.editsession_clear_update_event_observation(this.__wbg_ptr);
    }
    /**
     * Drops the update observer registered by [`EditSession::set_update_observer`].
     */
    clear_update_observer() {
        wasm.editsession_clear_update_observer(this.__wbg_ptr);
    }
    /**
     * This replica's client id, as passed to the constructor.
     * @returns {number}
     */
    client_id() {
        const ret = wasm.editsession_client_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Resolves a text target and anchors a side-map comment over it in one
     * call (legacy agent helpers). `comment_json`:
     * `{"id","author","date","body"?}`. Returns `{"ok":true,"version"}` or a
     * refusal.
     * @param {string} target_json
     * @param {string} comment_json
     * @returns {string}
     */
    comment_text_target_json(target_json, comment_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(target_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(comment_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_comment_text_target_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Compares two DOCX packages into this session, which must hold no document: the original
     * is opened here and the revised body text differences are applied as tracked changes,
     * outside undo history.
     *
     * `options` is `{"author","date","granularity"?,"unsupported"?,"limits"?}`. Returns a final
     * `{"ok":false,"diagnostics"}` or `{"ok":true,"noop":true,"changes":[],"diagnostics"}`, or
     * `{"ok":true,"noop":false,"save"}` naming what a save of the applied changes may write:
     * then pass the saved bytes to [`EditSession::finish_compared_docx_json`], or the save
     * failure to [`EditSession::fail_compared_docx_json`]. Malformed options and internal
     * failures throw.
     * @param {Uint8Array} original
     * @param {Uint8Array} revised
     * @param {string} options
     * @returns {string}
     */
    compare_docx_json(original, revised, options) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passArray8ToWasm0(original, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(revised, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_compare_docx_json(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    content_control_targets_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_content_control_targets_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Adds a story holding one paragraph with `initial_text` (which must not
     * contain paragraph breaks), `p_style` and `alignment`. Receipt:
     * `{"paraId"}` — the paragraph ending at the story's pilcrow. Errors when
     * the story id already exists.
     * @param {string} story_id
     * @param {string} initial_text
     * @param {string} p_style
     * @param {string} alignment
     * @returns {string}
     */
    create_story(story_id, initial_text, p_style, alignment) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(initial_text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(p_style, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(alignment, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_create_story(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * @param {Uint8Array} bytes
     * @returns {Uint8Array}
     */
    decode_font(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_decode_font(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Deletes every column the [`TableRange`] `range_json` covers, along with
     * the stories of the cells removed. Always a plain local edit.
     * @param {string} range_json
     * @returns {string}
     */
    delete_column(range_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_delete_column(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Deletes `[start, end)`. Because a range crossing a paragraph boundary
     * includes the boundary pilcrow, a plain delete also merges those
     * paragraphs. Suggesting mode removes nothing and stamps the content
     * `del` instead. Receipt: `{"revisionId": string|null, "range"}`, the
     * range being what the delete left.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    delete_range(story, start_para, start_offset, end_para, end_offset, author_name, author_date) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            var ptr4 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len4 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_delete_range(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    /**
     * Deletes every row the [`TableRange`] `range_json` covers. In suggesting
     * mode the rows are marked `trDel` instead of removed.
     * @param {string} range_json
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    delete_row(range_json, author_name, author_date) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_delete_row(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * Removes one complete story and its content. Errors on an unknown story.
     * @param {string} story_id
     */
    delete_story(story_id) {
        const ptr0 = passStringToWasm0(story_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_delete_story(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Removes the table `table_json` ([`TableLocator`]) names plus every one
     * of its reachable cell stories. Always a plain local edit; the receipt
     * has `deletedTable: true`.
     * @param {string} table_json
     * @returns {string}
     */
    delete_table(table_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(table_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_delete_table(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The number of text batches applied directly to the live document.
     * @returns {number}
     */
    direct_batches_applied() {
        const ret = wasm.editsession_direct_batches_applied(this.__wbg_ptr);
        return ret;
    }
    /**
     * Region-aware hit test against the resident display list, so no
     * display-list JSON crosses the boundary. `x`/`y` are page-local px.
     * Returns
     * `{"region":"body"|"header"|"footer"|"footnote"|"endnote","rId"?,`
     * `"noteId"?,"pos":n|null,"target":"text"|"image"|"none"}`, or `"null"`
     * for a page index outside the frame. A header/footer `pos` refers to
     * that part's own document and a note `pos` to the `fn:{id}` / `en:{id}`
     * story, never the body; `target` is what sits under the point, which is
     * what a pointer cursor needs.
     * @param {number} page_index
     * @param {number} x
     * @param {number} y
     * @returns {string}
     */
    display_hit_test_regions_json(page_index, x, y) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_display_hit_test_regions_json(this.__wbg_ptr, page_index, x, y);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * [`EditSession::display_range_rects_region_json`] for many ranges, given as flat
     * `[from, to, from, to, ...]` pairs. Per range, in order: its rect count, then
     * `pageIndex, x, y, width, height` for each rect.
     * @param {string} region
     * @param {string} part_id
     * @param {Float64Array} ranges
     * @returns {Float64Array}
     */
    display_range_rects_batch(region, part_id, ranges) {
        const ptr0 = passStringToWasm0(region, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(part_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArrayF64ToWasm0(ranges, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_display_range_rects_batch(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v4 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v4;
    }
    /**
     * Highlight rectangles for a body document range against the resident
     * display list: a JSON array of `{pageIndex,x,y,width,height}` in
     * page-local px, one entry per page the range touches. Body positions
     * only. Errors when no display list is resident.
     * @param {number} from
     * @param {number} to
     * @returns {string}
     */
    display_range_rects_json(from, to) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_display_range_rects_json(this.__wbg_ptr, from, to);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @internal
     * @param {number} from
     * @param {number} to
     * @param {number} first_page
     * @param {number} last_page
     * @returns {string}
     */
    display_range_rects_on_pages_json(from, to, first_page, last_page) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_display_range_rects_on_pages_json(this.__wbg_ptr, from, to, first_page, last_page);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Same rectangles as [`EditSession::display_range_rects_json`], scoped to
     * a region. `region` is `"body"`, `"header"`, `"footer"`, `"footnote"` or
     * `"endnote"`; `part_id` names one header/footer part (an empty string
     * matches any) or the note whose story the positions belong to.
     * `from`/`to` are positions in THAT region's document, and a
     * header/footer part paints on every page carrying it, so the result
     * holds one rect set per such page, each tagged with its `pageIndex`.
     * Errors on an unknown `region` and when no display list is resident.
     * @param {string} region
     * @param {string} part_id
     * @param {number} from
     * @param {number} to
     * @returns {string}
     */
    display_range_rects_region_json(region, part_id, from, to) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(region, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(part_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_display_range_rects_region_json(this.__wbg_ptr, ptr0, len0, ptr1, len1, from, to);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Nearest caret position on the adjacent visual line. `direction` is
     * `"up"` or `"down"`; `goal_x` is the page-local x the caret is trying to
     * hold across successive moves (a non-finite value falls back to the
     * caret's own x). Returns `{"position","goalX"}`, or `"null"` when there
     * is no line in that direction. Errors on an unknown `direction` and when
     * no display list is resident.
     * @param {number} position
     * @param {string} direction
     * @param {number} goal_x
     * @returns {string}
     */
    display_vertical_move_json(position, direction, goal_x) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(direction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_display_vertical_move_json(this.__wbg_ptr, position, ptr0, len0, goal_x);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    document_properties_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_document_properties_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Pops the oldest queued transaction, in arrival order. Byte 0 is `1`
     * when the transaction had no local origin and `0` otherwise; the rest is
     * the v1 update. Empty when the queue is drained or observation never
     * started.
     * @returns {Uint8Array}
     */
    drain_update_event() {
        const ret = wasm.editsession_drain_update_event(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Typing echo model of one font at one shaping size from this session's
     * resident font store: `{"horizontal","glyphIds","advances","kerning",
     * "unsafePairs"}`, indexed by the characters of `alphabet`. `kern` is the
     * run's kerning gate. Errors for an unknown font or a non-positive size.
     * @param {number} font_id
     * @param {number} size
     * @param {boolean} kern
     * @param {string} alphabet
     * @returns {string}
     */
    echo_glyph_set_json(font_id, size, kern, alphabet) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(alphabet, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_echo_glyph_set_json(this.__wbg_ptr, font_id, size, kern, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * A plain local text edit that the resident lowering records, so the next
     * [`Self::layout_document_with_regions_after_edit`] re-lowers and
     * re-measures only its paragraph: inserts `text` at the collapsed range,
     * or deletes `[start, end)` without it. The document changes exactly as
     * through [`Self::insert_text`] or [`Self::delete_range`] without an
     * author, and the receipt is theirs. An empty insertion, an edit that
     * spans paragraphs, or one whose paragraph resident input is not ready
     * for goes through them instead and records nothing for the relayout.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string | null} [text]
     * @returns {string}
     */
    edit_text_resident(story, start_para, start_offset, end_para, end_offset, text) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(text) ? 0 : passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_edit_text_resident(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * [`EditSession::encode_diff`] as ordered updates for a sync that must
     * travel in bounded frames: the whole diff when it fits
     * `max_chunk_bytes`, otherwise causally ordered struct updates followed
     * by the delete set alone. Each fits the limit except one that carries a
     * single larger struct. Errors on a malformed state vector or a zero
     * limit.
     * @param {Uint8Array} remote_state_vector
     * @param {number} max_chunk_bytes
     * @returns {Array<any>}
     */
    encode_diff_chunks(remote_state_vector, max_chunk_bytes) {
        const ptr0 = passArray8ToWasm0(remote_state_vector, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_encode_diff_chunks(this.__wbg_ptr, ptr0, len0, max_chunk_bytes);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The yrs v1 update carrying everything this replica has that the peer
     * described by `remote_state_vector` does not. Errors on a malformed
     * state vector.
     * @param {Uint8Array} remote_state_vector
     * @returns {Uint8Array}
     */
    encode_diff(remote_state_vector) {
        const ptr0 = passArray8ToWasm0(remote_state_vector, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_encode_diff(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * @returns {Uint8Array}
     */
    encode_peer_metadata() {
        const ret = wasm.editsession_encode_peer_metadata(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * The full document state as one yrs v1 update. Hand it to
     * [`EditSession::load`] on a fresh replica to reproduce this document.
     * @returns {Uint8Array}
     */
    encode_state() {
        const ret = wasm.editsession_encode_state(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * This replica's yrs v1 state vector — what a peer sends so
     * [`EditSession::encode_diff`] can compute the update it is missing.
     * @returns {Uint8Array}
     */
    encode_state_vector() {
        const ret = wasm.editsession_encode_state_vector(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Encodes one Loc as opaque sticky-position bytes that keep pointing at
     * the same content as the story is edited. Publish them over an awareness
     * transport and resolve them with
     * [`EditSession::resolve_sticky_position`].
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @returns {Uint8Array}
     */
    encode_sticky_position(story, para_id, offset) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_encode_sticky_position(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v3;
    }
    /**
     * This peer's selection in transportable form:
     * `{"story","anchor":[byte, …],"head":[byte, …]}` with sticky-encoded
     * endpoints, or `"null"` before a selection is set. A peer resolves it
     * with [`EditSession::resolve_encoded_selection`].
     * @returns {string}
     */
    encoded_selection() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_encoded_selection(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Ends a shared-read scope, dropping shared story projections when the last scope ends.
     */
    end_shared_reads() {
        wasm.editsession_end_shared_reads(this.__wbg_ptr);
    }
    /**
     * [`EditSession::export_structured_json`] rendered as Markdown from the same read:
     * `{"ok":true,"version","content":{"markdown","anchors","diagnostics","truncated"}}`.
     * @param {string} options
     * @returns {string}
     */
    export_markdown_json(options) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_export_markdown_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Lays this private session out with its own fonts and exports it with pages as a
     * snapshot. `fonts` holds the font files back to back, `font_lengths` their byte lengths;
     * `request` is a region layout request whose font chains name fonts by their index. The
     * reply is `{"ok":true,"content"}` or `{"ok":false,"failure"}`; a rejected font or an
     * unusable request throws. The session's measurement fonts are left untouched.
     * @param {Uint8Array} fonts
     * @param {Uint32Array} font_lengths
     * @param {string} request
     * @param {string} options
     * @returns {string}
     */
    export_snapshot_with_private_fonts_json(fonts, font_lengths, request, options) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passArray8ToWasm0(fonts, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray32ToWasm0(font_lengths, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_export_snapshot_with_private_fonts_json(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Structured export of the committed document state:
     * `{"revisionView","stories"?,"includeFormatting"?,"maxBlocks"?,"maxBytes"?}` ->
     * `{"ok":true,"version","content"}` or `{"ok":false,"version","failure"}`. Anchors are scoped
     * to the returned version. Reads only: nothing is committed, minted or published.
     * @param {string} options
     * @returns {string}
     */
    export_structured_json(options) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_export_structured_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * [`EditSession::export_structured_json`] with the page map of the retained region
     * layout. `options` adds `"includeGeometry"?`, `"expectLayoutVersion"?`,
     * `"maxFragments"?` and `"maxLayoutBytes"?`; the reply is
     * `{"ok":true,"version","content":{"structured","layout"}}` or a refusal. An editor passes
     * the region layout request it would lay the document out with now as `current_request`,
     * and the layout must have been computed from the same inputs. Lays nothing out and changes
     * nothing.
     * @param {string} options
     * @param {string | null} [current_request]
     * @returns {string}
     */
    export_structured_with_pages_json(options, current_request) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(current_request) ? 0 : passStringToWasm0(current_request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_export_structured_with_pages_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * The final comparison result when saving the applied changes failed with `message`.
     * @param {string} message
     * @returns {string}
     */
    fail_compared_docx_json(message) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(message, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_fail_compared_docx_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * [`EditSession::list_content_controls_json`] keeping the controls that match `query`
     * (`{"kind":"id","controlId"}`, `{"kind":"tag","tag"}`, `{"kind":"ooxmlId","ooxmlId"}` or
     * `{"kind":"alias","alias"}`) exactly.
     * @param {string} query
     * @param {string} options
     * @returns {string}
     */
    find_content_controls_json(query, options) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_find_content_controls_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Exact, case-sensitive, paragraph-local search:
     * `{"text","within","view","limit"?}` ->
     * `{"ok":true,"version","matches":[{"text","range"}],"truncated"}`.
     * @param {string} request
     * @returns {string}
     */
    find_text_json(request) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_find_text_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The final comparison result for `bytes`, the saved applied changes, verified against both
     * inputs: `{"ok":true,"changes","diagnostics"}` or `{"ok":false,"diagnostics"}`. Throws
     * when no comparison awaits its saved bytes.
     * @param {Uint8Array} bytes
     * @returns {string}
     */
    finish_compared_docx_json(bytes) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_finish_compared_docx_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Applies a set-valued, tri-state inline formatting delta over
     * `[start, end)` in one transaction. An omitted key keeps the current
     * value, `null` clears it, and any other value sets it. `delta_json`:
     *
     * ```json
     * {
     *   "bold": true, "italic": true,
     *   "underline": true | {"style"?: string, "color"?: string},
     *   "strike": true | {"double"?: boolean},
     *   "color": {"rgb": string} | {"themeColor": string},
     *   "highlight": string,
     *   "fontSize": 12,
     *   "fontFamily": {"ascii": string, "hAnsi"?: string},
     *   "other": {"anyAttr": value}
     * }
     * ```
     *
     * `false` clears `bold`, `italic`, `underline` and `strike`. `color`
     * takes exactly one of `rgb` or `themeColor`. `other` writes arbitrary
     * run attributes, with `null` removing one. Always a plain local edit, so
     * there is no receipt. Errors when a key carries a type not listed here.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string} delta_json
     */
    format_range(story, start_para, start_offset, end_para, end_offset, delta_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(delta_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_format_range(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Resolves a text target and formats it in one call (legacy agent
     * helpers). `delta_json` is the [`EditSession::format_range`] delta.
     * Returns `{"ok":true,"version"}` or a refusal.
     * @param {string} target_json
     * @param {string} delta_json
     * @returns {string}
     */
    format_text_target_json(target_json, delta_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(target_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(delta_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_format_text_target_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @param {string} root
     * @returns {string}
     */
    geometry_position_outline_json(root) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(root, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_geometry_position_outline_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Whether a remote update is waiting on one that has not arrived yet.
     * @returns {boolean}
     */
    has_pending_update() {
        const ret = wasm.editsession_has_pending_update(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Whether the document has a story with this id.
     * @param {string} story
     * @returns {boolean}
     */
    has_story(story) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_has_story(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * Returns active alias-to-canonical relationship ids as a JSON object.
     * @returns {string}
     */
    header_footer_aliases_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_header_footer_aliases_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The headings of `story` in document order, classified as the structured export
     * classifies them: `[{"paraId","heading":{"outlineLevel","source"}}]`.
     * @param {string} story
     * @returns {string}
     */
    headings_json(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_headings_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Stories changed by the latest undo or redo, sorted.
     * @returns {string[]}
     */
    history_stories() {
        const ret = wasm.editsession_history_stories(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Inserts a column left (`after = false`) or right (`after = true`) of
     * the cell `at_json` ([`CellLoc`]) names. Always a plain local edit.
     * @param {string} at_json
     * @param {boolean} after
     * @returns {string}
     */
    insert_column(at_json, after) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(at_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_column(this.__wbg_ptr, ptr0, len0, after);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Inserts one inline image embed at `(story, para_id, offset)`.
     * The embed occupies one story unit. Receipt:
     * `{"revisionId": string|null, "range"}`, the range being where the image
     * landed. Errors when the payload is not an object.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} payload_json
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    insert_image(story, para_id, offset, payload_json, author_name, author_date) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            var ptr4 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len4 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_image(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    /**
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    insert_line_break(story, para_id, offset, author_name, author_date) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_line_break(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Inserts a page-break embed at `(story, para_id, offset)`, occupying one
     * story unit. Always a plain local edit.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     */
    insert_page_break(story, para_id, offset) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_insert_page_break(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Inserts a row above (`after = false`) or below (`after = true`) the
     * cell `at_json` names. `at_json` is a [`CellLoc`].
     * @param {string} at_json
     * @param {boolean} after
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    insert_row(at_json, after, author_name, author_date) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(at_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_row(this.__wbg_ptr, ptr0, len0, after, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * Inserts a section-break embed at `(story, para_id, offset)`.
     * `break_type` must be `"nextPage"`, `"continuous"`, `"oddPage"` or
     * `"evenPage"`; anything else errors. Always a plain local edit.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} break_type
     */
    insert_section_break(story, para_id, offset, break_type) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(break_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_insert_section_break(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Inserts a `rows` x `columns` table at `(story, para_id, offset)`,
     * creating one story per cell. Errors when either dimension is zero.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {number} rows
     * @param {number} columns
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    insert_table(story, para_id, offset, rows, columns, author_name, author_date) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_table(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, rows, columns, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Inserts a clipboard table fragment at `(story, para_id, offset)`.
     * `fragment_json` is a [`DocxTableFragment`] (`packages/docx/src/yrs/clipboardFragment.ts`).
     * Returns the [`TableFragmentReceipt`] JSON, with `after` carrying the
     * caret right after the inserted table embed.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} fragment_json
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    insert_table_fragment(story, para_id, offset, fragment_json, author_name, author_date) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(fragment_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            var ptr4 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len4 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_table_fragment(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    /**
     * Inserts `text` at `(story, para_id, offset)`. It must contain no
     * paragraph or line breaks, and it inherits the formatting at the
     * insertion point. Receipt: `{"revisionId": string|null, "range"}` —
     * the id is non-null in suggesting mode, where the text is stamped `ins`
     * and coalesces into an adjacent insertion by the same author rather than
     * opening a second revision; the range is where the text landed.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} text
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    insert_text(story, para_id, offset, text, author_name, author_date) {
        let deferred7_0;
        let deferred7_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            var ptr4 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len4 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_insert_text(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2, ptr3, len3, ptr4, len4);
            var ptr6 = ret[0];
            var len6 = ret[1];
            if (ret[3]) {
                ptr6 = 0; len6 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred7_0 = ptr6;
            deferred7_1 = len6;
            return getStringFromWasm0(ptr6, len6);
        } finally {
            wasm.__wbindgen_free(deferred7_0, deferred7_1, 1);
        }
    }
    /**
     * Inserts a watermark embed at `(story, para_id, offset)`, its payload
     * taken verbatim from the `watermark_json` object. Always a plain local
     * edit. Errors when the JSON is not an object.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} watermark_json
     */
    insert_watermark(story, para_id, offset, watermark_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(watermark_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_insert_watermark(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * `{ measured, options }` JSON in, `Layout` JSON out. Both the measured
     * input and the resulting layout are retained for the resident edit path.
     * Errors on unparseable input or on layout failure.
     * @param {string} input
     * @returns {string}
     */
    layout_document_json(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_layout_document_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * [`Self::layout_document_with_regions_retained`] after one edit: the
     * resident path when that edit was the [`Self::edit_text_resident`] taken
     * last; see `EngineSession::layout_document_with_regions_after_edit`.
     * @param {string} input
     */
    layout_document_with_regions_after_edit(input) {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_layout_document_with_regions_after_edit(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The retained region layout of exactly the first `pages` pages when no
     * later content can change them, and of the whole document otherwise; see
     * `EngineSession::layout_document_with_regions_exact_prefix_retained`.
     * Returns `{ provisional, pages, documentWidth? }` as JSON.
     * @param {string} input
     * @param {number} pages
     * @returns {string}
     */
    layout_document_with_regions_exact_prefix_retained(input, pages) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_layout_document_with_regions_exact_prefix_retained(this.__wbg_ptr, ptr0, len0, pages);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Region-layout input JSON in, a paginated envelope with section and page
     * regions already composed as JSON out — ready for the display builder
     * with no host-side layout mutation. Retains the pass for resident edits.
     * @param {string} input
     * @returns {string}
     */
    layout_document_with_regions_json(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_layout_document_with_regions_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The retained region layout of the first `pages` pages only; see
     * `EngineSession::layout_document_with_regions_prefix_retained_json`.
     * @param {string} input
     * @param {number} pages
     * @returns {string}
     */
    layout_document_with_regions_prefix_retained_json(input, pages) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_layout_document_with_regions_prefix_retained_json(this.__wbg_ptr, ptr0, len0, pages);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * [`Self::layout_document_with_regions_retained_json`] without the reply,
     * for a caller that reads only the retained state.
     * @param {string} input
     */
    layout_document_with_regions_retained(input) {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_layout_document_with_regions_retained(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Same full region pass as [`Self::layout_document_with_regions_json`],
     * but the reply carries only `{ layout, headersFooters?, notesConverged }`
     * — the measured arena stays retained wasm-side and is fetched on demand
     * via [`Self::retained_kernel_inputs_json`].
     * @param {string} input
     * @returns {string}
     */
    layout_document_with_regions_retained_json(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_layout_document_with_regions_retained_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @param {string} input
     * @returns {RetainedLayoutMeta}
     */
    layout_document_with_regions_retained_meta(input) {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_layout_document_with_regions_retained_meta(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return RetainedLayoutMeta.__wrap(ret[0]);
    }
    /**
     * Region-layout input JSON in, the font families and sizes that input
     * needs as JSON out, so the host can register fonts before laying out.
     * @param {string} input
     * @returns {string}
     */
    layout_font_requirements_json(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_layout_font_requirements_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Every comment the session holds, sorted by id:
     * `[{"id","author","date","done","parentId","body"}, …]`, `parentId`
     * null for a top-level comment and `body` the JSON value it was given.
     * @returns {string}
     */
    list_comments() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_list_comments(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The content controls of the committed state:
     * `{"stories"?,"maxControls"?,"maxBytes"?}` -> `{"ok":true,"version","content"}` or
     * `{"ok":false,"version","failure"}`. Control ids and anchors are scoped to the returned
     * version. Reads only.
     * @param {string} options
     * @returns {string}
     */
    list_content_controls_json(options) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_list_content_controls_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Every pending tracked change across all stories, in deterministic
     * story-then-position order:
     * `[{"revisionId","author","date","kind","story","preview",
     * "range":{"story","start":{"paraId","offset"},"end":{…}}}, …]`. `kind`
     * is one of `"insertion"`, `"deletion"`, `"pPrIns"`, `"pPrDel"`,
     * `"pPrChange"`, `"trIns"`, `"trDel"`, `"tableIns"` or `"tableDel"`.
     * `preview` holds the first few characters of the affected text, and is
     * empty for every structural kind, which covers no text.
     * @returns {string}
     */
    list_revisions() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_list_revisions(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    list_sections_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_list_sections_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Every story: `{"ok":true,"version","stories":[{"story","kind","parent"?,"root","part"?,
     * "uses"?:[{"sectionIndex","variant","shown"?}]}]}`, sorted by id. `shown` is present only
     * while a complete layout of the current version is retained.
     * @returns {string}
     */
    list_stories_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_list_stories_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Hydrates from a yrs v1 update. The first load after an unseeded open retains prior
     * comment writes and marks loaded fields differing from seed placeholders as authored.
     * @param {Uint8Array} update
     */
    load(update) {
        const ptr0 = passArray8ToWasm0(update, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_load(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Seeds stories from JSON:
     * `[{"storyId","paragraphs":[{"text","pStyle"?,"alignment"?}, …]}, …]`.
     * `pStyle` defaults to `"Normal"` and `alignment` to `"left"`; paragraph
     * text must not contain paragraph breaks. Receipt:
     * `{storyId: [paraId, …]}` with each story's paragraphs in document
     * order. Errors when a story entry has no `storyId`, no `paragraphs`
     * array, or an empty one, and when a story id already exists. Seeding a
     * document that has no opening yet starts one; see
     * [`EditingDoc::begin_opening`].
     * @param {string} stories_json
     * @returns {string}
     */
    load_json(stories_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(stories_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_load_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Lays this replica's `data:` image sources out as the `media:{n}` tokens
     * another replica seeded them from.
     * @param {string} json
     */
    load_media_sources(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_load_media_sources(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Loads separator notes from a yrs v1 update; empty clears them.
     * @param {Uint8Array} state
     */
    load_note_separators(state) {
        const ptr0 = passArray8ToWasm0(state, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_load_note_separators(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * `{"start","end"}` — the paragraph's span in story-global UTF-16 units.
     * `end` is the index of its own pilcrow, so `end - start` is the
     * paragraph length and the upper bound of a Loc `offset` in it. Errors
     * when the paragraph is not in `story`.
     * @param {string} story
     * @param {string} para_id
     * @returns {string}
     */
    locate_paragraph(story, para_id) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_locate_paragraph(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Re-parses the DOCX bytes retained by the last
     * [`EditSession::open_docx`] and returns the COMPLETE package envelope as
     * JSON, or `None` when no DOCX has been opened. Unlike `open_docx` this
     * keeps every part; it reflects the source file, not later edits.
     * @returns {string | undefined}
     */
    materialize_docx() {
        const ret = wasm.editsession_materialize_docx(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Measurement input JSON in, `ParagraphExtent` JSON out. Also records the
     * paragraph's immutable width/font envelope under its stable block id, so
     * a later resident edit re-measures only the changed block. Errors with
     * the engine's message for input it cannot measure.
     * @param {string} input
     * @returns {string}
     */
    measure_paragraph_json(input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_measure_paragraph_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The bytes a `media:{n}` image source displays, as the part's
     * [`EditSession::media_type`]; `undefined` for any other source or a
     * part that cannot be read.
     * @param {string} token
     * @returns {Uint8Array | undefined}
     */
    media_bytes(token) {
        const ptr0 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_media_bytes(this.__wbg_ptr, ptr0, len0);
        let v2;
        if (ret[0] !== 0) {
            v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * The `data:` URL a `media:{n}` image source stands for.
     * @param {string} token
     * @returns {string | undefined}
     */
    media_data_url(token) {
        const ptr0 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_media_data_url(this.__wbg_ptr, ptr0, len0);
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * The digests mapping the `data:` URLs this replica seeded to
     * `media:{n}` tokens, for [`EditSession::load_media_sources`]; empty
     * when it seeded none.
     * @returns {string}
     */
    media_sources_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_media_sources_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The media type of [`EditSession::media_bytes`].
     * @param {string} token
     * @returns {string | undefined}
     */
    media_type(token) {
        const ptr0 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_media_type(this.__wbg_ptr, ptr0, len0);
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * Merges the rectangle the [`TableRange`] `range_json` covers into its
     * top-left cell, whose story survives; the other cells' stories are
     * deleted. Always a plain local edit. Errors when the range covers fewer
     * than two cells or has no top-left anchor cell.
     * @param {string} range_json
     * @returns {string}
     */
    merge_cells(range_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_merge_cells(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Merges `para_id` with the FOLLOWING paragraph by deleting (plain) or
     * `del`- and `pPrDel`-marking (suggesting) its pilcrow. On a plain merge
     * the survivor adopts the deleted mark's properties and paraId, so the
     * earlier paragraph's identity wins. Receipt:
     * `{"revisionId": string|null}`. Errors on the story's final paragraph,
     * which has no following paragraph to merge with.
     * @param {string} story
     * @param {string} para_id
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    merge_paragraphs(story, para_id, author_name, author_date) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_merge_paragraphs(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Moves one inline embed in one local transaction.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} to_story
     * @param {string} to_para_id
     * @param {number} to_offset
     * @returns {string}
     */
    move_embed(story, para_id, offset, to_story, to_para_id, to_offset) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(to_story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(to_para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_move_embed(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2, ptr3, len3, to_offset);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Creates a replica. The host allocates `client_id` (a random 32-bit id
     * is fine) and must keep it unique across the replicas that will merge.
     * Errors unless it is a non-negative safe integer.
     * @param {number} client_id
     */
    constructor(client_id) {
        const ret = wasm.editsession_new(client_id);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        EditSessionFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The style a paragraph break at `(story, para_id, offset)` gives the new paragraph: the
     * paragraph style's `w:next` when the break falls at the paragraph end and `w:next` names
     * another paragraph style. `None` otherwise, and for a session without a source package.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @returns {string | undefined}
     */
    next_paragraph_style(story, para_id, offset) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_next_paragraph_style(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v3;
        if (ret[0] !== 0) {
            v3 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v3;
    }
    /**
     * The separator notes for another replica; empty when the package has none.
     * @returns {Uint8Array}
     */
    note_separators_state() {
        const ret = wasm.editsession_note_separators_state(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Parses a DOCX package, optionally seeds its editable stories into this
     * replica, and retains the source bytes for
     * [`EditSession::materialize_docx`] and paragraph identity reads.
     * Seeding starts a new opening, with `generation` or a fresh one, so its
     * session anchors are its own; see [`EditingDoc::begin_opening`].
     *
     * Returns `{"envelope","referencedFonts":[string, …],"unusedScriptFonts":[string, …]}`:
     * `unusedScriptFonts` are the referenced fonts a seeded package names only
     * for East Asian or complex-script text it does not contain. The envelope is
     * the parsed package with the parts the host does not need stripped —
     * body content, header/footer and note content, numbering, media and
     * charts are emptied, section entries keep only their properties — so
     * styles, theme, settings, fonts and relationships still cross while the
     * bulk of the document stays in Rust. Errors on bytes that are not a
     * readable DOCX.
     * `digest`, when given, must be the SHA-256 of `bytes` in lowercase hex,
     * as a host that hashed them off this thread already knows it.
     * @param {Uint8Array} bytes
     * @param {boolean} seed_stories
     * @param {string | null} [generation]
     * @param {string | null} [digest]
     * @returns {string}
     */
    open_docx(bytes, seed_stories, generation, digest) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(generation) ? 0 : passStringToWasm0(generation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(digest) ? 0 : passStringToWasm0(digest, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_open_docx(this.__wbg_ptr, ptr0, len0, seed_stories, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * Opens `bytes` for display only, seeded from the body's first `blocks`
     * blocks (see `seed::seed_docx_preview`): the reply is the host metadata
     * of that parse, as [`EditSession::open_docx`] replies, with the
     * `unusedScriptFonts` of its cut. The session keeps no source package, so
     * it cannot save.
     * Opens nothing and replies with nothing for a document the preview
     * refuses, which opens with [`EditSession::open_docx`] instead.
     * @param {Uint8Array} bytes
     * @param {number} blocks
     * @returns {string | undefined}
     */
    open_docx_preview(bytes, blocks) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_open_docx_preview(this.__wbg_ptr, ptr0, len0, blocks);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * @param {Uint8Array} bytes
     * @param {number} blocks
     * @param {number | null} [paragraph_budget]
     * @returns {string | undefined}
     */
    open_docx_preview_with_budget(bytes, blocks, paragraph_budget) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_open_docx_preview_with_budget(this.__wbg_ptr, ptr0, len0, blocks, isLikeNone(paragraph_budget) ? Number.MAX_SAFE_INTEGER : (paragraph_budget) >>> 0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * One glyph outline from this session's resident font store:
     * `{"upem":n,"cmds":[{"t":"M"|"L"|"Q"|"C"|"Z", …}]}` — commands in font
     * units, y-up. `font_id` comes from
     * [`EditSession::register_measure_font`] and `glyph_id` from shaping.
     * Errors when the glyph cannot be extracted.
     * @param {number} font_id
     * @param {number} glyph_id
     * @returns {string}
     */
    outline_glyph_json(font_id, glyph_id) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_outline_glyph_json(this.__wbg_ptr, font_id, glyph_id);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * How many paragraphs of `story` carry `para_id`: 0, 1, or 2 for two or
     * more. Errors on an unknown story.
     * @param {string} story
     * @param {string} para_id
     * @returns {number}
     */
    paragraph_id_count(story, para_id) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_paragraph_id_count(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * Every paragraph's identities: `{"sessionId","packageSha256",
     * "paragraphs":[{"session","origin","ooxmlParaId","idOrigin",
     * "persisted","source"}]}`, session paragraphs with stories sorted and
     * in document order, then source paragraphs outside the stories, whose
     * `session` is `null`. Reads only.
     * @returns {string}
     */
    paragraph_identities() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_paragraph_identities(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The paragraph IDs a save applies, as the package writer's
     * `paragraphIds` request field: `{"assignments":[{"part","ordinal",
     * "paraId"}],"patchedParts":[{"part","paraIds":[[ordinal,"ID"]]}]}`,
     * plus `"splicedParts":[{"part","sha256","paragraphs":[[ordinal,"key"]],
     * "changed":[ordinal],"inserted":[{"before"|"after":ordinal}],"removed":[ordinal]}]`,
     * whose session keys the caller resolves to the model paragraphs it marks
     * with their ordinals.
     * @returns {string}
     */
    paragraph_save_plan() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_paragraph_save_plan(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Compact paragraph-position projection built in one story traversal:
     * `[{"paraId","length"}, …]` in document order, where `length` counts the
     * UTF-16 text and inline embed units before that paragraph's pilcrow —
     * exactly the `offset` domain of a Loc in it. One call replaces crossing
     * the boundary once per paragraph. Errors on an unknown story.
     * @param {string} story
     * @returns {string}
     */
    paragraph_spans(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_paragraph_spans(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The index of the first paragraph of `story` that carries `para_id`, in
     * `paragraph_spans` order, or -1. Errors on an unknown story.
     * @param {string} story
     * @param {string} para_id
     * @returns {number}
     */
    paragraph_unit(story, para_id) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_paragraph_unit(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * `[{"paraId","text","properties"}, …]` in document order. `text` is the
     * paragraph's plain text without its pilcrow; `properties` is the
     * pilcrow's authored property map (`pStyle`, `alignment` and whatever
     * else has been set on it). Errors on an unknown story.
     * @param {string} story
     * @returns {string}
     */
    paragraphs(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_paragraphs(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    part_metadata_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_part_metadata_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Gives every paragraph that saves without a Word paragraph ID a fresh
     * one and repairs duplicates; see [`EditingDoc::persist_paragraph_ids`].
     * Receipt: `{"status":"applied","assignments":[{"paragraph",
     * "replacedParaId","previousOoxmlParaId","ooxmlParaId","idOrigin",
     * "persisted"}],"diagnostics":[…]}`, or `{"status":"refused","refusal"}`
     * when nothing was changed.
     * @returns {string}
     */
    persist_paragraph_ids() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_persist_paragraph_ids(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {string} ids_json
     * @returns {string}
     */
    proposal_revision_ranges_json(ids_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(ids_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_proposal_revision_ranges_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Versioned paragraph texts:
     * `{"story"?,"paraIds"?,"view":"accepted"|"original"}` ->
     * `{"ok":true,"version","view","paragraphs":[{"story","paraId","text",
     * "styleId"?,"atoms":[{"offset","kind"}]}]}`. Each inline atom occupies one
     * U+FFFC in `text`.
     * @param {string} request
     * @returns {string}
     */
    read_paragraphs_json(request) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_read_paragraphs_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Paragraph texts of selected stories in one read:
     * `{"stories"?:"all"|[kind|id…],"byRoot"?,"view","expectVersion"?}` -> `{"ok":true,
     * "version","view","truncated","stories":[{"story","ok":true,"paragraphs"}|{"story",
     * "ok":false,"failure"}]}`. Listed entries keep their order; a kind expands in id order.
     * @param {string} request
     * @returns {string}
     */
    read_stories_json(request) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_read_stories_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Reconciles and publishes the `[owner, paraId]` pairs a save captured,
     * an owner being a session key or a source occurrence's
     * `{partUri}#{ordinal}`; returns the stale pairs as the same JSON shape.
     * See [`EditingDoc::record_saved_paragraph_ids`].
     * @param {string} saved_json
     * @returns {string}
     */
    record_saved_paragraph_ids(saved_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(saved_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_record_saved_paragraph_ids(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Reapplies the latest locally undone transaction and reports whether
     * anything was reapplied.
     * @returns {boolean}
     */
    redo() {
        const ret = wasm.editsession_redo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Registers raw sfnt bytes in this session's resident measurement store
     * and returns the font id that measurement and display inputs reference.
     * Errors on bytes the font parser rejects.
     * @param {Uint8Array} bytes
     * @returns {number}
     */
    register_measure_font(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_register_measure_font(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * Registers a measurement view of `base` carrying the vertical metrics
     * and advance pitch Word measures `requested_family` with — for a face
     * this host had to substitute. Returns `base` for a family whose metrics
     * are unknown.
     * @param {number} base
     * @param {string} requested_family
     * @returns {number}
     */
    register_substitute_measure_font(base, requested_family) {
        const ptr0 = passStringToWasm0(requested_family, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_register_substitute_measure_font(this.__wbg_ptr, base, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * Rejects tracked changes — the inverse of
     * [`EditSession::accept_change`]: pending insertions roll back, pending
     * deletions restore their text; `pPrIns` marks join back with the
     * following paragraph, `pPrDel` marks clear so the split stays, and a
     * `pPrChange` restores the paragraph's previous properties. Same target,
     * receipt and error contract.
     * @param {string} target_json
     * @returns {string}
     */
    reject_change(target_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(target_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_reject_change(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Release display pages; an empty result means the request was superseded.
     * @param {Uint32Array} pages
     * @param {number} expected_frame_epoch
     * @returns {Uint8Array}
     */
    release_display_pages_frame(pages, expected_frame_epoch) {
        const ptr0 = passArray32ToWasm0(pages, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_release_display_pages_frame(this.__wbg_ptr, ptr0, len0, expected_frame_epoch);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * @param {string} story
     * @param {number} index
     * @param {boolean} remove
     * @returns {boolean}
     */
    repeat_content_control_at(story, index, remove) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_repeat_content_control_at(this.__wbg_ptr, ptr0, len0, index, remove);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Replaces `[start, end)` with `text` in one transaction. The inserted
     * text adopts the first replaced unit's formatting; in suggesting mode
     * the deletion and the insertion share one revision id. Receipt:
     * `{"revisionId": string|null, "range": {"story", "start": {"paraId", "offset"}, "end": {"paraId", "offset"}}}`.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string} text
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    replace_range(story, start_para, start_offset, end_para, end_offset, text, author_name, author_date) {
        let deferred8_0;
        let deferred8_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ptr3 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len3 = WASM_VECTOR_LEN;
            var ptr4 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len4 = WASM_VECTOR_LEN;
            var ptr5 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len5 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_replace_range(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3, ptr4, len4, ptr5, len5);
            var ptr7 = ret[0];
            var len7 = ret[1];
            if (ret[3]) {
                ptr7 = 0; len7 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred8_0 = ptr7;
            deferred8_1 = len7;
            return getStringFromWasm0(ptr7, len7);
        } finally {
            wasm.__wbindgen_free(deferred8_0, deferred8_1, 1);
        }
    }
    /**
     * Makes the next display frame a full one whatever epoch its caller
     * passes, for a host that switches to this engine from another.
     */
    reset_frame_base() {
        wasm.editsession_reset_frame_base(this.__wbg_ptr);
    }
    /**
     * `{"frameEpoch", "caretRect": {…}|null}` for the session's own collapsed
     * body selection. `caretRect` is null whenever there is no selection, the
     * selection is not a collapsed body caret, or the retained layout has no
     * geometry for it. `frameEpoch` identifies the frame the rect belongs to.
     * @returns {string}
     */
    resident_caret_snapshot_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_resident_caret_snapshot_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Characters the last [`EditSession::apply_delete`] removed.
     * @returns {number}
     */
    resident_deleted_units() {
        const ret = wasm.editsession_resident_deleted_units(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {string} root
     * @param {string} request
     * @returns {string}
     */
    resident_geometry_json(root, request) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(root, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_resident_geometry_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    resident_section_revision() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_resident_section_revision(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Where a comment's sticky anchors currently sit:
     * `[{"story","start","end"}, …]`, one entry per anchored range, in
     * story-global UTF-16 units. Errors on an unknown comment id and when an
     * anchor no longer resolves.
     * @param {string} comment_id
     * @returns {string}
     */
    resolve_comment(comment_id) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(comment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_resolve_comment(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Resolves another peer's encoded selection against this replica's
     * current state: `{"anchor":{"story","paraId","offset"},"head":{…}}`.
     * Errors on malformed bytes or an endpoint that no longer resolves.
     * @param {string} story
     * @param {Uint8Array} anchor
     * @param {Uint8Array} head
     * @returns {string}
     */
    resolve_encoded_selection(story, anchor, head) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(anchor, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passArray8ToWasm0(head, wasm.__wbindgen_malloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_resolve_encoded_selection(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * Resolves a `session`, `source` or `persisted` anchor JSON against the
     * current state: `{"status":"found","anchor"}`, `{"status":"missing"}`,
     * `{"status":"ambiguous","candidates"}` or `{"status":"unsupported",
     * "reason"}` with a `foreign-session`, `foreign-package` or
     * `no-source-package` reason. A found source paragraph outside the
     * session stories comes back as its source anchor. Errors on a malformed
     * anchor.
     * @param {string} anchor_json
     * @returns {string}
     */
    resolve_paragraph_anchor(anchor_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(anchor_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_resolve_paragraph_anchor(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Resolves sticky bytes from [`EditSession::encode_sticky_position`] back
     * to `{"story","paraId","offset"}`. Errors when the bytes are malformed
     * or the position no longer resolves in `story`.
     * @param {string} story
     * @param {Uint8Array} position
     * @returns {string}
     */
    resolve_sticky_position(story, position) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(position, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_resolve_sticky_position(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Measures up to `blocks` more body blocks of the begun pass; see
     * `EngineSession::resume_region_layout`.
     * @param {number} blocks
     * @returns {string}
     */
    resume_region_layout(blocks) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_resume_region_layout(this.__wbg_ptr, blocks);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The retained region layout's `headersFooters` JSON, when it has any.
     * @returns {string | undefined}
     */
    retained_headers_footers_json() {
        const ret = wasm.editsession_retained_headers_footers_json(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Retained `{ measured, options }` for the main-thread display-list
     * fallback after a retained-only region layout.
     * @returns {string}
     */
    retained_kernel_inputs_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_retained_kernel_inputs_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    retained_layout_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_retained_layout_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Ids of the tracked changes of `story` whose range holds the caret at
     * `para_id`/`offset`, in `list_revisions` order: `["id", …]`. The caret
     * and both range ends resolve through their paragraph's span start as
     * `locate_paragraph` gives it; a range whose paragraph does not resolve
     * holds nothing. Reads only `story`, unlike `list_revisions`.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @returns {string}
     */
    revision_ids_at(story, para_id, offset) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_revision_ids_at(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Author and date stamps for the requested revision ids.
     * @param {string} ids_json
     * @returns {string}
     */
    revision_stamps_json(ids_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(ids_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_revision_stamps_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Resolves what runs inherit under `styles_json`, a package's style definitions or `null`.
     * @param {string} styles_json
     * @returns {RunInheritance}
     */
    run_inheritance(styles_json) {
        const ptr0 = passStringToWasm0(styles_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_run_inheritance(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return RunInheritance.__wrap(ret[0]);
    }
    /**
     * @param {string} query
     * @param {boolean} case_sensitive
     * @param {number | null} [limit]
     * @returns {string}
     */
    search_text(query, case_sensitive, limit) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_search_text(this.__wbg_ptr, ptr0, len0, case_sensitive, isLikeNone(limit) ? Number.MAX_SAFE_INTEGER : (limit) >>> 0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    section_margins_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_section_margins_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Initializes imported metadata, creating an unanchored comment when absent.
     * @param {string} comment_id
     * @param {string} patch_json
     */
    seed_comment_metadata_json(comment_id, patch_json) {
        const ptr0 = passStringToWasm0(comment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(patch_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_seed_comment_metadata_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * [`EditSession::open_docx`] with seeding always on.
     * @param {Uint8Array} bytes
     * @param {string | null} [generation]
     * @returns {string}
     */
    seed_from_docx(bytes, generation) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(generation) ? 0 : passStringToWasm0(generation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_seed_from_docx(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Unions seeded opaque sequence names into document state.
     * @param {string} names_json
     */
    seed_opaque_sequences(names_json) {
        const ptr0 = passStringToWasm0(names_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_seed_opaque_sequences(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Selects a story, closing capture unless manual grouping is selected.
     * @param {string} story
     */
    select_story(story) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.editsession_select_story(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Aggregated toolbar and accessibility state over `[start, end)`:
     *
     * ```json
     * {
     *   "bold": true | false | "mixed", "italic": …, "underline": …, "strike": …,
     *   "superscript": …, "subscript": …,
     *   "fontFamily": string|null, "fontSize": number|null, "color": string|null,
     *   "highlight": string|null,
     *   "paraId": string, "styleId": string|null, "alignment": string|null,
     *   "paragraphProperties": {…},
     *   "hasSelection": bool, "isMultiParagraph": bool, "inTable": bool,
     *   "isSingleEmbed": bool, "embedKind": string|null, "isImage": bool,
     *   "inInsertion": bool, "inDeletion": bool
     * }
     * ```
     *
     * A toggle mark is `"mixed"` when the range disagrees about it; a value
     * mark is `null` when it is absent OR not uniform, so the two cases are
     * not distinguished. `isImage` is `embedKind == "image"`, and
     * `inInsertion`/`inDeletion` report whether the range sits inside a
     * pending tracked change.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @returns {string}
     */
    selection_context(story, start_para, start_offset, end_para, end_offset) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_selection_context(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * This peer's current selection as `{"anchor":{"story","paraId","offset"},
     * "head":{…}}`, or `"null"` before [`EditSession::set_selection`] is
     * called. Errors when an endpoint no longer resolves.
     * @returns {string}
     */
    selection() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.editsession_selection(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Accepted-view texts around a paragraph-keyed selection:
     * `{"paraId","selectedText","paragraphText","before","after"}`, with
     * `\n` between paragraphs and U+FFFC for each inline atom.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @returns {string}
     */
    selection_text_json(story, start_para, start_offset, end_para, end_offset) {
        let deferred5_0;
        let deferred5_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_selection_text_json(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * Merges the sides of the JSON object `borders_json` into every selected
     * cell's `tcPr.borders`; `insideH`/`insideV` resolve to the physical edges
     * interior to the selection. `range_json` is a [`TableRange`]. Always a
     * plain local edit.
     * @param {string} range_json
     * @param {string} borders_json
     * @returns {string}
     */
    set_cell_borders(range_json, borders_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(borders_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_set_cell_borders(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Stores a rectangular anchor-cell to head-cell selection outside the yrs
     * document. `range_json` is a [`TableRange`]:
     * `{"anchor":{"story","tableIndex","row","column"},"head":{…}}`. The table
     * embed is held by a sticky index and each endpoint by its cell story's
     * stable identity, so the selection survives unrelated edits and follows
     * inserted or deleted rows and columns. Errors when the two endpoints are
     * not in the same table, or when either cell does not resolve.
     * @param {string} range_json
     */
    set_cell_selection(range_json) {
        const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_cell_selection(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Sets every selected cell's background to `color` (hex, with or without
     * a leading `#`), or clears it when `color` is absent. `range_json` is a
     * [`TableRange`]. Always a plain local edit.
     * @param {string} range_json
     * @param {string | null} [color]
     * @returns {string}
     */
    set_cell_shading(range_json, color) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(color) ? 0 : passStringToWasm0(color, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_set_cell_shading(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Merges the JSON object `patch_json` into every selected cell's `tcPr`;
     * a `null` value removes that key. `range_json` is a [`TableRange`].
     * Always a plain local edit. Errors when the patch touches `rowspan`,
     * `colspan`, `gridSpan` or `vMerge`, which only merge and split may set.
     * @param {string} range_json
     * @param {string} patch_json
     * @returns {string}
     */
    set_cell_text_format(range_json, patch_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(range_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(patch_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_set_cell_text_format(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Sets the grid width, in twips, of the column holding the cell `at_json`
     * ([`CellLoc`]) names. Always a plain local edit. Errors unless
     * `width_twips` is finite and positive.
     * @param {string} at_json
     * @param {number} width_twips
     * @returns {string}
     */
    set_column_width(at_json, width_twips) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(at_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_set_column_width(this.__wbg_ptr, ptr0, len0, width_twips);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Reanchors an existing comment without changing its metadata.
     * @param {string} comment_id
     * @param {string} ranges_json
     */
    set_comment_ranges(comment_id, ranges_json) {
        const ptr0 = passStringToWasm0(comment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(ranges_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_comment_ranges(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Sets the authored `value` on the content-control embed at
     * `(story, para_id, offset)` — the way to reach a control with no
     * authored `w:id` or tag, which
     * [`EditSession::set_content_control_value`] cannot address. A text
     * control's string value fills it as that method does. Errors when that
     * position holds no embed.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} value_json
     */
    set_content_control_value_at(story, para_id, offset, value_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(value_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_content_control_value_at(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Sets the authored `value` (any JSON) on the content-control embed
     * carrying `embed_id`, searching every story. A plain- or rich-text
     * control takes a string, which fills its content as one
     * version-checked batch step instead. Errors when no embed has that id
     * and when a fill is refused.
     * @param {string} embed_id
     * @param {string} value_json
     */
    set_content_control_value(embed_id, value_json) {
        const ptr0 = passStringToWasm0(embed_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(value_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_content_control_value(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} story
     * @param {number} index
     * @param {string} json
     */
    set_content_control_value_index(story, index, json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_content_control_value_index(this.__wbg_ptr, ptr0, len0, index, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Apply admitted paragraph-local text batches directly. Off by default.
     * @param {boolean} enabled
     */
    set_direct_batches(enabled) {
        wasm.editsession_set_direct_batches(this.__wbg_ptr, enabled);
    }
    /**
     * Keep every previously built page while windowed builds are on.
     * @param {boolean} retain
     */
    set_display_retain_built_pages(retain) {
        wasm.editsession_set_display_retain_built_pages(this.__wbg_ptr, retain);
    }
    /**
     * Limit full display builds to pages `start..end` plus the pages already
     * built; the others stay unbuilt placeholders carrying their geometry
     * until [`Self::build_display_pages_frame`] builds them.
     * @param {number} start
     * @param {number} end
     */
    set_display_window(start, end) {
        wasm.editsession_set_display_window(this.__wbg_ptr, start, end);
    }
    /**
     * @param {string} key
     * @param {string} json
     * @returns {boolean}
     */
    set_document_property(key, json) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_document_property(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Declares header/footer alias groups before host-side seeding.
     * @param {string} json
     */
    set_header_footer_aliases(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_header_footer_aliases(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Sets or clears the hyperlink attribute over `[start, end)`.
     * `hyperlink_json` is `{"href", "tooltip"?, "rId"?}` or `null` to unlink.
     * The attribute is protected: ordinary formatting ops cannot write or
     * erase it, only this one. Errors when the JSON is neither an object nor
     * `null`.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string} hyperlink_json
     */
    set_hyperlink(story, start_para, start_offset, end_para, end_offset, hyperlink_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(hyperlink_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_hyperlink(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * [`EditSession::set_image_geometry`] for the image embed at
     * `(story, para_id, offset)` — the way to reach one of several images
     * sharing a relationship id, which the id variant resolves to the first.
     * Errors when that position holds no image.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string} geometry_json
     */
    set_image_geometry_at(story, para_id, offset, geometry_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(geometry_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_image_geometry_at(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Writes geometry fields onto the image embed carrying `embed_id` in one
     * transaction. Every key of the `geometry_json` object becomes a payload
     * entry, with `null` clearing it; the entries of a nested `"other"`
     * object are flattened into the payload alongside them. Errors when
     * `geometry_json` or its `"other"` is not an object, and when no embed
     * has that id.
     * @param {string} embed_id
     * @param {string} geometry_json
     */
    set_image_geometry(embed_id, geometry_json) {
        const ptr0 = passStringToWasm0(embed_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(geometry_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_image_geometry(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Let an eligible resident text edit re-lower only its paragraph. Off by default.
     * @param {boolean} enabled
     */
    set_local_lowering(enabled) {
        wasm.editsession_set_local_lowering(this.__wbg_ptr, enabled);
    }
    /**
     * Whether [`EditSession::open_docx`] seeds images as `media:{n}` tokens,
     * which only a replica opened from the same package resolves, instead of
     * `data:` URLs. Off by default.
     * @param {boolean} enabled
     */
    set_media_tokens(enabled) {
        wasm.editsession_set_media_tokens(this.__wbg_ptr, enabled);
    }
    /**
     * Sets one paragraph property to any JSON value on `para_id`'s pilcrow,
     * searching every story. Unlike
     * [`EditSession::set_paragraph_attrs`] this writes a single key and never
     * records a revision. Errors when the paragraph is unknown and when `key`
     * names schema-managed identity (`paraId` or the embed discriminator).
     * @param {string} para_id
     * @param {string} key
     * @param {string} value_json
     */
    set_paragraph_attr(para_id, key, value_json) {
        const ptr0 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(value_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_paragraph_attr(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies a tri-state paragraph-property delta to every paragraph
     * intersecting `[start, end)` in one transaction. An omitted key keeps
     * the current value and `null` clears it. `attrs_json` recognises
     * `alignment`, `lineSpacing`, `lineSpacingRule`, `spaceBefore`,
     * `spaceAfter`, `indentLeft`, `indentRight`, `indentFirstLine`,
     * `hangingIndent`, `bidi`, `tabs`
     * (`[{"position":number,"alignment":string,"leader"?:string}, …]`) and
     * `defaultTextFormatting` (an object of run defaults). Any other key —
     * whether written at the top level or nested under `"other"` — is stored
     * as an opaque paragraph property. Spacing and indents are authored OOXML
     * units (twips, line-spacing units), never pixels. In suggesting mode a
     * change is recorded as a `pPrChange` revision. Errors when a recognised
     * key carries the wrong type, and when a key names schema-managed
     * identity such as `paraId`.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string} attrs_json
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     */
    set_paragraph_attrs(story, start_para, start_offset, end_para, end_offset, attrs_json, author_name, author_date) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(attrs_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        var ptr5 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len5 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_paragraph_attrs(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3, ptr4, len4, ptr5, len5);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} json
     * @param {string} remove_json
     * @returns {boolean}
     */
    set_part_metadata(json, remove_json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(remove_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_part_metadata(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Marks whether the session's document is part of a package, as a
     * replica of a preview is: its layouts render NUMPAGES empty.
     * @param {boolean} partial
     */
    set_partial_document(partial) {
        wasm.editsession_set_partial_document(this.__wbg_ptr, partial);
    }
    /**
     * @param {string} section
     * @param {string} json
     * @returns {boolean}
     */
    set_section_margins(section, json) {
        const ptr0 = passStringToWasm0(section, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_section_margins(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Stores this peer's anchor and head as sticky positions, replacing any
     * previous selection. Both endpoints must lie in `story`. The positions
     * live outside the yrs document, so they are never serialized as content
     * or carried in an update. `Assoc::After` makes a collapsed caret advance
     * with text inserted at it.
     * @param {string} story
     * @param {string} anchor_para
     * @param {number} anchor_offset
     * @param {string} head_para
     * @param {number} head_offset
     */
    set_selection(story, anchor_para, anchor_offset, head_para, head_offset) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(anchor_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(head_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_selection(this.__wbg_ptr, ptr0, len0, ptr1, len1, anchor_offset, ptr2, len2, head_offset);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} table_json
     * @param {string} patch_json
     * @returns {string}
     */
    set_table_properties(table_json, patch_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(table_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(patch_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_set_table_properties(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Sets the preferred width, in twips, of the table `table_json`
     * ([`TableLocator`]) names. Always a plain local edit. Errors unless
     * `width_twips` is finite and positive.
     * @param {string} table_json
     * @param {number} width_twips
     * @returns {string}
     */
    set_table_width(table_json, width_twips) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(table_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_set_table_width(this.__wbg_ptr, ptr0, len0, width_twips);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Changes grouping policy while retaining undo and redo history.
     * @param {string} mode
     */
    set_undo_capture_mode(mode) {
        const ptr0 = passStringToWasm0(mode, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_set_undo_capture_mode(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Pins the input span used to measure the next capture gap.
     * @param {number} first
     * @param {number} last
     */
    set_undo_input_time(first, last) {
        wasm.editsession_set_undo_input_time(this.__wbg_ptr, first, last);
    }
    /**
     * Subscribes `callback(update: Uint8Array, isRemote: 0|1)` to every
     * committed transaction. `update` is v1-encoded — feed it straight to
     * [`EditSession::apply_update`] on a peer — and is copied out of wasm
     * memory, so JS may hold it across later edits. The second argument is
     * `1` when the transaction had no local origin; a remote update's own
     * formatting cleanup follows it as a `0` update to forward. One observer
     * per session; a second call replaces the first, and a throwing callback
     * is ignored.
     * @param {Function} callback
     */
    set_update_observer(callback) {
        const ret = wasm.editsession_set_update_observer(this.__wbg_ptr, callback);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Limit incremental rebuilds to the display window and caret pages. Off by default.
     * @param {boolean} enabled
     */
    set_windowed_incremental_builds(enabled) {
        wasm.editsession_set_windowed_incremental_builds(this.__wbg_ptr, enabled);
    }
    /**
     * Resolves tracked changes by revision id outside undo history:
     * `{"accept":[string, …],"reject":[string, …]}` -> `{"ok":true,"revisionIds":[string, …]}`,
     * the ids resolved, or `{"ok":false,"version","failure"}`. An id that matches nothing is
     * skipped. See [`EditingDoc::settle_revisions`].
     * @param {string} request
     * @returns {string}
     */
    settle_revisions_json(request) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_settle_revisions_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Splits the cell `at_json` ([`CellLoc`]) covers into a `rows` x
     * `columns` grid; the original story stays in the top-left slot and every
     * other slot gets a fresh one-paragraph cell story. Omitting both
     * dimensions unmerges the cell into the slots it already covers, which
     * then requires a merged cell. Always a plain local edit. Errors on a
     * zero dimension or a grid smaller than the cell already covers.
     * @param {string} at_json
     * @param {number | null} [rows]
     * @param {number | null} [columns]
     * @returns {string}
     */
    split_cell(at_json, rows, columns) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(at_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_split_cell(this.__wbg_ptr, ptr0, len0, isLikeNone(rows) ? Number.MAX_SAFE_INTEGER : (rows) >>> 0, isLikeNone(columns) ? Number.MAX_SAFE_INTEGER : (columns) >>> 0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Splits a paragraph at `(story, para_id, offset)` by inserting one
     * pilcrow. The FIRST half keeps the original paraId and the second is
     * re-minted. A split at the paragraph end leaves the empty second half
     * with only the inherited property subset; a mid-paragraph split keeps
     * its properties. Paragraph borders are cleared either way. Suggesting
     * mode stamps the new pilcrow `ins` and `pPrIns`. Receipt:
     * `{"firstParaId","secondParaId","revisionId": string|null}`.
     * @param {string} story
     * @param {string} para_id
     * @param {number} offset
     * @param {string | null} [author_name]
     * @param {string | null} [author_date]
     * @returns {string}
     */
    split_paragraph(story, para_id, offset, author_name, author_date) {
        let deferred6_0;
        let deferred6_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(para_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(author_name) ? 0 : passStringToWasm0(author_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            var ptr3 = isLikeNone(author_date) ? 0 : passStringToWasm0(author_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len3 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_split_paragraph(this.__wbg_ptr, ptr0, len0, ptr1, len1, offset, ptr2, len2, ptr3, len3);
            var ptr5 = ret[0];
            var len5 = ret[1];
            if (ret[3]) {
                ptr5 = 0; len5 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred6_0 = ptr5;
            deferred6_1 = len5;
            return getStringFromWasm0(ptr5, len5);
        } finally {
            wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
        }
    }
    /**
     * Starts queueing committed transactions for
     * [`EditSession::drain_update_event`] instead of pushing them through a
     * callback. Idempotent while observation is running.
     */
    start_update_event_observation() {
        const ret = wasm.editsession_start_update_event_observation(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * `{"revision","stories":[…]}`: the current story revision and the sorted
     * ids of the stories created, edited, or deleted after revision `since`.
     * @param {number} since
     * @returns {string}
     */
    stories_changed_since(since) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_stories_changed_since(this.__wbg_ptr, since);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The story's `canonical-stream-v1` FNV-1a checksum (see
     * [`crate::canonical`]) as a DECIMAL STRING, because a u64 exceeds the
     * JavaScript safe-integer range. Two stories with the same authored
     * content share a checksum even when their paragraph and comment ids
     * differ. Errors on an unknown story.
     * @param {string} story
     * @returns {string}
     */
    story_checksum(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_story_checksum(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Every story id in the document, sorted so the order is stable across
     * replicas.
     * @returns {string[]}
     */
    story_ids() {
        const ret = wasm.editsession_story_ids(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Story length in UTF-16 units, every embed (pilcrows included) counting
     * as one. Errors on an unknown story.
     * @param {string} story
     * @returns {number}
     */
    story_len(story) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_story_len(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * The Word paragraph ID each paragraph of `story` saves with, as a JSON
     * array of strings or `null` in document order. Errors on an unknown story.
     * @param {string} story
     * @returns {string}
     */
    story_paragraph_ids(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_story_paragraph_ids(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * `story_segments` split after each pilcrow into units, as one hex digest
     * per unit: `["digest", …]`. Equal digests mean equal segments.
     * @param {string} story
     * @returns {string}
     */
    story_segment_unit_digests(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_story_segment_unit_digests(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The segments of the listed units (indices into
     * `story_segment_unit_digests`), each as `story_segments` gives them:
     * `[[segment, …], …]`. Errors on an index past the last unit.
     * @param {string} story
     * @param {Uint32Array} units
     * @returns {string}
     */
    story_segment_units(story, units) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray32ToWasm0(units, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_story_segment_units(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * The story as an ordered run of formatted segments — the same view
     * lowering reads:
     *
     * - `{"kind":"text","text","attributes"}`
     * - `{"kind":"pilcrow","paraId","properties","attributes"}`
     * - `{"kind":"embed","embedKind","payload","attributes"}`
     *
     * A text segment covers one maximal run of identically formatted
     * characters; each pilcrow and embed is its own segment worth one unit.
     * `attributes` holds the segment's run marks together with any `ins`/`del`
     * tracked-change stamps. Errors on an unknown story.
     * @param {string} story
     * @returns {string}
     */
    story_segments(story) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_story_segments(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * The `payload` of the story's `table_index`-th table embed, as
     * `story_segments` gives it, or `None` when the story has no such
     * table. Errors on an unknown story.
     * @param {string} story
     * @param {number} table_index
     * @returns {string | undefined}
     */
    table_payload(story, table_index) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_table_payload(this.__wbg_ptr, ptr0, len0, table_index);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * Applies one run mark over `[start, end)`. `mark_json`:
     * `{"type":"bold"|"italic"|"underline"|"strike"|"superscript"|"subscript"} |
     * {"type":"fontFamily"|"color","value":string} |
     * {"type":"fontSize","value":number}`. The six boolean types TOGGLE —
     * they turn on unless the whole range already carries the mark — while
     * font family, size and color SET. Formatting is always a plain local
     * edit, never a tracked change, so there is no receipt. Errors on an
     * unknown `"type"` or a missing/mistyped `"value"`.
     * @param {string} story
     * @param {string} start_para
     * @param {number} start_offset
     * @param {string} end_para
     * @param {number} end_offset
     * @param {string} mark_json
     */
    toggle_mark(story, start_para, start_offset, end_para, end_offset, mark_json) {
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_para, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(mark_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_toggle_mark(this.__wbg_ptr, ptr0, len0, ptr1, len1, start_offset, ptr2, len2, end_offset, ptr3, len3);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Starts local-origin undo tracking across every story. Call this after
     * import or seeding but before the first edit, so the initial document is
     * not an undo step; later calls keep the history.
     */
    track_undo() {
        wasm.editsession_track_undo(this.__wbg_ptr);
    }
    /**
     * Current undo grouping policy.
     * @returns {string}
     */
    undo_capture_mode() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_undo_capture_mode(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Reverts the latest local-origin step and reports whether anything was
     * reverted. Remote and system transactions are excluded by the manager's
     * tracked-origin policy; `false` before tracking starts.
     * @returns {boolean}
     */
    undo() {
        const ret = wasm.editsession_undo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {string} comment_id
     * @param {string} patch_json
     */
    update_comment_metadata_json(comment_id, patch_json) {
        const ptr0 = passStringToWasm0(comment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(patch_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_update_comment_metadata_json(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Runs every check of [`EditSession::apply_edits_json`], staging included,
     * without changing anything: `{"ok":true,"baseVersion","wouldApply","previews"}`.
     * @param {string} request
     * @returns {string}
     */
    validate_edits_json(request) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(request, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_validate_edits_json(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @param {string} fragment_json
     */
    validate_table_fragment(fragment_json) {
        const ptr0 = passStringToWasm0(fragment_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_validate_table_fragment(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The session-scoped version token of the committed document state. It
     * changes on every committed change, local or remote, and when the
     * document or its retained source is replaced.
     * @returns {string}
     */
    version() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.editsession_version(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Warms resident lowered blocks.
     * @param {string} story
     * @param {string} env_json
     */
    warm_story(story, env_json) {
        if (typeof wasm.editsession_warm_story !== "function") {
            JSON.parse(this.yrs_blocks_for_story(story, env_json));
            return;
        }
        const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(env_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.editsession_warm_story(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The Word paragraph IDs a DOCX package holds, as JSON mapping each XML
     * part URI to its paragraphs' IDs in document order, in canonical form.
     * @param {Uint8Array} bytes
     * @returns {string}
     */
    written_paragraph_ids(bytes) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_written_paragraph_ids(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Lowers one story to a `LayoutBlock[]` JSON array — the block, run and
     * table vocabulary the layout engine consumes. `env_json` supplies the
     * document-level values lowering cannot read off the story:
     * `{"themeColors":{slot: hex},"defaultTabStopTwips":number|null,
     * "pageContentHeight":number|null,"numericIds":{yrsId: number},
     * "tocStyleIds":[styleId],"showHiddenText":bool,
     * "defaultParagraphStyleId":string,
     * "revisionPreview":{revisionId: "accepted"|"rejected"}}`, all
     * optional. Errors when the story does not end in a pilcrow, holds a
     * malformed table, references itself through a cell story, or contains an
     * embed lowering does not support.
     * @param {string} story
     * @param {string} env_json
     * @returns {string}
     */
    yrs_blocks_for_story(story, env_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(story, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(env_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.editsession_yrs_blocks_for_story(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
}
if (Symbol.dispose) EditSession.prototype[Symbol.dispose] = EditSession.prototype.free;

export class RetainedLayoutMeta {
    static __wrap(ptr) {
        const obj = Object.create(RetainedLayoutMeta.prototype);
        obj.__wbg_ptr = ptr;
        RetainedLayoutMetaFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RetainedLayoutMetaFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_retainedlayoutmeta_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    layout_shell_json() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.retainedlayoutmeta_layout_shell_json(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    get notes_converged() {
        const ret = wasm.retainedlayoutmeta_notes_converged(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    get page_count() {
        const ret = wasm.retainedlayoutmeta_page_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {Float64Array}
     */
    page_sizes() {
        const ret = wasm.retainedlayoutmeta_page_sizes(this.__wbg_ptr);
        var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v1;
    }
    /**
     * @returns {boolean}
     */
    get partial() {
        const ret = wasm.retainedlayoutmeta_partial(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    get provisional() {
        const ret = wasm.retainedlayoutmeta_provisional(this.__wbg_ptr);
        return ret !== 0;
    }
}
if (Symbol.dispose) RetainedLayoutMeta.prototype[Symbol.dispose] = RetainedLayoutMeta.prototype.free;

/**
 * What runs inherit under one package's styles; see [`EditSession::run_inheritance`].
 */
export class RunInheritance {
    static __wrap(ptr) {
        const obj = Object.create(RunInheritance.prototype);
        obj.__wbg_ptr = ptr;
        RunInheritanceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RunInheritanceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_runinheritance_free(ptr, 0);
    }
    /**
     * The attributes, as a JSON object, that seeding merges into the marks of a run of
     * `run_style` in a paragraph of `paragraph_style` before the run's direct formatting.
     * @param {string | null} [paragraph_style]
     * @param {string | null} [run_style]
     * @param {string | null} [table_run_json]
     * @returns {string}
     */
    attributes(paragraph_style, run_style, table_run_json) {
        let deferred5_0;
        let deferred5_1;
        try {
            var ptr0 = isLikeNone(paragraph_style) ? 0 : passStringToWasm0(paragraph_style, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len0 = WASM_VECTOR_LEN;
            var ptr1 = isLikeNone(run_style) ? 0 : passStringToWasm0(run_style, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            var ptr2 = isLikeNone(table_run_json) ? 0 : passStringToWasm0(table_run_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len2 = WASM_VECTOR_LEN;
            const ret = wasm.runinheritance_attributes(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
            var ptr4 = ret[0];
            var len4 = ret[1];
            if (ret[3]) {
                ptr4 = 0; len4 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * @param {string | null | undefined} paragraph_style
     * @param {string} table_formatting_json
     * @returns {string}
     */
    paragraph_formatting(paragraph_style, table_formatting_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            var ptr0 = isLikeNone(paragraph_style) ? 0 : passStringToWasm0(paragraph_style, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(table_formatting_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.runinheritance_paragraph_formatting(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @param {string} table_json
     * @returns {string}
     */
    table_attributes(table_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(table_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.runinheritance_table_attributes(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
}
if (Symbol.dispose) RunInheritance.prototype[Symbol.dispose] = RunInheritance.prototype.free;

/**
 * wasm compatibility wrapper. Resident engine users call
 * [`build_display_list_value`] and keep the typed result.
 * @param {string} input
 * @returns {string}
 */
export function build_display_list_json(input) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.build_display_list_json(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Drop every registered measurement font (ids restart at 0). Callers must
 * re-register before the next `measure_paragraph_json`.
 */
export function clear_measure_fonts() {
    const ret = wasm.clear_measure_fonts();
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * wasm wrapper over [`session::close_display_list`]: drop a handle so its
 * parsed display list is freed. Idempotent.
 * @param {number} handle
 */
export function close_display_list(handle) {
    wasm.close_display_list(handle);
}

/**
 * Decodes TIFF bytes to PNG bytes for browsers without a TIFF decoder.
 * @param {Uint8Array} data
 * @returns {Uint8Array}
 */
export function decodeTiffPng(data) {
    const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeTiffPng(ptr0, len0);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}

/**
 * [`export_docx_structured_json`] rendered as Markdown.
 * @param {Uint8Array} bytes
 * @param {string} options
 * @returns {string}
 */
export function export_docx_markdown_json(bytes, options) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.export_docx_markdown_json(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Structured export of DOCX bytes as a snapshot; `options` as for
 * [`EditSession::export_structured_json`]. No session is created.
 * @param {Uint8Array} bytes
 * @param {string} options
 * @returns {string}
 */
export function export_docx_structured_json(bytes, options) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.export_docx_structured_json(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * The content controls of DOCX bytes that match `query` exactly.
 * @param {Uint8Array} bytes
 * @param {string} query
 * @param {string} options
 * @returns {string}
 */
export function find_docx_content_controls_json(bytes, query, options) {
    let deferred5_0;
    let deferred5_1;
    try {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.find_docx_content_controls_json(ptr0, len0, ptr1, len1, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * wasm wrapper over [`hit::hit_test_json`]: display-list JSON + page-local
 * point in, document position (or `null`) as JSON out.
 * @param {string} display_list
 * @param {number} page_index
 * @param {number} x
 * @param {number} y
 * @returns {string}
 */
export function hit_test_json(display_list, page_index, x, y) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.hit_test_json(ptr0, len0, page_index, x, y);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * wasm wrapper over [`session::hit_test_regions_by_handle`]: region-aware hit
 * test against a stored display list. `Err` on an unknown/closed handle so the
 * caller can fall back to [`hit_test_regions_json`].
 * @param {number} handle
 * @param {number} page_index
 * @param {number} x
 * @param {number} y
 * @returns {string}
 */
export function hit_test_regions_by_handle(handle, page_index, x, y) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.hit_test_regions_by_handle(handle, page_index, x, y);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * wasm wrapper over [`hit::hit_test_regions_json`]: region-aware hit test —
 * `{"region":"body"|"header"|"footer"|"footnote"|"endnote","rId"?,"noteId"?,`
 * `"pos":n|null,"target":"text"|"image"|"none"}` (or `"null"` for an
 * out-of-range page). The plain `hit_test_json` export stays body-only.
 * @param {string} display_list
 * @param {number} page_index
 * @param {number} x
 * @param {number} y
 * @returns {string}
 */
export function hit_test_regions_json(display_list, page_index, x, y) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.hit_test_regions_json(ptr0, len0, page_index, x, y);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * wasm panics abort, so a trap reaches JS as a bare `RuntimeError:
 * unreachable executed`. Log the panic first so it stays diagnosable. Runs on
 * module init for every wasm core that links this crate (layout and edit).
 */
export function install_panic_hook() {
    wasm.install_panic_hook();
}

/**
 * wasm wrapper over [`layout_to_json`].
 * @param {string} input
 * @returns {string}
 */
export function layout_document_json(input) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.layout_document_json(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * The content controls of DOCX bytes as a snapshot; `options` as for
 * [`EditSession::list_content_controls_json`]. No session is created.
 * @param {Uint8Array} bytes
 * @param {string} options
 * @returns {string}
 */
export function list_docx_content_controls_json(bytes, options) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.list_docx_content_controls_json(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Measures a paragraph: measurement input JSON in, `ParagraphExtent` JSON
 * out. An `Err` whose message starts with `"UNSUPPORTED"` means the caller
 * must fall back to browser measurement for that block.
 * @param {string} input
 * @returns {string}
 */
export function measure_paragraph_json(input) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.measure_paragraph_json(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * wasm wrapper over [`session::open_display_list`]: parse a display list once
 * and return a handle the by-handle query exports reuse (no per-query
 * re-parse). The caller frees it with [`close_display_list`]. `Err` on
 * malformed JSON — the caller then stays on the JSON-arg path.
 * @param {string} display_list
 * @returns {number}
 */
export function open_display_list(display_list) {
    const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.open_display_list(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] >>> 0;
}

/**
 * wasm wrapper over [`ooxml_text::FontStore::outline_glyph_json`]: the outline
 * of a registered font's glyph, in font design units, as JSON:
 * `{"upem":2048,"cmds":[{"t":"M","x":..,"y":..},{"t":"L","x":..,"y":..},
 * {"t":"Q","cx":..,"cy":..,"x":..,"y":..},
 * {"t":"C","c1x":..,"c1y":..,"c2x":..,"c2y":..,"x":..,"y":..},{"t":"Z"}]}`.
 * The canvas caches this per `(fontId, glyphId)` and scales by `size/upem`,
 * flipping y at draw time. `cmds` is empty for a blank glyph (space).
 * @param {number} font_id
 * @param {number} glyph_id
 * @returns {string}
 */
export function outline_glyph_json(font_id, glyph_id) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.outline_glyph_json(font_id, glyph_id);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @returns {number}
 */
export function paragraphPatchWriterVersion() {
    const ret = wasm.paragraphPatchWriterVersion();
    return ret >>> 0;
}

/**
 * Wasm control-plane entry: safe ZIP -> bounded XML -> typed relationships.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_relationships(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_relationships(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S2 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s2(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s2(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S3 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s3(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s3(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S4 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s4(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s4(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S5 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s5(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s5(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S6 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s6(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s6(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S7 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s7(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s7(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses an S8 package projection.
 * @param {Uint8Array} data
 * @returns {string}
 */
export function parse_docx_s8(data) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s8(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses the full document wire in one package pass.
 * @param {Uint8Array} data
 * @param {string} options_json
 * @returns {string}
 */
export function parse_docx_s9(data, options_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(options_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.parse_docx_s9(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Focused wasm leaf used by hostile-input and facade tests.
 * @param {Uint8Array} xml
 * @param {string} part_path
 * @returns {string}
 */
export function parse_relationships_xml(xml, part_path) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passArray8ToWasm0(xml, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(part_path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.parse_relationships_xml(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * wasm wrapper over [`session::range_rects_by_handle`]: range rects against a
 * stored display list. `Err` on an unknown/closed handle so the caller can
 * fall back to [`range_rects_json`].
 * @param {number} handle
 * @param {number} from
 * @param {number} to
 * @returns {string}
 */
export function range_rects_by_handle(handle, from, to) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.range_rects_by_handle(handle, from, to);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * wasm wrapper over [`hit::range_rects_json`]: display-list JSON + document range
 * in, JSON array of page-local rects out.
 * @param {string} display_list
 * @param {number} from
 * @param {number} to
 * @returns {string}
 */
export function range_rects_json(display_list, from, to) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.range_rects_json(ptr0, len0, from, to);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @internal
 * @param {number} handle
 * @param {number} from
 * @param {number} to
 * @param {number} first_page
 * @param {number} last_page
 * @returns {string}
 */
export function range_rects_on_pages_by_handle(handle, from, to, first_page, last_page) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.range_rects_on_pages_by_handle(handle, from, to, first_page, last_page);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @internal
 * @param {string} display_list
 * @param {number} from
 * @param {number} to
 * @param {number} first_page
 * @param {number} last_page
 * @returns {string}
 */
export function range_rects_on_pages_json(display_list, from, to, first_page, last_page) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.range_rects_on_pages_json(ptr0, len0, from, to, first_page, last_page);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * wasm wrapper over [`session::range_rects_region_by_handle`]: region-aware
 * range rects against a stored display list. `region` is
 * `"body" | "header" | "footer" | "footnote" | "endnote"`; `part_id` scopes
 * header/footer to one HF part and names the note id for a note region.
 * `Err` on an unknown/closed handle so the caller can fall back to
 * [`range_rects_region_json`].
 * @param {number} handle
 * @param {string} region
 * @param {string} part_id
 * @param {number} from
 * @param {number} to
 * @returns {string}
 */
export function range_rects_region_by_handle(handle, region, part_id, from, to) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(region, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(part_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.range_rects_region_by_handle(handle, ptr0, len0, ptr1, len1, from, to);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * wasm wrapper over [`hit::range_rects_region_json`]: region-aware range rects.
 * `region` is `"body" | "header" | "footer" | "footnote" | "endnote"`;
 * `part_id` scopes a header/footer to one HF part (empty for body / match-any)
 * and names the note id for a note region. The `from`/`to` refer to that
 * region's doc. The plain `range_rects_json` export stays body-only.
 * @param {string} display_list
 * @param {string} region
 * @param {string} part_id
 * @param {number} from
 * @param {number} to
 * @returns {string}
 */
export function range_rects_region_json(display_list, region, part_id, from, to) {
    let deferred5_0;
    let deferred5_1;
    try {
        const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(region, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(part_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.range_rects_region_json(ptr0, len0, ptr1, len1, ptr2, len2, from, to);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * Register a font for measurement from raw sfnt bytes; returns the font id
 * that `measure_paragraph_json` inputs reference in their `fontChains`.
 * Malformed bytes (attacker-controlled embedded fonts) are rejected as an
 * error at this boundary, mirroring `FontStore::register`.
 * @param {Uint8Array} bytes
 * @returns {number}
 */
export function register_measure_font(bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.register_measure_font(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] >>> 0;
}

/**
 * Register a measurement view of `base` carrying the vertical metrics and
 * advance pitch Word measures `requested_family` with, and return its id;
 * returns `base` unchanged for a family with no known metrics. Hosts call
 * this for a face they substituted, and put the result at the head of that
 * family's chain. Pagination, the display list and glyph outlines all read
 * this one store, so a widened view measures and paints at one pitch.
 * @param {number} base
 * @param {string} requested_family
 * @returns {number}
 */
export function register_substitute_measure_font(base, requested_family) {
    const ptr0 = passStringToWasm0(requested_family, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.register_substitute_measure_font(base, ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] >>> 0;
}

/**
 * Renders structured content as Markdown: `content` is a schema-version-1 export and
 * `options` is `{"maxBytes"?}`.
 * @param {string} content
 * @param {string} options
 * @returns {string}
 */
export function render_docx_markdown_json(content, options) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.render_docx_markdown_json(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Renders a paged export as Markdown: `content` is `{"structured","layout"}` from a paged
 * export and `options` is `{"maxBytes"?,"pageMarkers"?}`.
 * @param {string} content
 * @param {string} options
 * @returns {string}
 */
export function render_docx_markdown_with_pages_json(content, options) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.render_docx_markdown_with_pages_json(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Starts a new peak window at the current live bytes.
 */
export function reset_wasm_peak_bytes() {
    wasm.reset_wasm_peak_bytes();
}

/**
 * Serializes an S10 request.
 * @param {string} request_json
 * @returns {string}
 */
export function serialize_docx_s10(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serialize_docx_s10(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Serializes an S11 request.
 * @param {string} request_json
 * @returns {string}
 */
export function serialize_docx_s11(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serialize_docx_s11(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Serializes an S12 request.
 * @param {string} request_json
 * @returns {string}
 */
export function serialize_docx_s12(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serialize_docx_s12(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Caps the bytes allocated at once; an allocation past the cap fails. A
 * non-finite or negative value removes the cap.
 * @param {number} bytes
 */
export function set_wasm_heap_limit(bytes) {
    wasm.set_wasm_heap_limit(bytes);
}

/**
 * wasm wrapper over [`session::update_display_list`]: apply a page-delta
 * update to a stored display list so an incremental rebuild re-parses only
 * its changed pages. `Err` closes the handle first, so the caller's fallback
 * (a fresh [`open_display_list`]) can never race a half-updated list.
 * @param {number} handle
 * @param {string} update
 */
export function update_display_list(handle, update) {
    const ptr0 = passStringToWasm0(update, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.update_display_list(handle, ptr0, len0);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * @param {number} handle
 * @param {number} position
 * @param {string} direction
 * @param {number} goal_x
 * @returns {string}
 */
export function vertical_move_by_handle(handle, position, direction, goal_x) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(direction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vertical_move_by_handle(handle, position, ptr0, len0, goal_x);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {string} display_list
 * @param {number} position
 * @param {string} direction
 * @param {number} goal_x
 * @returns {string}
 */
export function vertical_move_json(display_list, position, direction, goal_x) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(display_list, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(direction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.vertical_move_json(ptr0, len0, position, ptr1, len1, goal_x);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Size of the last allocation that failed, or 0. An allocation fails when the
 * linear memory cannot grow or the limit is reached, and the module then aborts.
 * @returns {number}
 */
export function wasm_failed_allocation_bytes() {
    const ret = wasm.wasm_failed_allocation_bytes();
    return ret;
}

/**
 * Whether the counters below see every allocation of this module.
 * @returns {boolean}
 */
export function wasm_heap_counted() {
    const ret = wasm.wasm_heap_counted();
    return ret !== 0;
}

/**
 * Bytes currently allocated on the Rust heap.
 * @returns {number}
 */
export function wasm_live_bytes() {
    const ret = wasm.wasm_live_bytes();
    return ret;
}

/**
 * The most bytes allocated at once since the module started or the last reset.
 * @returns {number}
 */
export function wasm_peak_bytes() {
    const ret = wasm.wasm_peak_bytes();
    return ret;
}

/**
 * Writes a DOCX from a typed model and original package.
 * @param {string} request_json
 * @param {Uint8Array} original_docx
 * @returns {Uint8Array}
 */
export function write_docx_s13_wasm(request_json, original_docx) {
    const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(original_docx, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.write_docx_s13_wasm(ptr0, len0, ptr1, len1);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v3;
}

/**
 * [`write_docx_s13_wasm`], framing save diagnostics ahead of the package
 * bytes: `u64 LE warnings_len || warnings_json || docx_bytes`.
 * @param {string} request_json
 * @param {Uint8Array} original_docx
 * @returns {Uint8Array}
 */
export function write_docx_s13_wasm_with_warnings(request_json, original_docx) {
    const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(original_docx, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.write_docx_s13_wasm_with_warnings(ptr0, len0, ptr1, len1);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v3;
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_is_function_1f9d30630b8b1d3d: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_undefined_8865fb403f8fe9d8: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_throw_41e9ee4f547fc59a: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_call_1875a20c43a36133: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.call(arg1, arg2, arg3);
            return ret;
        }, arguments); },
        __wbg_call_6137034ef55c9d0f: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_error_211d2d8e1709a144: function(arg0, arg1) {
            console.error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_getRandomValues_a608c4436c19407a: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_get_31af05bd4842a84f: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_unchecked_288889d017702237: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_instanceof_Uint8Array_828cef2aaacafc31: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_length_7f3c00c40364105e: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_d4bdea10311bd9cf: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_new_343a093a3c2ffb4e: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_ee2291f50781bf1d: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_from_slice_9a868026ffa4208a: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_now_aa4ccb83129e9e55: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_now_c81ff7c7df1420e9: function() {
            const ret = performance.now();
            return ret;
        },
        __wbg_prototypesetcall_bc27214492979395: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_push_2baf45db356cf468: function(arg0, arg1) {
            const ret = arg0.push(arg1);
            return ret;
        },
        __wbg_random_5a4cafd2f02395ff: function() {
            const ret = Math.random();
            return ret;
        },
        __wbg_set_145a351398b48c65: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_set_name_2c630595dc90a7aa: function(arg0, arg1, arg2) {
            arg0.name = getStringFromWasm0(arg1, arg2);
        },
        __wbg_static_accessor_GLOBAL_266715b9d96ba635: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_THIS_10fb7dc1ae063179: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_0b583911f537483a: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_d7f903d1508cbdc4: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_warn_768d247861fc553b: function(arg0, arg1) {
            console.warn(getStringFromWasm0(arg0, arg1));
        },
        __wbindgen_generic_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./docx_edit_bg.js": import0,
    };
}

const EditSessionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_editsession_free(ptr, 1));
const RetainedLayoutMetaFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_retainedlayoutmeta_free(ptr, 1));
const RunInheritanceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_runinheritance_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function getArrayF64FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat64ArrayMemory0().subarray(ptr / 8, ptr / 8 + len);
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

let cachedFloat64ArrayMemory0 = null;
function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArray32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getUint32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedFloat64ArrayMemory0 = null;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('docx_edit_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
