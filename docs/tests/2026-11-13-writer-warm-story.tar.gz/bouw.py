from pathlib import Path
import os,subprocess,json,time,shutil,signal
p=Path(__file__).resolve().parent;repo=p.parents[2];cmd=['python3',str(p/'bouw-opdracht.py')]
env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true');begin=time.monotonic();vrij=shutil.disk_usage(p).free;assert vrij>5*1024**3
with (p/'bouw.log').open('x') as log:
 proces=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);reden=None
 (p/'actief.json').write_text(json.dumps({'status':'profielwasm_bouw','pid':proces.pid,'supervisor':os.getpid(),'max_seconden':900,'min_vrij_gib':4},indent=2)+'\n')
 while proces.poll() is None:
  time.sleep(1);vrij=min(vrij,shutil.disk_usage(p).free)
  if vrij<4*1024**3 or time.monotonic()-begin>900:
   reden='grens vrije ruimte of15min';os.killpg(proces.pid,signal.SIGTERM)
   try:proces.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proces.pid,signal.SIGKILL);proces.wait()
   break
r={'code':proces.returncode,'reden':reden,'seconden':time.monotonic()-begin,'min_vrij_bytes':vrij,'opdracht':cmd,'offline':True};(p/'bouw.json').write_text(json.dumps(r,indent=2)+'\n');(p/'actief.json').write_text(json.dumps({'status':'klaar','resultaat':r},indent=2)+'\n');print(json.dumps(r));raise SystemExit(proces.returncode)
