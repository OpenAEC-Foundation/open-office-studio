(()=>{
 'use strict';
 if(window._werkerProbe)throw Error('Werkermeting bestaat al');
 const proto=Worker.prototype,oud=Object.getOwnPropertyDescriptor(proto,'postMessage'),fn=proto.postMessage;
 if(typeof fn!=='function'||!oud?.configurable)throw Error('Werkermethode niet veilig te volgen');
 const regels=[],werkers=new Map(),omgevingen=[],envIds=new Map();let envBytes=0,envOver=0;let actief=true,overgeslagen=0;
 const waarde=(o,k)=>o&&Object.getOwnPropertyDescriptor(o,k)?.value;
 function voeg(r){if(!actief)return;if(regels.length<4096)regels.push(r);else overgeslagen++}
 function envId(value){try{const json=JSON.stringify(value??{});if(envIds.has(json))return envIds.get(json);if(json.length>262144||omgevingen.length>=128||envBytes+json.length>2097152){envOver++;return null}const id=omgevingen.length;envIds.set(json,id);omgevingen.push({id,json});envBytes+=json.length;return id}catch{envOver++;return null}}
 function meta(o){
  const r={};const type=waarde(o,'type'),snap=waarde(o,'snapshot');if(type==='fontRequirements'){const s=waarde(o,'layoutInput');if(typeof s==='string'&&s.length<262144){try{const input=JSON.parse(s);r.env={font:envId(input.renderEnv),bodyStory:input.bodyStory}}catch{envOver++}}}if(type==='sync'&&snap){const input=waarde(snap,'layoutInput'),renders=waarde(snap,'renderInputs');r.env={};if(typeof input==='string'&&input.length<262144){try{r.env.layout=envId(JSON.parse(input).renderEnv)}catch{envOver++}}if(Array.isArray(renders))r.env.renders=renders.slice(0,32).map(x=>({story:waarde(x,'story'),env:envId(waarde(x,'env'))}));}
for(const k of ['id','type','ok']){const v=waarde(o,k);if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')r[k]=typeof v==='string'?v.slice(0,80):v}
  const saved=waarde(o,'saved'),updates=waarde(o,'updates');
  if(saved instanceof ArrayBuffer)r.bewaarbytes=saved.byteLength;
  if(Array.isArray(updates))r.updates=updates.length;
  for(const k of ['commandFrame','caret','collabUpdates'])if(waarde(o,k))r[k]=true;
  return r;
 }
 const wrapper={postMessage(...args){
  if(!actief)return Reflect.apply(fn,this,args);
  let nr=werkers.get(this)?.nr;
  if(!nr&&werkers.size<8){nr=werkers.size+1;const luister=e=>{try{voeg({richting:'ontvangst',werker:nr,tijd:performance.now(),...meta(e.data)})}catch{}};this.addEventListener('message',luister,true);werkers.set(this,{nr,luister})}
  try{voeg({richting:'verzending',werker:nr??null,tijd:performance.now(),...meta(args[0])})}catch{}
  return Reflect.apply(fn,this,args);
 }}.postMessage;
 Object.defineProperty(proto,'postMessage',{...oud,value:wrapper});
 window._werkerProbe={stop(){actief=false;for(const [w,x]of werkers)w.removeEventListener('message',x.luister,true);const hersteld=proto.postMessage===wrapper;if(hersteld)Object.defineProperty(proto,'postMessage',oud);return {regels,overgeslagen,hersteld,omgevingen,envOver,envBytes,werkers:werkers.size,grens:4096,werkergrens:8,geen_extra_aanvragen:true}}};
 return {grens:4096,werkergrens:8};
})()
