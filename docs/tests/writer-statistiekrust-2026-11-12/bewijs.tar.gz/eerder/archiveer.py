from pathlib import Path
import hashlib,json,tarfile,tempfile,os,stat,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/bron-uitlezingen'
paden={r/'.local/integratiecontrole/invoerwachtrij/open-office-studio-bundel16':'a9fa9f18d6599044c459dffef721f23644c03bfd647ea8532dc4f1b1815dff3a',r/'.local/integratiecontrole/adaptieve-invoer/open-office-studio-adaptieve-bundels':'5f394b993ed21ab28322d45684ab8ce3ae88516bc4c71f4c4b3b0fe1bbc78b04',r/'.local/integratiecontrole/native-sortering/open-office-studio-sortering':'cb44a9c3ff47c793678da68487b3b1be346a723d765d24a9d8e1b53cab959d25'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
uit={'vrije_bytes_voor':shutil.disk_usage(r).free,'bestanden':[]}
arch=u/'afgewezen-proefprogrammas.tar.gz'
with tarfile.open(arch,'x:gz',format=tarfile.PAX_FORMAT) as t:
 for p,h in paden.items():
  assert sha(p)==h;pstat=p.stat();naam=str(p.relative_to(r));t.add(p,arcname=naam,recursive=False);uit['bestanden'].append({'pad':str(p),'lid':naam,'sha256':h,'mode':stat.S_IMODE(pstat.st_mode),'mtime_ns':pstat.st_mtime_ns})
with tarfile.open(arch) as t,tempfile.TemporaryDirectory(dir=u) as tmp:
 for b in uit['bestanden']:
  p=Path(tmp)/'herstel';p.write_bytes(t.extractfile(b['lid']).read());p.chmod(b['mode']);os.utime(p,ns=(b['mtime_ns'],b['mtime_ns']));assert sha(p)==b['sha256'] and stat.S_IMODE(p.stat().st_mode)==b['mode'] and p.stat().st_mtime_ns==b['mtime_ns'];p.unlink()
# Alleen de eigen afgewezen losse proeven; de vijf vaste ELF-referenties blijven staan.
for p in paden:p.unlink()
uit.update(archief=str(arch),archief_sha256=sha(arch),archief_bytes=arch.stat().st_size,hersteld_en_byte_mode_mtime_getest=True)
# De verworpen Cargo-app is een dubbele bouwcachekopie; beide harde links zijn bekend.
target=r.parent/'Open-Office-Studio/.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release';exe=target/'open-office-studio';st=exe.stat();assert sha(exe)==paden[r/'.local/integratiecontrole/native-sortering/open-office-studio-sortering']
links=[exe]+[p for p in (target/'deps').glob('open_office_studio-*') if p.is_file() and p.stat().st_ino==st.st_ino and p.stat().st_dev==st.st_dev];assert len(links)==st.st_nlink==2
uit['dubbele_cargo_app']=[{'pad':str(p),'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode),'mtime_ns':p.stat().st_mtime_ns,'herstel_uit_lid':uit['bestanden'][2]['lid']} for p in links]
for p in links:p.unlink()
uit['vrije_bytes_na']=shutil.disk_usage(r).free
(u/'archief.json').write_text(json.dumps(uit,indent=2)+'\n');print(json.dumps({k:v for k,v in uit.items() if k not in ['bestanden','dubbele_cargo_app']}))
