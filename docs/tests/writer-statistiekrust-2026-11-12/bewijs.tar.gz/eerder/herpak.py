from pathlib import Path
import gzip,hashlib,json,lzma,os,shutil,stat,tarfile,tempfile
r=Path.cwd();u=r/'.local/integratiecontrole/bron-uitlezingen';p=u/'archief.json';j=json.loads(p.read_text());oud=Path(j['archief']);nieuw=oud.with_suffix('').with_suffix('.tar.xz')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(oud)==j['archief_sha256']
with gzip.open(oud,'rb') as a,lzma.open(nieuw,'xb',preset=6) as b:shutil.copyfileobj(a,b,1024*1024)
with tarfile.open(nieuw) as t,tempfile.TemporaryDirectory(dir=u) as tmp:
 for b in j['bestanden']:
  herstel=Path(tmp)/'herstel';herstel.write_bytes(t.extractfile(b['lid']).read());herstel.chmod(b['mode']);os.utime(herstel,ns=(b['mtime_ns'],b['mtime_ns']));assert sha(herstel)==b['sha256'] and stat.S_IMODE(herstel.stat().st_mode)==b['mode'] and herstel.stat().st_mtime_ns==b['mtime_ns'];herstel.unlink()
j['vorige_gzip_sha256']=j['archief_sha256'];j['archief']=str(nieuw);j['archief_sha256']=sha(nieuw);j['archief_bytes']=nieuw.stat().st_size;oud.unlink()
# Vijf eigen test-/controlebinaries; bronnen, ruwe resultaten en vaste apps blijven behouden.
proeven=[r/'.local/integratiecontrole/native-sortering'/n for n in ['controle-oud','controle-nieuw','controle-definitief','controle-hersteld','native-tests']]
meta=[];arch=u/'oude-encodertests.tar.gz'
with tarfile.open(arch,'x:gz') as t:
 for x in proeven:
  st=x.stat();b={'pad':str(x),'lid':x.name,'sha256':sha(x),'mode':stat.S_IMODE(st.st_mode),'mtime_ns':st.st_mtime_ns};meta.append(b);t.add(x,arcname=x.name,recursive=False)
with tarfile.open(arch) as t,tempfile.TemporaryDirectory(dir=u) as tmp:
 for b in meta:
  herstel=Path(tmp)/'herstel';herstel.write_bytes(t.extractfile(b['lid']).read());herstel.chmod(b['mode']);os.utime(herstel,ns=(b['mtime_ns'],b['mtime_ns']));assert sha(herstel)==b['sha256'] and stat.S_IMODE(herstel.stat().st_mode)==b['mode'] and herstel.stat().st_mtime_ns==b['mtime_ns'];herstel.unlink()
for x in proeven:x.unlink()
j['oude_encodertests']={'archief':str(arch),'sha256':sha(arch),'bestanden':meta,'herstel_getest':True};j['vrije_bytes_na_herpakken']=shutil.disk_usage(r).free;p.write_text(json.dumps(j,indent=2)+'\n');print(j['archief_bytes'],j['vrije_bytes_na_herpakken'])
