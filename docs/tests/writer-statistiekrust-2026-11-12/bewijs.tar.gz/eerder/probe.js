(() => {
  if (window._uitleesProbe) throw Error('Uitleesprobe bestaat al');
  const doel=sessie(), namen=['readParagraphs','tablePayload',...(typeof doel.readStories==='function'?['readStories']:[])], oud=new Map(), regels=[], stacks=new Map();
  let overgeslagen=0;
  for(const naam of namen){
    const descriptor=Object.getOwnPropertyDescriptor(doel,naam), fn=doel[naam];
    if(typeof fn!=='function'||(descriptor&&!descriptor.configurable))throw Error('Niet veilig te volgen methode: '+naam);
    oud.set(naam,{descriptor,fn});
  }
  const wrappers=new Map();
  for(const naam of namen){
    const wrapper=function(...args){
      const begin=performance.now();let fout=false, antwoord;
      try{antwoord=Reflect.apply(oud.get(naam).fn,this,args);return antwoord}catch(e){fout=true;throw e}
      finally{
        const duur=performance.now()-begin;
        if(regels.length<8192){
          const versie=String(doel.version()), a=args[0];
          const vraag=naam==='tablePayload'?{story:typeof a==='string'?a:null,index:args[1]}:{sleutels:a&&typeof a==='object'?Object.keys(a).sort():[],story:a?.story??null,view:a?.view??null,paraIds:a?.paraIds?.length??null};
          if(naam==='readStories')vraag.verhalen=a?.stories?.length??null;
          const sleutel=naam+'|'+JSON.stringify(vraag);
          let stack=stacks.get(sleutel);
          if(stack===undefined&&stacks.size<24){stack=new Error().stack.slice(0,2400);stacks.set(sleutel,stack)}
          regels.push({naam,begin,duur,versie,vraag,fout,antwoord:naam==='readStories'?{ok:antwoord?.ok??null,truncated:antwoord?.truncated??null,verhalen:antwoord?.stories?.length??null}:null,stack:stack===undefined?null:sleutel});
        }else overgeslagen++;
      }
    };
    wrappers.set(naam,wrapper);
    Object.defineProperty(doel,naam,{value:wrapper,configurable:true,writable:true,enumerable:oud.get(naam).descriptor?.enumerable??false});
  }
  window._uitleesProbe={stop(){
    if(sessie()!==doel)throw Error('Gevolgde sessie vervangen');
    for(const naam of namen)if(doel[naam]!==wrappers.get(naam))throw Error('Gevolgde methode vervangen: '+naam);
    for(const naam of namen){const d=oud.get(naam).descriptor;if(d)Object.defineProperty(doel,naam,d);else delete doel[naam]}
    return {regels,stacks:Object.fromEntries(stacks),overgeslagen,grens:8192,hersteld:namen.every(n=>doel[n]===oud.get(n).fn)};
  }};
  return {namen,grens:8192,stackgrens:24};
})()
