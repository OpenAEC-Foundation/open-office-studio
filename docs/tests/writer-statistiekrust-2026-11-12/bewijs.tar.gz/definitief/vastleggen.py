from pathlib import Path
import hashlib,json,tarfile
r=Path.cwd();u=r/'.local/integratiecontrole/status-telling';eerste=r/'.local/integratiecontrole/bron-uitlezingen';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '2337 passed (2337)' in (u/'frontend.log').read_text() and not (u/'typescript.log').read_text() and 'built in' in (u/'vite.log').read_text()
assert 'Ran 127 tests' in (u/'python-tests.log').read_text() and '\nOK\n' in (u/'python-tests.log').read_text()
a=json.loads((u/'analyse.json').read_text());assert len(a['rondes'])==8
pinnen=json.loads((u/'bronpinnen.json').read_text());assert pinnen=={p:sha(r/p) for p in pinnen}
neg=json.loads((eerste/'rijk-nieuw-a/rapport.json').read_text());assert not neg['geslaagd'] and 'Statusbalktelling' in neg['fout']
probe=json.loads((eerste/'opname-a/rapport.json').read_text());assert not probe['geslaagd'] and probe['uitlezingen']['overgeslagen']==305
ci=json.loads((u/'native-ci-4e.json').read_text());assert ci['conclusion']=='success'
# Alleen eigen bron-/meet-/beeldbestanden. Bouwassets, caches, archieven en ELFs
# blijven privé behouden; ieder gepubliceerd archieflid wordt exact vergeleken.
leden={}
for prefix,map in [('definitief',u),('eerder',eerste)]:
 for p in map.rglob('*'):
  rel=p.relative_to(map)
  if not p.is_file() or 'dist' in rel.parts or '__pycache__' in rel.parts or p.suffix=='.pyc':continue
  if p.name.endswith(('.tar.gz','.tar.xz')):continue
  with p.open('rb') as f:elf=f.read(4)==b'\x7fELF'
  if elf:continue
  assert p.stat().st_size<16*1024*1024,(p,p.stat().st_size)
  leden[str(Path(prefix)/rel)]=p
uit=r/'docs/tests/writer-statistiekrust-2026-11-12';uit.mkdir(exist_ok=False);arch=uit/'bewijs.tar.gz'
with tarfile.open(arch,'w:gz') as t:
 for n,p in sorted(leden.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(arch) as t:
 for m in t:assert m.isfile() and '..' not in Path(m.name).parts and t.extractfile(m).read()==leden[m.name].read_bytes()
rapport={
 'schema':1,'datum':'2026-11-12','status':'Lokaal functioneel en visueel gecontroleerde beperking van achtergrondtelling. Writer-vertraging en volledige migratie blijven open.',
 'basis':'8f2154627be1ada3772cfaab6c985123043aef49','ontwikkelbranch':'codex/native-rust-office-integratie',
 'wijziging':'De bestaande600ms-statusbalktelling begint pas zonder lopende invoer. Ze volgt de actuele editor-ref, bindt resultaten aan sessie en bronversie, verwerpt late/verouderde antwoorden en annuleert bij vervangen/ontkoppelen. De invoerwachtrij, Undo-groepering en Rust-bronbindingscontroles zijn niet gewijzigd. Een al begonnen leesactie wordt niet afgebroken.',
 'bronpinnen':pinnen,'programma':json.loads((u/'desktop.json').read_text()),
 'afgekeurd':['Eerste uitleesprobe:4096monsters en305overgeslagen; niet als geslaagde proef gebruikt. Begrensde herhaling8192 registreert wel alle5203aanroepen en herstelt de echte methoden.','Eerste echte desktopkandidaatd89c faalt op de onafhankelijke91423-tekencontrole:statusbalktelling ontbreekt. Ongewijzigde negatieve bron/logs/beelden en herstelgeteste ELF-archivering behouden. Niet gecommit of uitgegeven.','De definitieve kandidaat volgt sessie/versie via een actuele ref-getter; een vernieuwd openbaar API-object mag dezelfde geldige bron niet laten verdwijnen. Extra regressie hiervoor toegevoegd. Dezelfde GUI-controle slaagt nu in beide rijke kandidaatproeven.'],
 'controles':['2337frontendtests in228bestanden, inclusief9nieuwe statusplanningsgevallen en de bestaande echte Rust-hostproeven.','TypeScript en Vite slagen. Alleen de appcrate herbouwd voor de definitieve native ELF; minimum3234508800vrije bytes, boven3GiB.','127Python-tests slagen.','Acht volledige native scenario’s, klein ABBA en rijk ABBA; gewone invoer zonder kunstmatige antwoordvertraging, exacte tekst/stand/Undo/Redo, afzonderlijke selectie/vervanging/bewaring en verwerpen met vastgehouden echte antwoorden.','Rijke opgeslagen bestanden:128tabellen en hoofdtekst exact teruggelezen. Statusbalk telt91423tekens, onafhankelijk uitDOCX berekend; nieuw document toont14tekens. NulGUI-/engine-/consolefouten.','Vijf vaste ELF-referenties en alle529standaardbundelbestanden (bytes/mode/mtime) na beide bouwen exact behouden.'],
 'rondes':a['rondes'],'vergelijking':a['vergelijking'],
 'duiding':'In deze twee waarnemingen per variant daalt de mediane totale wandtijd klein2015→1705ms en rijk23740,5→20624ms. Losse sessie-alineauitlezingen tijdens rijke invoer:4615→1539 in beide paren. Rijke eindlatency oud2496/2386ms tegenover nieuw2545/2425ms:iets hoger, dus geen eindlatencyfix of algemene snelheidsacceptatie. Er zijn nog circa2,5s na laatste ontvangen toets nodig.',
 'visueel':{'bekeken':['klein-nieuw-a/snel-getypt-bewaard.png','rijk-nieuw-a/invoer-redo.png','rijk-nieuw-b/snel-getypt-bewaard.png','rijk-nieuw-b/nieuw-na-laat-antwoord.png','eerder/rijk-nieuw-a/afgekeurd.png'],'vergelijking':json.loads((u/'beeldvergelijking.json').read_text()),'grens':'Zes korte kandidaatbeelden volledig pixelgelijk aan de korte referentie. Rijke kandidaatbeelden verschillen25–91pixels op vastgelegde cursor-/pictogram-/statusposities; geen volledige pixelpariteit geclaimd.'},
 'bestandsbehoud':{'vergelijking':json.loads((u/'docx-verschillen.json').read_text()),'grens':'Alle ZIP-leden exact gelijk aan de eigen referentiebewaring, behoudens onafhankelijk vastgelegde Modified en soms TotalTime. Geen opgeslagen DOCX opnieuw via de GUI geopend in deze proeven.'},
 'opslag':'Drie eigen afgewezen programma’s, vijf eigen oude encodertestbinaries en de eerste afgekeurde kandidaat zijn verliesloos en met werkelijk herstel van bytes/mode/mtime gearchiveerd. Dubbele eigen Cargo-appcachelinks verwijderd met vastgelegde herstelbron. Rustbibliotheken, gebruikersdocumenten en vaste vijf referenties behouden. Metadata in bewijs; grote private ELF-archieven niet gepubliceerd.',
 'platformen':{'native_ci_4e':{'url':ci['url'],'bron':ci['headSha'],'conclusion':ci['conclusion'],'banen':[{k:x[k] for k in ['name','conclusion']} for x in ci['jobs']]},'grens':'Deze geheel groene native CI betreft de eerdere Rust-/encodertestbron4e, niet de nieuwe desktop-UI-bron. Definitieve kandidaat lokaal alleen Linux-schema2 onderzocht. Nieuwe desktopmatrix en afzonderlijke Linuxdev-build moeten na push afzonderlijk worden gecontroleerd.'},
 'niet_afgerond':['Volledige Writer-invoer-/selectieprestatie, alle functies/edities, fysieke paint/FPS en hardware-IME.','Nieuwe Windows-/macOS-desktopresultaten en Linuxdev-pakket voor deze bron.','Schema3-GUI en volledige lokale native workspace-/vendor-suite niet opnieuw uitgevoerd.','Geen issue gesloten, geen migratiegebied als volledig aangemerkt; migratiecontrole meldt nog10open gebieden.'],
 'vervolg':'Na push desktopmatrix en geïsoleerde Linuxdev-build volgen. Vervolgens de resterende story-/positieprojectie en tabelPayload-herlezing in echte invoergroepen meten; geen onveilige tabelcache of blinde invoerwachttijd toevoegen.',
 'bewijs':{'pad':str(arch.relative_to(r)),'sha256':sha(arch),'bytes':arch.stat().st_size,'bestanden':len(leden),'elk_lid_bytegelijk_gecontroleerd':True}
}
(r/'docs/tests/2026-11-12-writer-statistiekrust.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rapport['bewijs']))
p=r/'docs/voortgang-migratie.md';s=p.read_text();i=s.index('\n')+1
bullet='\n- De Writer-statusbalktelling begint nu pas bij invoerrust en publiceert alleen uit dezelfde sessie/bronversie; vernieuwde API-refs blijven bruikbaar. Een eerste kandidaat met lege telling is afgekeurd en behouden. Definitief2337frontendtests, TypeScript, web-/Linux-bouw,127Python-tests en acht native ABBA-functieproeven groen. Rijke alineauitlezingen dalen4615→1539; totale invoerwandtijd is in de twee paren lager, maar de rijke eindlatency blijft circa2,5s en iets hoger (+49/+39ms). Status91423tekens na bewaren en14in nieuw document onafhankelijk gecontroleerd;128tabellen exact. Korte kandidaatbeelden pixelgelijk; rijke cursor-/UI-verschillen en DOCX-tijdmetadata vastgelegd. Geen algemene snelheids-, platform- of migratieacceptatie. [Bron, afkeuring, controles en ruwe beelden](tests/2026-11-12-writer-statistiekrust.json).\n'
p.write_text(s[:i]+bullet+s[i:])
