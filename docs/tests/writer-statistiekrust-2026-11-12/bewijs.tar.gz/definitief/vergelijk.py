from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
import json
from PIL import Image,ImageChops
u=Path(__file__).resolve().parent;uit={};delen={}
for soort in ['klein','rijk']:
 referentie=u/(soort+'-oud-a')
 for variant in ['nieuw-a','nieuw-b','oud-b']:
  n=soort+'-'+variant;p=u/n;uit[n]={};delen[n]={}
  for naam in ['invoer-redo','snel-getypt-bewaard','nieuw-na-laat-antwoord']:
   a=Image.open(referentie/(naam+'.png')).convert('RGB');b=Image.open(p/(naam+'.png')).convert('RGB');assert a.size==b.size
   d=ImageChops.difference(a,b);box=d.getbbox();pixels=sum(v!=(0,0,0) for v in d.getdata());uit[n][naam]={'pixels':pixels,'bbox':box}
  with ZipFile(referentie/'Ontwerpnotitie.docx') as a,ZipFile(p/'Ontwerpnotitie.docx') as b:
   assert set(a.namelist())==set(b.namelist())
   for naam in a.namelist():
    x,y=a.read(naam),b.read(naam)
    if x==y:continue
    assert naam in ['docProps/core.xml','docProps/app.xml'],(n,naam)
    aa,bb=E.fromstring(x),E.fromstring(y);verschil=[]
    for xx,yy in zip(aa.iter(),bb.iter()):
     assert xx.tag==yy.tag and xx.attrib==yy.attrib
     if xx.text!=yy.text:
      verschil.append({'tag':xx.tag,'oud':xx.text,'nieuw':yy.text});assert xx.tag in ['{http://purl.org/dc/terms/}modified','{http://schemas.openxmlformats.org/officeDocument/2006/extended-properties}TotalTime']
      xx.text=yy.text
    assert E.tostring(aa)==E.tostring(bb)
    delen[n][naam]=verschil
(u/'beeldvergelijking.json').write_text(json.dumps(uit,indent=2)+'\n');(u/'docx-verschillen.json').write_text(json.dumps(delen,indent=2)+'\n');print(json.dumps(uit));print('Alle DOCX-leden exact, behoudens vastgelegde Modified/TotalTime.')
