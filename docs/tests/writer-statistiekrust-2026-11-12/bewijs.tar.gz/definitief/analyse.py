"""Controleer alle gewone invoer apart van de vastgehouden functietests."""
from pathlib import Path
import collections,hashlib,json,statistics
from zipfile import ZipFile
from xml.etree import ElementTree as E
u=Path(__file__).resolve().parent
b=json.loads((u/'desktop.json').read_text());assert b['code']==0 and b['gecompileerde_crates']==['open-office-studio']
uit={}
for soort in ['klein','rijk']:
 for naam in ['oud-a','nieuw-a','nieuw-b','oud-b']:
  n=soort+'-'+naam;p=u/n;r=json.loads((p/'rapport.json').read_text())
  assert r['geslaagd'] and r['schema']==2 and not any(r['fouten'].values()),n
  h=b['programma_sha256'] if naam.startswith('nieuw') else '7afdfb82ac07c31ef1e086598e4573c9695d1e6d4b72a91ec822c30bd128aa8f'
  assert r['programma_sha256']==h
  tekst=' Een korte zin. EINDEPROEF.' if soort=='klein' else ' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.'
  prefix='';calls=[]
  for m in r['native_opdrachten']:
   calls.append(m)
   if m.get('caret'):prefix+=m['text']
   assert tekst.startswith(prefix),n
   if prefix==tekst:break
  assert prefix==tekst and all(x['bronbinding'] and x['gereed'] and not x.get('vertragingMs') and not x['wacht'] for x in calls)
  x={'geslaagd':True,'programma_sha256':h,'invoer':r['lange_invoer'],'gewone_native_opdrachten':len(calls),'undo_groepen':r['undo_groepen_lange_invoer'],'fouten':r['fouten']}
  if soort=='rijk':
   a=r['uitlezingen'];assert a['hersteld'] and a['overgeslagen']==0 and a['grens']==8192
   rows=a['regels'];c=collections.Counter(x['naam'] for x in rows)
   assert all(not x['fout'] and x['duur']>=0 and x['versie'] for x in rows)
   x.update(sessie_uitlezingen=dict(c),synchrone_uitleesduur_ms={k:round(sum(x['duur'] for x in rows if x['naam']==k),3) for k in c},status_na_bewaren=r['status_na_bewaren'],status_nieuw_document=r['status_nieuw_document'])
   assert r['bewaarde_tabellen_exact']==128 and r['status_na_bewaren']['tekens']==91423 and '14 characters' in r['status_nieuw_document']
   ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
   with ZipFile(p/'Ontwerpnotitie.docx') as z:xml=E.fromstring(z.read('word/document.xml'))
   assert sum(len(''.join(t.text or '' for t in p.findall('.//w:t',ns))) for p in xml.findall('.//w:p',ns))==91423
  uit[n]=x
sam={}
for soort in ['klein','rijk']:
 sam[soort]={}
 for variant in ['oud','nieuw']:
  rs=[uit[soort+'-'+variant+'-'+n] for n in ['a','b']]
  sam[soort][variant]={'wall_ms':[r['invoer']['wall_begin_tot_frame_ms'] for r in rs],'laatste_keyup_tot_frame_ms':[r['invoer']['laatste_keyup_tot_frame_ms'] for r in rs],'native_opdrachten':[r['gewone_native_opdrachten'] for r in rs]}
(u/'analyse.json').write_text(json.dumps({'rondes':uit,'vergelijking':sam,'grens':'Twee waarnemingen per variant; geen statistische zekerheid, fysieke paint/FPS of volledige Writer-snelheidsacceptatie. Uitleesduur is synchroon en bevat niet de overige wachttijd.'},ensure_ascii=False,indent=2)+'\n')
for n,r in uit.items():print(n,r['invoer']['wall_begin_tot_frame_ms'],r['invoer']['laatste_keyup_tot_frame_ms'],r['gewone_native_opdrachten'],r.get('sessie_uitlezingen'))
