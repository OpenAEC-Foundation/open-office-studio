from pathlib import Path
import hashlib,json,tarfile,tempfile,os,stat
r=Path.cwd();u=r/'.local/integratiecontrole/status-telling';p=r/'.local/integratiecontrole/bron-uitlezingen/open-office-studio-status-telling';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h='d89c2d67100ed50af38c74afddce107657f65669f8a14ce4230b8c5ea6773edf';assert sha(p)==h;st=p.stat();a=u/'eerste-afgekeurde-kandidaat.tar.gz'
with tarfile.open(a,'x:gz',format=tarfile.PAX_FORMAT) as t:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(a) as t,tempfile.TemporaryDirectory(dir=u) as tmp:
 q=Path(tmp)/p.name;q.write_bytes(t.extractfile(p.name).read());q.chmod(stat.S_IMODE(st.st_mode));os.utime(q,ns=(st.st_mtime_ns,st.st_mtime_ns));assert sha(q)==h and q.stat().st_mtime_ns==st.st_mtime_ns and stat.S_IMODE(q.stat().st_mode)==stat.S_IMODE(st.st_mode)
m={'origineel':str(p),'lid':p.name,'sha256':h,'mode':stat.S_IMODE(st.st_mode),'mtime_ns':st.st_mtime_ns,'archief':str(a),'archief_sha256':sha(a),'herstel_getest':True};(u/'eerste-kandidaat-archief.json').write_text(json.dumps(m,indent=2)+'\n');p.unlink();print('Eigen afgekeurde eerste kandidaat verliesloos en herstelgetest gearchiveerd.')
