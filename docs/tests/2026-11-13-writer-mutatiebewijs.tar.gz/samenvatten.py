from pathlib import Path
import json,hashlib,stat,gzip
p=Path(__file__).resolve().parent;repo=p.parents[2];sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();r=json.load(open(p/'controle-definitief.json'));assert r['geslaagd'];assert len(r['gevallen'])==24;steps=[s for c in r['gevallen']for s in c['stappen']];assert len(steps)==35;assert sum(s['proof']['accepted']for s in steps)==12
raw=json.load(open(p/'controle-ruw.json'));assert raw['geslaagd'] and len(raw['gevallen'])==23
pin=json.load(open(p/'bronpinnen.json'));src=repo/'.local/integratiecontrole/font-hergebruik/bron/crates/docx-edit/src'
for n,v in pin.items():assert sha(src/n)==v['na_sha256']
assert sha(src/'engine.rs')==json.load(open(repo/'.local/integratiecontrole/font-hergebruik/route-bronpinnen.json'))['engine_na']
refs=json.load(open(repo/'.local/integratiecontrole/werker-fasekopie/referenties-nacontrole.json'));assert len(refs)==16
for q,h in refs.items():assert sha(Path(q))==h
files=json.load(open(repo/'.local/integratiecontrole/werker-fasekopie/standaardbundel.json'));assert len(files)==529
for n,v in files.items():
 q=repo/'dist'/n;s=q.stat();assert sha(q)==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and s.st_mtime_ns==v['mtime_ns'],n
assert len([q for q in (repo/'dist').rglob('*')if q.is_file()])==529
assert sha(repo/'node_modules/@betteroffice/docx-react/dist/index.mjs')=='85a8d0fd2c1f45b1a1fc5b9b7e9fa0065ffee4dd6ad423939798f421fe9bffbb'
meta=json.load(open(repo/'patches/tekstengine-nootnummering.json'))
for q,h in [('vendor/tekstengine/docx_edit_bg.wasm',meta['wasmSha256']),('vendor/tekstengine/docx_layout_bg.wasm',meta['layoutWasmSha256']),('node_modules/@betteroffice/docx/dist/generated/edit/docx_edit_bg.wasm',meta['oorspronkelijkWasmSha256'])]:assert sha(repo/q)==h
for n in ['kern','kern2','kern2-ruw']:
 info=json.load(open(p/n/'bouw.json'));assert sha(p/n/'docx_edit_bg.wasm')==info['sha256'];(p/(n+'-bouwgegevens.json')).write_text(json.dumps(info,indent=2)+'\n')
r={'geslaagd':True,'gevallen':24,'updates':35,'toegelaten':12,'afgewezen':23,'ruwe_kern_gevallen':23,'ruwe_kern_updates':27,'ruwe_en_geoptimaliseerde_kern_functioneel_gecontroleerd':True,'geoptimaliseerd_alle_stappen_volledige_staat_vector_body_metadata_font_blokken_exact':True,'nieuwe_mutatiebron_en_bestaande_font_engine_exact_aan_bouw_gebonden':True,'behoud':{'ELFs_exact':16,'standaarddist_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':True},'eerder_afgewezen':{'bouw_afgebroken':'Eigen bron vooraf aangescherpt: geen oud positief profiel na fout; registratielimieten.','bouw_lege_map':'Herstart geweigerd omdat de lege eigen uitvoermap al bestond; lege map en foutlog behouden, opnieuw met lege nieuwe uitvoer.','eerste_corpus':'Er werd null doorgegeven aan een verplichte datumstring; uitsluitend proef gecorrigeerd naar vaste synthetische datum, eerste corpus en log behouden.','eerste_kern':'Arc::try_unwrap nam ten onrechte uniek eigendom van de meetbuffer aan. Eigen Wasm-panic en daaropvolgende free-borrowfout vastgelegd. Buffer wordt nu onder mutex uitgenomen na afmelden; oude module109f811d behouden, geen productstabiliteitsclaim.'}}
(p/'samenvatting.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r))
