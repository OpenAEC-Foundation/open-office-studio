use std::collections::BTreeSet;
use std::sync::{Arc, Mutex};

use serde::Serialize;
use yrs::types::{DeepObservable, Delta, Event, PathSegment};
use yrs::{Any, BranchID, Out, ReadTxn, Transact};

use crate::{CommitHook, EditingDoc};

#[derive(Default, Serialize)]
struct Observed {
    commits: u32,
    text_events: u32,
    insertions: u32,
    start: Option<u32>,
    text: Option<String>,
    attribute_keys: Vec<String>,
    roots: BTreeSet<String>,
    reasons: BTreeSet<&'static str>,
}

#[derive(Serialize)]
pub(crate) struct Proof {
    accepted: bool,
    before_epoch: u64,
    after_epoch: u64,
    paragraph: Option<String>,
    offset: Option<u32>,
    observed: Observed,
}

pub(crate) struct UpdateWatch {
    state: Arc<Mutex<Observed>>,
    before_epoch: u64,
    before_roots: Option<Vec<String>>,
    before_index: Option<Arc<crate::segments::ParagraphIndex>>,
    pending_before: bool,
    subscription: Option<yrs::Subscription>,
    hook: CommitHook,
}

fn roots(doc: &EditingDoc) -> Option<Vec<String>> {
    let txn = doc.yrs_doc().transact();
    let mut names: Vec<_> = txn
        .root_refs()
        .take(33)
        .map(|(name, _)| name.to_owned())
        .collect();
    if names.len() > 32 || names.iter().any(|name| name.len() > 256) {
        return None;
    }
    names.sort();
    Some(names)
}

impl UpdateWatch {
    pub(crate) fn new(doc: &EditingDoc) -> Self {
        let state = Arc::new(Mutex::new(Observed::default()));
        let recording = Arc::clone(&state);
        let subscription = {
            let txn = doc.yrs_doc().transact();
            txn.get_map(crate::STORIES).map(|stories| stories.observe_deep(move |txn, events| {
                let mut state = recording.lock().unwrap();
                for event in events.iter() {
                    let Event::Text(event) = event else {
                        state.reasons.insert("non_text_event");
                        continue;
                    };
                    state.text_events = state.text_events.saturating_add(1);
                    if state.text_events > 32 {
                        state.reasons.insert("event_bound");
                        continue;
                    }
                    let path = event.path();
                    if path.len() != 1 || !matches!(path.front(), Some(PathSegment::Key(key)) if key.as_ref() == "body") {
                        state.reasons.insert("not_body_text");
                    }
                    let mut index = 0_u32;
                    for delta in event.delta(txn) {
                        match delta {
                            Delta::Retain(length, attributes) => {
                                if attributes.is_some() {
                                    state.reasons.insert("retained_format_change");
                                }
                                index = index.saturating_add(*length);
                            }
                            Delta::Deleted(_) => {
                                state.reasons.insert("deletion");
                            }
                            Delta::Inserted(Out::Any(Any::String(text)), attributes) => {
                                state.insertions = state.insertions.saturating_add(1);
                                let units = text.encode_utf16().count();
                                if units == 0 || units > 4096 || text.chars().any(|c| matches!(c, '\r' | '\n')) {
                                    state.reasons.insert("text_boundary");
                                } else if state.insertions == 1 {
                                    state.start = Some(index);
                                    state.text = Some(text.to_string());
                                }
                                if let Some(attributes) = attributes {
                                    if attributes.len() > 32 || attributes.keys().any(|key| key.len() > 128) {
                                        state.reasons.insert("attribute_bound");
                                    } else {
                                        state.attribute_keys = attributes.keys().map(|key| key.to_string()).collect();
                                        state.attribute_keys.sort();
                                    }
                                }
                                index = index.saturating_add(u32::try_from(units).unwrap_or(u32::MAX));
                            }
                            Delta::Inserted(_, _) => {
                                state.reasons.insert("embedded_content");
                                index = index.saturating_add(1);
                            }
                        }
                    }
                }
            }))
        };
        let recording = Arc::clone(&state);
        let hook = doc.observe_commit(move |txn| {
            if txn.before_state() == txn.after_state() && txn.delete_set().is_empty() {
                return;
            }
            let mut state = recording.lock().unwrap();
            state.commits = state.commits.saturating_add(1);
            let mut found_root = false;
            for branch in txn.changed_parent_types() {
                if let BranchID::Root(name) = branch.id() {
                    found_root = true;
                    if state.roots.len() >= 32 {
                        state.reasons.insert("root_bound");
                        break;
                    }
                    if name.len() > 256 {
                        state.reasons.insert("root_name_bound");
                        continue;
                    }
                    state.roots.insert(name.to_string());
                    if name.as_ref() != crate::STORIES {
                        state.reasons.insert("other_root");
                    }
                }
            }
            if !found_root {
                state.reasons.insert("missing_root_event");
            }
        });
        Self {
            state,
            before_epoch: doc.committed_epoch(),
            before_roots: roots(doc),
            before_index: doc.paragraph_index("body").ok(),
            pending_before: doc.holds_pending_update(),
            subscription,
            hook,
        }
    }

    pub(crate) fn finish(self, doc: &EditingDoc) -> Proof {
        let Self {
            state,
            before_epoch,
            before_roots,
            before_index,
            pending_before,
            subscription,
            hook,
        } = self;
        drop(subscription);
        drop(hook);
        let mut observed = Arc::try_unwrap(state).ok().unwrap().into_inner().unwrap();
        let after_epoch = doc.committed_epoch();
        if before_roots.is_none() || roots(doc) != before_roots {
            observed.reasons.insert("root_set_changed");
        }
        if pending_before || doc.holds_pending_update() {
            observed.reasons.insert("pending_update");
        }
        if observed.commits != 1 || after_epoch != before_epoch.wrapping_add(1) {
            observed.reasons.insert("commit_boundary");
        }
        if observed.text_events != 1 || observed.insertions != 1 {
            observed.reasons.insert("not_one_insertion");
        }
        if observed.roots.len() != 1 || !observed.roots.contains(crate::STORIES) {
            observed.reasons.insert("not_one_root");
        }
        let (paragraph, offset) = (|| {
            let start = observed.start?;
            let before = before_index.as_ref()?.para_at(start)?;
            let after_index = doc.paragraph_index("body").ok()?;
            let after = after_index.para_at(start)?;
            if before.para_id != after.para_id
                || before.start != after.start
                || start < before.start
            {
                return None;
            }
            Some((Some(before.para_id.to_string()), Some(start - before.start)))
        })()
        .unwrap_or_else(|| {
            observed.reasons.insert("paragraph_boundary");
            (None, None)
        });
        Proof {
            accepted: observed.reasons.is_empty(),
            before_epoch,
            after_epoch,
            paragraph,
            offset,
            observed,
        }
    }
}
