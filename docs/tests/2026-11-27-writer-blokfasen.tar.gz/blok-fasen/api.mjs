import fs from 'node:fs';import path from 'node:path';import {pathToFileURL}from'node:url';import assert from'node:assert/strict';import crypto from'node:crypto';
const p=path.resolve('.local/integratiecontrole/blok-fasen'),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),wasm=fs.readFileSync(process.argv[2]);assert.equal(sha(wasm),process.argv[3]);const label=process.argv[4];assert.match(label,/^[a-z-]+$/);
const corpus=JSON.parse(fs.readFileSync('.local/integratiecontrole/replica-paragraaf/corpus-met-projectie.json')),initial=corpus.gevallen[0].initial;
const raw=fs.readFileSync(initial.origin?path.resolve('.local/integratiecontrole',initial.origin,initial.file):path.resolve('.local/integratiecontrole/replica-paragraaf',initial.file));assert.equal(sha(raw),initial.sha256);
const {preloadEditWasm,createEditSession}=await import(pathToFileURL(path.resolve('node_modules/@betteroffice/docx/dist/wasm-edit.mjs')).href);await preloadEditWasm(wasm);const s=createEditSession(902),rows=[];
try{s.open_docx(fs.readFileSync('docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx'),false);s.load(raw);
for(const[name,story,env]of [['leeg','body','{}'],['cachehit','body','{}'],['media','body','{"mediaTokens":true}'],['nultolerantie','body','null'],['arraytolerantie','body','[]'],['verkeerdeveldtypes','body','{"defaultTabStopTwips":"x","showHiddenText":"nee"}'],['grid','body','{"showTableGridlines":true}'],['jsonfout','body','{'],['onbekend','niet-bestaand','{}']]){
 const state=sha(s.encode_state()),vector=sha(s.encode_state_vector()),version=s.version();let value=null,error=null;
 try{value=s.yrs_blocks_for_story(story,env)}catch(e){error=String(e)}
 assert.equal(sha(s.encode_state()),state);assert.equal(sha(s.encode_state_vector()),vector);assert.equal(s.version(),version);
 rows.push({name,error,sha256:value===null?null:sha(value),bytes:value===null?null:Buffer.byteLength(value),profile:value===null?null:JSON.parse(s.apply_input_profile_json())});
}
fs.writeFileSync(path.join(p,`api-${label}.json`),JSON.stringify({geslaagd:true,wasm_sha256:sha(wasm),rows},null,2)+'\n');console.log(JSON.stringify({geslaagd:true,gevallen:rows.length}));}finally{s.free()}
