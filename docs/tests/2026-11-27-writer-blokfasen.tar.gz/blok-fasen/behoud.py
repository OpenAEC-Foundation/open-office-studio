from pathlib import Path
import hashlib,json,stat,ast,re
r=Path.cwd();p=r/'.local/integratiecontrole/blok-fasen';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();old=r/'.local/integratiecontrole/projectie-context-telling-herbouw'
refs=json.loads((r/'.local/integratiecontrole/sync-contract/referenties-nacontrole.json').read_text());assert len(refs)==31
for f,h in refs.items():assert sha(Path(f))==h
exe=p/'open-office-studio-blok-fasen';build=json.loads((p/'desktop.json').read_text());assert build['code']==0 and sha(exe)==build['programma_sha256'];refs[str(exe)]=sha(exe);(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_canonieke_bron_exact'];assert len(pins)==15
for f,h in pins.items():assert sha(r/f)==h
bundle=json.loads((old/'standaardbundel.json').read_text());assert len(bundle)==529
for f,v in bundle.items():
 q=r/'dist'/f;assert sha(q)==v['sha256']and stat.S_IMODE(q.stat().st_mode)==v['mode']and q.stat().st_mtime_ns==v['mtime_ns']
base=r/'.local/integratiecontrole/sync-contract/dist';bf={str(f.relative_to(base)):sha(f)for f in base.rglob('*')if f.is_file()};cf={str(f.relative_to(p/'dist')):sha(f)for f in(p/'dist').rglob('*')if f.is_file()};assert set(bf)==set(cf);diff=[n for n in bf if bf[n]!=cf[n]];assert set(diff)=={'assets/chunk-Q7OC7M5Q-BzppsI5m.js','assets/docx_edit_bg-ONvZFP_n.wasm'}
for f in p.glob('*.py'):ast.parse(f.read_text())
assert set(re.findall(r'^\s*Compiling ([^ ]+)',(p/'desktop.log').read_text(),re.M))=={'open-office-studio'}
result={'oude_referenties31_exact':True,'aanwezige_referenties':32,'nieuwe_elf_sha256':sha(exe),'bronpinnen15_exact':True,'standaardbundel529_byte_mode_mtime_exact':True,'verschillende_assets_tegen_sync_contract':diff,'python_ast_groen':True,'alleen_app_crate_herbouwd':True,'historisch_ontbrekende_autocorrectiereferentie':'Blijft reeds ontbreken; niet verwijderd.'};(p/'behoud.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
