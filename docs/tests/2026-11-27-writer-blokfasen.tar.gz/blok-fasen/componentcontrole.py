from pathlib import Path
import json
p=Path(__file__).resolve().parent;a=json.loads((p/'api-basis.json').read_text());b=json.loads((p/'api-klok.json').read_text());assert a['geslaagd']and b['geslaagd'];assert len(a['rows'])==len(b['rows'])==9
for x,y in zip(a['rows'],b['rows']):
 for k in ['name','error','sha256','bytes']:assert x[k]==y[k],(x['name'],k)
 if y['error']is None:assert y['profile']['kind']=='blocks'and y['profile']['error']is None
cached=next(x for x in b['rows']if x['name']=='cachehit')['profile'];assert cached['before']['serialized_cached']and cached['before']['env_equal'];assert not any(x[0].startswith('serde_')for x in cached['marks']);assert cached['before']['misses']==cached['after']['misses']and cached['after']['hits']==cached['before']['hits']+1
c=json.loads((p/'klok.json').read_text());assert c['geslaagd'];rows=[s for x in c['gevallen']for s in x['stappen']];assert len(c['gevallen'])==30 and len(rows)==43;assert all(x['blockProfile']['kind']=='blocks'and x['blockProfile']['error']is None for x in rows)
out={'geslaagd':True,'corpusgevallen':30,'updates':43,'bloklezing_bewaart_staat':True,'apiproeven':9,'apifouten':sum(x['error']is not None for x in b['rows']),'api_uitvoer_en_fouten_exact':True,'herhaalde_lezing_cachehit_zonder_serde':True,'grens':'Componentproef in Node; vaste corpusasserties voor inference/errors/staat/vector/body/marges/metadata/fonts/blokken behouden, plus staat na bloklezing. API-cases behouden staat/vector en sessiegebonden versie. Geen native snelheid/visuele dekking.'};(p/'componentcontrole.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
