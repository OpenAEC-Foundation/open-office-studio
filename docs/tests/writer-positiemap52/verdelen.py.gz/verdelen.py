from pathlib import Path
import json,gzip,hashlib,collections
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/cpu52-geijkt';uit=r/'.local/doorwerk-2026-11-06/cpu52-verdeling';p=json.loads((u/'gui/profiel.json').read_text());assert p['geslaagd']and p['cpu_kalibratie']['leaf_eerst']and p['cpu_kalibratie']['aantal']==90
c=json.loads((u/'gui/cpu.json').read_text());assert not c['fout'];t=[m for m in c['berichten']if m['method']=='ScriptProfiler.trackingComplete'];assert len(t)==1;stacks=t[0]['params']['samples']['stackTraces'];assert len(stacks)==5329
bronnen={}
for b in p['cpu_scriptbronnen']:
 data=gzip.decompress((u/'gui'/b['bestand']).read_bytes());assert hashlib.sha256(data).hexdigest()==b['sha256'];bronnen[b['url']]=data.decode().splitlines()
def kader(f):return(f['name'],f['url'],f['line'],f['column'])
def detail(k,n):
 naam,url,lijn,kolom=k;d={'samples':n,'naam':naam,'url':url,'lijn':lijn,'kolom':kolom}
 if url in bronnen and lijn>0 and kolom>0:
  data=bronnen[url][lijn-1].encode('utf-16-le');start=(kolom-1)*2;d['bronfragment']=data[max(0,start-160):start+500].decode('utf-16-le',errors='replace')
 return d
result=[]
for doel in ['buildStory','paragraphSpans','readStories','getDocument']:
 totaal=collections.Counter();paden=collections.Counter();mede=collections.Counter()
 for s in stacks:
  fs=s['stackFrames'];pos=[i for i,f in enumerate(fs)if f['name']==doel]
  if not pos:continue
  namen={f['name']for f in fs};mede.update([n for n in ['getDocument','buildStory','paragraphSpans','readStories']if n in namen])
  # Eén keer per sample tellen; buitenste recursieve doel bepaalt de bovenliggende route.
  rest=fs[max(pos)+1:];pad=tuple(kader(f)for f in rest[:7]);paden[pad]+=1
  if rest:totaal[kader(rest[0])]+=1
 result.append({'doel':doel,'samples':sum(paden.values()),'mede_in_dezelfde_stack':dict(mede),'directe_buitenste_aanroeper':[detail(k,n)for k,n in totaal.most_common(12)],'paden':[{'samples':n,'pad':[detail(k,n)for k in pad]}for pad,n in paden.most_common(10)]})
d={'samples':len(stacks),'kalibratie_voorbeelden':90,'raw_sha256':hashlib.sha256((u/'gui/cpu.json').read_bytes()).hexdigest(),'groepen':result,'grens':'Verdeling van bestaande nul-tijdstempelmonsters. Overlappende families, geen CPU-tijd, percentages van tijd of speed-up. Buitenste doelaanroep is na de runtime-geijkte leaf-eerstvolgorde gekozen. Alleen exacte eigen scriptbytes, kolommen UTF-16.'};(uit/'verdeling.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
for g in result:
 print(g['doel'],g['samples'],g['mede_in_dezelfde_stack'])
 for a in g['directe_buitenste_aanroeper'][:6]:print(a['samples'],a['naam'],a.get('bronfragment','')[:320])
