/** De echte rendererpublicatie bepaalt de vorm die de echte resolver ontvangt. */
import { readFileSync } from "node:fs";
import { afterEach, expect, it, vi } from "vitest";
const bron = readFileSync("node_modules/@betteroffice/docx-react/dist/index.mjs", "utf8");
const metadata = readFileSync("node_modules/@betteroffice/docx-react/dist/chunk-LZ2DPBZ6.mjs", "utf8");
const mb = metadata.indexOf("var Lu=new WeakMap;function JE("), me = metadata.indexOf("var wi=new WeakMap", mb);
const hb = bron.indexOf("function _openaecQueryBronVersie(query){"), he = bron.indexOf("var Gv=", hb);
const fb = bron.indexOf("function Fm("), tb = bron.indexOf("var Ta=class", fb), te = bron.indexOf(";function Ea(", tb);
const xb = bron.indexOf("let X=useCallback((l,V)=>{let Ae=l.queries;"), xe = bron.indexOf("},[", xb);
if ([mb,me,hb,he,fb,tb,te,xb,xe].some(n => n < 0)) throw Error("Controleer metadata, resolver en echte publicatie na een SDK-update");
type Query = {isReady(): boolean};
type Snapshot = {queries:Query;frameEpoch:number|null};
const meta = new Function(`${metadata.slice(mb,me)};return {schrijf:JE,lees:Ci}`)() as {schrijf(q:Query,v:string):void;lees(q:Query):string|null};
const lees = new Function("c", `${bron.slice(hb,he)};return _openaecQueryBronVersie`)(meta.lees);
const Klass = new Function("b$1", "_openaecQueryBronVersie", `${bron.slice(fb,tb)};${bron.slice(tb,te)};return Ta`)(
  (o:Record<string,unknown>,k:string,v:unknown) => {o[k]=v;}, lees,
) as new () => {current:Snapshot|null;resolveVersion(o:{version():string;maximumWaitMs:number}):Promise<{status:string;queries:Query|null}>};
afterEach(() => vi.useRealTimers());
it("bevestigt de echte {queries,frameEpoch}-publicatie en leest metadata van het binnenste object", async () => {
  vi.useFakeTimers(); const r = new Klass(), query = {isReady: () => true}; meta.schrijf(query,"bron");
  const frame = {queries:query,frame:{frameEpoch:42},displayList:{}};
  const context = {v:{current:3},A:r,Kb:()=>{},Kt:{},y:{current:frame},Y:{current:new Set()}};
  const publiceer = new Function(...Object.keys(context), `return ${bron.slice(xb+"let X=useCallback(".length,xe+1)}`)(...Object.values(context));
  const antwoord = r.resolveVersion({version: () => "bron",maximumWaitMs:25}); publiceer(frame,3);
  expect(r.current).toEqual({queries:query,frameEpoch:42});
  await vi.advanceTimersByTimeAsync(25);
  await expect(antwoord).resolves.toEqual({status:"ready",queries:query});
});
