from pathlib import Path
import os,subprocess,json,hashlib,shutil
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer';m=json.loads((r/'querypakket46-bronnen.json').read_text())
for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
for fase,cmd,lognaam in [('frontend',['node_modules/.bin/vitest','run'],'querypakket46-volledig.log'),('desktop',['node_modules/.bin/tauri','build','--no-bundle'],'querypakket46-bouw.log')]:
    print('START',fase,flush=True)
    with (r/lognaam).open('w') as log:
        p=subprocess.Popen(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
        (r/'querypakket46-levende-fase.json').write_text(json.dumps({'fase':fase,'pid':p.pid,'opdracht':cmd},indent=2)+'\n')
        code=p.wait()
    print('EINDE',fase,code,flush=True)
    if code:raise SystemExit(code)
for n,h in m['bronbestanden'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
bron=repo/'src-tauri/target/release/open-office-studio';doel=r/'open-office-studio-45.46-querypakket';assert not doel.exists()
digest=hashlib.sha256(bron.read_bytes()).hexdigest();assert digest!='5a35a86227724254a2d827c753506207de61e00d0adda383744f0d02c16e112e'
shutil.copy2(bron,doel);assert hashlib.sha256(doel.read_bytes()).hexdigest()==digest
m.update(programma=str(doel.relative_to(repo)),programma_sha256=digest)
(r/'querypakket46-bronnen.json').write_text(json.dumps(m,indent=2)+'\n')
compilers=[]
for p in Path('/proc').glob('[0-9]*/comm'):
    try:
        naam=p.read_text().strip()
        if naam in ['rustc','cargo','rust-lld','ld.lld','cc']:compilers.append((str(p.parent),naam))
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not compilers,compilers
print('Eigen ELF bevroren',digest,'; fysieke vergelijking starten',flush=True)
p=subprocess.run(['python3',str(r/'voer-querypakket46-passieve-metingen.py')],cwd=repo)
print('EINDE fysieke vergelijking',p.returncode,flush=True)
raise SystemExit(p.returncode)
