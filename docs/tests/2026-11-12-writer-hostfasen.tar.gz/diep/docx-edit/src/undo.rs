//! Local-origin undo management.
//!
//! One manager per session, scoped on the stories root, so every story — body, headers, footers,
//! notes and table cells — shares one ordered history. yrs gates `SystemClock`,
//! `Options::default()` and `UndoManager::new` off `wasm32-unknown-unknown`, so the manager is
//! built from explicit `Options` around an injectable [`Clock`]: native code reads the system
//! clock and the wasm host injects `Date.now`.

use std::cell::{Cell, RefCell};
use std::collections::{BTreeMap, HashSet};
use std::sync::{Arc, Mutex, Weak};

use yrs::sync::time::Clock;
use yrs::types::text::YChange;
use yrs::types::{DeepObservable, Delta, EntryChange, Event};
use yrs::{
    Any, Doc, IdSet, Map, MapRef, Origin, Out, ReadTxn, Snapshot, Subscription, Text, Transact,
};

use crate::identity::{IdentityRepair, IdentityWatch};
use crate::sticky_positions::{sticky_index, sticky_offset};
use crate::{COMMENTS, EditingDoc, STORIES};

/// Undo capture window.
pub const UNDO_CAPTURE_TIMEOUT_MS: u64 = 500;

/// Target undo depth; yrs exposes no stack-trim API.
pub const UNDO_DEPTH: usize = 100;

type AnchorBoundaries = [IdSet; 2];
type StoryVisibility = Vec<(String, bool)>;

#[derive(Default)]
struct AnchorHistory(
    Arc<Mutex<AnchorBoundaries>>,
    Arc<Mutex<StoryVisibility>>,
    Arc<Mutex<Option<HashSet<String>>>>,
);

#[derive(Default)]
struct AnchorState {
    current: AnchorBoundaries,
    pending: AnchorBoundaries,
    latest: Weak<Mutex<AnchorBoundaries>>,
    removed_before: HashSet<String>,
}

/// Policy for grouping tracked local transactions.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum UndoCaptureMode {
    #[default]
    Auto,
    Manual,
}

struct CaptureClock {
    source: Arc<dyn Clock>,
    state: Mutex<CaptureClockState>,
}

struct CaptureClockState {
    mode: UndoCaptureMode,
    ticks: u64,
    last_source: u64,
    input: Option<(u64, u64)>,
    last_input: Option<u64>,
}

impl CaptureClock {
    fn new(source: Arc<dyn Clock>) -> Self {
        Self {
            state: Mutex::new(CaptureClockState {
                mode: UndoCaptureMode::Auto,
                ticks: 1,
                last_source: source.now(),
                input: None,
                last_input: None,
            }),
            source,
        }
    }

    fn mode(&self) -> UndoCaptureMode {
        self.state.lock().unwrap().mode
    }

    fn set_mode(&self, mode: UndoCaptureMode) {
        self.state.lock().unwrap().mode = mode;
    }

    fn set_input_time(&self, span: Option<(u64, u64)>) {
        self.state.lock().unwrap().input = span.map(|(first, last)| (first, first.max(last)));
    }
}

impl Clock for CaptureClock {
    fn now(&self) -> u64 {
        let mut state = self.state.lock().unwrap();
        let now = self.source.now();
        // Yrs has no runtime timeout setter; its clock controls capture policy.
        let elapsed = match state.mode {
            UndoCaptureMode::Auto => match (state.input, state.last_input) {
                (Some((first, _)), Some(previous)) => first.saturating_sub(previous),
                _ => now.saturating_sub(state.last_source),
            },
            UndoCaptureMode::Manual => 0,
        };
        state.last_source = now;
        state.last_input = state.input.map(|(_, last)| last);
        state.ticks = state.ticks.saturating_add(elapsed);
        state.ticks
    }
}

/// The contract-shaped undo surface over yrs [`yrs::undo::UndoManager`].
pub struct DocUndoManager {
    inner: yrs::undo::UndoManager<AnchorHistory>,
    changed_stories: Arc<Mutex<Vec<String>>>,
    _popped: Subscription,
    doc: Doc,
    identities: IdentityRepair,
    anchor_state: Arc<Mutex<AnchorState>>,
    _anchors: Subscription,
    _removals: Subscription,
    _history: [Subscription; 2],
    clock: Arc<CaptureClock>,
}

/// System clock on native targets. `wasm32-unknown-unknown` has no ambient clock, so the fallback
/// advances a counter by a full capture window per reading: every transaction is its own step.
pub(crate) fn default_clock() -> Arc<dyn Clock> {
    #[cfg(not(all(target_family = "wasm", target_os = "unknown")))]
    {
        Arc::new(|| {
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|elapsed| elapsed.as_millis() as u64)
                .unwrap_or_default()
        })
    }
    #[cfg(all(target_family = "wasm", target_os = "unknown"))]
    {
        use std::sync::atomic::{AtomicU64, Ordering};
        let ticks = AtomicU64::new(0);
        Arc::new(move || ticks.fetch_add(UNDO_CAPTURE_TIMEOUT_MS + 1, Ordering::Relaxed))
    }
}

impl EditingDoc {
    /// Local-origin undo manager over every story, on the default clock. The replica keeps
    /// deleted content from then on.
    pub fn undo_manager(&self) -> DocUndoManager {
        DocUndoManager::new(self, default_clock())
    }
}

impl DocUndoManager {
    /// Tracks the local client id only, so agent, remote and system transactions (string
    /// origins) never enter the history; groups edits within [`UNDO_CAPTURE_TIMEOUT_MS`].
    fn new(doc: &EditingDoc, clock: Arc<dyn Clock>) -> Self {
        doc.keep_deleted();
        let clock = Arc::new(CaptureClock::new(clock));
        let options = yrs::undo::Options {
            capture_timeout_millis: UNDO_CAPTURE_TIMEOUT_MS,
            tracked_origins: HashSet::from([Origin::from(doc.client_id())]),
            capture_transaction: None,
            timestamp: clock.clone(),
            init_undo_stack: Vec::new(),
            init_redo_stack: Vec::new(),
        };
        let mut inner = yrs::undo::UndoManager::<AnchorHistory>::with_options(options);
        let root = stories_root(&doc.yrs_doc().transact());
        inner.expand_scope(doc.yrs_doc(), &root);
        let removed = doc
            .yrs_doc()
            .transact()
            .get_map(crate::REMOVED_STORIES)
            .expect("removed stories root is declared");
        inner.expand_scope(doc.yrs_doc(), &removed);
        let removal_root = removed.clone();
        let comments = doc
            .yrs_doc()
            .transact()
            .get_map(COMMENTS)
            .expect("comments root is declared");
        inner.expand_scope(doc.yrs_doc(), &comments);
        let parts = doc
            .yrs_doc()
            .transact()
            .get_map(crate::part_metadata::PART_METADATA)
            .expect("part metadata root is declared");
        inner.expand_scope(doc.yrs_doc(), &parts);
        let properties = doc
            .yrs_doc()
            .transact()
            .get_map(crate::document_properties::DOCUMENT_PROPERTIES)
            .expect("document properties root is declared");
        inner.expand_scope(doc.yrs_doc(), &properties);
        let margins = doc
            .yrs_doc()
            .transact()
            .get_map(crate::section_margins::SECTION_MARGINS)
            .expect("section margins root is declared");
        inner.expand_scope(doc.yrs_doc(), &margins);
        let anchor_root = comments.clone();
        let anchor_state = Arc::new(Mutex::new(AnchorState {
            current: comment_boundaries(&doc.doc.transact()),
            ..AnchorState::default()
        }));
        let changed_stories = Arc::new(Mutex::new(Vec::new()));
        let popped = {
            let changed_stories = Arc::clone(&changed_stories);
            let state = Arc::clone(&anchor_state);
            inner.observe_item_popped(move |txn, event| {
                if let Some(latest) = state.lock().unwrap().latest.upgrade() {
                    merge_boundaries(&mut latest.lock().unwrap(), &event.meta().0.lock().unwrap());
                }
                let comments_changed = event.has_changed(&comments)
                    || event.has_changed(&removed)
                    || event.has_changed(&parts)
                    || event.has_changed(&properties)
                    || event.has_changed(&margins);
                let mut changed: Vec<String> = crate::live_stories(&stories_root(txn), txn)
                    .filter_map(|(story, value)| match value {
                        Out::YText(text) if comments_changed || event.has_changed(&text) => {
                            Some(story.to_owned())
                        }
                        _ => None,
                    })
                    .collect();
                changed.sort();
                *lock(&changed_stories) = changed;
            })
        };
        let anchors = {
            let state = Arc::clone(&anchor_state);
            anchor_root.observe_deep(move |txn, _| {
                let next = comment_boundaries(txn);
                let mut state = state.lock().unwrap();
                state.pending = std::mem::replace(&mut state.current, next.clone());
                merge_boundaries(&mut state.pending, &next);
            })
        };
        let removals = {
            let state = Arc::clone(&anchor_state);
            let removed = removal_root.clone();
            removal_root.observe_deep(move |txn, events| {
                let mut before: HashSet<_> = removed.keys(txn).map(str::to_owned).collect();
                for event in events.iter() {
                    if let Event::Map(event) = event {
                        for (story, change) in event.keys(txn) {
                            match change {
                                EntryChange::Inserted(_) => {
                                    before.remove(story.as_ref());
                                }
                                EntryChange::Removed(_) | EntryChange::Updated(_, _) => {
                                    before.insert(story.to_string());
                                }
                            }
                        }
                    }
                }
                state.lock().unwrap().removed_before = before;
            })
        };
        let added = {
            let state = Arc::clone(&anchor_state);
            inner.observe_item_added(move |txn, event| {
                remember_history_boundaries(txn, event, &state);
            })
        };
        let updated = {
            let state = Arc::clone(&anchor_state);
            inner.observe_item_updated(move |txn, event| {
                remember_history_boundaries(txn, event, &state);
            })
        };
        Self {
            doc: doc.doc.clone(),
            identities: doc.identity_repair(),
            anchor_state,
            _anchors: anchors,
            _removals: removals,
            _history: [added, updated],
            clock,
            inner,
            changed_stories,
            _popped: popped,
        }
    }

    pub fn capture_mode(&self) -> UndoCaptureMode {
        self.clock.mode()
    }

    /// Pins the input span used to measure the next capture gap.
    pub fn set_input_time(&self, span: Option<(u64, u64)>) {
        self.clock.set_input_time(span);
    }

    /// Changes capture policy and closes the current group, retaining history.
    pub fn set_capture_mode(&mut self, mode: UndoCaptureMode) {
        if self.capture_mode() != mode {
            self.add_undo_barrier();
            self.clock.set_mode(mode);
        }
    }

    pub fn undo(&mut self) -> bool {
        self.pop(true)
    }

    pub fn redo(&mut self) -> bool {
        self.pop(false)
    }

    fn pop(&mut self, undoing: bool) -> bool {
        lock(&self.changed_stories).clear();
        let tables = Arc::new(Mutex::new(Vec::new()));
        let restored_stories = Arc::new(Mutex::new(HashSet::new()));
        let restored = {
            let tables = Arc::clone(&tables);
            let restored_stories = Arc::clone(&restored_stories);
            stories_root(&self.doc.transact()).observe_deep(move |txn, events| {
                let mut tables = tables.lock().unwrap();
                let mut restored_stories = restored_stories.lock().unwrap();
                let mut keys = None;
                for event in events.iter() {
                    match event {
                        Event::Map(event) if event.keys(txn).contains_key("rows") => {
                            let mut previous = HashSet::new();
                            match &event.keys(txn)["rows"] {
                                EntryChange::Updated(Out::Any(rows), _)
                                | EntryChange::Removed(Out::Any(rows)) => {
                                    collect_row_stories(rows, &mut previous);
                                }
                                _ => {}
                            }
                            let mut current = HashSet::new();
                            if let Some(Out::Any(rows)) = event.target().get(txn, "rows") {
                                collect_row_stories(&rows, &mut current);
                            }
                            for story in current.difference(&previous) {
                                collect_story_tree(
                                    txn,
                                    keys.get_or_insert_with(|| story_keys(txn)),
                                    story,
                                    &mut restored_stories,
                                );
                            }
                            if !tables.contains(event.target()) {
                                tables.push(event.target().clone());
                            }
                        }
                        Event::Text(event) => {
                            for delta in event.delta(txn) {
                                if let Delta::Inserted(Out::YMap(map), _) = delta {
                                    collect_table_stories(
                                        txn,
                                        keys.get_or_insert_with(|| story_keys(txn)),
                                        map,
                                        &mut restored_stories,
                                    );
                                    if !tables.contains(map) {
                                        tables.push(map.clone());
                                    }
                                }
                            }
                        }
                        _ => {}
                    }
                }
            })
        };
        let visibility = Arc::new(Mutex::new(Vec::new()));
        let protected_stories = Arc::new(Mutex::new(None));
        let popped = {
            let visibility = Arc::clone(&visibility);
            let protected_stories = Arc::clone(&protected_stories);
            self.inner.observe_item_popped(move |_, event| {
                *visibility.lock().unwrap() = event.meta().1.lock().unwrap().clone();
                *protected_stories.lock().unwrap() = event.meta().2.lock().unwrap().clone();
            })
        };
        let identities = IdentityWatch::new(&self.doc);
        let applied = if undoing {
            self.inner.undo_blocking()
        } else {
            self.inner.redo_blocking()
        };
        drop((restored, popped));
        if applied {
            let mut txn = self.doc.transact_mut_with("system");
            let removed = txn
                .get_map(crate::REMOVED_STORIES)
                .expect("removed stories root is declared");
            let tables = tables.lock().unwrap();
            let live_tables: Vec<_> = if tables.is_empty() {
                Vec::new()
            } else {
                crate::live_stories(&stories_root(&txn), &txn)
                    .filter_map(|(_, value)| match value {
                        Out::YText(text) => Some(text),
                        _ => None,
                    })
                    .flat_map(|text| text.diff(&txn, YChange::identity))
                    .filter_map(|diff| match diff.insert {
                        Out::YMap(map) => Some(map),
                        _ => None,
                    })
                    .collect()
            };
            let mut cells = HashSet::new();
            let keys = if tables.is_empty() {
                Vec::new()
            } else {
                story_keys(&txn)
            };
            for table in tables.iter() {
                if live_tables.contains(table) {
                    collect_table_stories(&txn, &keys, table, &mut cells);
                }
            }
            let mut inverse = BTreeMap::new();
            let protected_stories = protected_stories
                .lock()
                .unwrap()
                .clone()
                .unwrap_or_default();
            for (story, hidden) in visibility.lock().unwrap().iter() {
                if *hidden {
                    removed.insert(&mut txn, story.as_str(), true);
                    lock(&self.changed_stories).push(story.clone());
                } else if cells.contains(story) && !protected_stories.contains(story) {
                    removed.remove(&mut txn, story);
                    lock(&self.changed_stories).push(story.clone());
                } else {
                    continue;
                }
                inverse.insert(story.clone(), !*hidden);
            }
            for story in cells.intersection(&restored_stories.lock().unwrap()) {
                if !protected_stories.contains(story) && removed.remove(&mut txn, story).is_some() {
                    inverse.insert(story.clone(), true);
                    lock(&self.changed_stories).push(story.clone());
                }
            }
            drop(txn);
            let stack = if undoing {
                self.inner.redo_stack()
            } else {
                self.inner.undo_stack()
            };
            if let Some(item) = stack.last() {
                *item.meta().1.lock().unwrap() = inverse.into_iter().collect();
                *item.meta().2.lock().unwrap() = Some(protected_stories);
            }
            {
                let mut changed = lock(&self.changed_stories);
                changed.sort();
                changed.dedup();
            }
            self.restore_history(identities);
        }
        applied
    }

    fn restore_history(&self, identities: IdentityWatch) {
        let changed = identities.changed();
        drop(identities);
        if changed {
            let stories = self
                .identities
                .repair(&mut self.doc.transact_mut_with("system"));
            let mut changed = lock(&self.changed_stories);
            changed.extend(stories);
            changed.sort();
            changed.dedup();
        }
        self.restore_comment_boundaries();
    }

    fn restore_comment_boundaries(&self) {
        let mut boundaries = self.anchor_state.lock().unwrap().current.clone();
        for item in self
            .inner
            .undo_stack()
            .iter()
            .chain(self.inner.redo_stack())
        {
            merge_boundaries(&mut boundaries, &item.meta().0.lock().unwrap());
        }
        if boundaries.iter().all(IdSet::is_empty) {
            return;
        }
        let mut txn = self.doc.transact_mut();
        let Some(Out::YText(text)) = crate::live_stories(&stories_root(&txn), &txn)
            .map(|(_, value)| value)
            .find(|value| matches!(value, Out::YText(_)))
        else {
            return;
        };
        // Yrs 0.27 drops intra-item offsets while following redone links. Snapshot
        // splitting preserves those offsets without authoring document changes.
        for deleted in boundaries {
            if deleted.is_empty() {
                continue;
            }
            let snapshot = Snapshot::new(Default::default(), deleted);
            text.diff_range(&mut txn, Some(&snapshot), None, |_| ());
        }
        let Some(comments) = txn.get_map(COMMENTS) else {
            return;
        };
        let mut boundaries = comment_boundaries(&txn);
        for (_, value) in comments.iter(&txn) {
            let Out::YMap(comment) = value else {
                continue;
            };
            let Some(Out::Any(yrs::Any::Array(anchors))) = comment.get(&txn, "anchors") else {
                continue;
            };
            for value in anchors.iter() {
                let Ok(anchor) = crate::decode_anchor(value) else {
                    continue;
                };
                let Ok(story) = crate::story_ref(&txn, &anchor.story) else {
                    continue;
                };
                for sticky in [anchor.start, anchor.end] {
                    let Some(offset) = sticky_offset(&sticky, &txn) else {
                        continue;
                    };
                    let Some(current) = sticky_index(&story, &txn, offset.index, sticky.assoc)
                    else {
                        continue;
                    };
                    if let Some(id) = current.id() {
                        boundaries[id.clock as usize % 2].insert(*id, 1);
                    }
                }
            }
        }
        let mut state = self.anchor_state.lock().unwrap();
        if let Some(latest) = state.latest.upgrade() {
            merge_boundaries(&mut latest.lock().unwrap(), &boundaries);
        }
        state.current = boundaries;
    }

    pub fn can_undo(&self) -> bool {
        self.inner.can_undo()
    }

    pub fn can_redo(&self) -> bool {
        self.inner.can_redo()
    }

    /// Stories changed by the latest undo or redo, sorted.
    pub fn changed_stories(&self) -> Vec<String> {
        lock(&self.changed_stories).clone()
    }

    /// Closes the current capture group.
    pub fn add_undo_barrier(&mut self) {
        self.inner.reset();
    }

    /// Current undo stack size (see [`UNDO_DEPTH`]).
    pub fn undo_depth(&self) -> usize {
        self.inner.undo_stack().len()
    }

    /// Current redo stack size — the redo twin of [`DocUndoManager::undo_depth`].
    pub fn redo_depth(&self) -> usize {
        self.inner.redo_stack().len()
    }

    /// Clears both stacks (file-load reset).
    pub fn clear(&mut self) {
        self.inner.clear_all();
        *self.anchor_state.lock().unwrap() = AnchorState {
            current: comment_boundaries(&self.doc.transact()),
            ..AnchorState::default()
        };
    }
}

fn story_keys(txn: &impl ReadTxn) -> Vec<String> {
    let mut keys: Vec<String> = stories_root(txn).keys(txn).map(str::to_owned).collect();
    keys.sort_unstable();
    keys
}

fn collect_table_stories(
    txn: &impl ReadTxn,
    keys: &[String],
    table: &MapRef,
    stories: &mut HashSet<String>,
) {
    if crate::map_string(table, txn, crate::KIND_KEY).as_deref() != Some("table") {
        return;
    }
    let Some(Out::Any(rows)) = table.get(txn, "rows") else {
        return;
    };
    let mut cells = HashSet::new();
    collect_row_stories(&rows, &mut cells);
    for cell in cells {
        collect_story_tree(txn, keys, &cell, stories);
    }
}

fn collect_row_stories(rows: &Any, stories: &mut HashSet<String>) {
    let Any::Array(rows) = rows else {
        return;
    };
    for row in rows.iter() {
        let Any::Map(row) = row else {
            continue;
        };
        let Some(Any::Array(cells)) = row.get("cells") else {
            continue;
        };
        for cell in cells.iter() {
            let Any::Map(cell) = cell else {
                continue;
            };
            let Some(Any::String(story)) = cell.get("story") else {
                continue;
            };
            stories.insert(story.to_string());
        }
    }
}

fn collect_story_tree(
    txn: &impl ReadTxn,
    keys: &[String],
    story: &str,
    stories: &mut HashSet<String>,
) {
    if !stories.insert(story.to_owned()) {
        return;
    }
    let root = stories_root(txn);
    let prefix = format!("{story}:");
    let start = keys.partition_point(|key| key.as_str() < prefix.as_str());
    for child in keys[start..]
        .iter()
        .take_while(|key| key.starts_with(&prefix))
    {
        collect_story_tree(txn, keys, child, stories);
    }
    let Some(Out::YText(text)) = root.get(txn, story) else {
        return;
    };
    for diff in text.diff(txn, YChange::identity) {
        if let Out::YMap(embed) = diff.insert {
            if let Some(child) = crate::map_string(&embed, txn, "story") {
                collect_story_tree(txn, keys, &child, stories);
            }
            collect_table_stories(txn, keys, &embed, stories);
        }
    }
}

fn merge_boundaries(target: &mut AnchorBoundaries, source: &AnchorBoundaries) {
    for (target, source) in target.iter_mut().zip(source) {
        target.merge_with(source.clone());
    }
}

fn remember_history_boundaries(
    txn: &impl ReadTxn,
    event: &mut yrs::undo::Event<AnchorHistory>,
    state: &Mutex<AnchorState>,
) {
    let mut state = state.lock().unwrap();
    let mut removed_before = event.meta().2.lock().unwrap();
    if removed_before.is_none() {
        let removed = txn
            .get_map(crate::REMOVED_STORIES)
            .expect("removed stories root is declared");
        *removed_before = Some(if event.has_changed(&removed) {
            state.removed_before.clone()
        } else {
            removed.keys(txn).map(str::to_owned).collect()
        });
    }
    let mut boundaries = event.meta().0.lock().unwrap();
    merge_boundaries(&mut boundaries, &state.current);
    merge_boundaries(&mut boundaries, &state.pending);
    state.current = comment_boundaries(txn);
    merge_boundaries(&mut boundaries, &state.current);
    state.pending = Default::default();
    state.latest = Arc::downgrade(&event.meta().0);
}

fn comment_boundaries(txn: &impl ReadTxn) -> AnchorBoundaries {
    let mut boundaries = AnchorBoundaries::default();
    let Some(comments) = txn.get_map(COMMENTS) else {
        return boundaries;
    };
    for (_, value) in comments.iter(txn) {
        let Out::YMap(comment) = value else {
            continue;
        };
        let Some(Out::Any(yrs::Any::Array(anchors))) = comment.get(txn, "anchors") else {
            continue;
        };
        for value in anchors.iter() {
            let Ok(anchor) = crate::decode_anchor(value) else {
                continue;
            };
            for sticky in [anchor.start, anchor.end] {
                if let Some(id) = sticky.id() {
                    // Separate adjacent ids so IdSet cannot merge away a boundary.
                    boundaries[id.clock as usize % 2].insert(*id, 1);
                }
            }
        }
    }
    boundaries
}

fn stories_root(txn: &impl ReadTxn) -> yrs::MapRef {
    txn.get_map(STORIES)
        .expect("stories root is declared by EditingDoc::new")
}

fn lock(stories: &Mutex<Vec<String>>) -> std::sync::MutexGuard<'_, Vec<String>> {
    stories
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// The session's undo state, shared by the WASM boundary and the native facade.
///
/// Inert until [`UndoSession::track`] runs, so a host may import or seed first without the
/// initial document becoming an undo step.
pub struct UndoSession {
    clock: Arc<dyn Clock>,
    manager: RefCell<Option<DocUndoManager>>,
    story: RefCell<Option<String>>,
    mode: Cell<UndoCaptureMode>,
    doc: Cell<Option<u64>>,
    input_time: Cell<Option<(u64, u64)>>,
}

impl Default for UndoSession {
    fn default() -> Self {
        Self::with_clock(default_clock())
    }
}

impl UndoSession {
    pub fn new() -> Self {
        Self::default()
    }

    /// Groups edits within [`UNDO_CAPTURE_TIMEOUT_MS`] as read from `clock` (milliseconds).
    pub fn with_clock(clock: Arc<dyn Clock>) -> Self {
        Self {
            clock,
            manager: RefCell::new(None),
            story: RefCell::new(None),
            mode: Cell::new(UndoCaptureMode::Auto),
            doc: Cell::new(None),
            input_time: Cell::new(None),
        }
    }

    /// Starts tracking local edits in every story; later calls keep the history. The replica keeps
    /// deleted content from then on.
    pub fn track(&self, doc: &EditingDoc) {
        let mut manager = self.manager.borrow_mut();
        if manager.is_none() {
            let mut next = DocUndoManager::new(doc, Arc::clone(&self.clock));
            next.set_capture_mode(self.mode.get());
            next.set_input_time(self.input_time.get());
            *manager = Some(next);
            self.doc.set(Some(doc.instance));
        }
    }

    /// Whether this history is unbound or tracks `doc`.
    pub fn belongs_to(&self, doc: &EditingDoc) -> bool {
        self.doc
            .get()
            .is_none_or(|instance| instance == doc.instance)
    }

    /// Story switches close capture unless manual grouping is selected.
    pub fn select_story(&self, story: &str) {
        if self.story.borrow().as_deref() == Some(story) {
            return;
        }
        *self.story.borrow_mut() = Some(story.to_owned());
        if self.mode.get() != UndoCaptureMode::Manual {
            self.add_undo_barrier();
        }
    }

    pub fn capture_mode(&self) -> UndoCaptureMode {
        self.mode.get()
    }

    /// Pins the input span used to measure the next capture gap.
    pub fn set_input_time(&self, span: Option<(u64, u64)>) {
        self.input_time.set(span);
        if let Some(manager) = self.manager.borrow().as_ref() {
            manager.set_input_time(span);
        }
    }

    /// Sets capture policy before or during tracking without clearing history.
    pub fn set_capture_mode(&self, mode: UndoCaptureMode) {
        self.mode.set(mode);
        if let Some(manager) = self.manager.borrow_mut().as_mut() {
            manager.set_capture_mode(mode);
        }
    }

    pub fn undo(&self) -> bool {
        self.manager
            .borrow_mut()
            .as_mut()
            .is_some_and(DocUndoManager::undo)
    }

    pub fn redo(&self) -> bool {
        self.manager
            .borrow_mut()
            .as_mut()
            .is_some_and(DocUndoManager::redo)
    }

    pub fn can_undo(&self) -> bool {
        self.manager
            .borrow()
            .as_ref()
            .is_some_and(DocUndoManager::can_undo)
    }

    pub fn can_redo(&self) -> bool {
        self.manager
            .borrow()
            .as_ref()
            .is_some_and(DocUndoManager::can_redo)
    }

    /// Stories changed by the latest undo or redo, sorted.
    pub fn changed_stories(&self) -> Vec<String> {
        self.manager
            .borrow()
            .as_ref()
            .map(DocUndoManager::changed_stories)
            .unwrap_or_default()
    }

    pub fn add_undo_barrier(&self) {
        if let Some(manager) = self.manager.borrow_mut().as_mut() {
            manager.add_undo_barrier();
        }
    }
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicU64, Ordering};

    use super::*;
    use crate::{EditCtx, FormatPolicy, Position, StoryRange};

    #[test]
    fn discarded_history_releases_its_anchor_boundaries() {
        let doc = seed();
        let id = doc
            .add_comment(&[StoryRange::new(BODY, 0, 1)], "Ada", "", yrs::Any::Null)
            .unwrap();
        let mut undo = doc.undo_manager();
        doc.set_comment_ranges(&id, &[StoryRange::new(BODY, 2, 3)])
            .unwrap();
        assert!(undo.undo());
        let discarded = Arc::downgrade(&undo.inner.redo_stack()[0].meta().0);
        append(&doc, BODY, "!");
        assert!(!undo.can_redo());
        assert!(discarded.upgrade().is_none());
        let cleared = Arc::downgrade(&undo.inner.undo_stack()[0].meta().0);
        undo.clear();
        assert!(cleared.upgrade().is_none());
    }

    #[test]
    fn remote_reanchoring_keeps_only_current_and_pending_boundaries() {
        let peer = EditingDoc::new(200);
        peer.create_story(BODY, &"a".repeat(128), "Normal", "left")
            .unwrap();
        let id = peer
            .add_comment(&[StoryRange::new(BODY, 0, 1)], "Ada", "", yrs::Any::Null)
            .unwrap();
        let doc = EditingDoc::new(201);
        doc.apply_update_v1(&peer.encode_state_as_update_v1())
            .unwrap();
        let undo = doc.undo_manager();
        for start in 1..100 {
            peer.set_comment_ranges(&id, &[StoryRange::new(BODY, start, start + 1)])
                .unwrap();
            doc.apply_update_v1(&peer.encode_state_as_update_v1())
                .unwrap();
        }
        assert_eq!(undo.undo_depth(), 0);
        let state = undo.anchor_state.lock().unwrap();
        let count = |sets: &AnchorBoundaries| -> u32 {
            sets.iter()
                .flat_map(|set| set.iter())
                .flat_map(|(_, ranges)| ranges.iter())
                .map(|range| range.end - range.start)
                .sum()
        };
        assert!(count(&state.current) <= 2);
        assert!(count(&state.pending) <= 4);
    }

    const BODY: &str = "body";
    const HEADER: &str = "header:rId7";

    fn seed() -> EditingDoc {
        let doc = EditingDoc::new(100);
        doc.create_story(BODY, "body", "Normal", "left").unwrap();
        doc.create_story(HEADER, "header", "Header", "left")
            .unwrap();
        doc
    }

    fn append(doc: &EditingDoc, story: &str, text: &str) {
        let end = doc.story_len(story).unwrap() - 1;
        doc.insert_text(
            &EditCtx::local("", ""),
            Position::new(story, end),
            text,
            FormatPolicy::Plain,
        )
        .unwrap();
    }

    fn text(doc: &EditingDoc, story: &str) -> String {
        doc.paragraphs(story).unwrap()[0].text.clone()
    }

    /// A session whose clock only moves when the test advances `now`.
    fn stepped_session() -> (UndoSession, Arc<AtomicU64>) {
        let now = Arc::new(AtomicU64::new(1_000));
        let clock = Arc::clone(&now);
        let session = UndoSession::with_clock(Arc::new(move || clock.load(Ordering::Relaxed)));
        (session, now)
    }

    #[test]
    fn one_history_spans_every_story_in_order() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.track(&doc);

        append(&doc, BODY, "!");
        now.fetch_add(UNDO_CAPTURE_TIMEOUT_MS + 1, Ordering::Relaxed);
        append(&doc, HEADER, "?");
        now.fetch_add(UNDO_CAPTURE_TIMEOUT_MS + 1, Ordering::Relaxed);
        undo.track(&doc);

        assert!(undo.undo());
        assert_eq!(text(&doc, HEADER), "header");
        assert_eq!(text(&doc, BODY), "body!");
        assert_eq!(undo.changed_stories(), [HEADER]);

        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
        assert_eq!(undo.changed_stories(), [BODY]);
        assert!(!undo.undo());

        assert!(undo.redo());
        assert_eq!(text(&doc, BODY), "body!");
        assert_eq!(undo.changed_stories(), [BODY]);
    }

    #[test]
    fn keystrokes_inside_the_capture_window_form_one_step() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.track(&doc);

        append(&doc, BODY, "a");
        now.fetch_add(100, Ordering::Relaxed);
        append(&doc, BODY, "b");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");

        now.fetch_add(UNDO_CAPTURE_TIMEOUT_MS + 1, Ordering::Relaxed);
        append(&doc, BODY, "c");
        now.fetch_add(600, Ordering::Relaxed);
        append(&doc, BODY, "d");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "bodyc");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
    }

    fn type_at(doc: &EditingDoc, undo: &UndoSession, key: &str, first: u64, last: u64) {
        undo.set_input_time(Some((first, last)));
        append(doc, BODY, key);
        undo.set_input_time(None);
    }

    #[test]
    fn input_time_groups_keystrokes_that_apply_late() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.track(&doc);
        for (index, key) in ["a", "b", "c"].into_iter().enumerate() {
            let at = 5_000 + 50 * index as u64;
            type_at(&doc, &undo, key, at, at);
            now.fetch_add(700, Ordering::Relaxed);
        }
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
    }

    #[test]
    fn input_pauses_split_steps_that_apply_together() {
        let doc = seed();
        let (undo, _now) = stepped_session();
        undo.track(&doc);
        type_at(&doc, &undo, "a", 5_000, 5_000);
        type_at(&doc, &undo, "b", 5_600, 5_600);
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "bodya");
    }

    #[test]
    fn input_spans_group_from_their_last_input() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.track(&doc);
        type_at(&doc, &undo, "ab", 5_000, 5_600);
        now.fetch_add(700, Ordering::Relaxed);
        type_at(&doc, &undo, "c", 5_700, 5_700);
        now.fetch_add(700, Ordering::Relaxed);
        type_at(&doc, &undo, "d", 6_300, 6_300);
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "bodyabc");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
    }

    #[test]
    fn edits_without_input_time_measure_apply_time() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.track(&doc);
        type_at(&doc, &undo, "a", 5_000, 5_000);
        now.fetch_add(100, Ordering::Relaxed);
        append(&doc, BODY, "b");
        now.fetch_add(700, Ordering::Relaxed);
        type_at(&doc, &undo, "c", 5_050, 5_050);
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "bodyab");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
    }

    #[test]
    fn moving_the_caret_to_another_story_closes_the_capture_group() {
        let doc = seed();
        let (undo, _now) = stepped_session();
        undo.track(&doc);

        undo.select_story(BODY);
        append(&doc, BODY, "!");
        undo.select_story(HEADER);
        append(&doc, HEADER, "?");

        assert!(undo.undo());
        assert_eq!(text(&doc, HEADER), "header");
        assert_eq!(text(&doc, BODY), "body!");
        assert_eq!(undo.changed_stories(), [HEADER]);
    }

    #[test]
    fn explicit_boundaries_separate_transactions() {
        let doc = seed();
        let (undo, _now) = stepped_session();
        undo.track(&doc);
        append(&doc, BODY, "a");
        undo.add_undo_barrier();
        append(&doc, BODY, "b");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "bodya");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
        assert!(!undo.undo());
    }

    #[test]
    fn manual_capture_spans_time_and_stories_until_a_boundary() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.set_capture_mode(UndoCaptureMode::Manual);
        undo.track(&doc);
        undo.select_story(BODY);
        append(&doc, BODY, "a");
        now.fetch_add(86_400_000, Ordering::Relaxed);
        undo.select_story(HEADER);
        append(&doc, HEADER, "b");
        undo.add_undo_barrier();
        append(&doc, BODY, "c");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "bodya");
        assert_eq!(text(&doc, HEADER), "headerb");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
        assert_eq!(text(&doc, HEADER), "header");
        assert_eq!(undo.changed_stories(), [BODY, HEADER]);
        assert!(!undo.undo());
        assert!(undo.redo());
        assert_eq!(text(&doc, BODY), "bodya");
        assert_eq!(text(&doc, HEADER), "headerb");
    }

    #[test]
    fn manual_capture_excludes_remote_transactions() {
        let doc = seed();
        let peer = EditingDoc::new(200);
        peer.apply_update_v1(&doc.encode_state_as_update_v1())
            .unwrap();
        let (undo, now) = stepped_session();
        undo.set_capture_mode(UndoCaptureMode::Manual);
        undo.track(&doc);
        append(&doc, BODY, "a");
        append(&peer, HEADER, "remote");
        doc.apply_update_v1(&peer.encode_state_as_update_v1())
            .unwrap();
        now.fetch_add(600, Ordering::Relaxed);
        append(&doc, BODY, "b");
        assert!(undo.undo());
        assert_eq!(text(&doc, BODY), "body");
        assert_eq!(text(&doc, HEADER), "headerremote");
        assert!(!undo.undo());
    }

    #[test]
    fn switching_modes_and_repeating_a_mode_preserve_history() {
        let doc = seed();
        let (undo, now) = stepped_session();
        undo.track(&doc);
        append(&doc, BODY, "a");
        undo.set_capture_mode(UndoCaptureMode::Manual);
        append(&doc, BODY, "b");
        now.fetch_add(600, Ordering::Relaxed);
        undo.set_capture_mode(UndoCaptureMode::Manual);
        append(&doc, BODY, "c");
        undo.set_capture_mode(UndoCaptureMode::Auto);
        append(&doc, BODY, "d");
        append(&doc, BODY, "e");
        for expected in ["bodyabc", "bodya", "body"] {
            assert!(undo.undo());
            assert_eq!(text(&doc, BODY), expected);
        }
        assert!(!undo.undo());
        undo.set_capture_mode(UndoCaptureMode::Manual);
        assert!(undo.can_redo());
        for expected in ["bodya", "bodyabc", "bodyabcde"] {
            assert!(undo.redo());
            assert_eq!(text(&doc, BODY), expected);
        }
    }

    #[test]
    fn session_is_inert_until_tracked() {
        let doc = seed();
        let undo = UndoSession::new();
        append(&doc, BODY, "seed");
        assert!(!undo.can_undo());
        assert!(!undo.undo());

        undo.track(&doc);
        assert!(!undo.can_undo());
        append(&doc, BODY, "!");
        assert!(undo.can_undo());
    }
}
