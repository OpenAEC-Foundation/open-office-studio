use std::collections::{HashMap, HashSet};

use serde::{Deserialize, Serialize};
use yrs::{ReadTxn, Transact};

use crate::EditingDoc;
use crate::batch::DocumentVersion;
use crate::structured::{HeaderFooterVariant, StoryKind, header_footer_index};
use crate::target::Views;

/// What a session story holds. Comment bodies are not session stories, so there is no comment
/// kind.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum StoryInfoKind {
    Body,
    TableCell,
    ContentControl,
    Header,
    Footer,
    Footnote,
    Endnote,
    Other,
}

impl StoryInfoKind {
    fn parse(name: &str) -> Option<Self> {
        Some(match name {
            "body" => Self::Body,
            "tableCell" => Self::TableCell,
            "contentControl" => Self::ContentControl,
            "header" => Self::Header,
            "footer" => Self::Footer,
            "footnote" => Self::Footnote,
            "endnote" => Self::Endnote,
            "other" => Self::Other,
            _ => return None,
        })
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ListStoryUse {
    pub section_index: u32,
    pub variant: HeaderFooterVariant,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub shown: Option<bool>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct StoryInfo {
    pub story: String,
    pub kind: StoryInfoKind,
    /// The story a table cell or block content control sits in.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub parent: Option<String>,
    /// The top-level story this one belongs to; itself for a top-level story.
    pub root: String,
    /// A header's or footer's package part, when the session was opened from DOCX bytes.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub part: Option<String>,
    /// A header's or footer's sections whose properties reference the part, inheritance
    /// applied, whether or not a page shows it; a preview's may be incomplete.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub uses: Option<Vec<ListStoryUse>>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ListStoriesResponse {
    pub version: DocumentVersion,
    pub stories: Vec<StoryInfo>,
}

/// `"all"`, or story kinds and story ids in any mix.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(untagged)]
pub enum StorySelection {
    All(AllStories),
    Listed(Vec<String>),
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum AllStories {
    All,
}

/// Every story of `views`, sorted by id.
pub(crate) fn story_infos<T: ReadTxn>(views: &mut Views<'_, T>) -> Vec<StoryInfo> {
    let txn = views.txn();
    let mut ids: Vec<String> = txn
        .get_map(crate::STORIES)
        .map(|stories| {
            crate::live_stories(&stories, txn)
                .map(|(id, _)| id.to_owned())
                .collect()
        })
        .unwrap_or_default();
    ids.sort();
    let index = header_footer_index(views);
    let ownership = views.ownership();
    ids.into_iter()
        .map(|story| {
            let nested = ownership.owner(&story).map(|owner| {
                let mut root = owner.parent.as_str();
                let mut seen = HashSet::from([story.as_str()]);
                while let Some(up) = ownership.owner(root) {
                    if !seen.insert(root) {
                        break;
                    }
                    root = up.parent.as_str();
                }
                let kind = if owner.cell {
                    StoryInfoKind::TableCell
                } else {
                    StoryInfoKind::ContentControl
                };
                (kind, owner.parent.clone(), root.to_owned())
            });
            if let Some((kind, parent, root)) = nested {
                return StoryInfo {
                    story,
                    kind,
                    parent: Some(parent),
                    root,
                    part: None,
                    uses: None,
                };
            }
            let root = story.clone();
            let (kind, part, uses) = match index.roles.get(&story) {
                Some((role, part)) => (
                    if *role == StoryKind::Header {
                        StoryInfoKind::Header
                    } else {
                        StoryInfoKind::Footer
                    },
                    part.clone(),
                    Some(
                        index
                            .uses
                            .get(&story)
                            .into_iter()
                            .flatten()
                            .map(|usage| ListStoryUse {
                                section_index: usage.section_index,
                                variant: usage.variant,
                                shown: None,
                            })
                            .collect(),
                    ),
                ),
                None if story == "body" => (StoryInfoKind::Body, None, None),
                None if story.starts_with("fn:") => (StoryInfoKind::Footnote, None, None),
                None if story.starts_with("en:") => (StoryInfoKind::Endnote, None, None),
                None => (StoryInfoKind::Other, None, None),
            };
            StoryInfo {
                story,
                kind,
                parent: None,
                root,
                part,
                uses,
            }
        })
        .collect()
}

/// The selected story ids: every story sorted, or the listed entries in order, a kind standing
/// for its stories in id order, without repeats. `by_root` matches a kind against each story's
/// root.
pub(crate) fn select_stories<T: ReadTxn>(
    views: &mut Views<'_, T>,
    selection: &StorySelection,
    by_root: bool,
) -> Vec<String> {
    let entries = match selection {
        StorySelection::All(_) => {
            return story_infos(views)
                .into_iter()
                .map(|info| info.story)
                .collect();
        }
        StorySelection::Listed(entries) => entries,
    };
    let infos = entries
        .iter()
        .any(|entry| StoryInfoKind::parse(entry).is_some())
        .then(|| {
            let infos = story_infos(views);
            let kinds: HashMap<String, StoryInfoKind> = infos
                .iter()
                .map(|info| (info.story.clone(), info.kind))
                .collect();
            infos
                .into_iter()
                .map(|info| {
                    let kind = if by_root {
                        kinds.get(&info.root).copied().unwrap_or(info.kind)
                    } else {
                        info.kind
                    };
                    (info.story, kind)
                })
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
    let mut seen = HashSet::new();
    let mut selected = Vec::new();
    for entry in entries {
        match StoryInfoKind::parse(entry) {
            Some(kind) => {
                for (story, _) in infos.iter().filter(|(_, matched)| *matched == kind) {
                    if seen.insert(story.as_str()) {
                        selected.push(story.clone());
                    }
                }
            }
            None => {
                if seen.insert(entry.as_str()) {
                    selected.push(entry.clone());
                }
            }
        }
    }
    selected
}

impl EditingDoc {
    /// Every story with its kind, container and, for a header or footer, its part and uses.
    pub fn list_stories(&self) -> ListStoriesResponse {
        let version = self.version();
        let txn = self.yrs_doc().transact();
        let mut views = Views::committed(self, &txn);
        ListStoriesResponse {
            version,
            stories: story_infos(&mut views),
        }
    }
}

#[cfg(test)]
mod tests {
    use yrs::Any;

    use super::*;
    use crate::{EditCtx, RawOp};

    #[test]
    fn story_info_kinds_use_camel_case() {
        for (kind, name) in [
            (StoryInfoKind::TableCell, "tableCell"),
            (StoryInfoKind::ContentControl, "contentControl"),
        ] {
            let value = serde_json::json!(name);
            assert_eq!(serde_json::to_value(kind).unwrap(), value);
            assert_eq!(
                serde_json::from_value::<StoryInfoKind>(value).unwrap(),
                kind
            );
            assert_eq!(StoryInfoKind::parse(name), Some(kind));
        }
    }

    #[test]
    fn without_a_source_section_references_name_headers_and_footers() {
        let doc = EditingDoc::new(100);
        doc.create_story("body", "x", "Normal", "left").unwrap();
        for story in ["hf:rIdH", "hf:rIdF", "hf:rIdX"] {
            doc.create_story(story, "y", "Normal", "left").unwrap();
        }
        let section = Any::from_json(
            r#"{"headerReferences":[{"type":"default","rId":"rIdH"}],"footerReferences":[{"type":"first","rId":"rIdF"}]}"#,
        )
        .unwrap();
        doc.apply_raw_ops(
            "body",
            vec![RawOp::SetEmbedAttr {
                index: 1,
                key: "sectPr".to_owned(),
                value: section,
            }],
            &EditCtx::local("", ""),
        )
        .unwrap();
        let listed = serde_json::to_value(doc.list_stories().stories).unwrap();
        assert_eq!(
            listed,
            serde_json::json!([
                { "story": "body", "kind": "body", "root": "body" },
                {
                    "story": "hf:rIdF", "kind": "footer", "root": "hf:rIdF",
                    "uses": [
                        { "sectionIndex": 0, "variant": "first" },
                        { "sectionIndex": 1, "variant": "first" },
                    ],
                },
                {
                    "story": "hf:rIdH", "kind": "header", "root": "hf:rIdH",
                    "uses": [
                        { "sectionIndex": 0, "variant": "default" },
                        { "sectionIndex": 1, "variant": "default" },
                    ],
                },
                { "story": "hf:rIdX", "kind": "other", "root": "hf:rIdX" },
            ])
        );
    }
}
