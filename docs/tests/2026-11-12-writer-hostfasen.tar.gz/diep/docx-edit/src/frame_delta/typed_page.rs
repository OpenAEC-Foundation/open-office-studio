//! Streaming typed-page serialization for the FrameDelta encoder.
//!
//! One `serde::Serializer` walks a typed [`DisplayPage`] directly, without
//! materializing an intermediate value tree, and in the same pass emits the
//! page's typed value stream, interning every string it references into the
//! frame's string table, and mixes the page's structural and visual
//! fingerprints from what it emits.
//!
//! The two fingerprints answer different questions, so each excludes what it
//! must not notice. The structural one ignores the root `pageIndex`, since a
//! page that only moved is still the same page. The visual one additionally
//! ignores `docStart`, `docEnd`, `fragmentDocStart`, `fragmentDocEnd`, a note
//! region note's `anchorDocStart` and `anchorDocEnd`, and an
//! `inlineSdtWidget`'s `pos`: those shift as text is edited elsewhere without
//! changing a pixel, and a page whose visual fingerprint holds can ship a
//! position patch rather than a full re-encode. Fingerprints are only ever
//! compared against others from the same session. They take a string's
//! content hash rather than its id, and a container's end rather than its
//! byte lengths, so a page fingerprints the same whichever frame emits it.
//!
//! Emission rules the browser decoder depends on:
//!
//! - object field order is declaration order — the decoder materializes
//!   fields one by one and does not care;
//! - a duplicate key, which a named field colliding with a `serde(flatten)`
//!   member produces, is compacted to its LAST write, because the decoder
//!   rejects duplicate object keys outright;
//! - an unsigned value that fits in `i64` emits `VALUE_I64`, so a number has
//!   one canonical encoding;
//! - a non-finite float emits `VALUE_NULL`, JSON having no spelling for it;
//! - an array under `"glyphs"` whose entries all carry the expected numeric
//!   fields emits the compact `VALUE_GLYPH_ARRAY` payload instead of a
//!   generic array.

use std::fmt;

use docx_layout::display_list::DisplayPage;
use serde::Serialize;
use serde::ser::{self, Serializer};

use super::{
    GLYPH_BIDI_LEVEL, GLYPH_LOGICAL_ORDER, StringTable, VALUE_ARRAY, VALUE_F64, VALUE_FALSE,
    VALUE_GLYPH_ARRAY, VALUE_I64, VALUE_NULL, VALUE_OBJECT, VALUE_STRING, VALUE_TRUE, VALUE_U64,
    checked_u32, mix, patch_u32, write_f64, write_u32, write_u64,
};

pub(super) struct PageHashes {
    /// Changes whenever the page's content changes, ignoring only its index.
    pub fingerprint: u64,
    /// Changes only when the page's appearance changes; equal fingerprints
    /// mean a position patch suffices.
    pub visual_fingerprint: u64,
}

impl PageHashes {
    fn mix(&mut self, scope: Scope, word: u64) {
        if scope.fingerprint {
            self.fingerprint = mix(self.fingerprint, word);
        }
        if scope.visual {
            self.visual_fingerprint = mix(self.visual_fingerprint, word);
        }
    }
}

/// The fingerprints a value feeds.
#[derive(Clone, Copy)]
struct Scope {
    fingerprint: bool,
    visual: bool,
}

/// Emit the typed value stream for `page` using the frame's string table,
/// returning the page's fingerprints.
pub(super) fn encode_page(
    page: &DisplayPage,
    ids: &mut StringTable,
    out: &mut Vec<u8>,
) -> Result<PageHashes, String> {
    let mut hashes = PageHashes {
        fingerprint: super::FNV_OFFSET,
        visual_fingerprint: super::FNV_OFFSET,
    };
    page.serialize(EmitSer {
        ids,
        out,
        hashes: &mut hashes,
        scope: Scope {
            fingerprint: true,
            visual: true,
        },
        root: true,
        slot: Slot::None,
    })
    .map_err(|error| format!("encode display page: {error}"))?;
    Ok(hashes)
}

/// The fingerprints [`encode_page`] returns, without keeping its output.
#[cfg(test)]
pub(super) fn hash_page(page: &DisplayPage) -> Result<PageHashes, String> {
    encode_page(page, &mut StringTable::default(), &mut Vec::new())
}

// ---------------------------------------------------------------------------
// shared plumbing
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------

#[derive(Debug)]
pub(super) struct SerError(String);

impl fmt::Display for SerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl std::error::Error for SerError {}

impl ser::Error for SerError {
    fn custom<T: fmt::Display>(msg: T) -> Self {
        SerError(msg.to_string())
    }
}

fn unsupported<T>(what: &str) -> Result<T, SerError> {
    Err(SerError(format!(
        "display page serialization does not use {what}"
    )))
}

/// The parent key a value sits under, where that changes how it is treated:
/// glyph arrays compact, and an inline SDT widget's `pos` leaves the visual
/// fingerprint. Array elements inherit their array's slot.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Slot {
    None,
    Glyphs,
    InlineSdtWidget,
}

fn classify(key: &str) -> Slot {
    match key {
        "glyphs" => Slot::Glyphs,
        "inlineSdtWidget" => Slot::InlineSdtWidget,
        _ => Slot::None,
    }
}

/// Keys the visual fingerprint ignores: they move with edits elsewhere in the
/// document without changing what the page looks like.
fn is_position_key(key: &str) -> bool {
    matches!(
        key,
        "docStart"
            | "docEnd"
            | "fragmentDocStart"
            | "fragmentDocEnd"
            | "anchorDocStart"
            | "anchorDocEnd"
    )
}

/// Captures one dynamic map key into a reusable buffer (Value-object entries;
/// typed structs pass `&'static str` keys directly and never hit this).
struct KeySer<'a>(&'a mut String);

impl Serializer for KeySer<'_> {
    type Ok = ();
    type Error = SerError;
    type SerializeSeq = ser::Impossible<(), SerError>;
    type SerializeTuple = ser::Impossible<(), SerError>;
    type SerializeTupleStruct = ser::Impossible<(), SerError>;
    type SerializeTupleVariant = ser::Impossible<(), SerError>;
    type SerializeMap = ser::Impossible<(), SerError>;
    type SerializeStruct = ser::Impossible<(), SerError>;
    type SerializeStructVariant = ser::Impossible<(), SerError>;

    fn serialize_str(self, value: &str) -> Result<(), SerError> {
        self.0.clear();
        self.0.push_str(value);
        Ok(())
    }

    fn serialize_char(self, value: char) -> Result<(), SerError> {
        self.0.clear();
        self.0.push(value);
        Ok(())
    }

    fn serialize_bool(self, _: bool) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_i8(self, _: i8) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_i16(self, _: i16) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_i32(self, _: i32) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_i64(self, _: i64) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_u8(self, _: u8) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_u16(self, _: u16) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_u32(self, _: u32) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_u64(self, _: u64) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_f32(self, _: f32) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_f64(self, _: f64) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_bytes(self, _: &[u8]) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_none(self) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_some<T: Serialize + ?Sized>(self, value: &T) -> Result<(), SerError> {
        value.serialize(self)
    }
    fn serialize_unit(self) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_unit_struct(self, _: &'static str) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_unit_variant(
        self,
        _: &'static str,
        _: u32,
        variant: &'static str,
    ) -> Result<(), SerError> {
        self.serialize_str(variant)
    }
    fn serialize_newtype_struct<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        value: &T,
    ) -> Result<(), SerError> {
        value.serialize(self)
    }
    fn serialize_newtype_variant<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: &T,
    ) -> Result<(), SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_seq(self, _: Option<usize>) -> Result<Self::SerializeSeq, SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_tuple(self, _: usize) -> Result<Self::SerializeTuple, SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_tuple_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleStruct, SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_tuple_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleVariant, SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_map(self, _: Option<usize>) -> Result<Self::SerializeMap, SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStruct, SerError> {
        unsupported("non-string map keys")
    }
    fn serialize_struct_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStructVariant, SerError> {
        unsupported("non-string map keys")
    }
}

// ---------------------------------------------------------------------------
// wire emission and fingerprints
// ---------------------------------------------------------------------------

/// Mixed where a container ends, so the fingerprints see its nesting without
/// its byte lengths.
const CONTAINER_END: u64 = u64::MAX;

struct EmitSer<'a> {
    ids: &'a mut StringTable,
    out: &'a mut Vec<u8>,
    hashes: &'a mut PageHashes,
    scope: Scope,
    /// True only for the page's outermost container: its direct fields apply
    /// the root-level `pageIndex` exclusion.
    root: bool,
    /// The key this value sits under (drives the `inlineSdtWidget.pos` rule).
    slot: Slot,
}

impl EmitSer<'_> {
    fn tag(&mut self, tag: u8) {
        self.out.push(tag);
        self.hashes.mix(self.scope, tag.into());
    }

    fn word(&mut self, tag: u8, word: u64) {
        self.tag(tag);
        write_u64(self.out, word);
        self.hashes.mix(self.scope, word);
    }

    fn string(mut self, value: &str) -> Result<(), SerError> {
        let (id, hash) = self.ids.intern(value).map_err(SerError)?;
        self.tag(VALUE_STRING);
        write_u32(self.out, id);
        self.hashes.mix(self.scope, hash);
        Ok(())
    }
}

struct EmitContainer<'a> {
    ids: &'a mut StringTable,
    out: &'a mut Vec<u8>,
    hashes: &'a mut PageHashes,
    scope: Scope,
    fields_root: bool,
    slot: Slot,
    length_at: usize,
    count_at: usize,
    payload_at: usize,
    count: u32,
    key_buf: String,
    /// One `(key id, byte offset of that entry)` per object entry, so
    /// [`EmitContainer::compact_duplicate_keys`] can splice out a superseded
    /// key — which a named field colliding with a `serde(flatten)` member
    /// produces.
    entries: Vec<(u32, usize)>,
}

impl<'a> EmitContainer<'a> {
    fn open(opcode: u8, mut ser: EmitSer<'a>) -> Self {
        ser.tag(opcode);
        let length_at = ser.out.len();
        write_u32(ser.out, 0);
        let count_at = ser.out.len();
        write_u32(ser.out, 0);
        let payload_at = ser.out.len();
        EmitContainer {
            ids: ser.ids,
            out: ser.out,
            hashes: ser.hashes,
            scope: ser.scope,
            fields_root: ser.root,
            slot: ser.slot,
            length_at,
            count_at,
            payload_at,
            count: 0,
            key_buf: String::new(),
            entries: Vec::new(),
        }
    }

    fn close(mut self) -> Result<(), SerError> {
        self.hashes.mix(self.scope, CONTAINER_END);
        self.compact_duplicate_keys();
        let payload_len = self.out.len() - self.payload_at;
        patch_u32(
            self.out,
            self.length_at,
            checked_u32(payload_len, "container payload length").map_err(SerError)?,
        );
        patch_u32(self.out, self.count_at, self.count);
        Ok(())
    }

    /// Drops every non-final occurrence of a repeated object key, so the last
    /// write wins — a correctness rule, not a size optimization, because the
    /// decoder rejects duplicate keys outright. Duplicate-free objects, the
    /// overwhelming majority, pay one linear scan and nothing else; container
    /// payloads carry only relative lengths, so splicing bytes out can never
    /// invalidate an inner container.
    fn compact_duplicate_keys(&mut self) {
        let has_duplicate = self.entries.iter().enumerate().any(|(index, (key, _))| {
            self.entries[index + 1..]
                .iter()
                .any(|(other, _)| other == key)
        });
        if !has_duplicate {
            return;
        }
        let mut retained = Vec::with_capacity(self.out.len() - self.payload_at);
        let mut kept = 0_u32;
        for (index, (key, start)) in self.entries.iter().enumerate() {
            let end = self
                .entries
                .get(index + 1)
                .map_or(self.out.len(), |(_, next_start)| *next_start);
            let superseded = self.entries[index + 1..]
                .iter()
                .any(|(other, _)| other == key);
            if superseded {
                continue;
            }
            retained.extend_from_slice(&self.out[*start..end]);
            kept += 1;
        }
        self.out.truncate(self.payload_at);
        self.out.extend_from_slice(&retained);
        self.count = kept;
    }

    fn element<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        self.count = self
            .count
            .checked_add(1)
            .ok_or_else(|| SerError("container element count exceeds u32".to_owned()))?;
        value.serialize(EmitSer {
            ids: &mut *self.ids,
            out: &mut *self.out,
            hashes: &mut *self.hashes,
            scope: self.scope,
            root: false,
            // Array elements inherit the array's slot, so an object in an
            // `inlineSdtWidget` array still counts as sitting under it.
            slot: self.slot,
        })
    }

    fn field<T: Serialize + ?Sized>(&mut self, key: &str, value: &T) -> Result<(), SerError> {
        let fp_skip = self.fields_root && key == "pageIndex";
        let vfp_skip =
            fp_skip || is_position_key(key) || (self.slot == Slot::InlineSdtWidget && key == "pos");
        let scope = Scope {
            fingerprint: self.scope.fingerprint && !fp_skip,
            visual: self.scope.visual && !vfp_skip,
        };
        self.entry(key, value, scope, classify(key))
    }

    fn entry<T: Serialize + ?Sized>(
        &mut self,
        key: &str,
        value: &T,
        scope: Scope,
        slot: Slot,
    ) -> Result<(), SerError> {
        self.count = self
            .count
            .checked_add(1)
            .ok_or_else(|| SerError("object field count exceeds u32".to_owned()))?;
        let (key_id, key_hash) = self.ids.intern(key).map_err(SerError)?;
        self.entries.push((key_id, self.out.len()));
        write_u32(self.out, key_id);
        self.hashes.mix(scope, key_hash);
        if key == "glyphs"
            && let Some(glyphs) = probe_glyphs(value)
        {
            return emit_glyph_array(&glyphs, self.out, self.hashes, scope);
        }
        value.serialize(EmitSer {
            ids: &mut *self.ids,
            out: &mut *self.out,
            hashes: &mut *self.hashes,
            scope,
            root: false,
            slot,
        })
    }
}

impl<'a> Serializer for EmitSer<'a> {
    type Ok = ();
    type Error = SerError;
    type SerializeSeq = EmitContainer<'a>;
    type SerializeTuple = Self::SerializeSeq;
    type SerializeTupleStruct = Self::SerializeSeq;
    type SerializeTupleVariant = Self::SerializeSeq;
    type SerializeMap = Self::SerializeSeq;
    type SerializeStruct = Self::SerializeSeq;
    type SerializeStructVariant = Self::SerializeSeq;

    fn serialize_bool(mut self, value: bool) -> Result<(), SerError> {
        self.tag(if value { VALUE_TRUE } else { VALUE_FALSE });
        Ok(())
    }
    fn serialize_i8(self, value: i8) -> Result<(), SerError> {
        self.serialize_i64(value.into())
    }
    fn serialize_i16(self, value: i16) -> Result<(), SerError> {
        self.serialize_i64(value.into())
    }
    fn serialize_i32(self, value: i32) -> Result<(), SerError> {
        self.serialize_i64(value.into())
    }
    fn serialize_i64(mut self, value: i64) -> Result<(), SerError> {
        self.word(VALUE_I64, value as u64);
        Ok(())
    }
    fn serialize_u8(self, value: u8) -> Result<(), SerError> {
        self.serialize_u64(value.into())
    }
    fn serialize_u16(self, value: u16) -> Result<(), SerError> {
        self.serialize_u64(value.into())
    }
    fn serialize_u32(self, value: u32) -> Result<(), SerError> {
        self.serialize_u64(value.into())
    }
    fn serialize_u64(mut self, value: u64) -> Result<(), SerError> {
        // One canonical encoding per number: prefer VALUE_I64.
        if i64::try_from(value).is_ok() {
            self.word(VALUE_I64, value);
        } else {
            self.word(VALUE_U64, value);
        }
        Ok(())
    }
    fn serialize_f32(self, value: f32) -> Result<(), SerError> {
        self.serialize_f64(value.into())
    }
    fn serialize_f64(mut self, value: f64) -> Result<(), SerError> {
        // JSON cannot spell a non-finite float; emit null.
        if value.is_finite() {
            self.word(VALUE_F64, value.to_bits());
        } else {
            self.tag(VALUE_NULL);
        }
        Ok(())
    }
    fn serialize_char(self, value: char) -> Result<(), SerError> {
        self.string(value.encode_utf8(&mut [0; 4]))
    }
    fn serialize_str(self, value: &str) -> Result<(), SerError> {
        self.string(value)
    }
    fn serialize_bytes(self, value: &[u8]) -> Result<(), SerError> {
        let mut seq = self.serialize_seq(Some(value.len()))?;
        for byte in value {
            ser::SerializeSeq::serialize_element(&mut seq, byte)?;
        }
        ser::SerializeSeq::end(seq)
    }
    fn serialize_none(mut self) -> Result<(), SerError> {
        self.tag(VALUE_NULL);
        Ok(())
    }
    fn serialize_some<T: Serialize + ?Sized>(self, value: &T) -> Result<(), SerError> {
        value.serialize(self)
    }
    fn serialize_unit(mut self) -> Result<(), SerError> {
        self.tag(VALUE_NULL);
        Ok(())
    }
    fn serialize_unit_struct(self, _: &'static str) -> Result<(), SerError> {
        self.serialize_unit()
    }
    fn serialize_unit_variant(
        self,
        _: &'static str,
        _: u32,
        variant: &'static str,
    ) -> Result<(), SerError> {
        self.string(variant)
    }
    fn serialize_newtype_struct<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        value: &T,
    ) -> Result<(), SerError> {
        value.serialize(self)
    }
    fn serialize_newtype_variant<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        _: u32,
        variant: &'static str,
        value: &T,
    ) -> Result<(), SerError> {
        // serde_json shape: {variant: value}
        let mut container = EmitContainer::open(
            VALUE_OBJECT,
            EmitSer {
                root: false,
                slot: Slot::None,
                ..self
            },
        );
        let scope = container.scope;
        container.entry(variant, value, scope, Slot::None)?;
        container.close()
    }
    fn serialize_seq(self, _: Option<usize>) -> Result<Self::SerializeSeq, SerError> {
        Ok(EmitContainer::open(VALUE_ARRAY, self))
    }
    fn serialize_tuple(self, len: usize) -> Result<Self::SerializeTuple, SerError> {
        self.serialize_seq(Some(len))
    }
    fn serialize_tuple_struct(
        self,
        _: &'static str,
        len: usize,
    ) -> Result<Self::SerializeTupleStruct, SerError> {
        self.serialize_seq(Some(len))
    }
    fn serialize_tuple_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleVariant, SerError> {
        unsupported("tuple variants")
    }
    fn serialize_map(self, _: Option<usize>) -> Result<Self::SerializeMap, SerError> {
        Ok(EmitContainer::open(VALUE_OBJECT, self))
    }
    fn serialize_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStruct, SerError> {
        self.serialize_map(None)
    }
    fn serialize_struct_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStructVariant, SerError> {
        unsupported("struct variants")
    }
}
impl ser::SerializeSeq for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_element<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        self.element(value)
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

impl ser::SerializeTuple for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_element<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        self.element(value)
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

impl ser::SerializeTupleStruct for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_field<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        self.element(value)
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

impl ser::SerializeTupleVariant for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_field<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        self.element(value)
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

impl ser::SerializeMap for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_key<T: Serialize + ?Sized>(&mut self, key: &T) -> Result<(), SerError> {
        let mut buf = std::mem::take(&mut self.key_buf);
        key.serialize(KeySer(&mut buf))?;
        self.key_buf = buf;
        Ok(())
    }
    fn serialize_value<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        let key = std::mem::take(&mut self.key_buf);
        let result = self.field(&key, value);
        self.key_buf = key;
        result
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

impl ser::SerializeStruct for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_field<T: Serialize + ?Sized>(
        &mut self,
        key: &'static str,
        value: &T,
    ) -> Result<(), SerError> {
        self.field(key, value)
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

impl ser::SerializeStructVariant for EmitContainer<'_> {
    type Ok = ();
    type Error = SerError;
    fn serialize_field<T: Serialize + ?Sized>(
        &mut self,
        key: &'static str,
        value: &T,
    ) -> Result<(), SerError> {
        self.field(key, value)
    }
    fn end(self) -> Result<(), SerError> {
        self.close()
    }
}

// ---------------------------------------------------------------------------
// compact glyph probe
// ---------------------------------------------------------------------------

/// One glyph eligible for the fixed-field wire payload. Eligibility only
/// checks that the expected fields are present and numeric; narrowing the id
/// and cluster to `u32` happens at emission, where an out-of-range value is a
/// hard error rather than a fall back to the generic array encoding.
struct CompactGlyph {
    id: u64,
    x: f64,
    y: f64,
    cluster: u64,
    advance: f64,
    logical_order: Option<u64>,
    bidi_level: Option<u64>,
}

/// Serialize `value` through the eligibility probe. `None` means the value is
/// not a compact-eligible glyph array and must encode generically.
fn probe_glyphs<T: Serialize + ?Sized>(value: &T) -> Option<Vec<CompactGlyph>> {
    value.serialize(GlyphSeqProbe).ok()
}

/// Emits `VALUE_GLYPH_ARRAY`: a byte length and count, then a fixed-width
/// record per glyph. `logicalOrder` and `bidiLevel` are optional, so each
/// record carries a flag byte saying which of them follow.
fn emit_glyph_array(
    glyphs: &[CompactGlyph],
    out: &mut Vec<u8>,
    hashes: &mut PageHashes,
    scope: Scope,
) -> Result<(), SerError> {
    out.push(VALUE_GLYPH_ARRAY);
    hashes.mix(scope, VALUE_GLYPH_ARRAY.into());
    hashes.mix(scope, glyphs.len() as u64);
    let length_at = out.len();
    write_u32(out, 0);
    write_u32(
        out,
        checked_u32(glyphs.len(), "glyph array count").map_err(SerError)?,
    );
    let payload_at = out.len();
    for glyph in glyphs {
        write_u32(
            out,
            u32::try_from(glyph.id).map_err(|_| SerError("glyph id exceeds u32".to_owned()))?,
        );
        write_f64(out, glyph.x);
        write_f64(out, glyph.y);
        write_u32(
            out,
            u32::try_from(glyph.cluster)
                .map_err(|_| SerError("glyph cluster exceeds u32".to_owned()))?,
        );
        write_f64(out, glyph.advance);
        let flags = if glyph.logical_order.is_some() {
            GLYPH_LOGICAL_ORDER
        } else {
            0
        } | if glyph.bidi_level.is_some() {
            GLYPH_BIDI_LEVEL
        } else {
            0
        };
        out.push(flags);
        for word in [
            glyph.id,
            glyph.x.to_bits(),
            glyph.y.to_bits(),
            glyph.cluster,
            glyph.advance.to_bits(),
            flags.into(),
        ] {
            hashes.mix(scope, word);
        }
        if let Some(value) = glyph.logical_order {
            write_u64(out, value);
            hashes.mix(scope, value);
        }
        if let Some(value) = glyph.bidi_level {
            out.push(value as u8);
            hashes.mix(scope, value);
        }
    }
    let payload_len = out.len() - payload_at;
    patch_u32(
        out,
        length_at,
        checked_u32(payload_len, "glyph array payload length").map_err(SerError)?,
    );
    Ok(())
}

/// Signals "not a compact glyph array" out of the probe. The error never
/// reaches a caller: [`probe_glyphs`] turns it into `None`, which selects the
/// generic array encoding.
fn ineligible<T>() -> Result<T, SerError> {
    Err(SerError("glyph array is not compact-eligible".to_owned()))
}

/// Numeric capture for one glyph field.
#[derive(Clone, Copy)]
enum GlyphNum {
    Int(i64),
    Uint(u64),
    Float(f64),
}

impl GlyphNum {
    /// The value as `u64`, refusing a float even when it is whole.
    fn as_u64(self) -> Option<u64> {
        match self {
            GlyphNum::Uint(value) => Some(value),
            GlyphNum::Int(value) => u64::try_from(value).ok(),
            GlyphNum::Float(_) => None,
        }
    }

    /// The value as `f64`, widening either integer form.
    fn as_f64(self) -> Option<f64> {
        match self {
            GlyphNum::Uint(value) => Some(value as f64),
            GlyphNum::Int(value) => Some(value as f64),
            GlyphNum::Float(value) => value.is_finite().then_some(value),
        }
    }
}

struct GlyphNumProbe;

impl Serializer for GlyphNumProbe {
    type Ok = GlyphNum;
    type Error = SerError;
    type SerializeSeq = ser::Impossible<GlyphNum, SerError>;
    type SerializeTuple = ser::Impossible<GlyphNum, SerError>;
    type SerializeTupleStruct = ser::Impossible<GlyphNum, SerError>;
    type SerializeTupleVariant = ser::Impossible<GlyphNum, SerError>;
    type SerializeMap = ser::Impossible<GlyphNum, SerError>;
    type SerializeStruct = ser::Impossible<GlyphNum, SerError>;
    type SerializeStructVariant = ser::Impossible<GlyphNum, SerError>;

    fn serialize_i8(self, value: i8) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Int(value.into()))
    }
    fn serialize_i16(self, value: i16) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Int(value.into()))
    }
    fn serialize_i32(self, value: i32) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Int(value.into()))
    }
    fn serialize_i64(self, value: i64) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Int(value))
    }
    fn serialize_u8(self, value: u8) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Uint(value.into()))
    }
    fn serialize_u16(self, value: u16) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Uint(value.into()))
    }
    fn serialize_u32(self, value: u32) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Uint(value.into()))
    }
    fn serialize_u64(self, value: u64) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Uint(value))
    }
    fn serialize_f32(self, value: f32) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Float(value.into()))
    }
    fn serialize_f64(self, value: f64) -> Result<GlyphNum, SerError> {
        Ok(GlyphNum::Float(value))
    }
    fn serialize_some<T: Serialize + ?Sized>(self, value: &T) -> Result<GlyphNum, SerError> {
        value.serialize(self)
    }
    fn serialize_newtype_struct<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        value: &T,
    ) -> Result<GlyphNum, SerError> {
        value.serialize(self)
    }

    fn serialize_bool(self, _: bool) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_char(self, _: char) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_str(self, _: &str) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_bytes(self, _: &[u8]) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_none(self) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_unit(self) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_unit_struct(self, _: &'static str) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_unit_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
    ) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_newtype_variant<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: &T,
    ) -> Result<GlyphNum, SerError> {
        ineligible()
    }
    fn serialize_seq(self, _: Option<usize>) -> Result<Self::SerializeSeq, SerError> {
        ineligible()
    }
    fn serialize_tuple(self, _: usize) -> Result<Self::SerializeTuple, SerError> {
        ineligible()
    }
    fn serialize_tuple_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleStruct, SerError> {
        ineligible()
    }
    fn serialize_tuple_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleVariant, SerError> {
        ineligible()
    }
    fn serialize_map(self, _: Option<usize>) -> Result<Self::SerializeMap, SerError> {
        ineligible()
    }
    fn serialize_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStruct, SerError> {
        ineligible()
    }
    fn serialize_struct_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStructVariant, SerError> {
        ineligible()
    }
}

struct GlyphSeqProbe;

impl Serializer for GlyphSeqProbe {
    type Ok = Vec<CompactGlyph>;
    type Error = SerError;
    type SerializeSeq = GlyphSeqBuilder;
    type SerializeTuple = ser::Impossible<Vec<CompactGlyph>, SerError>;
    type SerializeTupleStruct = ser::Impossible<Vec<CompactGlyph>, SerError>;
    type SerializeTupleVariant = ser::Impossible<Vec<CompactGlyph>, SerError>;
    type SerializeMap = ser::Impossible<Vec<CompactGlyph>, SerError>;
    type SerializeStruct = ser::Impossible<Vec<CompactGlyph>, SerError>;
    type SerializeStructVariant = ser::Impossible<Vec<CompactGlyph>, SerError>;

    fn serialize_seq(self, len: Option<usize>) -> Result<Self::SerializeSeq, SerError> {
        Ok(GlyphSeqBuilder {
            glyphs: Vec::with_capacity(len.unwrap_or(0)),
        })
    }
    fn serialize_some<T: Serialize + ?Sized>(
        self,
        value: &T,
    ) -> Result<Vec<CompactGlyph>, SerError> {
        value.serialize(self)
    }
    fn serialize_newtype_struct<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        value: &T,
    ) -> Result<Vec<CompactGlyph>, SerError> {
        value.serialize(self)
    }

    fn serialize_bool(self, _: bool) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_i8(self, _: i8) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_i16(self, _: i16) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_i32(self, _: i32) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_i64(self, _: i64) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_u8(self, _: u8) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_u16(self, _: u16) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_u32(self, _: u32) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_u64(self, _: u64) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_f32(self, _: f32) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_f64(self, _: f64) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_char(self, _: char) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_str(self, _: &str) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_bytes(self, _: &[u8]) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_none(self) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_unit(self) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_unit_struct(self, _: &'static str) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_unit_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
    ) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_newtype_variant<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: &T,
    ) -> Result<Vec<CompactGlyph>, SerError> {
        ineligible()
    }
    fn serialize_tuple(self, _: usize) -> Result<Self::SerializeTuple, SerError> {
        ineligible()
    }
    fn serialize_tuple_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleStruct, SerError> {
        ineligible()
    }
    fn serialize_tuple_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleVariant, SerError> {
        ineligible()
    }
    fn serialize_map(self, _: Option<usize>) -> Result<Self::SerializeMap, SerError> {
        ineligible()
    }
    fn serialize_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStruct, SerError> {
        ineligible()
    }
    fn serialize_struct_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStructVariant, SerError> {
        ineligible()
    }
}

struct GlyphSeqBuilder {
    glyphs: Vec<CompactGlyph>,
}

impl ser::SerializeSeq for GlyphSeqBuilder {
    type Ok = Vec<CompactGlyph>;
    type Error = SerError;
    fn serialize_element<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        self.glyphs.push(value.serialize(GlyphElemProbe)?);
        Ok(())
    }
    fn end(self) -> Result<Vec<CompactGlyph>, SerError> {
        Ok(self.glyphs)
    }
}

const GLYPH_SEEN_ID: u8 = 1 << 0;
const GLYPH_SEEN_X: u8 = 1 << 1;
const GLYPH_SEEN_Y: u8 = 1 << 2;
const GLYPH_SEEN_CLUSTER: u8 = 1 << 3;
const GLYPH_SEEN_ADVANCE: u8 = 1 << 4;
const GLYPH_SEEN_LOGICAL_ORDER: u8 = 1 << 5;
const GLYPH_SEEN_BIDI_LEVEL: u8 = 1 << 6;
const GLYPH_SEEN_MANDATORY: u8 =
    GLYPH_SEEN_ID | GLYPH_SEEN_X | GLYPH_SEEN_Y | GLYPH_SEEN_CLUSTER | GLYPH_SEEN_ADVANCE;

struct GlyphElemProbe;

impl Serializer for GlyphElemProbe {
    type Ok = CompactGlyph;
    type Error = SerError;
    type SerializeSeq = ser::Impossible<CompactGlyph, SerError>;
    type SerializeTuple = ser::Impossible<CompactGlyph, SerError>;
    type SerializeTupleStruct = ser::Impossible<CompactGlyph, SerError>;
    type SerializeTupleVariant = ser::Impossible<CompactGlyph, SerError>;
    type SerializeMap = GlyphFieldProbe;
    type SerializeStruct = GlyphFieldProbe;
    type SerializeStructVariant = ser::Impossible<CompactGlyph, SerError>;

    fn serialize_map(self, _: Option<usize>) -> Result<Self::SerializeMap, SerError> {
        Ok(GlyphFieldProbe::default())
    }
    fn serialize_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStruct, SerError> {
        Ok(GlyphFieldProbe::default())
    }
    fn serialize_some<T: Serialize + ?Sized>(self, value: &T) -> Result<CompactGlyph, SerError> {
        value.serialize(self)
    }
    fn serialize_newtype_struct<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        value: &T,
    ) -> Result<CompactGlyph, SerError> {
        value.serialize(self)
    }

    fn serialize_bool(self, _: bool) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_i8(self, _: i8) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_i16(self, _: i16) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_i32(self, _: i32) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_i64(self, _: i64) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_u8(self, _: u8) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_u16(self, _: u16) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_u32(self, _: u32) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_u64(self, _: u64) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_f32(self, _: f32) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_f64(self, _: f64) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_char(self, _: char) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_str(self, _: &str) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_bytes(self, _: &[u8]) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_none(self) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_unit(self) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_unit_struct(self, _: &'static str) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_unit_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
    ) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_newtype_variant<T: Serialize + ?Sized>(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: &T,
    ) -> Result<CompactGlyph, SerError> {
        ineligible()
    }
    fn serialize_seq(self, _: Option<usize>) -> Result<Self::SerializeSeq, SerError> {
        ineligible()
    }
    fn serialize_tuple(self, _: usize) -> Result<Self::SerializeTuple, SerError> {
        ineligible()
    }
    fn serialize_tuple_struct(
        self,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleStruct, SerError> {
        ineligible()
    }
    fn serialize_tuple_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeTupleVariant, SerError> {
        ineligible()
    }
    fn serialize_struct_variant(
        self,
        _: &'static str,
        _: u32,
        _: &'static str,
        _: usize,
    ) -> Result<Self::SerializeStructVariant, SerError> {
        ineligible()
    }
}

#[derive(Default)]
struct GlyphFieldProbe {
    seen: u8,
    id: u64,
    x: f64,
    y: f64,
    cluster: u64,
    advance: f64,
    logical_order: Option<u64>,
    bidi_level: Option<u64>,
    key_buf: String,
}

impl GlyphFieldProbe {
    fn field<T: Serialize + ?Sized>(&mut self, key: &str, value: &T) -> Result<(), SerError> {
        let (bit, number) = match key {
            "id" => (GLYPH_SEEN_ID, value.serialize(GlyphNumProbe)?),
            "x" => (GLYPH_SEEN_X, value.serialize(GlyphNumProbe)?),
            "y" => (GLYPH_SEEN_Y, value.serialize(GlyphNumProbe)?),
            "cluster" => (GLYPH_SEEN_CLUSTER, value.serialize(GlyphNumProbe)?),
            "advance" => (GLYPH_SEEN_ADVANCE, value.serialize(GlyphNumProbe)?),
            "logicalOrder" => (GLYPH_SEEN_LOGICAL_ORDER, value.serialize(GlyphNumProbe)?),
            "bidiLevel" => (GLYPH_SEEN_BIDI_LEVEL, value.serialize(GlyphNumProbe)?),
            _ => return ineligible(),
        };
        if self.seen & bit != 0 {
            return ineligible();
        }
        self.seen |= bit;
        match bit {
            GLYPH_SEEN_ID => self.id = number.as_u64().map_or_else(ineligible, Ok)?,
            GLYPH_SEEN_X => self.x = number.as_f64().map_or_else(ineligible, Ok)?,
            GLYPH_SEEN_Y => self.y = number.as_f64().map_or_else(ineligible, Ok)?,
            GLYPH_SEEN_CLUSTER => self.cluster = number.as_u64().map_or_else(ineligible, Ok)?,
            GLYPH_SEEN_ADVANCE => self.advance = number.as_f64().map_or_else(ineligible, Ok)?,
            GLYPH_SEEN_LOGICAL_ORDER => {
                self.logical_order = Some(number.as_u64().map_or_else(ineligible, Ok)?);
            }
            _ => {
                let level = number.as_u64().map_or_else(ineligible, Ok)?;
                if level > u8::MAX as u64 {
                    return ineligible();
                }
                self.bidi_level = Some(level);
            }
        }
        Ok(())
    }

    fn finish(self) -> Result<CompactGlyph, SerError> {
        if self.seen & GLYPH_SEEN_MANDATORY != GLYPH_SEEN_MANDATORY {
            return ineligible();
        }
        Ok(CompactGlyph {
            id: self.id,
            x: self.x,
            y: self.y,
            cluster: self.cluster,
            advance: self.advance,
            logical_order: self.logical_order,
            bidi_level: self.bidi_level,
        })
    }
}

impl ser::SerializeMap for GlyphFieldProbe {
    type Ok = CompactGlyph;
    type Error = SerError;
    fn serialize_key<T: Serialize + ?Sized>(&mut self, key: &T) -> Result<(), SerError> {
        let mut buf = std::mem::take(&mut self.key_buf);
        key.serialize(KeySer(&mut buf))?;
        self.key_buf = buf;
        Ok(())
    }
    fn serialize_value<T: Serialize + ?Sized>(&mut self, value: &T) -> Result<(), SerError> {
        let key = std::mem::take(&mut self.key_buf);
        let result = self.field(&key, value);
        self.key_buf = key;
        result
    }
    fn end(self) -> Result<CompactGlyph, SerError> {
        self.finish()
    }
}

impl ser::SerializeStruct for GlyphFieldProbe {
    type Ok = CompactGlyph;
    type Error = SerError;
    fn serialize_field<T: Serialize + ?Sized>(
        &mut self,
        key: &'static str,
        value: &T,
    ) -> Result<(), SerError> {
        self.field(key, value)
    }
    fn end(self) -> Result<CompactGlyph, SerError> {
        self.finish()
    }
}
