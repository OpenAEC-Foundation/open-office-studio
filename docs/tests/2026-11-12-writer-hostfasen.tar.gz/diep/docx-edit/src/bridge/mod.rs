//! Read-only lowering from the pilcrow-stream editing model to the layout
//! engine's [`LayoutBlock`] vocabulary.
//!
//! One yrs story in, one flat block list out. The walk goes in UTF-16 units,
//! every embed (pilcrows included) counting as one, and turns:
//!
//! - a run of identically formatted text into one paragraph run, cut further
//!   at tabs and at comment-interval boundaries so each run carries a single
//!   comment set;
//! - a pilcrow into the end of a paragraph block, lowering its authored OOXML
//!   properties (spacing, indents, borders, tabs, list numbering, section
//!   properties) into the block's attributes;
//! - a table embed into a table block whose cells recurse into their own
//!   stories, and other embeds into image, break, field or shape runs.
//!
//! Nothing here mutates the document, and the whole lowering runs inside one
//! read transaction, so the result is a consistent snapshot.
//!
//! Two things cross the walk rather than sitting on a single item. Section
//! properties CASCADE: a section that overrides one margin emits a full
//! margins record whose unset sides inherit from the previous section instead
//! of resetting to the OOXML default. List counters advance per numbering id
//! across the whole story, so a marker depends on every earlier list paragraph.
//!
//! Positions come out in two coordinate systems. Story offsets are the UTF-16
//! indices above; the `pm_*` fields carry the paragraph-node positions that
//! [`pm_position`] derives, in which every paragraph adds two positions for
//! its own open and close. Inline content occupies the same width in both, so
//! an embed that displays as several characters — a `noteRef` showing a
//! multi-digit number — still spans exactly one position.
//!
//! Values the story cannot supply — theme colors, the default tab stop, the
//! page content height, and the mapping from yrs ids to the numeric ids the
//! layout contract uses — arrive in [`RenderEnv`].

use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::fmt;
use std::sync::Arc;

use docx_layout::types::{
    BlockId, BorderStyle, BoxEdges, CellBorderSpec, CellBorders, ChartBlock, ColumnBreakBlock,
    ColumnLayout, FieldRun, FloatingTablePosition, HorizontalRule, HyperlinkInfo, ImageRun,
    ImageRunPosition, LayoutBlock, LineBreakRun, ListNumPr, PageBreakBlock, PageMargins,
    ParagraphAttrs, ParagraphBlock, ParagraphBorders, ParagraphIndent, ParagraphSpacing, Run,
    RunFontSlots, RunFormatting, RunLanguageSlots, SdtGroup, SectionBreakBlock, SectionBreakType,
    ShapeBlock, Size, SpacingExplicit, TabRun, TabStop, TableBlock, TableCell, TableRow, TextRun,
    UnderlineSpec,
};
use docx_parse::{drawingml::resolve_color_value_to_hex, scalars::ColorValue};
use serde_json::{Map as JsonMap, Value};
use yrs::types::Attrs;
use yrs::types::text::YChange;
use yrs::{Any, Map, MapRef, OffsetKind, Out, ReadTxn, Text, Transact};

use super::{COMMENTS, DEL, EditError, EditingDoc, INS, decode_anchor, is_pilcrow, story_ref};
use crate::list_marker::{ListState, compute_list_marker};
use crate::seed::synthesized_cell_width;
use crate::sticky_positions::sticky_offset;

pub(crate) mod group_pictures;
mod group_transforms;
pub(crate) mod local;
pub(crate) mod preview;
pub mod reservations;
pub use group_pictures::GroupPictureSources;
mod shapes;

pub use reservations::{Reservation, ReservationKind, ReservationSide, Reservations};

const AUTO_PARAGRAPH_SPACING_PX: f64 = 14.0;

/// Document-level values lowering cannot read off a story. Every field
/// defaults, so an empty env lowers a story with built-in fallbacks.
#[derive(Clone, Debug, Default, PartialEq, serde::Deserialize, serde::Serialize)]
#[serde(default, rename_all = "camelCase")]
pub struct RenderEnv {
    pub compatibility_flags: docx_parse::CompatibilityFlags,
    #[serde(skip_serializing_if = "BTreeSet::is_empty")]
    pub toc_style_ids: BTreeSet<String>,
    /// Six-digit RGB values keyed by OOXML theme slot. A missing slot falls
    /// back to the default Office palette.
    pub theme_colors: BTreeMap<String, String>,
    /// Interval between implicit tab stops, passed through to each paragraph.
    /// `None` leaves the layout engine's own default in effect.
    pub default_tab_stop_twips: Option<f64>,
    /// Usable page height in px. Images taller than this are scaled down to
    /// fit; `None` or a non-positive value clamps nothing.
    pub page_content_height: Option<f64>,
    /// Maps a yrs `{client}:{counter}` revision or comment id to the number
    /// the layout contract carries. An unmapped id is hashed into the
    /// safe-integer range instead, which is stable but not shared with a peer
    /// that numbers the same document differently.
    pub numeric_ids: BTreeMap<String, f64>,
    /// Include hidden text in visible layout without changing the document.
    pub show_hidden_text: bool,
    /// Report borderless table cell edges as view-only guides.
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub show_table_gridlines: bool,
    /// Revision id, as [`crate::ChangeInfo`] reports it, to the decision
    /// shown in place of its markup. A decided insertion or deletion renders
    /// as plain text or not at all, at its original positions; any other
    /// revision renders as a tracked change. Entries with other values are
    /// ignored.
    #[serde(
        skip_serializing_if = "BTreeMap::is_empty",
        deserialize_with = "deserialize_revision_preview"
    )]
    pub revision_preview: BTreeMap<String, RevisionPreview>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub paragraph_spacing_line_px: Option<f64>,
    /// Section document-grid snap pitch in px (`w:docGrid w:linePitch`),
    /// gated to an activating grid type. Lowering stamps it onto every
    /// paragraph; the engine's per-section resolve pass corrects later
    /// sections. `None` disables snapping.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub doc_grid_pitch_px: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub default_paragraph_style_id: Option<String>,
    /// Lower the `data:` image sources seeding wrote as the `media:{n}`
    /// tokens of their parts, which the host then resolves.
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub media_tokens: bool,
    /// The seeded media [`Self::media_tokens`] reads; lowering takes the
    /// document's when empty.
    #[serde(skip)]
    pub media: crate::media::MediaSources,
    /// View-only layout space and hidden ranges, by host key. Never saved.
    #[serde(skip_serializing_if = "Reservations::is_empty")]
    pub reservations: Reservations,
    #[serde(skip)]
    pub group_pictures: GroupPictureSources,
}

impl RenderEnv {
    pub fn with_numeric_id(mut self, yrs_id: impl Into<String>, layout_id: f64) -> Self {
        self.numeric_ids.insert(yrs_id.into(), layout_id);
        self
    }

    pub fn with_revision_preview(
        mut self,
        revision_id: impl Into<String>,
        preview: RevisionPreview,
    ) -> Self {
        self.revision_preview.insert(revision_id.into(), preview);
        self
    }

    /// Reads `revisionPreview` entries from JSON, skipping any that are not
    /// an `"accepted"` or `"rejected"` string.
    pub fn parse_revision_preview(value: &Value) -> BTreeMap<String, RevisionPreview> {
        let Value::Object(entries) = value else {
            return BTreeMap::new();
        };
        entries
            .iter()
            .filter_map(|(id, state)| {
                let preview = match state.as_str()? {
                    "accepted" => RevisionPreview::Accepted,
                    "rejected" => RevisionPreview::Rejected,
                    _ => return None,
                };
                Some((id.clone(), preview))
            })
            .collect()
    }

    fn revision_decision(&self, value: &Any) -> Option<RevisionPreview> {
        preview::record_decision(value);
        if self.revision_preview.is_empty() {
            return None;
        }
        let (id, ..) = crate::queries::revision_parts(value)?;
        self.revision_preview.get(&id).copied()
    }

    /// Whether the decisions previewed hide a run with these attributes: an
    /// insertion rejected, or a deletion accepted.
    fn revision_hidden(&self, attributes: Option<&Attrs>) -> bool {
        attribute(attributes, INS).and_then(|value| self.revision_decision(value))
            == Some(RevisionPreview::Rejected)
            || attribute(attributes, DEL).and_then(|value| self.revision_decision(value))
                == Some(RevisionPreview::Accepted)
    }
}

/// A decision [`RenderEnv::revision_preview`] shows for one revision.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize)]
#[serde(rename_all = "lowercase")]
pub enum RevisionPreview {
    Accepted,
    Rejected,
}

fn deserialize_revision_preview<'de, D>(
    deserializer: D,
) -> Result<BTreeMap<String, RevisionPreview>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let value = <Value as serde::Deserialize>::deserialize(deserializer)?;
    Ok(RenderEnv::parse_revision_preview(&value))
}

/// Why a story could not be lowered. Every variant means the input is wrong,
/// not that lowering is incomplete.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BridgeError {
    /// The story or a comment anchor could not be read.
    Edit(EditError),
    /// The document counts in code points rather than UTF-16 units, so every
    /// offset in the block output would be wrong.
    WrongOffsetKind,
    /// The story does not end in a pilcrow, so its last paragraph has no mark.
    UnterminatedStory(String),
    /// An embed kind lowering does not know how to render.
    UnsupportedEmbed { story: String, index: u32 },
    /// A table embed whose rows, grid or spans do not describe a rectangle.
    MalformedTable {
        story: String,
        index: u32,
        detail: String,
    },
    /// A table cell refers back to a story already being lowered.
    RecursiveStory(String),
}

impl fmt::Display for BridgeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Edit(error) => error.fmt(f),
            Self::WrongOffsetKind => write!(f, "render bridge requires OffsetKind::Utf16"),
            Self::UnterminatedStory(story) => {
                write!(f, "story {story:?} does not end in a pilcrow embed")
            }
            Self::UnsupportedEmbed { story, index } => {
                write!(
                    f,
                    "story {story:?} contains an unsupported embed at {index}"
                )
            }
            Self::MalformedTable {
                story,
                index,
                detail,
            } => write!(f, "malformed table in story {story:?} at {index}: {detail}"),
            Self::RecursiveStory(story) => {
                write!(f, "recursive table story reference to {story:?}")
            }
        }
    }
}

impl std::error::Error for BridgeError {}

impl From<EditError> for BridgeError {
    fn from(value: EditError) -> Self {
        Self::Edit(value)
    }
}

/// Where each laid-out position of one lowered story came from, recorded by the lowering that
/// produced the blocks so no identity is ever recovered from a block id.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct LoweringMap {
    /// The stories lowered, the root first and then every cell and control story in order.
    pub stories: Vec<String>,
    /// Source paragraphs: their story (an index into `stories`) and paragraph id.
    pub paragraphs: Vec<(u32, String)>,
    /// Paragraph blocks by start position, with their source paragraph. A paragraph that
    /// in-flow drawings split contributes one block per segment.
    pub paragraph_blocks: Vec<(u64, u32)>,
    /// Inline content and drawing blocks by display position, sorted and disjoint.
    pub spans: Vec<SourceSpan>,
    /// Tables by start position: their story and their ordinal among its table embeds.
    pub tables: Vec<(u64, u32, u32)>,
}

/// Display positions `[pm_start, pm_end)` and the story units `[raw_start, raw_end)` of their
/// source paragraph's story they show. An atom's content, however wide, shows one unit.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SourceSpan {
    pub pm_start: u64,
    pub pm_end: u64,
    pub paragraph: u32,
    pub raw_start: u32,
    pub raw_end: u32,
    pub atom: bool,
}

impl LoweringMap {
    /// The span holding display position `pm`.
    pub fn span_at(&self, pm: u64) -> Option<&SourceSpan> {
        let index = self.spans.partition_point(|span| span.pm_start <= pm);
        self.spans
            .get(index.checked_sub(1)?)
            .filter(|span| pm < span.pm_end)
    }

    /// The source paragraph of the paragraph block starting at `pm`.
    pub fn paragraph_at(&self, pm: u64) -> Option<u32> {
        let index = self
            .paragraph_blocks
            .binary_search_by_key(&pm, |(start, _)| *start)
            .ok()?;
        Some(self.paragraph_blocks[index].1)
    }

    /// The story and ordinal of the table starting at `pm`.
    pub fn table_at(&self, pm: u64) -> Option<(u32, u32)> {
        let index = self
            .tables
            .binary_search_by_key(&pm, |(start, ..)| *start)
            .ok()?;
        let (_, story, ordinal) = self.tables[index];
        Some((story, ordinal))
    }

    fn finish(&mut self) {
        self.spans.sort_by_key(|span| span.pm_start);
        self.paragraph_blocks.sort_by_key(|(start, _)| *start);
        self.tables.sort_by_key(|(start, ..)| *start);
    }
}

/// Maps a UTF-16 story offset to its paragraph-node position.
///
/// A paragraph node occupies its content plus two positions, one for each of
/// its boundaries, while a story counts one unit per pilcrow. Each pilcrow
/// already crossed therefore contributes the one extra position the story
/// index does not have, and the leading `+ 1` opens the first paragraph.
pub const fn pm_position(story_index: u32, pilcrows_before: u32) -> u64 {
    story_index as u64 + 1 + pilcrows_before as u64
}

/// Lowers one story to the layout engine's block vocabulary. Table cells
/// recurse, so a body story yields the blocks of every cell it contains.
pub fn yrs_doc_to_layout_blocks(
    doc: &EditingDoc,
    story_id: &str,
    env: &RenderEnv,
) -> Result<Vec<LayoutBlock>, BridgeError> {
    yrs_doc_to_mapped_layout_blocks(doc, story_id, env).map(|(blocks, _)| blocks)
}

/// [`yrs_doc_to_layout_blocks`] with the [`LoweringMap`] of the same walk.
pub fn yrs_doc_to_mapped_layout_blocks(
    doc: &EditingDoc,
    story_id: &str,
    env: &RenderEnv,
) -> Result<(Vec<LayoutBlock>, LoweringMap), BridgeError> {
    let mut local = local::LocalLowering::new(false);
    yrs_doc_to_mapped_layout_blocks_inner(doc, story_id, env, &mut None, &mut local, &mut None)
}

/// [`yrs_doc_to_mapped_layout_blocks`] plus the blocks it leaves out that a revision
/// preview can reveal: suppressed field results and drawing-only paragraphs.
#[cfg(test)]
pub(crate) fn yrs_doc_to_mapped_layout_blocks_with_revealable(
    doc: &EditingDoc,
    story_id: &str,
    env: &RenderEnv,
    local: &mut local::LocalLowering,
) -> Result<(Vec<LayoutBlock>, LoweringMap, Vec<LayoutBlock>), BridgeError> {
    let mut revealable = Some(Vec::new());
    let (blocks, map) = yrs_doc_to_mapped_layout_blocks_inner(
        doc,
        story_id,
        env,
        &mut revealable,
        local,
        &mut None,
    )?;
    local.finish(&blocks, &map);
    Ok((blocks, map, revealable.unwrap_or_default()))
}

fn yrs_doc_to_mapped_layout_blocks_inner(
    doc: &EditingDoc,
    story_id: &str,
    env: &RenderEnv,
    revealable: &mut Option<Vec<LayoutBlock>>,
    local: &mut local::LocalLowering,
    preview_units: &mut Option<preview::PreviewUnits>,
) -> Result<(Vec<LayoutBlock>, LoweringMap), BridgeError> {
    if doc.yrs_doc().offset_kind() != OffsetKind::Utf16 {
        return Err(BridgeError::WrongOffsetKind);
    }

    let with_sources = RenderEnv {
        media: if env.media_tokens && env.media.is_empty() {
            doc.media_sources()
        } else {
            env.media.clone()
        },
        group_pictures: doc
            .source_index()
            .map(|index| index.group_picture_sources())
            .unwrap_or_else(|| env.group_pictures.clone()),
        ..env.clone()
    };
    let env = &with_sources;
    let source = doc.source_metadata();
    local.source = source.as_ref().map(Arc::downgrade).unwrap_or_default();
    local.block(source.as_ref().is_some_and(|source| {
        source
            .run_revision_stories()
            .any(|story| story == "body" || story.starts_with("body:"))
    }));
    let mut list_state = ListState::new(source.map(|source| source.numbering()));
    let txn = doc.yrs_doc().transact();
    local.block(
        txn.get_map(COMMENTS)
            .is_some_and(|comments| comments.len(&txn) != 0),
    );
    let mut active_stories = BTreeSet::new();
    let mut map = preview::LoweringOutput::default();
    let session = txn.get_map(crate::identity::SESSION);
    let has_sequence_metadata = session
        .as_ref()
        .is_some_and(|session| session.contains_key(&txn, crate::seed::OPAQUE_SEQUENCES));
    let mut opaque_sequences: BTreeSet<String> = session
        .map(|session| {
            any_strings(shared_any(&session, &txn, crate::seed::OPAQUE_SEQUENCES).as_ref())
                .into_iter()
                .collect()
        })
        .unwrap_or_default();
    local.preview_blocked |= has_sequence_metadata;
    if local.legacy {
        local.block(has_sequence_metadata);
    }
    let mut recording = if story_id == "body" {
        preview_units
            .take()
            .map(|units| preview::UnitRecorder::new(units, local.enabled && !local.legacy))
    } else {
        None
    };
    let _reads = recording.as_ref().map(preview::UnitRecorder::read_guard);
    let (mut blocks, _) = lower_story_with_preview(
        &txn,
        story_id,
        env,
        0,
        &mut active_stories,
        &mut list_state,
        CellEdges::default(),
        &mut map,
        &mut opaque_sequences,
        revealable,
        local,
        recording.as_mut(),
    )?;
    *preview_units = recording.map(|recording| recording.finish(has_sequence_metadata));
    // Word numbers SEQ fields in the main text only.
    if story_id == "body" && has_sequence_metadata {
        docx_layout::sequence_fields::number_sequence_fields_with_opaque(
            &mut blocks,
            opaque_sequences,
        );
    }
    map.finish();
    Ok((blocks, map.map))
}

#[derive(Clone, Copy, Default)]
struct CellEdges {
    before: bool,
    after: bool,
}

#[allow(clippy::too_many_arguments)]
fn lower_story<T: ReadTxn>(
    txn: &T,
    story_id: &str,
    env: &RenderEnv,
    pm_base: u64,
    active_stories: &mut BTreeSet<String>,
    list_state: &mut ListState,
    cell_edges: CellEdges,
    map: &mut preview::LoweringOutput,
    opaque_sequences: &mut BTreeSet<String>,
    revealable: &mut Option<Vec<LayoutBlock>>,
    local: &mut local::LocalLowering,
) -> Result<(Vec<LayoutBlock>, u64), BridgeError> {
    lower_story_with_preview(
        txn,
        story_id,
        env,
        pm_base,
        active_stories,
        list_state,
        cell_edges,
        map,
        opaque_sequences,
        revealable,
        local,
        None,
    )
}

#[allow(clippy::too_many_arguments)]
fn lower_story_with_preview<T: ReadTxn>(
    txn: &T,
    story_id: &str,
    env: &RenderEnv,
    pm_base: u64,
    active_stories: &mut BTreeSet<String>,
    list_state: &mut ListState,
    cell_edges: CellEdges,
    map: &mut preview::LoweringOutput,
    opaque_sequences: &mut BTreeSet<String>,
    revealable: &mut Option<Vec<LayoutBlock>>,
    local: &mut local::LocalLowering,
    mut recording: Option<&mut preview::UnitRecorder>,
) -> Result<(Vec<LayoutBlock>, u64), BridgeError> {
    if !active_stories.insert(story_id.to_owned()) {
        return Err(BridgeError::RecursiveStory(story_id.to_owned()));
    }
    let story_slot = map.story_count();
    map.stories.push(story_id.to_owned());
    let result = (|| {
        let story = story_ref(txn, story_id)?;
        let comments = std::rc::Rc::new(resolve_comment_intervals(txn, story_id, env)?);
        let chunks = story.diff(txn, YChange::identity);
        let share_chunks = !local.blocked && !local.legacy;
        let (owned_chunks, shared_chunks) = if story_id == "body" && share_chunks {
            (
                Vec::new(),
                Some(std::rc::Rc::new(local::SeedChunks::new(chunks))),
            )
        } else {
            (chunks, None)
        };
        if story_id == "body" {
            local.chunks.clone_from(&shared_chunks);
        }
        let chunks = shared_chunks
            .as_ref()
            .map_or(owned_chunks.as_slice(), |chunks| chunks.diffs.as_slice());
        let initial = preview::WalkPosition::new(story_slot, pm_base, map);
        let (blocks, after, _) = walk_story_chunks(
            txn,
            story_id,
            env,
            active_stories,
            list_state,
            cell_edges,
            map,
            opaque_sequences,
            revealable,
            local,
            &story,
            &comments,
            chunks,
            initial,
            BTreeSet::new(),
            recording.as_deref_mut(),
        )?;
        if let Some(recording) = recording {
            recording.save_chunks(chunks, comments);
        }
        Ok((blocks, after.pm_cursor - pm_base))
    })();
    if story_id == "body" {
        local.chunks = None;
    }
    active_stories.remove(story_id);
    result
}

fn can_omit_trailing_body_page_break<T: ReadTxn>(
    txn: &T,
    chunks: &[yrs::types::text::Diff<YChange>],
    starts_at_boundary: bool,
    local: &local::LocalLowering,
) -> bool {
    use crate::structured::source::InlineSource;

    let Some(source) = local.source.upgrade() else {
        return false;
    };
    let mut tail = chunks.iter().rev();
    let pilcrow = loop {
        match tail.next().map(|diff| &diff.insert) {
            Some(Out::YMap(embed))
                if shared_map_string(embed, txn, "_kind").as_deref() == Some("pageBreak") => {}
            Some(Out::YMap(mark)) if is_pilcrow(mark, txn) => break mark,
            _ => return false,
        }
    };
    let empty = match tail.next().map(|diff| &diff.insert) {
        Some(Out::YMap(embed)) => matches!(
            shared_map_string(embed, txn, "_kind").as_deref(),
            Some("pilcrow" | "table" | "blockSdt" | "pageBreak")
        ),
        None => starts_at_boundary,
        _ => false,
    };
    if !empty
        || pilcrow.contains_key(txn, "sectPr")
        || pilcrow.contains_key(txn, "sectionBreakType")
    {
        return false;
    }
    let Some(para_id) = shared_map_string(pilcrow, txn, "paraId") else {
        return false;
    };
    let read = source.read();
    let provenance = &read.provenance;
    if provenance
        .block_order
        .get("body")
        .is_some_and(|order| order.last().and_then(Option::as_deref) != Some(para_id.as_str()))
        || !provenance
            .relocated
            .iter()
            .any(|item| item.pin.story == "body" && item.para_id == para_id)
        || provenance.inline.iter().any(|item| {
            item.pin.story == "body"
                && item.para_id == para_id
                && !matches!(
                    item.content,
                    InlineSource::Break {
                        kind: crate::structured::BreakType::Page,
                        ..
                    }
                )
        })
    {
        return false;
    }
    let footnote_position = read
        .final_section
        .as_ref()
        .and_then(|section| section.get("footnotePr"))
        .and_then(|properties| properties.get("position"))
        .or_else(|| read.settings.as_ref()?.get("footnotePr")?.get("position"))
        .and_then(Value::as_str)
        .unwrap_or("pageBottom");
    !txn.get_map(crate::STORIES).is_some_and(|stories| {
        stories.iter(txn).any(|(id, _)| {
            let note_id = id.strip_prefix("en:").or_else(|| {
                if matches!(footnote_position, "docEnd" | "sectEnd") {
                    id.strip_prefix("fn:")
                } else {
                    None
                }
            });
            note_id.is_some_and(|id| id.parse::<i64>().is_ok_and(|id| id > 0))
        })
    })
}

#[allow(clippy::too_many_arguments)]
fn walk_story_chunks<T: ReadTxn>(
    txn: &T,
    story_id: &str,
    env: &RenderEnv,
    active_stories: &mut BTreeSet<String>,
    list_state: &mut ListState,
    cell_edges: CellEdges,
    map: &mut preview::LoweringOutput,
    opaque_sequences: &mut BTreeSet<String>,
    revealable: &mut Option<Vec<LayoutBlock>>,
    local: &mut local::LocalLowering,
    story: &yrs::TextRef,
    comments: &[CommentInterval],
    chunks: &[yrs::types::text::Diff<YChange>],
    initial: preview::WalkPosition,
    mut hidden_field_blocks: BTreeSet<String>,
    mut recording: Option<&mut preview::UnitRecorder>,
) -> Result<(Vec<LayoutBlock>, preview::WalkPosition, BTreeSet<String>), BridgeError> {
    let starts_at_boundary =
        initial.at_block_boundary && initial.paragraph_start == initial.story_index;
    let preview::WalkPosition {
        story_slot,
        mut table_ordinal,
        mut break_ordinal,
        mut story_index,
        mut paragraph_start,
        mut paragraph_pm_start,
        mut paragraph_pm_units,
        mut pm_cursor,
        mut at_block_boundary,
        mut section_margins,
        ..
    } = initial;
    let mut blocks = Vec::new();
    let mut paragraph_runs = Vec::new();
    let mut paragraph_drawings: Vec<DrawingMarker> = Vec::new();
    let mut pending_hidden_field_blocks = BTreeSet::new();
    let mut pending_code_join: Option<(Vec<FieldCodeParagraph>, String)> = None;
    let mut field_join: Option<FieldJoin> = None;
    let mut section_mark_breaks = None;
    macro_rules! position {
        () => {
            preview::WalkPosition {
                story_slot,
                table_ordinal,
                break_ordinal,
                story_index,
                paragraph_start,
                paragraph_pm_start,
                paragraph_pm_units,
                pm_cursor,
                at_block_boundary,
                section_margins,
                stories: map.story_count(),
                paragraphs: map.paragraph_count(),
                safe: at_block_boundary
                    && paragraph_start == story_index
                    && paragraph_runs.is_empty()
                    && paragraph_drawings.is_empty()
                    && pending_hidden_field_blocks.is_empty()
                    && pending_code_join.is_none()
                    && field_join.is_none()
                    && active_stories.len() == 1
                    && active_stories.contains(story_id),
            }
        };
    }
    let mut plain = local::ParagraphSeed::default();
    for (chunk_index, diff) in chunks.iter().enumerate() {
        let local_safe = !local.legacy
            && !local.blocked
            && pending_hidden_field_blocks.is_empty()
            && pending_code_join.is_none()
            && field_join.is_none()
            && story_id == "body"
            && active_stories.len() == 1
            && active_stories.contains("body");
        if !local.legacy && !local.blocked && at_block_boundary && paragraph_start == story_index {
            plain.start(local_safe && paragraph_runs.is_empty() && paragraph_drawings.is_empty());
        }
        if let Some(recording) = recording.as_deref_mut()
            && recording.wants_chunk(story_index)
        {
            recording.before_chunk(
                chunk_index,
                diff,
                txn,
                position!(),
                list_state,
                opaque_sequences,
                &hidden_field_blocks,
                blocks.len(),
                revealable.as_ref().map_or(0, Vec::len),
                map,
            );
        }
        let attributes = diff.attributes.as_deref();
        let width = match &diff.insert {
            Out::Any(Any::String(text)) => utf16_len(text),
            _ => 0,
        };
        local.observe(&mut plain, diff, txn, story_id, chunk_index, width);
        match &diff.insert {
            Out::Any(Any::String(text)) => {
                let text = text.as_ref();
                push_text_chunks(
                    &mut paragraph_runs,
                    text,
                    story_index,
                    attributes,
                    comments,
                    env,
                    paragraph_pm_units,
                );
                story_index += width;
                paragraph_pm_units += width;
                at_block_boundary = false;
            }
            Out::YMap(pilcrow) if is_pilcrow(pilcrow, txn) => {
                let values = pilcrow_values(pilcrow, txn);
                let para_id = value_string(values.get("paraId")).unwrap_or_default();
                let reserved = env.reservations.paragraph(story_id, &para_id);
                local.observe_pilcrow(
                    &mut plain,
                    pilcrow,
                    &values,
                    attributes,
                    story_id,
                    (
                        paragraph_start,
                        paragraph_pm_start,
                        blocks.len(),
                        map.paragraph_count(),
                    ),
                    story_index + 1 == story.len(txn),
                    local_safe
                        && !(story_id == "body"
                            && chunk_index + 2 == chunks.len()
                            && chunks.get(chunk_index + 1).is_some_and(|next| {
                                matches!(&next.insert, Out::YMap(embed)
                                    if shared_map_string(embed, txn, "_kind").as_deref()
                                        == Some("pageBreak"))
                            }))
                        && reserved.is_empty()
                        && !value_string(values.get("paraId"))
                            .is_some_and(|id| hidden_field_blocks.contains(&id)),
                );
                let placed = reservations::place(
                    reserved,
                    &mut paragraph_runs,
                    &mut paragraph_drawings,
                    paragraph_start,
                    story_index,
                );
                let code_join = pending_code_join.take();
                let sectioned =
                    values.contains_key("sectPr") || values.contains_key("sectionBreakType");
                let suppressed = hidden_field_blocks.contains(&para_id);
                retain_visible_drawings(&mut paragraph_drawings, env, opaque_sequences);
                if !sectioned
                    && field_join
                        .as_ref()
                        .and_then(|join| join.hidden.get(join.next_hidden))
                        .is_some_and(|paragraph| {
                            paragraph.id == para_id && paragraph.allows(&paragraph_runs, env)
                        })
                    && paragraph_drawings.iter().all(|drawing| drawing.anchored)
                {
                    paragraph_runs.retain(|run| {
                        let kept = run.visible(env) && run.anchored();
                        if !kept && !run.revision_hidden {
                            collect_run_sequences(run, opaque_sequences);
                        }
                        kept
                    });
                    if !paragraph_runs.is_empty() || !paragraph_drawings.is_empty() {
                        let source = map.paragraph_count();
                        map.paragraphs.push((story_slot, para_id));
                        blocks.extend(lift_drawings(
                            std::mem::take(&mut paragraph_drawings),
                            source,
                            paragraph_pm_start,
                            map,
                        ));
                        if !paragraph_runs.is_empty() {
                            let join = field_join.as_mut().unwrap();
                            let offset = (paragraph_pm_start - join.pm_start) as u32;
                            let defaults = paragraph_run_defaults(&values);
                            for run in &mut paragraph_runs {
                                run.pm_start += offset;
                                run.pm_end += offset;
                                apply_run_defaults(&mut run.formatting, &defaults);
                            }
                            join.pm_units = offset + paragraph_pm_units;
                            join.segments
                                .push((source, std::mem::take(&mut paragraph_runs)));
                        }
                    }
                    field_join.as_mut().unwrap().next_hidden += 1;
                    hidden_field_blocks.append(&mut pending_hidden_field_blocks);
                    paragraph_runs = Vec::new();
                    paragraph_drawings = Vec::new();
                    pm_cursor = paragraph_pm_start + u64::from(paragraph_pm_units) + 2;
                    story_index += 1;
                    paragraph_start = story_index;
                    paragraph_pm_start = pm_cursor;
                    paragraph_pm_units = 0;
                    at_block_boundary = true;
                    continue;
                }
                let joinable = !sectioned
                    && !suppressed
                    && paragraph_drawings.iter().all(|drawing| drawing.anchored);
                let carried = field_join.take().and_then(|join| {
                    if joinable && join.next_hidden == join.hidden.len() && join.target == para_id {
                        return Some(join);
                    }
                    blocks.extend(join.flush(
                        txn,
                        story_id,
                        env,
                        list_state,
                        map,
                        story_slot,
                        CellEdges {
                            before: cell_edges.before,
                            after: false,
                        },
                        opaque_sequences,
                        revealable,
                    ));
                    None
                });
                let (block_pm_start, block_start, mut segments) = match carried {
                    Some(join) => (join.pm_start, join.story_start, join.segments),
                    None => (paragraph_pm_start, paragraph_start, Vec::new()),
                };
                let offset = (paragraph_pm_start - block_pm_start) as u32;
                for run in &mut paragraph_runs {
                    run.pm_start += offset;
                    run.pm_end += offset;
                }
                for drawing in &mut paragraph_drawings {
                    drawing.pm_offset += offset;
                }
                let block_pm_units = offset + paragraph_pm_units;
                pm_cursor = paragraph_pm_start + u64::from(paragraph_pm_units) + 2;
                if let Some((hidden, target)) = code_join
                    && joinable
                {
                    let defaults = paragraph_run_defaults(&values);
                    for run in &mut paragraph_runs {
                        apply_run_defaults(&mut run.formatting, &defaults);
                    }
                    let source = map.paragraph_count();
                    map.paragraphs.push((story_slot, para_id));
                    blocks.extend(lift_drawings(
                        std::mem::take(&mut paragraph_drawings),
                        source,
                        block_pm_start,
                        map,
                    ));
                    segments.push((source, std::mem::take(&mut paragraph_runs)));
                    field_join = Some(FieldJoin {
                        pilcrow: pilcrow.clone(),
                        attributes: attributes.cloned(),
                        segments,
                        pm_start: block_pm_start,
                        pm_units: block_pm_units,
                        story_start: block_start,
                        hidden,
                        next_hidden: 0,
                        target,
                    });
                    hidden_field_blocks.append(&mut pending_hidden_field_blocks);
                    story_index += 1;
                    paragraph_start = story_index;
                    paragraph_pm_start = pm_cursor;
                    paragraph_pm_units = 0;
                    at_block_boundary = true;
                    continue;
                }
                let mut paragraph_blocks = flush_paragraph_parts(
                    paragraph_runs,
                    paragraph_drawings,
                    pilcrow,
                    attributes,
                    txn,
                    story_id,
                    env,
                    block_pm_start,
                    block_pm_units,
                    list_state,
                    (map, story_slot),
                    opaque_sequences,
                    revealable,
                    segments,
                    placed.hides_mark,
                );
                suppress_cell_edge_spacing(
                    &mut paragraph_blocks,
                    &values,
                    CellEdges {
                        before: cell_edges.before && block_start == 0,
                        after: cell_edges.after && story_index + 1 == story.len(txn),
                    },
                );
                let paragraph_blocks: Vec<LayoutBlock> = placed
                    .before
                    .into_iter()
                    .chain(paragraph_blocks)
                    .chain(placed.after)
                    .collect();
                if !shared_map_string(pilcrow, txn, "paraId")
                    .is_some_and(|id| hidden_field_blocks.contains(&id))
                {
                    blocks.extend(paragraph_blocks);
                } else if let Some(revealed) = revealable {
                    revealed.extend(paragraph_blocks);
                }
                // The field's own paragraph is the one just closed, so the
                // range it suppresses opens with the next block.
                hidden_field_blocks.append(&mut pending_hidden_field_blocks);
                // A pilcrow carrying section properties ENDS its section,
                // so the break block follows its paragraph.
                if let Some(section_break) = section_break_block(&values, &mut section_margins) {
                    blocks.push(LayoutBlock::SectionBreak(section_break));
                }
                paragraph_runs = Vec::new();
                paragraph_drawings = Vec::new();
                story_index += 1;
                paragraph_start = story_index;
                paragraph_pm_start = pm_cursor;
                paragraph_pm_units = 0;
                at_block_boundary = true;
            }
            Out::YMap(table)
                if shared_map_string(table, txn, "_kind").as_deref() == Some("table") =>
            {
                if let Some(join) = field_join.take() {
                    blocks.extend(join.flush(
                        txn,
                        story_id,
                        env,
                        list_state,
                        map,
                        story_slot,
                        CellEdges {
                            before: cell_edges.before,
                            after: false,
                        },
                        opaque_sequences,
                        revealable,
                    ));
                }
                if !paragraph_runs.is_empty()
                    || !paragraph_drawings.is_empty()
                    || paragraph_start != story_index
                {
                    return Err(BridgeError::MalformedTable {
                        story: story_id.to_owned(),
                        index: story_index,
                        detail: "table embed interrupts paragraph content".to_owned(),
                    });
                }
                let previewed_out = env.revision_hidden(attributes);
                let hidden = previewed_out
                    || shared_map_string(table, txn, "blockId")
                        .is_some_and(|id| hidden_field_blocks.contains(&id));
                map.tables.push((pm_cursor, story_slot, table_ordinal));
                table_ordinal += 1;
                let mut unnumbered = previewed_out.then(|| list_state.clone());
                let (lowered, node_size) = lower_table(
                    table,
                    txn,
                    story_id,
                    story_index,
                    pm_cursor,
                    env,
                    active_stories,
                    unnumbered.as_mut().unwrap_or(&mut *list_state),
                    map,
                    opaque_sequences,
                    revealable,
                    local,
                )?;
                if !hidden {
                    blocks.push(LayoutBlock::Table(lowered));
                } else if !previewed_out && let Some(revealed) = revealable {
                    revealed.push(LayoutBlock::Table(lowered));
                }
                story_index += 1;
                paragraph_start = story_index;
                pm_cursor += node_size;
                paragraph_pm_start = pm_cursor;
                paragraph_pm_units = 0;
                at_block_boundary = true;
            }
            Out::YMap(page_break)
                if matches!(
                    shared_map_string(page_break, txn, "_kind").as_deref(),
                    Some("pageBreak" | "columnBreak")
                ) =>
            {
                if let Some(join) = field_join.take() {
                    blocks.extend(join.flush(
                        txn,
                        story_id,
                        env,
                        list_state,
                        map,
                        story_slot,
                        CellEdges {
                            before: cell_edges.before,
                            after: false,
                        },
                        opaque_sequences,
                        revealable,
                    ));
                }
                if !at_block_boundary
                    || !paragraph_runs.is_empty()
                    || !paragraph_drawings.is_empty()
                {
                    return Err(BridgeError::UnsupportedEmbed {
                        story: story_id.to_owned(),
                        index: story_index,
                    });
                }
                let kind = shared_map_string(page_break, txn, "_kind").unwrap_or_default();
                let hidden = env.revision_hidden(attributes);
                if kind == "pageBreak"
                    && !hidden
                    && let Some(LayoutBlock::Paragraph(paragraph)) = blocks.last_mut()
                    && paragraph.runs.is_empty()
                    && paragraph.pm_end == Some(pm_cursor as f64)
                    && paragraph.pm_end == paragraph.pm_start.map(|start| start + 2.0)
                    && let Some(attrs) = paragraph.attrs.as_mut()
                    && attrs.list_marker.is_some()
                {
                    attrs.list_marker_hidden = Some(true);
                }
                // Numbered among the story's breaks rather than by position,
                // so an edit before a break leaves its block unchanged.
                let id = BlockId::Str(format!("{story_id}:{kind}:{break_ordinal}"));
                break_ordinal += 1;
                let terminal = kind == "pageBreak"
                    && story_id == "body"
                    && story_index + 1 == story.len(txn)
                    && can_omit_trailing_body_page_break(txn, chunks, starts_at_boundary, local);
                if !hidden && !terminal {
                    let (pm_start, pm_end) = (Some(pm_cursor as f64), Some((pm_cursor + 1) as f64));
                    blocks.push(if kind == "columnBreak" {
                        LayoutBlock::ColumnBreak(ColumnBreakBlock {
                            sdt_groups: None,
                            id,
                            pm_start,
                            pm_end,
                        })
                    } else {
                        LayoutBlock::PageBreak(PageBreakBlock {
                            section_mark_ineligible: section_mark_ineligible(
                                txn,
                                chunks,
                                (chunk_index, story_index),
                                local.source.upgrade().as_deref(),
                                story_id,
                                &mut section_mark_breaks,
                            )
                            .then_some(true),
                            sdt_groups: None,
                            id,
                            pm_start,
                            pm_end,
                        })
                    });
                }
                story_index += 1;
                paragraph_start = story_index;
                pm_cursor += 1;
                paragraph_pm_start = pm_cursor;
                paragraph_pm_units = 0;
                at_block_boundary = true;
            }
            Out::YMap(block_sdt)
                if shared_map_string(block_sdt, txn, "_kind").as_deref() == Some("blockSdt") =>
            {
                if let Some(join) = field_join.take() {
                    blocks.extend(join.flush(
                        txn,
                        story_id,
                        env,
                        list_state,
                        map,
                        story_slot,
                        CellEdges {
                            before: cell_edges.before,
                            after: false,
                        },
                        opaque_sequences,
                        revealable,
                    ));
                }
                if !at_block_boundary
                    || !paragraph_runs.is_empty()
                    || !paragraph_drawings.is_empty()
                {
                    return Err(BridgeError::UnsupportedEmbed {
                        story: story_id.to_owned(),
                        index: story_index,
                    });
                }
                let Some(child_story) = shared_map_string(block_sdt, txn, "story") else {
                    return Err(BridgeError::UnsupportedEmbed {
                        story: story_id.to_owned(),
                        index: story_index,
                    });
                };
                let group = lower_sdt_group(block_sdt, txn, pm_cursor as i64);
                let previewed_out = env.revision_hidden(attributes);
                let mut unnumbered = previewed_out.then(|| list_state.clone());
                let (mut child_blocks, content_size) = lower_story(
                    txn,
                    &child_story,
                    env,
                    pm_cursor + 1,
                    active_stories,
                    unnumbered.as_mut().unwrap_or(&mut *list_state),
                    CellEdges {
                        before: cell_edges.before && story_index == 0,
                        after: cell_edges.after && story_index + 1 == story.len(txn),
                    },
                    map,
                    opaque_sequences,
                    revealable,
                    local,
                )?;
                stamp_sdt_group(&mut child_blocks, group);
                if !previewed_out && !hidden_field_blocks.contains(&child_story) {
                    blocks.extend(child_blocks);
                } else if !previewed_out && let Some(revealed) = revealable {
                    revealed.extend(child_blocks);
                }
                story_index += 1;
                paragraph_start = story_index;
                pm_cursor += content_size + 2;
                paragraph_pm_start = pm_cursor;
                paragraph_pm_units = 0;
                at_block_boundary = true;
            }
            Out::YMap(note_ref)
                if shared_map_string(note_ref, txn, "_kind").as_deref() == Some("noteRef") =>
            {
                let footnote_id = shared_any(note_ref, txn, "footnoteRefId")
                    .as_ref()
                    .and_then(|value| note_ref_id(value, env));
                let endnote_id = shared_any(note_ref, txn, "endnoteRefId")
                    .as_ref()
                    .and_then(|value| note_ref_id(value, env));
                let Some(id) = footnote_id.or(endnote_id) else {
                    return Err(BridgeError::UnsupportedEmbed {
                        story: story_id.to_owned(),
                        index: story_index,
                    });
                };
                let mut formatting = lower_run_formatting(attributes, env);
                formatting.superscript = Some(true);
                if footnote_id.is_some() {
                    formatting.footnote_ref_id = Some(id);
                } else {
                    formatting.endnote_ref_id = Some(id);
                }
                let mut comment_ids: Vec<f64> = comments
                    .iter()
                    .filter(|interval| {
                        interval.start <= story_index && story_index + 1 <= interval.end
                    })
                    .map(|interval| interval.id)
                    .collect();
                comment_ids.sort_by(f64::total_cmp);
                comment_ids.dedup_by(|a, b| a.total_cmp(b).is_eq());
                if !comment_ids.is_empty() {
                    formatting.comment_ids = Some(comment_ids);
                }
                paragraph_runs.push(RawRun {
                    kind: RawRunKind::Text(note_ref_label(id)),
                    formatting,
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: paragraph_pm_units,
                    pm_end: paragraph_pm_units + 1,
                    inherited_hyperlink: inherited_hyperlink_style(attributes),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(attributes),
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(field)
                if shared_map_string(field, txn, "_kind").as_deref() == Some("field") =>
            {
                let instruction =
                    shared_map_string(field, txn, "instruction").filter(|value| !value.is_empty());
                let hidden = instruction
                    .as_deref()
                    .is_some_and(super::seed::numeric_field_instruction);
                if hidden && !env.revision_hidden(attributes) {
                    preview::touch_hidden_fields();
                    pending_hidden_field_blocks.append(&mut hidden_field_result_blocks(field, txn));
                }
                if joins_field_code_paragraphs(story_id)
                    && let Some(join) = field_code_join(field, txn)
                    && !env.revision_hidden(attributes)
                    && pending_code_join
                        .as_ref()
                        .is_none_or(|(hidden, _)| join.0.len() > hidden.len())
                {
                    pending_code_join = Some(join);
                }
                let field_type = shared_map_string(field, txn, "fieldType")
                    .unwrap_or_else(|| "OTHER".to_owned());
                let mapped_type = match field_type.as_str() {
                    "PAGE" | "NUMPAGES" | "DATE" | "TIME" => field_type.clone(),
                    _ => "OTHER".to_owned(),
                };
                let nested_sequences = lower_nested_sequences(
                    instruction.as_deref(),
                    shared_any(field, txn, "resultProjection").as_ref(),
                );
                paragraph_runs.push(RawRun {
                    kind: RawRunKind::Field {
                        field_type: mapped_type.clone(),
                        raw_type: (field_type != mapped_type).then_some(field_type),
                        instruction,
                        fallback: Some(if hidden {
                            String::new()
                        } else {
                            shared_map_string(field, txn, "displayText").unwrap_or_default()
                        }),
                        source: field_join
                            .as_ref()
                            .and_then(|_| shared_map_string(field, txn, "fieldData")),
                        locked: shared_any(field, txn, "fldLock")
                            .as_ref()
                            .and_then(any_bool)
                            .unwrap_or(false),
                        nested_sequences,
                    },
                    formatting: lower_run_formatting(attributes, env),
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: paragraph_pm_units,
                    pm_end: paragraph_pm_units + 1,
                    inherited_hyperlink: inherited_hyperlink_style(attributes),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(attributes),
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(line_break)
                if shared_map_string(line_break, txn, "_kind").as_deref() == Some("break") =>
            {
                paragraph_runs.push(RawRun {
                    kind: RawRunKind::LineBreak,
                    formatting: lower_run_formatting(attributes, env),
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: paragraph_pm_units,
                    pm_end: paragraph_pm_units + 1,
                    inherited_hyperlink: inherited_hyperlink_style(attributes),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(attributes),
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(image)
                if shared_map_string(image, txn, "_kind").as_deref() == Some("image") =>
            {
                let formatting = lower_run_formatting(attributes, env);
                paragraph_runs.push(RawRun {
                    kind: RawRunKind::Image(lower_image_run(image, txn, &formatting, env)),
                    formatting,
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: paragraph_pm_units,
                    pm_end: paragraph_pm_units + 1,
                    inherited_hyperlink: inherited_hyperlink_style(attributes),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(attributes),
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(rule)
                if shared_map_string(rule, txn, "_kind").as_deref() == Some("horizontalRule") =>
            {
                let Some(rule) = shared_any(rule, txn, "rule")
                        .filter(|value| {
                            any_map(value).is_some_and(|map| {
                                ["width", "widthPercent", "height"].iter().all(|key| {
                                    !matches!(map.get(*key), Some(Any::Number(value)) if !value.is_finite())
                                })
                            })
                        })
                        .and_then(|value| any_json(&value))
                        .and_then(|value| {
                            serde_json::to_string(&value).ok().and_then(|s| serde_json::from_str::<docx_parse::vml::HorizontalRule>(&s).ok())
                        })
                    else {
                        return Err(BridgeError::UnsupportedEmbed {
                            story: story_id.to_owned(),
                            index: story_index,
                        });
                    };
                paragraph_runs.push(RawRun {
                    kind: RawRunKind::HorizontalRule(HorizontalRule {
                        width: rule.width.map(|width| width / 9_525.0),
                        width_percent: rule.width_percent,
                        height: rule.height / 9_525.0,
                        alignment: rule.alignment,
                        no_shade: rule.no_shade,
                        color: rule.color,
                        pm_start: 0.0,
                        pm_end: 0.0,
                    }),
                    formatting: lower_run_formatting(attributes, env),
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: paragraph_pm_units,
                    pm_end: paragraph_pm_units + 1,
                    inherited_hyperlink: inherited_hyperlink_style(attributes),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(attributes),
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(math) if shared_map_string(math, txn, "_kind").as_deref() == Some("math") => {
                let text = shared_map_string(math, txn, "plainText")
                    .filter(|value| !value.is_empty())
                    .unwrap_or_else(|| "[equation]".to_owned());
                paragraph_runs.push(RawRun {
                    kind: RawRunKind::Text(text),
                    formatting: RunFormatting {
                        italic: Some(true),
                        font_family: Some("Cambria Math".to_owned()),
                        hidden: mark_bool(attributes, "hidden"),
                        // Sentinel consumed by `stamp_logical_order`: a
                        // math fallback run gets no logical order.
                        logical_order: Some(u64::MAX),
                        ..RunFormatting::default()
                    },
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: paragraph_pm_units,
                    pm_end: paragraph_pm_units + 1,
                    inherited_hyperlink: inherited_hyperlink_style(attributes),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(attributes),
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(sdt) if shared_map_string(sdt, txn, "_kind").as_deref() == Some("sdt") => {
                let first = paragraph_runs.len();
                let node_size = lower_inline_sdt(
                    sdt,
                    txn,
                    env,
                    story_index,
                    paragraph_pm_start,
                    paragraph_pm_units,
                    None,
                    &mut paragraph_runs,
                );
                inherit_inline_revision(&mut paragraph_runs[first..], attributes, env);
                if env.revision_hidden(attributes) {
                    hide_runs(&mut paragraph_runs[first..]);
                }
                story_index += 1;
                paragraph_pm_units += node_size;
                at_block_boundary = false;
            }
            Out::YMap(shape)
                if shared_map_string(shape, txn, "_kind").as_deref() == Some("shape") =>
            {
                let pm_offset = paragraph_pm_units;
                let Some(block) = lower_shape_block(
                    shape,
                    txn,
                    paragraph_pm_start + 1 + u64::from(pm_offset),
                    env,
                    story_id,
                ) else {
                    return Err(BridgeError::UnsupportedEmbed {
                        story: story_id.to_owned(),
                        index: story_index,
                    });
                };
                let formatting = lower_run_formatting(attributes, env);
                if shapes::inline_native_shape(&block) {
                    let image = ImageRun {
                        src: String::new(),
                        width: block.width,
                        height: block.height,
                        alt: block.description.clone().or_else(|| block.title.clone()),
                        shape_type: Some(block.shape_type.clone()),
                        transform: None,
                        position: None,
                        wrap_type: Some("inline".to_owned()),
                        display_mode: Some("inline".to_owned()),
                        css_float: Some("none".to_owned()),
                        dist_top: None,
                        dist_bottom: None,
                        dist_left: None,
                        dist_right: None,
                        crop_top: None,
                        crop_right: None,
                        crop_bottom: None,
                        crop_left: None,
                        opacity: None,
                        rotation_deg: None,
                        flip_h: None,
                        flip_v: None,
                        rotation_bounds: None,
                        wrap_text: None,
                        wrap_polygon: None,
                        allow_overlap: None,
                        layout_in_cell: None,
                        no_change_aspect: None,
                        effect_extent: None,
                        effects: None,
                        outline: None,
                        decorative: block.decorative,
                        hyperlink: formatting.hyperlink.clone(),
                        inline_shape: Some(Box::new(block)),
                        inline_chart: None,
                        horizontal_rule: None,
                        is_insertion: formatting.is_insertion,
                        is_deletion: formatting.is_deletion,
                        change_author: formatting.change_author.clone(),
                        change_date: formatting.change_date.clone(),
                        change_revision_id: formatting.change_revision_id,
                        pm_start: None,
                        pm_end: None,
                    };
                    paragraph_runs.push(RawRun {
                        kind: RawRunKind::Image(image),
                        formatting,
                        story_start: story_index,
                        story_end: story_index + 1,
                        pm_start: pm_offset,
                        pm_end: pm_offset + 1,
                        inherited_hyperlink: inherited_hyperlink_style(attributes),
                        inline_sdt_widget: None,
                        atom: true,
                        revision_hidden: env.revision_hidden(attributes),
                    });
                } else {
                    paragraph_drawings.push(DrawingMarker {
                        pm_offset,
                        story_index,
                        anchored: shapes::anchored_shape(&block),
                        block: LayoutBlock::Shape(block),
                        hidden: mark_bool(attributes, "hidden") == Some(true),
                        revision_hidden: env.revision_hidden(attributes),
                    });
                }
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(opaque)
                if shared_map_string(opaque, txn, "_kind").as_deref() == Some("opaqueDrawing") =>
            {
                let values = shared_values(opaque, txn);
                if let Some(block) = opaque_text_box(
                    &values,
                    paragraph_pm_start + 1 + u64::from(paragraph_pm_units),
                    env,
                    story_id,
                ) {
                    paragraph_drawings.push(DrawingMarker {
                        pm_offset: paragraph_pm_units,
                        story_index,
                        anchored: shapes::anchored_shape(&block),
                        block: LayoutBlock::Shape(block),
                        hidden: mark_bool(attributes, "hidden") == Some(true),
                        revision_hidden: env.revision_hidden(attributes),
                    });
                }
                for preview in opaque_image_previews(&values) {
                    let formatting = lower_run_formatting(attributes, env);
                    paragraph_runs.push(RawRun {
                        kind: RawRunKind::Image(lower_image_values(preview, &formatting, env)),
                        formatting,
                        story_start: story_index,
                        story_end: story_index + 1,
                        pm_start: paragraph_pm_units,
                        pm_end: paragraph_pm_units + 1,
                        inherited_hyperlink: inherited_hyperlink_style(attributes),
                        inline_sdt_widget: None,
                        atom: true,
                        revision_hidden: env.revision_hidden(attributes),
                    });
                }
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            Out::YMap(chart)
                if shared_map_string(chart, txn, "_kind").as_deref() == Some("chart") =>
            {
                let pm_offset = paragraph_pm_units;
                let Some(block) = lower_chart_block(
                    &shared_values(chart, txn),
                    Some(paragraph_pm_start + 1 + u64::from(pm_offset)),
                    env,
                ) else {
                    return Err(BridgeError::UnsupportedEmbed {
                        story: story_id.to_owned(),
                        index: story_index,
                    });
                };
                paragraph_drawings.push(DrawingMarker {
                    pm_offset,
                    story_index,
                    block: LayoutBlock::Chart(block),
                    hidden: mark_bool(attributes, "hidden") == Some(true),
                    revision_hidden: env.revision_hidden(attributes),
                    anchored: false,
                });
                story_index += 1;
                paragraph_pm_units += 1;
                at_block_boundary = false;
            }
            _ => {
                return Err(BridgeError::UnsupportedEmbed {
                    story: story_id.to_owned(),
                    index: story_index,
                });
            }
        }
    }

    if let Some(join) = field_join.take() {
        blocks.extend(join.flush(
            txn,
            story_id,
            env,
            list_state,
            map,
            story_slot,
            cell_edges,
            opaque_sequences,
            revealable,
        ));
    }
    if !at_block_boundary
        || !paragraph_runs.is_empty()
        || !paragraph_drawings.is_empty()
        || paragraph_start != story_index
    {
        return Err(BridgeError::UnterminatedStory(story_id.to_owned()));
    }

    let after = position!();
    if let Some(recording) = recording {
        recording.end_window(
            chunks.len(),
            after,
            list_state,
            opaque_sequences,
            &hidden_field_blocks,
            blocks.len(),
            revealable.as_ref().map_or(0, Vec::len),
            map,
        );
    }
    Ok((blocks, after, hidden_field_blocks))
}

type ParagraphBreakEnds = BTreeMap<String, (crate::structured::BreakType, Option<u32>)>;

fn section_mark_ineligible<T: ReadTxn>(
    txn: &T,
    chunks: &[yrs::types::text::Diff<YChange>],
    (chunk_index, story_index): (usize, u32),
    source: Option<&crate::seed::SourceMetadata>,
    story_id: &str,
    breaks: &mut Option<ParagraphBreakEnds>,
) -> bool {
    use crate::structured::source::InlineSource;

    let mut owner = chunk_index;
    let pilcrow = loop {
        let Some(previous) = owner.checked_sub(1) else {
            return false;
        };
        owner = previous;
        let Out::YMap(mark) = &chunks[owner].insert else {
            return false;
        };
        if is_pilcrow(mark, txn) {
            break mark;
        }
        if !matches!(
            shared_map_string(mark, txn, "_kind").as_deref(),
            Some("pageBreak" | "columnBreak")
        ) {
            return false;
        }
    };
    let start = chunks[..owner]
        .iter()
        .rposition(|chunk| {
            matches!(&chunk.insert, Out::YMap(mark) if matches!(
                shared_map_string(mark, txn, "_kind").as_deref(),
                Some("pilcrow" | "table" | "blockSdt" | "pageBreak" | "columnBreak")
            ))
        })
        .map_or(0, |index| index + 1);
    let whitespace_only = start < owner
        && chunks[start..owner]
            .iter()
            .all(|chunk| match &chunk.insert {
                Out::Any(Any::String(text)) => text.chars().all(char::is_whitespace),
                Out::YMap(mark) => shared_map_string(mark, txn, "_kind").as_deref() == Some("tab"),
                _ => false,
            });
    if whitespace_only {
        return true;
    }
    let breaks = breaks.get_or_insert_with(|| {
        let Some(source) = source else {
            return BTreeMap::new();
        };
        let provenance = &source.read().provenance;
        let Some((inline, _)) = provenance.by_story.get(story_id) else {
            return BTreeMap::new();
        };
        let mut resolved = Default::default();
        inline
            .iter()
            .filter_map(|&index| {
                let record = &provenance.inline[index];
                let InlineSource::Break { kind, .. } = record.content else {
                    return None;
                };
                Some((
                    record.para_id.clone(),
                    (kind, record.pin.resolve(txn, &mut resolved)),
                ))
            })
            .collect()
    });
    let para_id = shared_map_string(pilcrow, txn, "paraId").unwrap_or_default();
    let pilcrow_index = story_index - (chunk_index - owner) as u32;
    breaks.get(&para_id).is_some_and(|(kind, position)| {
        *kind != crate::structured::BreakType::Page || *position != Some(pilcrow_index)
    })
}

/// CamelCase alias of [`yrs_doc_to_layout_blocks`] for callers spelling the
/// entry point the way the boundary names it.
#[allow(non_snake_case)]
pub fn yrsDocToLayoutBlocks(
    doc: &EditingDoc,
    story_id: &str,
    env: &RenderEnv,
) -> Result<Vec<LayoutBlock>, BridgeError> {
    yrs_doc_to_layout_blocks(doc, story_id, env)
}

/// The display-only shape a legacy VML text box carries next to its verbatim markup.
fn opaque_text_box(
    values: &HashMap<String, Any>,
    pm_start: u64,
    env: &RenderEnv,
    story_id: &str,
) -> Option<ShapeBlock> {
    // Pictures shown as runs already hold the drawing's source position.
    if !opaque_image_previews(values).is_empty() {
        return None;
    }
    let Some(Any::String(source)) = values.get("textBoxJson") else {
        return None;
    };
    let value = serde_json::from_str::<Value>(&env.media.tokenized_json(source)).ok()?;
    if value.get("hidden").and_then(Value::as_bool) == Some(true) {
        return None;
    }
    let projected =
        group_pictures::project(&value, story_id, &env.group_pictures, env.media_tokens);
    let rendered = projected.unwrap_or_else(|| group_pictures::raw_projection(&value));
    shapes::lower_shape_json(&rendered, pm_start, env)
}

fn opaque_image_previews(values: &HashMap<String, Any>) -> Vec<&HashMap<String, Any>> {
    let mut previews = Vec::new();
    if let Some(preview) = values.get("preview").and_then(any_map) {
        previews.push(preview);
    }
    if let Some(Any::Array(images)) = values.get("previews") {
        previews.extend(images.iter().filter_map(any_map));
    }
    previews
}

/// The paragraph a field's paragraph joins because the field's code hides its mark, and the
/// paragraphs in between, which the code hides whole; bound at seed time.
fn field_code_join<T: ReadTxn>(
    field: &MapRef,
    txn: &T,
) -> Option<(Vec<FieldCodeParagraph>, String)> {
    let target = shared_map_string(field, txn, "fieldCodeTarget")?;
    let data = shared_map_string(field, txn, "fieldData")
        .and_then(|data| serde_json::from_str::<Value>(&data).ok());
    let code = data
        .as_ref()
        .and_then(|data| data.get("structuredCode"))
        .and_then(|code| code.get("blocks"))
        .and_then(Value::as_array);
    let hidden = match shared_any(field, txn, "fieldCodeMarks") {
        Some(Any::Array(ids)) => ids
            .iter()
            .filter_map(any_str)
            .enumerate()
            .map(|(index, id)| {
                let mut fields = Vec::new();
                if let Some(content) = code
                    .and_then(|blocks| blocks.get(index))
                    .and_then(|block| block.get("content"))
                {
                    nested_code_fields(content, &mut fields);
                }
                FieldCodeParagraph {
                    id: id.to_owned(),
                    fields,
                }
            })
            .collect(),
        _ => Vec::new(),
    };
    Some((hidden, target))
}

fn nested_code_fields(value: &Value, fields: &mut Vec<Value>) {
    match value {
        Value::Object(object)
            if matches!(
                object.get("type").and_then(Value::as_str),
                Some("simpleField" | "complexField")
            ) =>
        {
            fields.push(value.clone());
        }
        Value::Object(object) => {
            if let Some(content) = object
                .get("structuredChildren")
                .or_else(|| object.get("children"))
                .or_else(|| object.get("content"))
            {
                nested_code_fields(content, fields);
            }
        }
        Value::Array(values) => {
            for child in values {
                nested_code_fields(child, fields);
            }
        }
        _ => {}
    }
}

/// Headers and footers show a field whose code spans paragraph marks on one line, as Word
/// does; other stories keep each paragraph, whose carets and edits address it alone.
fn joins_field_code_paragraphs(story_id: &str) -> bool {
    story_id.starts_with("hf:")
}

struct FieldCodeParagraph {
    id: String,
    fields: Vec<Value>,
}

impl FieldCodeParagraph {
    fn allows(&self, runs: &[RawRun], env: &RenderEnv) -> bool {
        let mut fields = self.fields.iter();
        runs.iter()
            .filter(|run| run.visible(env) && !run.anchored())
            .all(|run| match &run.kind {
                RawRunKind::Field {
                    source: Some(source),
                    ..
                } => serde_json::from_str::<Value>(source)
                    .ok()
                    .is_some_and(|source| fields.any(|field| *field == source)),
                _ => false,
            })
    }
}

/// Paragraphs whose marks a field's code hides, held until the paragraph they join.
struct FieldJoin {
    /// The last held paragraph, whose properties apply if the join is cut short.
    pilcrow: MapRef,
    attributes: Option<Attrs>,
    /// Each held paragraph's source and runs, relative to `pm_start`, with its run defaults
    /// applied.
    segments: Vec<(u32, Vec<RawRun>)>,
    pm_start: u64,
    pm_units: u32,
    story_start: u32,
    /// The paragraphs between the last held one and `target`.
    hidden: Vec<FieldCodeParagraph>,
    next_hidden: usize,
    target: String,
}

impl FieldJoin {
    /// Lowers the held paragraphs as one paragraph, when what follows cannot take them.
    #[allow(clippy::too_many_arguments)]
    fn flush<T: ReadTxn>(
        self,
        txn: &T,
        story_id: &str,
        env: &RenderEnv,
        list_state: &mut ListState,
        map: &mut preview::LoweringOutput,
        story_slot: u32,
        cell_edges: CellEdges,
        opaque_sequences: &mut BTreeSet<String>,
        revealable: &mut Option<Vec<LayoutBlock>>,
    ) -> Vec<LayoutBlock> {
        let mut blocks = flush_paragraph_parts(
            Vec::new(),
            Vec::new(),
            &self.pilcrow,
            self.attributes.as_ref(),
            txn,
            story_id,
            env,
            self.pm_start,
            self.pm_units,
            list_state,
            (map, story_slot),
            opaque_sequences,
            revealable,
            self.segments,
            false,
        );
        suppress_cell_edge_spacing(
            &mut blocks,
            &pilcrow_values(&self.pilcrow, txn),
            CellEdges {
                before: cell_edges.before && self.story_start == 0,
                after: cell_edges.after,
            },
        );
        blocks
    }
}

/// Story blocks a hidden field's cached result duplicates, bound at seed time.
fn hidden_field_result_blocks<T: ReadTxn>(field: &MapRef, txn: &T) -> BTreeSet<String> {
    let Some(Any::Array(ids)) = shared_any(field, txn, "fieldResultBlocks") else {
        return BTreeSet::new();
    };
    ids.iter().filter_map(any_str).map(str::to_owned).collect()
}

fn malformed_table(story: &str, index: u32, detail: impl Into<String>) -> BridgeError {
    BridgeError::MalformedTable {
        story: story.to_owned(),
        index,
        detail: detail.into(),
    }
}

fn shared_any<T: ReadTxn>(map: &MapRef, txn: &T, key: &str) -> Option<Any> {
    match map.get(txn, key) {
        Some(Out::Any(value)) => Some(value),
        _ => None,
    }
}

fn shared_map_string<T: ReadTxn>(map: &MapRef, txn: &T, key: &str) -> Option<String> {
    shared_any(map, txn, key)
        .as_ref()
        .and_then(any_str)
        .map(str::to_owned)
}

fn note_ref_id(value: &Any, env: &RenderEnv) -> Option<f64> {
    match value {
        Any::String(value) => Some(numeric_id(value, env)),
        _ => any_number(value),
    }
}

fn note_ref_label(id: f64) -> String {
    if id.fract() == 0.0 {
        format!("{id:.0}")
    } else {
        id.to_string()
    }
}

#[allow(clippy::too_many_arguments)]
fn lower_table<T: ReadTxn>(
    table: &MapRef,
    txn: &T,
    parent_story: &str,
    story_index: u32,
    pm_start: u64,
    env: &RenderEnv,
    active_stories: &mut BTreeSet<String>,
    list_state: &mut ListState,
    map: &mut preview::LoweringOutput,
    opaque_sequences: &mut BTreeSet<String>,
    revealable: &mut Option<Vec<LayoutBlock>>,
    local: &mut local::LocalLowering,
) -> Result<(TableBlock, u64), BridgeError> {
    let tbl_pr_value = shared_any(table, txn, "tblPr")
        .ok_or_else(|| malformed_table(parent_story, story_index, "missing tblPr"))?;
    let tbl_pr = any_map(&tbl_pr_value)
        .ok_or_else(|| malformed_table(parent_story, story_index, "tblPr must be a map"))?;
    let grid_value = shared_any(table, txn, "grid")
        .ok_or_else(|| malformed_table(parent_story, story_index, "missing grid"))?;
    let grid = match &grid_value {
        Any::Array(values) => values,
        _ => {
            return Err(malformed_table(
                parent_story,
                story_index,
                "grid must be an array",
            ));
        }
    };
    let rows_value = shared_any(table, txn, "rows")
        .ok_or_else(|| malformed_table(parent_story, story_index, "missing rows"))?;
    let row_values = match &rows_value {
        Any::Array(values) => values,
        _ => {
            return Err(malformed_table(
                parent_story,
                story_index,
                "rows must be an array",
            ));
        }
    };
    // A table's absolute story index changes whenever text is inserted before it. Cell story
    // names, however, are persistent document identities, so anchor the table and row IDs to the
    // first cell instead. This keeps retained display-list primitive identities stable when an
    // unrelated earlier paragraph changes length.
    let table_identity = row_values
        .iter()
        .filter_map(any_map)
        .filter_map(|row| row.get("cells"))
        .filter_map(|cells| match cells {
            Any::Array(cells) => cells.first(),
            _ => None,
        })
        .filter_map(any_map)
        .find_map(|cell| map_string(cell, "story"));
    local.block(table_identity.is_none());
    let table_identity = table_identity.unwrap_or_else(|| story_index.to_string());
    let table_id = format!("{parent_story}:table:{table_identity}");

    let original = tbl_pr.get("_originalFormatting").and_then(any_map);
    let table_margins = tbl_pr.get("cellMargins").and_then(any_map);
    let grid_widths: Vec<Option<f64>> = grid.iter().map(any_number).collect();
    let total_grid_width: f64 = grid_widths.iter().flatten().sum();
    let mut column_row_ends = vec![0usize; grid_widths.len()];
    let mut rows = Vec::with_capacity(row_values.len());
    let mut row_pm_start = pm_start + 1;

    for (row_index, row_value) in row_values.iter().enumerate() {
        let row = any_map(row_value).ok_or_else(|| {
            malformed_table(
                parent_story,
                story_index,
                format!("row {row_index} must be a map"),
            )
        })?;
        let tr_pr = row.get("trPr").and_then(any_map).ok_or_else(|| {
            malformed_table(
                parent_story,
                story_index,
                format!("row {row_index} is missing trPr"),
            )
        })?;
        let cell_values = match row.get("cells") {
            Some(Any::Array(values)) => values,
            _ => {
                return Err(malformed_table(
                    parent_story,
                    story_index,
                    format!("row {row_index} cells must be an array"),
                ));
            }
        };

        let mut cells = Vec::with_capacity(cell_values.len());
        let mut cell_pm_start = row_pm_start + 1;
        let mut column = 0usize;
        for (cell_index, cell_value) in cell_values.iter().enumerate() {
            let cell = any_map(cell_value).ok_or_else(|| {
                malformed_table(
                    parent_story,
                    story_index,
                    format!("row {row_index} cell {cell_index} must be a map"),
                )
            })?;
            let tc_pr = cell.get("tcPr").and_then(any_map).ok_or_else(|| {
                malformed_table(
                    parent_story,
                    story_index,
                    format!("row {row_index} cell {cell_index} is missing tcPr"),
                )
            })?;
            let cell_story = map_string(cell, "story").ok_or_else(|| {
                malformed_table(
                    parent_story,
                    story_index,
                    format!("row {row_index} cell {cell_index} is missing story"),
                )
            })?;
            let (mut blocks, content_size) = lower_story(
                txn,
                &cell_story,
                env,
                cell_pm_start + 1,
                active_stories,
                list_state,
                CellEdges {
                    before: true,
                    after: true,
                },
                map,
                opaque_sequences,
                revealable,
                local,
            )?;

            for block in &mut blocks {
                if let LayoutBlock::Paragraph(paragraph) = block
                    && let Some(attrs) = &mut paragraph.attrs
                {
                    if env.compatibility_flags.allow_space_of_same_style_in_table {
                        attrs.contextual_spacing = Some(false);
                    }
                    if !env.compatibility_flags.adjust_line_height_in_table {
                        attrs.snap_to_grid = Some(false);
                    }
                }
            }
            while column_row_ends
                .get(column)
                .is_some_and(|end| *end > row_index)
            {
                column += 1;
            }
            let col_span = map_number(tc_pr, "colspan");
            let row_span = map_number(tc_pr, "rowspan");
            let colspan = col_span.unwrap_or(1.0) as usize;
            let width_type = map_string(tc_pr, "widthType");
            let width_value = map_number(tc_pr, "width");
            let authored_width = tc_pr
                .get("_originalFormatting")
                .and_then(any_map)
                .and_then(|value| value.get("width"));
            let synthesized_width = original.is_some()
                && authored_width.is_none()
                && width_type.as_deref() == Some("pct")
                && width_value.is_some()
                && width_value
                    == synthesized_cell_width(&grid_widths, total_grid_width, column, colspan);
            let width_value =
                width_value.filter(|_| width_type.as_deref() != Some("auto") && !synthesized_width);
            let width =
                width_value.filter(|value| *value != 0.0).and_then(|value| {
                    match width_type.as_deref() {
                        None | Some("dxa") => Some(twips_to_pixels(value)),
                        _ => None,
                    }
                });
            let background = map_string(tc_pr, "backgroundColor").map(|value| format!("#{value}"));
            for block in &mut blocks {
                if let LayoutBlock::Paragraph(paragraph) = block {
                    resolve_paragraph_auto_text_color(paragraph, background.as_deref(), None);
                }
            }
            cells.push(TableCell {
                text_direction: map_string(tc_pr, "textDirection"),
                id: BlockId::Str(cell_story),
                blocks,
                col_span,
                row_span,
                width,
                width_value,
                preferred_width: width_value.map(|value| docx_layout::types::PreferredWidth {
                    value: Some(value),
                    r#type: width_type.clone(),
                }),
                width_type,
                grid_start: None,
                min_content_width: None,
                max_content_width: None,
                vertical_align: map_string(tc_pr, "verticalAlign"),
                background,
                borders: lower_cell_borders(tc_pr, env),
                padding: Some(lower_cell_padding(tc_pr, table_margins)),
                no_wrap: (map_bool(tc_pr, "noWrap") == Some(true)).then_some(true),
                tracked_marker: tc_pr.get("cellMarker").and_then(any_json),
            });
            for end in column_row_ends.iter_mut().skip(column).take(colspan) {
                *end = row_index.saturating_add(row_span.unwrap_or(1.0) as usize);
            }
            column = column.saturating_add(colspan);
            cell_pm_start += content_size + 2;
        }

        let row_node_size = cell_pm_start + 1 - row_pm_start;
        let original = tr_pr.get("_originalFormatting").and_then(any_map);
        rows.push(TableRow {
            id: BlockId::Str(format!("{table_id}:r{row_index}")),
            cells,
            height: map_number(tr_pr, "height")
                .filter(|value| *value != 0.0)
                .map(twips_to_pixels),
            height_rule: map_string(tr_pr, "heightRule"),
            is_header: map_bool(tr_pr, "isHeader"),
            cant_split: original
                .and_then(|value| map_bool(value, "cantSplit"))
                .filter(|value| *value),
            grid_before: None,
            grid_after: None,
            width_before: None,
            width_after: None,
            tracked_ins: tr_pr
                .get("trIns")
                .and_then(|value| paragraph_revision_value(value, env)),
            tracked_del: tr_pr
                .get("trDel")
                .and_then(|value| paragraph_revision_value(value, env)),
        });
        row_pm_start += row_node_size;
    }

    let node_size = row_pm_start + 1 - pm_start;
    let column_widths: Vec<f64> = grid_widths
        .iter()
        .flatten()
        .map(|width| twips_to_pixels(*width))
        .collect();
    let indent = original
        .and_then(|value| value.get("indent"))
        .and_then(any_map)
        .filter(|value| map_string(value, "type").as_deref() == Some("dxa"))
        .and_then(|value| map_number(value, "value"))
        .filter(|value| *value != 0.0)
        .map(twips_to_pixels);
    let floating = tbl_pr
        .get("floating")
        .and_then(any_map)
        .map(lower_floating_table);
    let compatibility_mode = map_number(tbl_pr, "compatibilityMode").and_then(|value| {
        (value.is_finite() && (0.0..=255.0).contains(&value)).then_some(value as u8)
    });
    let layout_mode = map_string(tbl_pr, "tableLayout")
        .filter(|value| matches!(value.as_str(), "fixed" | "autofit"));
    let table_margin = |side: &str| {
        table_margins
            .and_then(|margins| map_number(margins, side))
            .map(twips_to_pixels)
            .filter(|value| value.is_finite() && *value > 0.0)
    };

    Ok((
        TableBlock {
            sdt_groups: None,
            id: BlockId::Str(table_id),
            rows,
            column_widths: (!column_widths.is_empty()).then_some(column_widths),
            grid_widths: None,
            width: map_number(tbl_pr, "width"),
            width_type: map_string(tbl_pr, "widthType"),
            preferred_width: None,
            layout_mode: None,
            table_layout: Some(layout_mode.unwrap_or_else(|| "autofit".to_owned())),
            width_algorithm: None,
            style_cascade: None,
            background: None,
            justification: map_string(tbl_pr, "justification"),
            bidi: (map_bool(tbl_pr, "bidi") == Some(true)).then_some(true),
            indent,
            floating,
            compatibility_mode,
            cell_margin_left: table_margin("left"),
            cell_margin_right: table_margin("right"),
            gridlines: env.show_table_gridlines.then_some(true),
            pm_start: Some(pm_start as f64),
            pm_end: Some((pm_start + node_size) as f64),
        },
        node_size,
    ))
}

fn resolve_paragraph_auto_text_color(
    paragraph: &mut ParagraphBlock,
    cell_background: Option<&str>,
    shape_background: Option<&str>,
) {
    let paragraph_background = paragraph
        .attrs
        .as_ref()
        .and_then(|attrs| attrs.shading.as_deref());
    for run in &mut paragraph.runs {
        let formatting = match run {
            Run::Text(run) => &mut run.fmt,
            Run::Tab(run) => &mut run.fmt,
            Run::Field(run) => &mut run.fmt,
            _ => continue,
        };
        resolve_auto_text_color(
            formatting,
            paragraph_background,
            cell_background,
            shape_background,
        );
    }
}

fn resolve_auto_text_color(
    formatting: &mut RunFormatting,
    paragraph_background: Option<&str>,
    cell_background: Option<&str>,
    shape_background: Option<&str>,
) {
    let background = formatting
        .highlight
        .as_deref()
        .or(paragraph_background)
        .or(cell_background)
        .or(shape_background);
    if let Some(background) = background {
        formatting.color.get_or_insert_with(|| {
            if automatic_text_needs_white(background) {
                "#FFFFFF".to_owned()
            } else {
                "#000000".to_owned()
            }
        });
    }
}

fn automatic_text_needs_white(color: &str) -> bool {
    let Some(value) = color
        .strip_prefix('#')
        .filter(|value| value.len() == 6)
        .and_then(|value| u32::from_str_radix(value, 16).ok())
    else {
        return false;
    };
    let linearize = |channel: u32| {
        let channel = f64::from(channel) / 255.0;
        if channel <= 0.04045 {
            channel / 12.92
        } else {
            ((channel + 0.055) / 1.055).powf(2.4)
        }
    };
    let red = linearize((value >> 16) & 255);
    let green = linearize((value >> 8) & 255);
    let blue = linearize(value & 255);
    let luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
    // Choose the higher WCAG contrast: Word uses white on 007AA8, black on EE0000 and 009A96.
    // Relative luminances between 0.167 and 0.182 are unobserved.
    luminance < 0.1791
}

fn any_json(value: &Any) -> Option<Value> {
    let value: Value = serde_json::to_string(value)
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())?;
    (!value.is_null()).then_some(value)
}

fn shared_values<T: ReadTxn>(map: &MapRef, txn: &T) -> std::collections::HashMap<String, Any> {
    map.iter(txn)
        .filter_map(|(key, value)| match value {
            Out::Any(value) => Some((key.to_string(), value)),
            _ => None,
        })
        .collect()
}

fn attrs_from_any(value: Option<&Any>) -> Attrs {
    value
        .and_then(any_map)
        .into_iter()
        .flat_map(|map| map.iter())
        .map(|(key, value)| (Arc::<str>::from(key.as_str()), value.clone()))
        .collect()
}

fn constrain_to_page(width: f64, height: f64, env: &RenderEnv) -> (f64, f64) {
    let Some(limit) = env.page_content_height.filter(|limit| *limit > 0.0) else {
        return (width, height);
    };
    if height <= limit {
        return (width, height);
    }
    ((width * (limit / height)).round(), limit)
}

fn image_transform_metrics(
    width: f64,
    height: f64,
    transform: Option<&str>,
) -> (Option<f64>, Option<bool>, Option<bool>, Option<Value>) {
    let rotation = transform
        .and_then(|value| value.split_once("rotate("))
        .and_then(|(_, tail)| tail.split_once("deg)"))
        .and_then(|(value, _)| value.trim().parse::<f64>().ok())
        .filter(|value| value.is_finite())
        .unwrap_or(0.0)
        .rem_euclid(360.0);
    let radians = rotation.to_radians();
    let bounds_width = width * radians.cos().abs() + height * radians.sin().abs();
    let bounds_height = width * radians.sin().abs() + height * radians.cos().abs();
    let bounds = (rotation != 0.0).then(|| {
        serde_json::json!({
            "width": bounds_width,
            "height": bounds_height,
            "offsetX": (bounds_width - width) / 2.0,
            "offsetY": (bounds_height - height) / 2.0,
        })
    });
    (
        (rotation != 0.0).then_some(rotation),
        transform
            .is_some_and(|value| value.contains("scaleX(-1)"))
            .then_some(true),
        transform
            .is_some_and(|value| value.contains("scaleY(-1)"))
            .then_some(true),
        bounds,
    )
}

fn image_outline(
    values: &std::collections::HashMap<String, Any>,
    env: &RenderEnv,
) -> Option<CellBorderSpec> {
    let color = values
        .get("borderColorValue")
        .and_then(any_json)
        .and_then(|value| serde_json::from_value::<ColorValue>(value).ok())
        .and_then(|mut color| {
            color.rgb = color.rgb.take().or_else(|| {
                color
                    .theme_color
                    .as_deref()
                    .and_then(|slot| theme_color(slot, env))
            });
            color.theme_color = None;
            resolve_color_value_to_hex(Some(&color))
        })
        .or_else(|| {
            map_string(values, "borderColor")
                .map(|color| css_hex(&color))
                .filter(|hex| {
                    hex.len() == 7 && hex[1..].bytes().all(|byte| byte.is_ascii_hexdigit())
                })
        })?;
    Some(CellBorderSpec {
        width: Some(map_number(values, "borderWidth").unwrap_or(1.0)),
        color: Some(color),
        style: Some(
            match map_string(values, "borderStyle").as_deref() {
                Some(style @ ("dotted" | "dashed")) => style,
                _ => "solid",
            }
            .to_owned(),
        ),
        ooxml_style: None,
    })
}

fn lower_image_values(
    values: &std::collections::HashMap<String, Any>,
    formatting: &RunFormatting,
    env: &RenderEnv,
) -> ImageRun {
    let (width, height) = constrain_to_page(
        map_number(values, "width")
            .filter(|value| *value != 0.0)
            .unwrap_or(100.0),
        map_number(values, "height")
            .filter(|value| *value != 0.0)
            .unwrap_or(100.0),
        env,
    );
    let transform = map_string(values, "transform");
    let (rotation_deg, flip_h, flip_v, rotation_bounds) =
        image_transform_metrics(width, height, transform.as_deref());
    let position = values
        .get("position")
        .and_then(any_json)
        .and_then(|mut value| {
            if let Some(position) = value.as_object_mut()
                && let Some(height) = position.remove("relativeHeight")
                && let Some(height) = height.as_f64().filter(|height| {
                    height.is_finite()
                        && *height >= 0.0
                        && *height <= u32::MAX as f64
                        && height.fract() == 0.0
                })
            {
                position.insert(
                    "relativeHeight".to_owned(),
                    serde_json::json!(height as u64),
                );
            }
            serde_json::to_string(&value)
                .ok()
                .and_then(|s| serde_json::from_str::<ImageRunPosition>(&s).ok())
        });

    ImageRun {
        src: match values.get("src") {
            Some(Any::String(src)) => env.media.token(src).unwrap_or_else(|| src.to_string()),
            value => value_string(value).unwrap_or_default(),
        },
        width,
        height,
        alt: map_string(values, "alt"),
        transform,
        position,
        wrap_type: map_string(values, "wrapType"),
        display_mode: map_string(values, "displayMode"),
        css_float: map_string(values, "cssFloat"),
        dist_top: map_number(values, "distTop"),
        dist_bottom: map_number(values, "distBottom"),
        dist_left: map_number(values, "distLeft"),
        dist_right: map_number(values, "distRight"),
        crop_top: map_number(values, "cropTop"),
        crop_right: map_number(values, "cropRight"),
        crop_bottom: map_number(values, "cropBottom"),
        crop_left: map_number(values, "cropLeft"),
        shape_type: map_string(values, "shapeType"),
        opacity: map_number(values, "opacity"),
        rotation_deg,
        flip_h,
        flip_v,
        rotation_bounds,
        wrap_text: None,
        wrap_polygon: None,
        allow_overlap: None,
        layout_in_cell: None,
        no_change_aspect: map_bool(values, "noChangeAspect"),
        effect_extent: None,
        effects: None,
        outline: image_outline(values, env),
        decorative: None,
        hyperlink: None,
        inline_shape: None,
        inline_chart: None,
        horizontal_rule: map_bool(values, "horizontalRule").filter(|rule| *rule),
        is_insertion: formatting.is_insertion,
        is_deletion: formatting.is_deletion,
        change_author: formatting.change_author.clone(),
        change_date: formatting.change_date.clone(),
        change_revision_id: formatting.change_revision_id,
        pm_start: None,
        pm_end: None,
    }
}

fn lower_image_run<T: ReadTxn>(
    image: &MapRef,
    txn: &T,
    formatting: &RunFormatting,
    env: &RenderEnv,
) -> ImageRun {
    lower_image_values(&shared_values(image, txn), formatting, env)
}

fn preset_geometry(shape_type: &str) -> Option<Vec<Value>> {
    let command = |value: Value| value;
    let close = || serde_json::json!({ "type": "close" });
    Some(match shape_type {
        "rect" | "textBox" => vec![
            command(serde_json::json!({"type":"move","x":0,"y":0})),
            command(serde_json::json!({"type":"line","x":1,"y":0})),
            command(serde_json::json!({"type":"line","x":1,"y":1})),
            command(serde_json::json!({"type":"line","x":0,"y":1})),
            close(),
        ],
        "roundRect" => {
            let r = 1.0 / 6.0;
            vec![
                serde_json::json!({"type":"move","x":r,"y":0}),
                serde_json::json!({"type":"line","x":1.0-r,"y":0}),
                serde_json::json!({"type":"quad","cpx":1,"cpy":0,"x":1,"y":r}),
                serde_json::json!({"type":"line","x":1,"y":1.0-r}),
                serde_json::json!({"type":"quad","cpx":1,"cpy":1,"x":1.0-r,"y":1}),
                serde_json::json!({"type":"line","x":r,"y":1}),
                serde_json::json!({"type":"quad","cpx":0,"cpy":1,"x":0,"y":1.0-r}),
                serde_json::json!({"type":"line","x":0,"y":r}),
                serde_json::json!({"type":"quad","cpx":0,"cpy":0,"x":r,"y":0}),
                close(),
            ]
        }
        "ellipse" => {
            let k = 0.552_284_749_830_793_6 / 2.0;
            vec![
                serde_json::json!({"type":"move","x":1,"y":0.5}),
                serde_json::json!({"type":"cubic","cp1x":1,"cp1y":0.5+k,"cp2x":0.5+k,"cp2y":1,"x":0.5,"y":1}),
                serde_json::json!({"type":"cubic","cp1x":0.5-k,"cp1y":1,"cp2x":0,"cp2y":0.5+k,"x":0,"y":0.5}),
                serde_json::json!({"type":"cubic","cp1x":0,"cp1y":0.5-k,"cp2x":0.5-k,"cp2y":0,"x":0.5,"y":0}),
                serde_json::json!({"type":"cubic","cp1x":0.5+k,"cp1y":0,"cp2x":1,"cp2y":0.5-k,"x":1,"y":0.5}),
                close(),
            ]
        }
        "line" | "straightConnector1" => vec![
            serde_json::json!({"type":"move","x":0,"y":0}),
            serde_json::json!({"type":"line","x":1,"y":1}),
        ],
        "triangle" | "isosTriangle" => vec![
            serde_json::json!({"type":"move","x":0.5,"y":0}),
            serde_json::json!({"type":"line","x":1,"y":1}),
            serde_json::json!({"type":"line","x":0,"y":1}),
            close(),
        ],
        _ => return None,
    })
}

fn shape_fill(values: &std::collections::HashMap<String, Any>) -> Option<Value> {
    let fill_type = map_string(values, "fillType").unwrap_or_else(|| "solid".to_owned());
    let color = map_string(values, "fillColor");
    let mut fill = JsonMap::new();
    fill.insert("type".to_owned(), Value::String(fill_type.clone()));
    if let Some(color) = color {
        fill.insert("color".to_owned(), Value::String(color));
    }
    if fill_type == "gradient" {
        if let Some(value) = map_string(values, "gradientType") {
            fill.insert("gradientType".to_owned(), Value::String(value));
        }
        if let Some(value) = map_number(values, "gradientAngle") {
            fill.insert("gradientAngle".to_owned(), Value::from(value));
        }
        if let Some(stops) = map_string(values, "gradientStops")
            .and_then(|value| serde_json::from_str::<Value>(&value).ok())
            .filter(Value::is_array)
        {
            fill.insert("gradientStops".to_owned(), stops);
        }
    }
    Some(Value::Object(fill))
}

fn shape_stroke(values: &std::collections::HashMap<String, Any>) -> Option<Value> {
    let width = map_number(values, "outlineWidth");
    let color = map_string(values, "outlineColor");
    let dash = map_string(values, "outlineStyle");
    if width.is_none() && color.is_none() && dash.is_none() {
        return None;
    }
    let mut stroke = JsonMap::new();
    if let Some(value) = color {
        stroke.insert("color".to_owned(), Value::String(value));
    }
    if let Some(value) = width {
        stroke.insert("width".to_owned(), Value::from(value));
    }
    if let Some(value) = dash {
        stroke.insert("dash".to_owned(), Value::String(value));
    }
    Some(Value::Object(stroke))
}

fn shape_transform(values: &std::collections::HashMap<String, Any>) -> Option<Value> {
    let rotation = map_number(values, "rotation").or_else(|| {
        map_string(values, "transform")
            .as_deref()
            .and_then(|value| image_transform_metrics(1.0, 1.0, Some(value)).0)
    });
    let flip_h = map_bool(values, "flipH") == Some(true)
        || map_string(values, "transform").is_some_and(|value| value.contains("scaleX(-1)"));
    let flip_v = map_bool(values, "flipV") == Some(true)
        || map_string(values, "transform").is_some_and(|value| value.contains("scaleY(-1)"));
    if rotation.is_none() && !flip_h && !flip_v {
        return None;
    }
    let mut transform = JsonMap::new();
    if let Some(value) = rotation {
        transform.insert("rotation".to_owned(), Value::from(value));
    }
    if flip_h {
        transform.insert("flipH".to_owned(), Value::Bool(true));
    }
    if flip_v {
        transform.insert("flipV".to_owned(), Value::Bool(true));
    }
    Some(Value::Object(transform))
}

fn lower_shape_block<T: ReadTxn>(
    shape: &MapRef,
    txn: &T,
    pm_start: u64,
    env: &RenderEnv,
    story_id: &str,
) -> Option<ShapeBlock> {
    let values = shared_values(shape, txn);
    if let Some(block) = values
        .get("shapeJson")
        .and_then(|value| match value {
            Any::String(source) => Some(env.media.tokenized_json(source)),
            _ => None,
        })
        .and_then(|value| serde_json::from_str::<Value>(&value).ok())
        .and_then(|value| {
            let projected =
                group_pictures::project(&value, story_id, &env.group_pictures, env.media_tokens);
            let rendered = projected.unwrap_or_else(|| group_pictures::raw_projection(&value));
            shapes::lower_shape_json(&rendered, pm_start, env)
        })
    {
        return Some(block);
    }
    let shape_type = map_string(&values, "shapeType").unwrap_or_else(|| "rect".to_owned());
    let geometry_path = values
        .get("geometryPath")
        .and_then(any_json)
        .and_then(|value| value.as_array().cloned())
        .filter(|value| !value.is_empty())
        .or_else(|| preset_geometry(&shape_type))?;
    let (width, height) = constrain_to_page(
        map_number(&values, "width")
            .filter(|value| *value != 0.0)
            .unwrap_or(100.0),
        map_number(&values, "height")
            .filter(|value| *value != 0.0)
            .unwrap_or(80.0),
        env,
    );
    Some(ShapeBlock {
        sdt_groups: None,
        id: BlockId::Str(format!("shape:{pm_start}")),
        shape_type,
        geometry_path,
        fill: shape_fill(&values),
        stroke: shape_stroke(&values),
        transform: shape_transform(&values),
        width,
        height,
        x: None,
        y: None,
        inner_text: None,
        nested_sequences: Vec::new(),
        inner_measures: None,
        children: Vec::new(),
        scene: None,
        effects: None,
        text_body_properties: None,
        wrap_distances: None,
        position: None,
        wrap_type: None,
        wrap_text: None,
        relative_height: None,
        behind_doc: None,
        decorative: None,
        title: None,
        description: None,
        doc_start: Some(pm_start as f64),
        doc_end: Some((pm_start + 1) as f64),
        pm_start: Some(pm_start as f64),
        pm_end: Some((pm_start + 1) as f64),
    })
}

fn lower_chart_block(
    values: &std::collections::HashMap<String, Any>,
    pm_start: Option<u64>,
    env: &RenderEnv,
) -> Option<ChartBlock> {
    let chart = map_string(values, "chartJson")
        .and_then(|value| serde_json::from_str::<Value>(&value).ok())?;
    let (width, height) = constrain_to_page(
        map_number(values, "width")
            .filter(|value| *value != 0.0)
            .unwrap_or(320.0),
        map_number(values, "height")
            .filter(|value| *value != 0.0)
            .unwrap_or(220.0),
        env,
    );
    Some(ChartBlock {
        sdt_groups: None,
        id: BlockId::Str(
            pm_start
                .map(|start| format!("chart:{start}"))
                .unwrap_or_else(|| "chart:inline".to_owned()),
        ),
        chart,
        width,
        height,
        position: None,
        wrap_type: None,
        wrap_text: None,
        relative_height: None,
        behind_doc: None,
        doc_start: pm_start.map(|start| start as f64),
        doc_end: pm_start.map(|start| (start + 1) as f64),
        pm_start: pm_start.map(|start| start as f64),
        pm_end: pm_start.map(|start| (start + 1) as f64),
    })
}

fn repeating_sdt_item(raw: Option<&str>) -> Option<bool> {
    let raw = raw?;
    let marker = "<w15:repeatingSectionItem";
    let tail = raw.split_once(marker)?.1;
    tail.chars()
        .next()
        .is_some_and(|ch| ch.is_whitespace() || ch == '/' || ch == '>')
        .then_some(true)
}

fn sdt_group_from_values(values: &std::collections::HashMap<String, Any>, pos: i64) -> SdtGroup {
    SdtGroup {
        id: format!("sdt@{pos}"),
        sdt_type: map_string(values, "sdtType").unwrap_or_else(|| "richText".to_owned()),
        tag: map_string(values, "tag"),
        alias: map_string(values, "alias"),
        lock: map_string(values, "lock"),
        checked: authored_checkbox_value(values).or_else(|| map_bool(values, "checked")),
        bound: values.get("dataBinding").map(|_| true),
        repeating_item: repeating_sdt_item(map_string(values, "rawPropertiesXml").as_deref()),
        control_id: map_number(values, "id").map(|value| value as i64),
        pos: None,
        control_state: None,
        properties: None,
    }
}

fn lower_sdt_group<T: ReadTxn>(sdt: &MapRef, txn: &T, pos: i64) -> SdtGroup {
    sdt_group_from_values(&shared_values(sdt, txn), pos)
}

fn stamp_sdt_group(blocks: &mut [LayoutBlock], group: SdtGroup) {
    for block in blocks {
        let groups = match block {
            LayoutBlock::Paragraph(block) => &mut block.sdt_groups,
            LayoutBlock::Table(block) => &mut block.sdt_groups,
            LayoutBlock::Image(block) => &mut block.sdt_groups,
            LayoutBlock::Shape(block) => &mut block.sdt_groups,
            LayoutBlock::Chart(block) => &mut block.sdt_groups,
            LayoutBlock::TextBox(block) => &mut block.sdt_groups,
            LayoutBlock::SectionBreak(block) => &mut block.sdt_groups,
            LayoutBlock::PageBreak(block) => &mut block.sdt_groups,
            LayoutBlock::ColumnBreak(block) => &mut block.sdt_groups,
            LayoutBlock::Reserved(_) | LayoutBlock::Unsupported => continue,
        };
        groups.get_or_insert_with(Vec::new).insert(0, group.clone());
    }
}

fn inline_checkbox_widget(
    values: &std::collections::HashMap<String, Any>,
    pos: i64,
) -> Option<Value> {
    if map_string(values, "sdtType").as_deref() != Some("checkbox") {
        return None;
    }
    if matches!(
        map_string(values, "lock").as_deref(),
        Some("contentLocked" | "sdtContentLocked")
    ) || values.contains_key("dataBinding")
    {
        return None;
    }
    let mut widget = JsonMap::from_iter([
        ("kind".to_owned(), Value::String("checkbox".to_owned())),
        ("groupId".to_owned(), Value::String(format!("sdt@{pos}"))),
        ("pos".to_owned(), Value::from(pos)),
    ]);
    if let Some(value) = map_string(values, "tag") {
        widget.insert("tag".to_owned(), Value::String(value));
    }
    if let Some(value) = map_string(values, "alias") {
        widget.insert("alias".to_owned(), Value::String(value));
    }
    if let Some(value) = map_number(values, "id") {
        widget.insert("controlId".to_owned(), Value::from(value as i64));
    }
    if let Some(value) = authored_checkbox_value(values).or_else(|| map_bool(values, "checked")) {
        widget.insert("checked".to_owned(), Value::Bool(value));
    }
    Some(Value::Object(widget))
}

fn authored_checkbox_value(values: &std::collections::HashMap<String, Any>) -> Option<bool> {
    let value = values.get("value").and_then(any_map)?;
    (map_string(value, "kind").as_deref() == Some("checkbox"))
        .then(|| map_bool(value, "checked"))
        .flatten()
}

fn inherit_inline_revision(runs: &mut [RawRun], attrs: Option<&Attrs>, env: &RenderEnv) {
    if !attrs.is_some_and(|attrs| attrs.contains_key(crate::INS) || attrs.contains_key(crate::DEL))
    {
        return;
    }
    let inherited = lower_run_formatting(attrs, env);
    if inherited.change_revision_id.is_none() {
        return;
    }
    for run in runs {
        if run.formatting.change_revision_id.is_none() {
            run.formatting.is_insertion = inherited.is_insertion;
            run.formatting.is_deletion = inherited.is_deletion;
            run.formatting.change_revision_id = inherited.change_revision_id;
            run.formatting.change_author = inherited.change_author.clone();
            run.formatting.change_date = inherited.change_date.clone();
            if let RawRunKind::Image(image) = &mut run.kind {
                image.is_insertion = inherited.is_insertion;
                image.is_deletion = inherited.is_deletion;
                image.change_revision_id = inherited.change_revision_id;
                image.change_author = inherited.change_author.clone();
                image.change_date = inherited.change_date.clone();
            }
        }
    }
}

/// Display units of an inline control whose payload holds `content`: its content and its two
/// boundaries.
pub(crate) fn inline_sdt_size(content: Option<&Any>) -> u32 {
    match content {
        Some(Any::Array(content)) => {
            content
                .iter()
                .filter_map(any_map)
                .map(inline_sdt_child_size)
                .sum::<u32>()
                + 2
        }
        _ => 2,
    }
}

/// Display units of one content item of an inline control. A shape or chart nested in it
/// produces no run, and every other leaf still occupies one position even without one.
fn inline_sdt_child_size(child: &std::collections::HashMap<String, Any>) -> u32 {
    match child.get("kind").and_then(any_str) {
        Some("text") => utf16_len(child.get("text").and_then(any_str).unwrap_or_default()),
        Some("sdt") => child
            .get("payload")
            .and_then(any_map)
            .map_or(2, |payload| inline_sdt_size(payload.get("content"))),
        _ => 1,
    }
}

#[allow(clippy::too_many_arguments)]
fn lower_inline_sdt<T: ReadTxn>(
    sdt: &MapRef,
    txn: &T,
    env: &RenderEnv,
    story_index: u32,
    paragraph_pm_start: u64,
    node_pm_start: u32,
    inherited_widget: Option<Value>,
    runs: &mut Vec<RawRun>,
) -> u32 {
    let values = shared_values(sdt, txn);
    lower_inline_sdt_values(
        &values,
        env,
        story_index,
        paragraph_pm_start,
        node_pm_start,
        inherited_widget,
        runs,
    );
    inline_sdt_size(values.get("content"))
}

#[allow(clippy::too_many_arguments)]
fn lower_inline_sdt_values(
    values: &std::collections::HashMap<String, Any>,
    env: &RenderEnv,
    story_index: u32,
    paragraph_pm_start: u64,
    node_pm_start: u32,
    inherited_widget: Option<Value>,
    runs: &mut Vec<RawRun>,
) {
    let absolute_pos = paragraph_pm_start + 1 + u64::from(node_pm_start);
    let widget = inline_checkbox_widget(values, absolute_pos as i64).or(inherited_widget);
    let mut content_size = 0_u32;
    let Some(Any::Array(content)) = values.get("content") else {
        return;
    };

    for child in content.iter() {
        let Some(child) = any_map(child) else {
            continue;
        };
        let kind = map_string(child, "kind").unwrap_or_default();
        let attrs = attrs_from_any(child.get("attrs"));
        let formatting = lower_run_formatting(Some(&attrs), env);
        let child_pm_start = node_pm_start + 1 + content_size;
        let payload = child.get("payload").and_then(any_map);
        let child_size = inline_sdt_child_size(child);
        match kind.as_str() {
            "text" => {
                let text = map_string(child, "text").unwrap_or_default();
                if child_size > 0 {
                    runs.push(RawRun {
                        kind: RawRunKind::Text(text),
                        formatting,
                        story_start: story_index,
                        story_end: story_index + 1,
                        pm_start: child_pm_start,
                        pm_end: child_pm_start + child_size,
                        inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                        inline_sdt_widget: widget.clone(),
                        atom: true,
                        revision_hidden: env.revision_hidden(Some(&attrs)),
                    });
                }
            }
            "tab" => {
                runs.push(RawRun {
                    kind: RawRunKind::Tab,
                    formatting,
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: child_pm_start,
                    pm_end: child_pm_start + 1,
                    inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(Some(&attrs)),
                });
            }
            "break" => {
                runs.push(RawRun {
                    kind: RawRunKind::LineBreak,
                    formatting,
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: child_pm_start,
                    pm_end: child_pm_start + 1,
                    inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(Some(&attrs)),
                });
            }
            "image" | "opaqueDrawing" => {
                let images = if kind == "opaqueDrawing" {
                    payload.map(opaque_image_previews).unwrap_or_default()
                } else {
                    payload.into_iter().collect()
                };
                for payload in images {
                    runs.push(RawRun {
                        kind: RawRunKind::Image(lower_image_values(payload, &formatting, env)),
                        formatting: formatting.clone(),
                        story_start: story_index,
                        story_end: story_index + 1,
                        pm_start: child_pm_start,
                        pm_end: child_pm_start + 1,
                        inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                        inline_sdt_widget: None,
                        atom: true,
                        revision_hidden: env.revision_hidden(Some(&attrs)),
                    });
                }
            }
            "field" => {
                let field_type = payload
                    .and_then(|payload| map_string(payload, "fieldType"))
                    .unwrap_or_else(|| "OTHER".to_owned());
                let mapped_type = match field_type.as_str() {
                    "PAGE" | "NUMPAGES" | "DATE" | "TIME" => field_type.clone(),
                    _ => "OTHER".to_owned(),
                };
                let instruction = payload
                    .and_then(|payload| map_string(payload, "instruction"))
                    .filter(|value| !value.is_empty());
                let nested_sequences = lower_nested_sequences(
                    instruction.as_deref(),
                    payload.and_then(|payload| payload.get("resultProjection")),
                );
                runs.push(RawRun {
                    kind: RawRunKind::Field {
                        field_type: mapped_type.clone(),
                        raw_type: (field_type != mapped_type).then_some(field_type),
                        instruction,
                        fallback: Some(
                            payload
                                .and_then(|payload| map_string(payload, "displayText"))
                                .unwrap_or_default(),
                        ),
                        source: payload.and_then(|payload| map_string(payload, "fieldData")),
                        locked: payload
                            .and_then(|payload| map_bool(payload, "fldLock"))
                            .unwrap_or(false),
                        nested_sequences,
                    },
                    formatting,
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: child_pm_start,
                    pm_end: child_pm_start + 1,
                    inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(Some(&attrs)),
                });
            }
            "math" => {
                let text = payload
                    .and_then(|payload| map_string(payload, "plainText"))
                    .filter(|value| !value.is_empty())
                    .unwrap_or_else(|| "[equation]".to_owned());
                runs.push(RawRun {
                    kind: RawRunKind::Text(text),
                    formatting: RunFormatting {
                        italic: Some(true),
                        font_family: Some("Cambria Math".to_owned()),
                        logical_order: Some(u64::MAX),
                        is_insertion: formatting.is_insertion,
                        is_deletion: formatting.is_deletion,
                        change_revision_id: formatting.change_revision_id,
                        change_author: formatting.change_author,
                        change_date: formatting.change_date,
                        ..RunFormatting::default()
                    },
                    story_start: story_index,
                    story_end: story_index + 1,
                    pm_start: child_pm_start,
                    pm_end: child_pm_start + 1,
                    inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                    inline_sdt_widget: None,
                    atom: true,
                    revision_hidden: env.revision_hidden(Some(&attrs)),
                });
            }
            "noteRef" => {
                let footnote_id = payload
                    .and_then(|payload| payload.get("footnoteRefId"))
                    .and_then(|value| note_ref_id(value, env));
                let endnote_id = payload
                    .and_then(|payload| payload.get("endnoteRefId"))
                    .and_then(|value| note_ref_id(value, env));
                if let Some(id) = footnote_id.or(endnote_id) {
                    let mut formatting = formatting;
                    formatting.superscript = Some(true);
                    if footnote_id.is_some() {
                        formatting.footnote_ref_id = Some(id);
                    } else {
                        formatting.endnote_ref_id = Some(id);
                    }
                    runs.push(RawRun {
                        kind: RawRunKind::Text(note_ref_label(id)),
                        formatting,
                        story_start: story_index,
                        story_end: story_index + 1,
                        pm_start: child_pm_start,
                        pm_end: child_pm_start + 1,
                        inherited_hyperlink: inherited_hyperlink_style(Some(&attrs)),
                        inline_sdt_widget: widget.clone(),
                        atom: true,
                        revision_hidden: env.revision_hidden(Some(&attrs)),
                    });
                }
            }
            "sdt" => {
                if let Some(payload) = payload {
                    let first = runs.len();
                    lower_inline_sdt_values(
                        payload,
                        env,
                        story_index,
                        paragraph_pm_start,
                        child_pm_start,
                        widget.clone(),
                        runs,
                    );
                    inherit_inline_revision(&mut runs[first..], Some(&attrs), env);
                    if env.revision_hidden(Some(&attrs)) {
                        hide_runs(&mut runs[first..]);
                    }
                }
            }
            _ => {}
        }
        content_size += child_size;
    }
}

fn lower_floating_table(value: &std::collections::HashMap<String, Any>) -> FloatingTablePosition {
    let px = |key| map_number(value, key).map(twips_to_pixels);
    FloatingTablePosition {
        horz_anchor: map_string(value, "horzAnchor"),
        tblp_x: px("tblpX"),
        tblp_x_spec: map_string(value, "tblpXSpec"),
        vert_anchor: map_string(value, "vertAnchor"),
        tblp_y: px("tblpY"),
        tblp_y_spec: map_string(value, "tblpYSpec"),
        top_from_text: px("topFromText"),
        right_from_text: px("rightFromText"),
        bottom_from_text: px("bottomFromText"),
        left_from_text: px("leftFromText"),
    }
}

fn lower_cell_padding(
    tc_pr: &std::collections::HashMap<String, Any>,
    table_margins: Option<&std::collections::HashMap<String, Any>>,
) -> BoxEdges {
    let cell_margins = tc_pr.get("margins").and_then(any_map);
    let side = |key: &str| {
        cell_margins
            .and_then(|margins| map_number(margins, key))
            .map(twips_to_pixels)
            .filter(|value| *value >= 0.0)
            .or_else(|| {
                table_margins
                    .and_then(|margins| map_number(margins, key))
                    .map(twips_to_pixels)
                    .filter(|value| *value >= 0.0)
            })
            .unwrap_or(0.0)
    };
    BoxEdges {
        top: side("top"),
        right: side("right"),
        bottom: side("bottom"),
        left: side("left"),
    }
}

fn lower_cell_borders(
    tc_pr: &std::collections::HashMap<String, Any>,
    env: &RenderEnv,
) -> Option<CellBorders> {
    let borders = tc_pr.get("borders").and_then(any_map)?;
    let side = |key: &str| {
        borders
            .get(key)
            .and_then(any_map)
            .and_then(|border| lower_cell_border(border, env))
            .or_else(|| {
                Some(CellBorderSpec {
                    width: Some(0.0),
                    color: None,
                    style: Some("none".to_owned()),
                    ooxml_style: None,
                })
            })
    };
    Some(CellBorders {
        top: side("top"),
        right: side("right"),
        bottom: side("bottom"),
        left: side("left"),
    })
}

fn lower_cell_border(
    border: &std::collections::HashMap<String, Any>,
    env: &RenderEnv,
) -> Option<CellBorderSpec> {
    let style = map_string(border, "style")?;
    if matches!(style.as_str(), "none" | "nil") {
        return None;
    }
    let css_style = match style.as_str() {
        "double"
        | "triple"
        | "thinThickSmallGap"
        | "thickThinSmallGap"
        | "thinThickThinSmallGap"
        | "thinThickMediumGap"
        | "thickThinMediumGap"
        | "thinThickThinMediumGap"
        | "thinThickLargeGap"
        | "thickThinLargeGap"
        | "thinThickThinLargeGap"
        | "doubleWave" => "double",
        "dotted" | "dotDotDash" => "dotted",
        "dashed" | "dashSmallGap" | "dotDash" | "dashDotStroked" => "dashed",
        "threeDEmboss" => "ridge",
        "threeDEngrave" => "groove",
        "outset" => "outset",
        "inset" => "inset",
        _ => "solid",
    };
    let width = map_number(border, "size")
        .filter(|size| size.is_finite() && *size > 0.0)
        .map_or(1.0, |size| size / 6.0);
    let color = border
        .get("color")
        .and_then(|value| resolve_color(value, env))
        .unwrap_or_else(|| "#000000".to_owned());
    Some(CellBorderSpec {
        width: Some(width),
        color: Some(color),
        style: Some(css_style.to_owned()),
        ooxml_style: Some(style),
    })
}

#[derive(Clone, Debug)]
struct CommentInterval {
    start: u32,
    end: u32,
    id: f64,
}

#[derive(Clone, Debug)]
enum RawRunKind {
    Text(String),
    Tab,
    Image(ImageRun),
    HorizontalRule(HorizontalRule),
    LineBreak,
    Field {
        field_type: String,
        raw_type: Option<String>,
        instruction: Option<String>,
        fallback: Option<String>,
        source: Option<String>,
        locked: bool,
        nested_sequences: Vec<String>,
    },
    Reserved(docx_layout::types::ReservedRun),
}

/// One run before coalescing and before its position is made absolute.
#[derive(Clone, Debug)]
struct RawRun {
    kind: RawRunKind,
    formatting: RunFormatting,
    inherited_hyperlink: (bool, bool),
    /// Story-global UTF-16 bounds of the source content.
    story_start: u32,
    story_end: u32,
    /// Rendered bounds relative to the paragraph's content start, always the
    /// same width as the story bounds.
    pm_start: u32,
    pm_end: u32,
    /// Checkbox chrome inherited from the nearest editable inline SDT.
    inline_sdt_widget: Option<Value>,
    /// Content of an embed rather than story text.
    atom: bool,
    /// Content the previewed revision decisions leave out of layout.
    revision_hidden: bool,
}

impl RawRun {
    fn visible(&self, env: &RenderEnv) -> bool {
        !self.revision_hidden && (env.show_hidden_text || self.formatting.hidden != Some(true))
    }

    fn anchored(&self) -> bool {
        let RawRunKind::Image(image) = &self.kind else {
            return false;
        };
        image.display_mode.as_deref() == Some("float")
            || matches!(
                image.wrap_type.as_deref(),
                Some("square" | "tight" | "through" | "topAndBottom" | "behind" | "inFront")
            )
    }
}

/// Leaves out the content of a control whose own revision the preview hides.
fn hide_runs(runs: &mut [RawRun]) {
    for run in runs {
        run.revision_hidden = true;
    }
}

/// A paragraph's shape or chart child, at the offset it occupied.
#[derive(Clone, Debug)]
struct DrawingMarker {
    pm_offset: u32,
    story_index: u32,
    block: LayoutBlock,
    hidden: bool,
    revision_hidden: bool,
    anchored: bool,
}

impl DrawingMarker {
    fn visible(&self, env: &RenderEnv) -> bool {
        !self.revision_hidden && (env.show_hidden_text || !self.hidden)
    }
}

fn lift_drawings(
    drawings: Vec<DrawingMarker>,
    source: u32,
    paragraph_pm_start: u64,
    map: &mut preview::LoweringOutput,
) -> Vec<LayoutBlock> {
    drawings
        .into_iter()
        .map(|drawing| {
            let pm_start = paragraph_pm_start + 1 + u64::from(drawing.pm_offset);
            map.spans.push(SourceSpan {
                pm_start,
                pm_end: pm_start + 1,
                paragraph: source,
                raw_start: drawing.story_index,
                raw_end: drawing.story_index + 1,
                atom: true,
            });
            drawing.block
        })
        .collect()
}

/// Resolves every comment anchored in `story_id` to sorted, story-global
/// UTF-16 intervals with the numeric ids the layout contract carries. Anchors
/// in other stories are skipped and an empty range contributes nothing. An
/// anchor whose text this replica has not integrated yet contributes nothing
/// either: anchors are opaque bytes, so a comment can arrive before the text
/// it points at, and the next lowering picks it up once that text arrives.
fn resolve_comment_intervals<T: ReadTxn>(
    txn: &T,
    story_id: &str,
    env: &RenderEnv,
) -> Result<Vec<CommentInterval>, BridgeError> {
    let comments = txn
        .get_map(COMMENTS)
        .expect("comments root is declared by EditingDoc::new");
    let mut intervals = Vec::new();

    for (comment_id, value) in comments.iter(txn) {
        let Out::YMap(comment) = value else {
            continue;
        };
        let Some(Out::Any(Any::Array(anchors))) = comment.get(txn, "anchors") else {
            return Err(EditError::InvalidComment("anchors must be an array".into()).into());
        };
        for encoded in anchors.iter() {
            let anchor = decode_anchor(encoded)?;
            if anchor.story != story_id {
                continue;
            }
            let (Some(start), Some(end)) = (
                sticky_offset(&anchor.start, txn),
                sticky_offset(&anchor.end, txn),
            ) else {
                continue;
            };
            if start.index < end.index {
                intervals.push(CommentInterval {
                    start: start.index,
                    end: end.index,
                    id: numeric_id(comment_id, env),
                });
            }
        }
    }

    intervals.sort_by(|a, b| {
        a.start
            .cmp(&b.start)
            .then(a.end.cmp(&b.end))
            .then(a.id.total_cmp(&b.id))
    });
    Ok(intervals)
}

/// Splits one formatted text chunk into runs. Cuts land at every comment
/// interval boundary inside the chunk, so a run's comment set is uniform, and
/// around each tab, which becomes a run of its own.
fn push_text_chunks(
    runs: &mut Vec<RawRun>,
    text: &str,
    chunk_start: u32,
    attributes: Option<&Attrs>,
    comments: &[CommentInterval],
    env: &RenderEnv,
    chunk_pm_start: u32,
) {
    let chunk_end = chunk_start + utf16_len(text);
    let mut cuts = BTreeSet::from([chunk_start, chunk_end]);
    for interval in comments {
        if interval.start > chunk_start && interval.start < chunk_end {
            cuts.insert(interval.start);
        }
        if interval.end > chunk_start && interval.end < chunk_end {
            cuts.insert(interval.end);
        }
    }
    let mut offset = chunk_start;
    for ch in text.chars() {
        let next = offset + ch.len_utf16() as u32;
        if ch == '\t' || ch == '\u{000b}' {
            cuts.insert(offset);
            cuts.insert(next);
        }
        offset = next;
    }

    let cuts: Vec<u32> = cuts.into_iter().collect();
    for pair in cuts.windows(2) {
        let start = pair[0];
        let end = pair[1];
        if start == end {
            continue;
        }
        let value = utf16_slice(text, start - chunk_start, end - chunk_start);
        let kind = match value.as_str() {
            "\t" => RawRunKind::Tab,
            "\u{000b}" => RawRunKind::LineBreak,
            _ => RawRunKind::Text(value),
        };
        let mut formatting = lower_run_formatting(attributes, env);
        let mut comment_ids: Vec<f64> = comments
            .iter()
            .filter(|interval| interval.start <= start && end <= interval.end)
            .map(|interval| interval.id)
            .collect();
        comment_ids.sort_by(f64::total_cmp);
        comment_ids.dedup_by(|a, b| a.total_cmp(b).is_eq());
        if !comment_ids.is_empty() {
            formatting.comment_ids = Some(comment_ids);
        }
        runs.push(RawRun {
            kind,
            formatting,
            story_start: start,
            story_end: end,
            pm_start: chunk_pm_start + start - chunk_start,
            pm_end: chunk_pm_start + end - chunk_start,
            inherited_hyperlink: inherited_hyperlink_style(attributes),
            inline_sdt_widget: None,
            atom: false,
            revision_hidden: env.revision_hidden(attributes),
        });
    }
}

/// Drops the drawings the view hides, keeping the sequences a hidden shape holds opaque.
fn retain_visible_drawings(
    drawings: &mut Vec<DrawingMarker>,
    env: &RenderEnv,
    opaque_sequences: &mut BTreeSet<String>,
) {
    drawings.retain(|drawing| {
        if drawing.visible(env) {
            return true;
        }
        if !drawing.revision_hidden
            && let LayoutBlock::Shape(shape) = &drawing.block
        {
            collect_shape_sequences(shape, opaque_sequences);
        }
        false
    });
}

/// Keeps the sequences a field run holds opaque when the view leaves it out.
fn collect_run_sequences(run: &RawRun, opaque_sequences: &mut BTreeSet<String>) {
    if let RawRunKind::Field {
        instruction,
        nested_sequences,
        ..
    } = &run.kind
    {
        opaque_sequences.extend(
            instruction
                .as_deref()
                .and_then(docx_layout::sequence_fields::sequence_name),
        );
        opaque_sequences.extend(nested_sequences.iter().cloned());
    }
}

fn collect_shape_sequences(shape: &ShapeBlock, opaque_sequences: &mut BTreeSet<String>) {
    opaque_sequences.extend(shape.nested_sequences.iter().cloned());
    for run in shape
        .inner_text
        .iter()
        .flatten()
        .flat_map(|paragraph| &paragraph.runs)
    {
        if let Run::Field(field) = run {
            opaque_sequences.extend(
                field
                    .instruction
                    .as_deref()
                    .and_then(docx_layout::sequence_fields::sequence_name),
            );
            opaque_sequences.extend(field.nested_sequences.iter().cloned());
        }
    }
    for child in &shape.children {
        collect_shape_sequences(child, opaque_sequences);
    }
}

fn lower_nested_sequences(
    instruction: Option<&str>,
    result_projection: Option<&Any>,
) -> Vec<String> {
    result_projection
        .and(instruction)
        .and_then(docx_layout::sequence_fields::sequence_name)
        .into_iter()
        .collect()
}

/// Emits the blocks one paragraph contributes. Anchored children are lifted
/// out ahead of it and leave it whole; in-flow ones break it into the text
/// segments around them, each carrying the same pilcrow properties.
#[allow(clippy::too_many_arguments)]
fn flush_paragraph_parts<T: ReadTxn>(
    mut raw_runs: Vec<RawRun>,
    mut drawings: Vec<DrawingMarker>,
    pilcrow: &MapRef,
    pilcrow_attributes: Option<&Attrs>,
    txn: &T,
    story_id: &str,
    env: &RenderEnv,
    paragraph_pm_start: u64,
    paragraph_pm_units: u32,
    list_state: &mut ListState,
    (map, story_slot): (&mut preview::LoweringOutput, u32),
    opaque_sequences: &mut BTreeSet<String>,
    revealable: &mut Option<Vec<LayoutBlock>>,
    mut carried: Vec<(u32, Vec<RawRun>)>,
    hides_mark: bool,
) -> Vec<LayoutBlock> {
    let source = map.paragraph_count();
    map.paragraphs.push((
        story_slot,
        shared_map_string(pilcrow, txn, "paraId").unwrap_or_default(),
    ));
    retain_visible_drawings(&mut drawings, env, opaque_sequences);
    for runs in std::iter::once(&mut raw_runs).chain(carried.iter_mut().map(|(_, runs)| runs)) {
        runs.retain(|run| {
            if run.visible(env) {
                return true;
            }
            if !run.revision_hidden {
                collect_run_sequences(run, opaque_sequences);
            }
            false
        });
        if env.show_hidden_text {
            for run in runs.iter_mut() {
                if run.formatting.hidden == Some(true) {
                    run.formatting.hidden = None;
                }
            }
        }
    }
    for drawing in &drawings {
        let pm_start = paragraph_pm_start + 1 + u64::from(drawing.pm_offset);
        map.spans.push(SourceSpan {
            pm_start,
            pm_end: pm_start + 1,
            paragraph: source,
            raw_start: drawing.story_index,
            raw_end: drawing.story_index + 1,
            atom: true,
        });
    }
    let has_source_content = !drawings.is_empty();
    let (anchored, drawings): (Vec<_>, Vec<_>) =
        drawings.into_iter().partition(|drawing| drawing.anchored);
    let mut blocks: Vec<LayoutBlock> = anchored.into_iter().map(|drawing| drawing.block).collect();

    if drawings.is_empty() {
        let mut paragraph = flush_paragraph(
            raw_runs,
            pilcrow,
            pilcrow_attributes,
            txn,
            story_id,
            env,
            paragraph_pm_start,
            paragraph_pm_units,
            list_state,
            (map, source),
            carried,
        );
        if has_source_content || (paragraph.runs.is_empty() && paragraph_pm_units > 0) {
            paragraph
                .attrs
                .get_or_insert_with(Default::default)
                .has_source_content = Some(true);
        }
        if paragraph.runs.is_empty()
            && (hides_mark
                || (!env.show_hidden_text
                    && mark_bool(pilcrow_attributes, "hidden").or_else(|| {
                        shared_any(pilcrow, txn, "defaultTextFormatting")
                            .as_ref()
                            .and_then(any_map)
                            .and_then(|defaults| map_bool(defaults, "hidden"))
                    }) == Some(true)))
        {
            return blocks;
        }
        blocks.push(LayoutBlock::Paragraph(paragraph));
        return blocks;
    }

    let mut segment_start = 0_u32;
    let mut first_part = true;
    for drawing in drawings {
        let split_at = raw_runs.partition_point(|run| run.pm_end <= drawing.pm_offset);
        let remaining = raw_runs.split_off(split_at);
        let mut segment = std::mem::replace(&mut raw_runs, remaining);
        if !segment.is_empty() {
            for run in &mut segment {
                run.pm_start -= segment_start;
                run.pm_end -= segment_start;
            }
            blocks.push(LayoutBlock::Paragraph(split_part(
                flush_paragraph(
                    segment,
                    pilcrow,
                    pilcrow_attributes,
                    txn,
                    story_id,
                    env,
                    paragraph_pm_start + u64::from(segment_start),
                    drawing.pm_offset - segment_start,
                    list_state,
                    (map, source),
                    Vec::new(),
                ),
                segment_start,
                &mut first_part,
            )));
        }
        blocks.push(drawing.block);
        segment_start = drawing.pm_offset + 1;
    }

    if !raw_runs.is_empty() {
        for run in &mut raw_runs {
            run.pm_start -= segment_start;
            run.pm_end -= segment_start;
        }
        blocks.push(LayoutBlock::Paragraph(split_part(
            flush_paragraph(
                raw_runs,
                pilcrow,
                pilcrow_attributes,
                txn,
                story_id,
                env,
                paragraph_pm_start + u64::from(segment_start),
                paragraph_pm_units - segment_start,
                list_state,
                (map, source),
                Vec::new(),
            ),
            segment_start,
            &mut first_part,
        )));
    }
    if let Some(revealed) = revealable
        && !blocks
            .iter()
            .any(|block| matches!(block, LayoutBlock::Paragraph(_)))
    {
        // A preview that hides every drawing leaves the paragraph itself.
        revealed.push(LayoutBlock::Paragraph(flush_paragraph(
            Vec::new(),
            pilcrow,
            pilcrow_attributes,
            txn,
            story_id,
            env,
            paragraph_pm_start,
            0,
            &mut list_state.clone(),
            (&mut preview::LoweringOutput::default(), 0),
            Vec::new(),
        )));
    }
    for block in &mut blocks {
        if let LayoutBlock::Paragraph(paragraph) = block {
            paragraph
                .attrs
                .get_or_insert_with(Default::default)
                .has_source_content = Some(true);
        }
    }
    blocks
}

/// Each part of a paragraph split around a drawing paints from its own block,
/// so the parts after the first take their start offset into their id.
fn split_part(
    mut paragraph: ParagraphBlock,
    segment_start: u32,
    first_part: &mut bool,
) -> ParagraphBlock {
    if !std::mem::replace(first_part, false)
        && let BlockId::Str(id) = &mut paragraph.id
    {
        id.push_str(&format!(":part{segment_start}"));
    }
    paragraph
}

#[cfg(test)]
thread_local! {
    pub(crate) static PARAGRAPHS_FLUSHED: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[allow(clippy::too_many_arguments)]
fn flush_paragraph<T: ReadTxn>(
    mut raw_runs: Vec<RawRun>,
    pilcrow: &MapRef,
    pilcrow_attributes: Option<&Attrs>,
    txn: &T,
    story_id: &str,
    env: &RenderEnv,
    paragraph_pm_start: u64,
    paragraph_pm_units: u32,
    list_state: &mut ListState,
    (map, source): (&mut preview::LoweringOutput, u32),
    carried: Vec<(u32, Vec<RawRun>)>,
) -> ParagraphBlock {
    #[cfg(test)]
    PARAGRAPHS_FLUSHED.with(|flushed| flushed.set(flushed.get() + 1));
    let values = pilcrow_values(pilcrow, txn);
    let para_id = value_string(values.get("paraId")).unwrap_or_default();
    let generated_prefix = format!("{story_id}:p");
    let para_id_is_generated = para_id
        .strip_prefix(&generated_prefix)
        .is_some_and(|suffix| suffix.parse::<usize>().is_ok());
    let style_id = paragraph_style_id(&values);
    let defaults = paragraph_run_defaults(&values);
    let semantic_toc = style_id
        .as_ref()
        .is_some_and(|id| env.toc_style_ids.contains(id));

    for run in &mut raw_runs {
        apply_run_defaults(&mut run.formatting, &defaults);
        if semantic_toc || style_id.as_deref().is_some_and(is_toc_style) {
            strip_toc_hyperlink_style(&mut run.formatting, run.inherited_hyperlink);
        }
    }
    let raw_runs = coalesce_runs(raw_runs);
    map.paragraph_blocks.push((paragraph_pm_start, source));
    let carried: Vec<_> = carried
        .into_iter()
        .map(|(source, runs)| (source, coalesce_runs(runs)))
        .collect();
    for (raw, source) in carried
        .iter()
        .flat_map(|(source, runs)| runs.iter().map(|raw| (raw, *source)))
        .chain(raw_runs.iter().map(|raw| (raw, source)))
        .filter(|(raw, _)| !matches!(raw.kind, RawRunKind::Reserved(_)))
    {
        map.spans.push(SourceSpan {
            pm_start: paragraph_pm_start + 1 + u64::from(raw.pm_start),
            pm_end: paragraph_pm_start + 1 + u64::from(raw.pm_end),
            paragraph: source,
            raw_start: raw.story_start,
            raw_end: raw.story_end,
            atom: raw.atom,
        });
    }
    let raw_runs: Vec<RawRun> = carried
        .into_iter()
        .flat_map(|(_, runs)| runs)
        .chain(raw_runs)
        .collect();
    let mut attrs = lower_paragraph_attrs(&values, pilcrow_attributes, env, list_state);
    for raw in &raw_runs {
        if let RawRunKind::HorizontalRule(rule) = &raw.kind {
            let mut rule = rule.clone();
            rule.pm_start = (paragraph_pm_start + 1 + u64::from(raw.pm_start)) as f64;
            rule.pm_end = (paragraph_pm_start + 1 + u64::from(raw.pm_end)) as f64;
            attrs.horizontal_rules.push(rule);
        }
    }
    let mut runs: Vec<Run> = raw_runs
        .into_iter()
        .map(|raw| raw_run_to_layout(raw, paragraph_pm_start))
        .collect();
    stamp_logical_order(&mut runs);

    let mut paragraph = ParagraphBlock {
        sdt_groups: None,
        id: BlockId::Str(para_id.clone()),
        para_id: (!para_id.is_empty() && !para_id_is_generated).then_some(para_id),
        runs,
        attrs: Some(attrs),
        pm_start: Some(paragraph_pm_start as f64),
        pm_end: Some((paragraph_pm_start + u64::from(paragraph_pm_units) + 2) as f64),
    };
    resolve_paragraph_auto_text_color(&mut paragraph, None, None);
    paragraph
}

fn pilcrow_values<T: ReadTxn>(pilcrow: &MapRef, txn: &T) -> BTreeMap<String, Any> {
    pilcrow
        .iter(txn)
        .filter_map(|(key, value)| match value {
            Out::Any(value) => Some((key.to_string(), value)),
            _ => None,
        })
        .collect()
}

/// OOXML page-geometry defaults in twips — US Letter, one-inch margins,
/// half-inch column gap — used when a `sectPr` overrides only part of the
/// geometry.
const DEFAULT_PAGE_WIDTH_TWIPS: f64 = 12240.0;
const DEFAULT_PAGE_HEIGHT_TWIPS: f64 = 15840.0;
const DEFAULT_SECTION_MARGIN_TWIPS: f64 = 1440.0;
const DEFAULT_COLUMN_GAP_TWIPS: f64 = 720.0;

/// The running per-side margin cascade across section breaks, in twips. A
/// section that overrides ANY margin emits a full margins record; its unset
/// sides inherit from the prior section rather than resetting to the OOXML
/// default.
#[derive(Clone, Copy, Debug, PartialEq)]
struct SectionMarginsTwips {
    top: f64,
    bottom: f64,
    left: f64,
    right: f64,
}

impl Default for SectionMarginsTwips {
    fn default() -> Self {
        Self {
            top: DEFAULT_SECTION_MARGIN_TWIPS,
            bottom: DEFAULT_SECTION_MARGIN_TWIPS,
            left: DEFAULT_SECTION_MARGIN_TWIPS,
            right: DEFAULT_SECTION_MARGIN_TWIPS,
        }
    }
}

fn section_break_type(value: &str) -> Option<SectionBreakType> {
    match value {
        "continuous" => Some(SectionBreakType::Continuous),
        "nextPage" => Some(SectionBreakType::NextPage),
        "evenPage" => Some(SectionBreakType::EvenPage),
        "oddPage" => Some(SectionBreakType::OddPage),
        "nextColumn" => Some(SectionBreakType::NextColumn),
        _ => None,
    }
}

/// Lowers a boundary pilcrow's `sectPr` sub-map and `sectionBreakType` to the
/// [`SectionBreakBlock`] the layout engine consumes, or `None` when the
/// pilcrow carries no section properties. Geometry converts twips to px; page
/// size is emitted only when a dimension is overridden, margins follow the
/// `cascade`, and columns only when the count exceeds one.
fn section_break_block(
    values: &BTreeMap<String, Any>,
    cascade: &mut SectionMarginsTwips,
) -> Option<SectionBreakBlock> {
    let sect_pr = values.get("sectPr").and_then(any_map);
    let break_attr = value_string(values.get("sectionBreakType"));
    if sect_pr.is_none() && break_attr.is_none() {
        return None;
    }

    let para_id = value_string(values.get("paraId")).unwrap_or_default();
    let mut block = SectionBreakBlock {
        sdt_groups: None,
        id: BlockId::Str(format!("sect:{para_id}")),
        break_type: sect_pr
            .and_then(|map| map_string(map, "sectionStart"))
            .or(break_attr)
            .as_deref()
            .and_then(section_break_type),
        page_size: None,
        orientation: None,
        margins: None,
        columns: None,
    };

    let Some(sect_pr) = sect_pr else {
        return Some(block);
    };

    let page_width = map_number(sect_pr, "pageWidth");
    let page_height = map_number(sect_pr, "pageHeight");
    if page_width.is_some() || page_height.is_some() {
        block.page_size = Some(Size {
            w: twips_to_pixels(page_width.unwrap_or(DEFAULT_PAGE_WIDTH_TWIPS)),
            h: twips_to_pixels(page_height.unwrap_or(DEFAULT_PAGE_HEIGHT_TWIPS)),
        });
    }

    let top = map_number(sect_pr, "marginTop");
    let bottom = map_number(sect_pr, "marginBottom");
    let left = map_number(sect_pr, "marginLeft");
    let right = map_number(sect_pr, "marginRight");
    if top.is_some() || bottom.is_some() || left.is_some() || right.is_some() {
        *cascade = SectionMarginsTwips {
            top: top.unwrap_or(cascade.top),
            bottom: bottom.unwrap_or(cascade.bottom),
            left: left.unwrap_or(cascade.left),
            right: right.unwrap_or(cascade.right),
        };
        block.margins = Some(PageMargins {
            top: twips_to_pixels(cascade.top),
            right: twips_to_pixels(cascade.right),
            bottom: twips_to_pixels(cascade.bottom),
            left: twips_to_pixels(cascade.left),
            header: None,
            footer: None,
        });
    }

    let column_count = map_number(sect_pr, "columnCount").unwrap_or(1.0);
    if column_count > 1.0 {
        block.columns = Some(ColumnLayout {
            count: column_count,
            gap: twips_to_pixels(
                map_number(sect_pr, "columnSpace").unwrap_or(DEFAULT_COLUMN_GAP_TWIPS),
            ),
            equal_width: Some(map_bool(sect_pr, "equalWidth").unwrap_or(true)),
            separator: map_bool(sect_pr, "separator"),
            columns: sect_pr
                .get("columns")
                .and_then(|value| match value {
                    Any::Array(columns) => Some(columns),
                    _ => None,
                })
                .map(|columns| {
                    columns
                        .iter()
                        .filter_map(any_map)
                        .map(|column| docx_layout::types::ColumnDefinition {
                            width: map_number(column, "width").map(twips_to_pixels),
                            space: map_number(column, "space").map(twips_to_pixels),
                        })
                        .collect()
                }),
        });
    }

    Some(block)
}

/// Merges neighbouring text runs that are adjacent in BOTH coordinate systems
/// and agree on formatting and inline-SDT chrome. Only text merges, so tabs,
/// images and fields always stay separate runs.
fn coalesce_runs(runs: Vec<RawRun>) -> Vec<RawRun> {
    let mut result: Vec<RawRun> = Vec::with_capacity(runs.len());
    for run in runs {
        let merged = if let Some(previous) = result.last_mut() {
            match (&mut previous.kind, &run.kind) {
                (RawRunKind::Text(previous_text), RawRunKind::Text(text))
                    if previous.story_end == run.story_start
                        && previous.pm_end == run.pm_start
                        && previous.atom == run.atom
                        && formatting_equal(&previous.formatting, &run.formatting)
                        && previous.inline_sdt_widget == run.inline_sdt_widget =>
                {
                    previous_text.push_str(text);
                    previous.story_end = run.story_end;
                    previous.pm_end = run.pm_end;
                    true
                }
                _ => false,
            }
        } else {
            false
        };
        if !merged {
            result.push(run);
        }
    }
    result
}

/// Compares formatting while preserving serialized non-finite equality.
fn formatting_equal(left: &RunFormatting, right: &RunFormatting) -> bool {
    left == right
        || (has_nonfinite(left)
            && has_nonfinite(right)
            && serde_json::to_string(left)
                .and_then(|s| serde_json::from_str::<Value>(&s))
                .expect("RunFormatting serializes")
                == serde_json::to_string(right)
                    .and_then(|s| serde_json::from_str::<Value>(&s))
                    .expect("RunFormatting serializes"))
}

fn has_nonfinite(formatting: &RunFormatting) -> bool {
    formatting
        .comment_ids
        .as_ref()
        .is_some_and(|ids| ids.iter().any(|id| !id.is_finite()))
        || [
            formatting.font_size,
            formatting.font_size_cs,
            formatting.letter_spacing,
            formatting.position_px,
            formatting.horizontal_scale,
            formatting.kerning_min_pt,
            formatting.footnote_ref_id,
            formatting.endnote_ref_id,
            formatting.change_revision_id,
        ]
        .into_iter()
        .flatten()
        .any(|value| !value.is_finite())
}

fn raw_run_to_layout(raw: RawRun, paragraph_pm_start: u64) -> Run {
    let pm_start = Some((paragraph_pm_start + 1 + u64::from(raw.pm_start)) as f64);
    let pm_end = Some((paragraph_pm_start + 1 + u64::from(raw.pm_end)) as f64);
    match raw.kind {
        RawRunKind::HorizontalRule(_) => Run::Text(TextRun {
            fmt: raw.formatting,
            text: "\u{200b}".to_owned(),
            pm_start,
            pm_end,
            inline_sdt_widget: raw.inline_sdt_widget,
        }),
        RawRunKind::Text(text) => Run::Text(TextRun {
            fmt: raw.formatting,
            text,
            pm_start,
            pm_end,
            inline_sdt_widget: raw.inline_sdt_widget,
        }),
        RawRunKind::Tab => Run::Tab(TabRun {
            fmt: raw.formatting,
            pm_start,
            pm_end,
            width: None,
            leader_glyphs: None,
        }),
        RawRunKind::LineBreak => Run::LineBreak(LineBreakRun { pm_start, pm_end }),
        RawRunKind::Image(mut image) => {
            image.pm_start = pm_start;
            image.pm_end = pm_end;
            Run::Image(image)
        }
        RawRunKind::Reserved(mut reserved) => {
            reserved.pm_start = pm_start;
            reserved.pm_end = pm_end;
            Run::Reserved(reserved)
        }
        RawRunKind::Field {
            field_type,
            raw_type,
            instruction,
            fallback,
            locked,
            nested_sequences,
            ..
        } => Run::Field(FieldRun {
            fmt: raw.formatting,
            field_type,
            raw_type,
            instruction,
            fallback,
            locked,
            nested_sequences,
            pm_start,
            pm_end,
        }),
    }
}

/// Numbers the runs of one paragraph in reading order. A run already carrying
/// the [`u64::MAX`] sentinel is left without a logical order instead.
fn stamp_logical_order(runs: &mut [Run]) {
    for (index, run) in runs.iter_mut().enumerate() {
        match run {
            Run::Text(run) if run.fmt.logical_order == Some(u64::MAX) => {
                run.fmt.logical_order = None;
            }
            Run::Text(run) => run.fmt.logical_order = Some(index as u64),
            Run::Tab(run) => run.fmt.logical_order = Some(index as u64),
            Run::Field(run) => run.fmt.logical_order = Some(index as u64),
            Run::Image(_) | Run::LineBreak(_) | Run::Reserved(_) | Run::Unsupported => {}
        }
    }
}

fn lower_run_formatting(attributes: Option<&Attrs>, env: &RenderEnv) -> RunFormatting {
    let mut result = RunFormatting {
        bold: mark_bool(attributes, "bold"),
        ..RunFormatting::default()
    };
    if let Some(map) = attribute_map(attributes, "bold")
        && (map_bool(map, "cs") == Some(true) || map_bool(map, "complexScript") == Some(true))
    {
        result.bold_cs = Some(true);
    }
    result.italic = mark_bool(attributes, "italic");
    if let Some(map) = attribute_map(attributes, "italic")
        && (map_bool(map, "cs") == Some(true) || map_bool(map, "complexScript") == Some(true))
    {
        result.italic_cs = Some(true);
    }
    result.underline = attribute(attributes, "underline").and_then(|value| match value {
        Any::Bool(flag) => Some(UnderlineSpec::Flag(*flag)),
        Any::Map(map) => {
            let style = map_string(map, "style");
            let color = map.get("color").and_then(|color| resolve_color(color, env));
            if style.is_some() || color.is_some() {
                Some(UnderlineSpec::Styled { style, color })
            } else {
                Some(UnderlineSpec::Flag(true))
            }
        }
        Any::Null | Any::Undefined => None,
        _ => Some(UnderlineSpec::Flag(true)),
    });
    result.strike = mark_bool(attributes, "strike");

    result.color = attribute(attributes, "textColor")
        .or_else(|| attribute(attributes, "color"))
        .and_then(|value| resolve_color(value, env));
    result.highlight = attribute(attributes, "highlight").and_then(resolve_highlight);

    lower_font_family(attributes, &mut result);
    lower_font_size(attributes, &mut result);
    lower_language(attributes, &mut result);
    lower_character_spacing(attributes, &mut result);

    result.superscript = mark_bool(attributes, "superscript");
    result.subscript = mark_bool(attributes, "subscript");
    result.all_caps = mark_bool(attributes, "allCaps");
    result.small_caps = mark_bool(attributes, "smallCaps");
    result.imprint = mark_bool(attributes, "imprint");
    result.emboss = mark_bool(attributes, "emboss");
    result.text_shadow = mark_bool(attributes, "textShadow");
    result.text_outline = mark_bool(attributes, "textOutline");
    result.hidden = mark_bool(attributes, "hidden");
    result.rtl = mark_bool(attributes, "rtl");
    // Document-grid opt-out (w:snapToGrid, default on): only an authored
    // off is carried, mirroring widowControl.
    if attribute(attributes, "snapToGrid").and_then(any_bool) == Some(false) {
        result.snap_to_grid = Some(false);
    }

    if let Some(value) = attribute(attributes, "complexScript") {
        match value {
            Any::Map(map) => {
                result.complex_script = Some(map_bool(map, "enabled").unwrap_or(true));
                result.bold_cs = map_bool(map, "bold").or(result.bold_cs);
                result.italic_cs = map_bool(map, "italic").or(result.italic_cs);
            }
            _ => result.complex_script = any_bool(value).or(Some(true)),
        }
    }
    result.bold_cs = mark_bool(attributes, "boldCs").or(result.bold_cs);
    result.italic_cs = mark_bool(attributes, "italicCs").or(result.italic_cs);

    if let Some(value) = attribute(attributes, "emphasisMark") {
        let emphasis = match value {
            Any::Map(map) => map_string(map, "type"),
            _ => value_string(Some(value)),
        };
        result.emphasis_mark = Some(match emphasis.as_deref() {
            Some("dot" | "comma" | "circle" | "underDot") => emphasis.unwrap(),
            _ => "dot".to_owned(),
        });
    }
    if let Some(value) = attribute(attributes, "textEffect") {
        let effect = match value {
            Any::Map(map) => map_string(map, "effect"),
            _ => value_string(Some(value)),
        };
        if effect.as_deref().is_some_and(|value| {
            matches!(
                value,
                "blinkBackground" | "lights" | "antsBlack" | "antsRed" | "shimmer" | "sparkle"
            )
        }) {
            result.text_effect = effect;
        }
    }
    if let Some(value) = attribute(attributes, "modernTextEffects") {
        let effects = match value {
            Any::Map(map) => map.get("effects").unwrap_or(value),
            _ => value,
        };
        if !is_nullish(effects) {
            result.modern_effects = serde_json::to_string(effects)
                .ok()
                .and_then(|s| serde_json::from_str(&s).ok());
        }
    }

    result.hyperlink = attribute(attributes, "hyperlink").and_then(lower_hyperlink);
    lower_revisions(attributes, env, &mut result);
    result
}

fn lower_font_family(attributes: Option<&Attrs>, result: &mut RunFormatting) {
    let Some(value) =
        attribute(attributes, "fontFamily").or_else(|| attribute(attributes, "rFonts"))
    else {
        return;
    };
    match value {
        Any::String(value) => {
            let family = value.to_string();
            result.font_family = Some(family.clone());
            result.font_slots = Some(RunFontSlots {
                ascii: Some(family.clone()),
                h_ansi: Some(family),
                ..RunFontSlots::default()
            });
        }
        Any::Map(map) => {
            let slots = RunFontSlots {
                ascii: map_string(map, "ascii"),
                h_ansi: map_string(map, "hAnsi"),
                east_asia: map_string(map, "eastAsia"),
                cs: map_string(map, "cs"),
                ascii_theme: map_string(map, "asciiTheme"),
                h_ansi_theme: map_string(map, "hAnsiTheme"),
                east_asia_theme: map_string(map, "eastAsiaTheme"),
                cs_theme: map_string(map, "csTheme"),
                hint: map_string(map, "hint"),
            };
            let rtl = mark_bool(attributes, "rtl") == Some(true);
            result.font_family = if rtl { slots.cs.clone() } else { None }
                .or_else(|| slots.ascii.clone())
                .or_else(|| slots.h_ansi.clone())
                .or_else(|| slots.east_asia.clone())
                .or_else(|| slots.cs.clone());
            result.font_slots = Some(slots);
        }
        _ => {}
    }
}

/// A `w:sz` half-point size in points, clamped to Word's 1–1638 pt range.
pub(crate) fn font_size_pt(half_points: f64) -> f64 {
    (half_points / 2.0).clamp(1.0, 1638.0)
}

fn lower_font_size(attributes: Option<&Attrs>, result: &mut RunFormatting) {
    let Some(value) = attribute(attributes, "fontSize").or_else(|| attribute(attributes, "sz"))
    else {
        return;
    };
    match value {
        // A scalar mark is the authored `w:sz`; the object form additionally
        // preserves an independent `w:szCs`. Both stay in half-points until
        // this conversion.
        Any::Number(half_points) => result.font_size = Some(font_size_pt(*half_points)),
        Any::BigInt(half_points) => result.font_size = Some(font_size_pt(*half_points as f64)),
        Any::Map(map) => {
            let size = map_number(map, "size").or_else(|| map_number(map, "sz"));
            let size_cs = map_number(map, "sizeCs").or_else(|| map_number(map, "szCs"));
            let rtl = mark_bool(attributes, "rtl") == Some(true);
            result.font_size = if rtl { size_cs.or(size) } else { size }.map(font_size_pt);
            result.font_size_cs = size_cs.map(font_size_pt);
        }
        _ => {}
    }
}

fn lower_language(attributes: Option<&Attrs>, result: &mut RunFormatting) {
    let Some(value) = attribute(attributes, "language").or_else(|| attribute(attributes, "lang"))
    else {
        return;
    };
    if let Any::Map(map) = value {
        result.language = Some(RunLanguageSlots {
            latin: map_string(map, "latin").or_else(|| map_string(map, "val")),
            east_asia: map_string(map, "eastAsia"),
            bidi: map_string(map, "bidi"),
        });
    }
}

fn lower_character_spacing(attributes: Option<&Attrs>, result: &mut RunFormatting) {
    let Some(Any::Map(map)) = attribute(attributes, "characterSpacing") else {
        return;
    };
    if let Some(spacing) = map_number(map, "spacing").filter(|value| *value != 0.0) {
        result.letter_spacing = Some(twips_to_pixels(spacing));
    }
    if let Some(position) = map_number(map, "position").filter(|value| *value != 0.0) {
        result.position_px = Some(half_points_to_pixels(position));
    }
    if let Some(scale) = map_number(map, "scale").filter(|value| *value != 100.0) {
        result.horizontal_scale = Some(scale);
    }
    if let Some(kerning) = map_number(map, "kerning").filter(|value| *value > 0.0) {
        result.kerning_min_pt = Some(kerning / 2.0);
    }
}

fn lower_hyperlink(value: &Any) -> Option<HyperlinkInfo> {
    match value {
        Any::String(href) => Some(HyperlinkInfo {
            href: href.to_string(),
            tooltip: None,
            no_default_style: None,
            target: None,
            history: None,
            doc_location: None,
        }),
        Any::Map(map) => Some(HyperlinkInfo {
            href: map_string(map, "href")?,
            tooltip: map_string(map, "tooltip"),
            no_default_style: map_bool(map, "noDefaultStyle"),
            target: map_string(map, "target"),
            history: map_bool(map, "history"),
            doc_location: map_string(map, "docLocation"),
        }),
        _ => None,
    }
}

#[derive(Clone, Debug)]
struct RevisionMeta {
    id: f64,
    author: Option<String>,
    date: Option<String>,
}

fn revision_meta(value: &Any, env: &RenderEnv) -> Option<RevisionMeta> {
    let Any::Map(map) = value else {
        return None;
    };
    let id_value = map.get("id").or_else(|| map.get("revisionId"))?;
    let id = match id_value {
        Any::String(value) => numeric_id(value, env),
        _ => any_number(id_value)?,
    };
    Some(RevisionMeta {
        id,
        author: map_string(map, "author"),
        date: map_string(map, "date"),
    })
}

fn lower_revisions(attributes: Option<&Attrs>, env: &RenderEnv, result: &mut RunFormatting) {
    let pending = |key| {
        attribute(attributes, key)
            .filter(|value| env.revision_decision(value).is_none())
            .and_then(|value| revision_meta(value, env))
    };
    let insertion = pending(INS);
    let deletion = pending(DEL);
    if insertion.is_some() {
        result.is_insertion = Some(true);
    }
    if deletion.is_some() {
        result.is_deletion = Some(true);
    }
    // The layout contract has one metadata triple even when both flags are present. Preserve the
    // insertion triple in the nested ins+del case; use deletion metadata when it is the only site.
    if let Some(revision) = insertion.or(deletion) {
        result.change_revision_id = Some(revision.id);
        result.change_author = revision.author;
        result.change_date = revision.date;
    }
}

fn lower_paragraph_attrs(
    values: &BTreeMap<String, Any>,
    pilcrow_attributes: Option<&Attrs>,
    env: &RenderEnv,
    list_state: &mut ListState,
) -> ParagraphAttrs {
    let alignment =
        value_string(values.get("alignment")).and_then(|alignment| match alignment.as_str() {
            "both" | "distribute" => Some("justify".to_owned()),
            "left" | "center" | "right" => Some(alignment),
            _ => None,
        });
    let mut result = ParagraphAttrs {
        alignment,
        style_id: paragraph_style_id(values),
        ..ParagraphAttrs::default()
    };
    let raw_missing = result
        .style_id
        .as_deref()
        .is_none_or(|style| style.is_empty());
    if raw_missing {
        result.effective_style_id = env
            .default_paragraph_style_id
            .clone()
            .filter(|style| !style.is_empty());
    }
    lower_paragraph_spacing(values, &mut result, env);
    // Section document-grid pitch for line-height snapping, stamped at
    // lowering so incremental reuse compares resolved blocks. The engine
    // overwrites this per section after lowering.
    result.doc_grid_pitch_px = env
        .doc_grid_pitch_px
        .filter(|pitch| pitch.is_finite() && *pitch > 0.0);
    lower_paragraph_indent(values, &mut result);
    lower_paragraph_tabs(values, &mut result);

    result.has_source_content = true_property(values, "hasSourceContent");
    result.keep_next = true_property(values, "keepNext");
    result.keep_lines = true_property(values, "keepLines");
    result.widow_control = false_property(values, "widowControl");
    result.page_break_before = true_property(values, "pageBreakBefore");
    result.page_break_before_run = true_property(values, "pageBreakBeforeRun");
    result.contextual_spacing = true_property(values, "contextualSpacing");
    result.bidi = true_property(values, "bidi");
    // Document-grid opt-out (w:snapToGrid, default on): the direct pPr child
    // AND the paragraph-mark rPr (in defaultTextFormatting) both opt out.
    result.snap_to_grid = false_property(values, "snapToGrid");
    if values
        .get("defaultTextFormatting")
        .and_then(any_map)
        .and_then(|defaults| defaults.get("snapToGrid"))
        .and_then(any_bool)
        == Some(false)
    {
        result.snap_to_grid = Some(false);
    }
    // East Asian auto-spacing opt-outs (w:autoSpaceDE / w:autoSpaceDN, both
    // default on).
    result.auto_space_de = false_property(values, "autoSpaceDE");
    result.auto_space_dn = false_property(values, "autoSpaceDN");
    result.borders = lower_paragraph_borders(values, env);
    result.shading = values
        .get("shading")
        .and_then(|shading| resolve_paragraph_shading(shading, env));

    if let Some(Any::Map(num_pr)) = values.get("numPr") {
        result.num_pr = Some(ListNumPr {
            num_id: map_number(num_pr, "numId"),
            ilvl: map_number(num_pr, "ilvl"),
        });
    }
    result.list_marker = compute_list_marker(values, list_state);
    result.list_is_bullet = values.get("listIsBullet").and_then(any_bool);
    result.list_marker_hidden = true_property(values, "listMarkerHidden");
    result.list_marker_font_family = value_string(values.get("listMarkerFontFamily"));
    result.list_marker_font_size = value_number(values.get("listMarkerFontSize"));
    if result.list_marker.is_some() {
        let explicit_bold = values.get("listMarkerBold").and_then(any_bool);
        let explicit_italic = values.get("listMarkerItalic").and_then(any_bool);
        let explicit_color = values
            .get("listMarkerColor")
            .and_then(|color| resolve_color(color, env));
        if let Some(Any::Map(formatting)) = values.get("defaultTextFormatting") {
            result.list_marker_bold = explicit_bold.or_else(|| map_bool(formatting, "bold"));
            result.list_marker_italic = explicit_italic.or_else(|| map_bool(formatting, "italic"));
            result.list_marker_color = explicit_color.or_else(|| {
                formatting
                    .get("color")
                    .and_then(|color| resolve_color(color, env))
            });
        } else {
            result.list_marker_bold = explicit_bold;
            result.list_marker_italic = explicit_italic;
            result.list_marker_color = explicit_color;
        }
    }
    result.list_marker_suffix = value_string(values.get("listMarkerSuffix"));
    result.default_tab_stop_twips = env.default_tab_stop_twips;
    lower_paragraph_defaults(values, &mut result);

    result.p_pr_ins = values
        .get("pPrIns")
        .filter(|value| !is_nullish(value))
        .and_then(|value| paragraph_revision_value(value, env))
        .or_else(|| {
            attribute(pilcrow_attributes, INS)
                .and_then(|value| paragraph_revision_value(value, env))
        });
    result.p_pr_del = values
        .get("pPrDel")
        .filter(|value| !is_nullish(value))
        .and_then(|value| paragraph_revision_value(value, env))
        .or_else(|| {
            attribute(pilcrow_attributes, DEL)
                .and_then(|value| paragraph_revision_value(value, env))
        });
    if result.num_pr.is_some() {
        let numbering_added = values.get("pPrChange").is_some_and(|changes| {
            let Any::Array(changes) = changes else {
                return false;
            };
            changes.iter().any(|change| {
                let Some(change) = any_map(change) else {
                    return true;
                };
                let Some(previous) = change.get("previousFormatting").and_then(any_map) else {
                    return true;
                };
                previous.get("numPr").is_none_or(is_nullish)
            })
        });
        result.list_marker_revision = if result.p_pr_del.is_some() {
            Some("del".to_owned())
        } else if result.p_pr_ins.is_some() || numbering_added {
            Some("ins".to_owned())
        } else {
            None
        };
    }

    result
}

fn lower_paragraph_borders(
    values: &BTreeMap<String, Any>,
    env: &RenderEnv,
) -> Option<ParagraphBorders> {
    let borders = values.get("borders").and_then(any_map)?;
    let side = |key: &str| {
        borders
            .get(key)
            .and_then(any_map)
            .and_then(|border| lower_paragraph_border(border, env))
    };
    let result = ParagraphBorders {
        top: side("top"),
        bottom: side("bottom"),
        left: side("left"),
        right: side("right"),
        between: side("between"),
        bar: side("bar"),
    };
    (result.top.is_some()
        || result.bottom.is_some()
        || result.left.is_some()
        || result.right.is_some()
        || result.between.is_some()
        || result.bar.is_some())
    .then_some(result)
}

fn lower_paragraph_border(
    border: &std::collections::HashMap<String, Any>,
    env: &RenderEnv,
) -> Option<BorderStyle> {
    let style = map_string(border, "style")?;
    if matches!(style.as_str(), "none" | "nil") {
        return None;
    }
    let css_style = match style.as_str() {
        "double"
        | "triple"
        | "thinThickSmallGap"
        | "thickThinSmallGap"
        | "thinThickThinSmallGap"
        | "thinThickMediumGap"
        | "thickThinMediumGap"
        | "thinThickThinMediumGap"
        | "thinThickLargeGap"
        | "thickThinLargeGap"
        | "thinThickThinLargeGap"
        | "doubleWave" => "double",
        "dotted" | "dotDotDash" => "dotted",
        "dashed" | "dashSmallGap" | "dotDash" | "dashDotStroked" => "dashed",
        "threeDEmboss" => "ridge",
        "threeDEngrave" => "groove",
        "outset" => "outset",
        "inset" => "inset",
        _ => "solid",
    };
    Some(BorderStyle {
        style: Some(css_style.to_owned()),
        width: Some(
            ((map_number(border, "size").unwrap_or(0.0) / 8.0) * 1.333)
                .round()
                .max(1.0),
        ),
        color: border
            .get("color")
            .and_then(|value| resolve_color(value, env))
            .or_else(|| Some("#000000".to_owned())),
        space: map_number(border, "space").map(|points| points * 4.0 / 3.0),
    })
}

fn paragraph_auto_spacing(values: &BTreeMap<String, Any>, key: &str) -> bool {
    values.get(key).and_then(any_bool).or_else(|| {
        values
            .get("_originalFormatting")
            .and_then(any_map)
            .and_then(|map| map_bool(map, key))
    }) == Some(true)
}

fn suppress_cell_edge_spacing(
    blocks: &mut [LayoutBlock],
    values: &BTreeMap<String, Any>,
    edges: CellEdges,
) {
    if edges.before
        && paragraph_auto_spacing(values, "beforeAutospacing")
        && let Some(spacing) = blocks.iter_mut().find_map(|block| match block {
            LayoutBlock::Paragraph(paragraph) => paragraph.attrs.as_mut()?.spacing.as_mut(),
            _ => None,
        })
    {
        spacing.before = Some(0.0);
    }
    if edges.after
        && paragraph_auto_spacing(values, "afterAutospacing")
        && let Some(spacing) = blocks.iter_mut().rev().find_map(|block| match block {
            LayoutBlock::Paragraph(paragraph) => paragraph.attrs.as_mut()?.spacing.as_mut(),
            _ => None,
        })
    {
        spacing.after = Some(0.0);
    }
}

fn lower_paragraph_spacing(
    values: &BTreeMap<String, Any>,
    result: &mut ParagraphAttrs,
    env: &RenderEnv,
) {
    let line_px = env
        .paragraph_spacing_line_px
        .filter(|line| line.is_finite() && *line > 0.0)
        .unwrap_or(16.0);
    let suppress_before = env.compatibility_flags.suppress_sp_bf_after_pg_brk
        && true_property(values, "pageBreakBeforeRun") == Some(true);
    let spacing_map = values.get("spacing").and_then(any_map);
    let auto_before = paragraph_auto_spacing(values, "beforeAutospacing");
    let auto_after = paragraph_auto_spacing(values, "afterAutospacing");
    let (auto_before_px, auto_after_px) = if env
        .compatibility_flags
        .do_not_use_html_paragraph_auto_spacing
    {
        (twips_to_pixels(100.0), twips_to_pixels(200.0))
    } else {
        (AUTO_PARAGRAPH_SPACING_PX, AUTO_PARAGRAPH_SPACING_PX)
    };
    let before_lines = (!auto_before && !suppress_before)
        .then(|| value_number(values.get("spaceBeforeLines")))
        .flatten()
        .filter(|value| value.is_finite() && *value > 0.0);
    let after_lines = (!auto_after)
        .then(|| value_number(values.get("spaceAfterLines")))
        .flatten()
        .filter(|value| value.is_finite() && *value > 0.0);
    let before = value_number(values.get("spaceBefore"))
        .or_else(|| spacing_map.and_then(|map| map_number(map, "before")));
    let after = value_number(values.get("spaceAfter"))
        .or_else(|| spacing_map.and_then(|map| map_number(map, "after")));
    let line = value_number(values.get("lineSpacing"))
        .or_else(|| spacing_map.and_then(|map| map_number(map, "line")));
    let line_rule = value_string(values.get("lineSpacingRule"))
        .or_else(|| spacing_map.and_then(|map| map_string(map, "lineRule")));

    if auto_before
        || auto_after
        || before.is_some()
        || after.is_some()
        || line.is_some()
        || before_lines.is_some()
        || after_lines.is_some()
    {
        let mut spacing = ParagraphSpacing {
            before_lines,
            after_lines,
            before: if suppress_before {
                Some(0.0)
            } else if auto_before {
                Some(auto_before_px)
            } else {
                before_lines
                    .map(|lines| lines * line_px / 100.0)
                    .or_else(|| before.map(twips_to_pixels))
            },
            after: if auto_after {
                Some(auto_after_px)
            } else {
                after_lines
                    .map(|lines| lines * line_px / 100.0)
                    .or_else(|| after.map(twips_to_pixels))
            },
            ..ParagraphSpacing::default()
        };
        if let Some(line) = line {
            if matches!(line_rule.as_deref(), Some("exact" | "atLeast")) {
                spacing.line = Some(twips_to_pixels(line));
                spacing.line_unit = Some("px".to_owned());
                spacing.line_rule = line_rule;
            } else {
                spacing.line = Some(line / 240.0);
                spacing.line_unit = Some("multiplier".to_owned());
                spacing.line_rule = Some("auto".to_owned());
            }
        }
        result.spacing = Some(spacing);
    }

    if let Some(Any::Map(explicit)) = values.get("spacingExplicit") {
        result.spacing_explicit = Some(SpacingExplicit {
            before: map_bool(explicit, "before"),
            after: map_bool(explicit, "after"),
        });
    }
}

fn lower_paragraph_indent(values: &BTreeMap<String, Any>, result: &mut ParagraphAttrs) {
    let indent_map = values.get("indent").and_then(any_map);
    let mut left = value_number(values.get("indentLeft"))
        .or_else(|| indent_map.and_then(|map| map_number(map, "left")));
    let right = value_number(values.get("indentRight"))
        .or_else(|| indent_map.and_then(|map| map_number(map, "right")));
    let mut first_line = value_number(values.get("indentFirstLine"))
        .or_else(|| indent_map.and_then(|map| map_number(map, "firstLine")));
    let mut hanging = values
        .get("hangingIndent")
        .and_then(any_bool)
        .or_else(|| indent_map.and_then(|map| map_bool(map, "hanging")))
        .unwrap_or(false);

    if let Some(Any::Map(num_pr)) = values.get("numPr") {
        let num_id = map_number(num_pr, "numId").unwrap_or(0.0);
        if num_id != 0.0 && left.is_none() {
            let level = map_number(num_pr, "ilvl").unwrap_or(0.0);
            left = Some((level + 1.0) * 720.0);
            if first_line.is_none() {
                first_line = Some(-360.0);
                hanging = true;
            }
        }
    }

    if left.is_some() || right.is_some() || first_line.is_some() {
        result.indent = Some(ParagraphIndent {
            left: left.map(twips_to_pixels),
            right: right.map(twips_to_pixels),
            first_line: first_line.filter(|_| !hanging).map(twips_to_pixels),
            hanging: first_line
                .filter(|_| hanging)
                .map(|value| twips_to_pixels(value).abs()),
        });
    }
}

fn lower_paragraph_tabs(values: &BTreeMap<String, Any>, result: &mut ParagraphAttrs) {
    let Some(Any::Array(tabs)) = values.get("tabs") else {
        return;
    };
    let tabs: Vec<TabStop> = tabs
        .iter()
        .filter_map(|tab| {
            let Any::Map(tab) = tab else {
                return None;
            };
            let alignment = map_string(tab, "alignment")
                .or_else(|| map_string(tab, "val"))
                .unwrap_or_else(|| "left".to_owned());
            let val = match alignment.as_str() {
                "left" | "num" => "start",
                "right" => "end",
                "center" => "center",
                "decimal" => "decimal",
                "bar" => "bar",
                "clear" => "clear",
                value @ ("start" | "end") => value,
                _ => "start",
            }
            .to_owned();
            Some(TabStop {
                val,
                // Tab stops are the intentional existing-contract exception: layout consumes
                // their authored twip positions directly and converts at measurement time.
                pos: map_number(tab, "position").or_else(|| map_number(tab, "pos"))?,
                leader: map_string(tab, "leader"),
            })
        })
        .collect();
    if !tabs.is_empty() {
        result.tabs = Some(tabs);
    }
}

fn paragraph_default_font_size(values: &BTreeMap<String, Any>) -> f64 {
    values
        .get("defaultTextFormatting")
        .and_then(any_map)
        .and_then(|defaults| map_number(defaults, "fontSize"))
        .map_or(10.0, font_size_pt)
}

fn lower_paragraph_defaults(values: &BTreeMap<String, Any>, result: &mut ParagraphAttrs) {
    result.default_font_size = Some(paragraph_default_font_size(values));
    let Some(Any::Map(defaults)) = values.get("defaultTextFormatting") else {
        return;
    };
    if let Some(Any::Map(fonts)) = defaults.get("fontFamily") {
        result.default_font_family =
            map_string(fonts, "ascii").or_else(|| map_string(fonts, "hAnsi"));
    }
}

fn paragraph_run_defaults(values: &BTreeMap<String, Any>) -> RunFormatting {
    let mut result = RunFormatting {
        font_size: Some(paragraph_default_font_size(values)),
        ..RunFormatting::default()
    };
    let Some(Any::Map(defaults)) = values.get("defaultTextFormatting") else {
        return result;
    };
    if let Some(Any::Map(fonts)) = defaults.get("fontFamily") {
        let slots = RunFontSlots {
            ascii: map_string(fonts, "ascii"),
            h_ansi: map_string(fonts, "hAnsi"),
            east_asia: map_string(fonts, "eastAsia"),
            cs: map_string(fonts, "cs"),
            ascii_theme: map_string(fonts, "asciiTheme"),
            h_ansi_theme: map_string(fonts, "hAnsiTheme"),
            east_asia_theme: map_string(fonts, "eastAsiaTheme"),
            cs_theme: map_string(fonts, "csTheme"),
            hint: map_string(fonts, "hint"),
        };
        result.font_family = slots
            .ascii
            .clone()
            .or_else(|| slots.h_ansi.clone())
            .or_else(|| slots.east_asia.clone())
            .or_else(|| slots.cs.clone());
        result.font_slots = Some(slots);
    }
    result.font_size_cs = map_number(defaults, "fontSizeCs").map(font_size_pt);
    result.bold_cs = map_bool(defaults, "boldCs");
    result.italic_cs = map_bool(defaults, "italicCs");
    result.complex_script = map_bool(defaults, "cs");
    if defaults.get("snapToGrid").and_then(any_bool) == Some(false) {
        result.snap_to_grid = Some(false);
    }
    if let Some(Any::Map(language)) = defaults.get("language") {
        result.language = Some(RunLanguageSlots {
            latin: map_string(language, "latin").or_else(|| map_string(language, "val")),
            east_asia: map_string(language, "eastAsia"),
            bidi: map_string(language, "bidi"),
        });
    }
    result
}

fn apply_run_defaults(target: &mut RunFormatting, defaults: &RunFormatting) {
    if target.font_slots.is_none() {
        target.font_slots = defaults.font_slots.clone();
    }
    if target.font_family.is_none() {
        target.font_family = defaults.font_family.clone();
    }
    if target.font_size.is_none() {
        target.font_size = defaults.font_size;
    }
    if target.font_size_cs.is_none() {
        target.font_size_cs = defaults.font_size_cs;
    }
    if target.bold_cs.is_none() {
        target.bold_cs = defaults.bold_cs;
    }
    if target.italic_cs.is_none() {
        target.italic_cs = defaults.italic_cs;
    }
    if target.complex_script.is_none() {
        target.complex_script = defaults.complex_script;
    }
    if target.snap_to_grid.is_none() {
        target.snap_to_grid = defaults.snap_to_grid;
    }
    if target.language.is_none() {
        target.language = defaults.language.clone();
    }
}

fn inherited_hyperlink_style(attributes: Option<&Attrs>) -> (bool, bool) {
    let inherited = |key| {
        attribute_map(attributes, key).and_then(|map| map_bool(map, "inheritedHyperlink"))
            == Some(true)
    };
    (inherited("textColor"), inherited("underline"))
}

fn strip_toc_hyperlink_style(formatting: &mut RunFormatting, inherited: (bool, bool)) {
    if let Some(hyperlink) = &mut formatting.hyperlink {
        hyperlink.no_default_style = Some(true);
        if inherited.0 {
            formatting.color = None;
        }
        if inherited.1 {
            formatting.underline = None;
        }
    }
}

fn is_toc_style(style_id: &str) -> bool {
    let upper = style_id.to_ascii_uppercase();
    upper
        .strip_prefix("TOC")
        .is_some_and(|suffix| suffix.chars().all(|ch| ch.is_ascii_digit()))
}

fn paragraph_style_id(values: &BTreeMap<String, Any>) -> Option<String> {
    value_string(values.get("styleId")).or_else(|| value_string(values.get("pStyle")))
}

fn paragraph_revision_value(value: &Any, env: &RenderEnv) -> Option<Value> {
    let revision = revision_meta(value, env)?;
    let mut object = JsonMap::new();
    object.insert("revisionId".to_owned(), Value::from(revision.id));
    object.insert(
        "author".to_owned(),
        revision.author.map(Value::from).unwrap_or(Value::Null),
    );
    object.insert(
        "date".to_owned(),
        revision.date.map(Value::from).unwrap_or(Value::Null),
    );
    Some(Value::Object(object))
}

fn resolve_paragraph_shading(value: &Any, env: &RenderEnv) -> Option<String> {
    let shading = any_map(value)?;
    if map_string(shading, "pattern").as_deref() == Some("nil") {
        return None;
    }
    let fill = shading.get("fill")?;
    match fill {
        Any::String(value) if value.as_ref() == "auto" => None,
        Any::Map(map) => {
            if map_string(map, "themeColor").is_some() {
                let mut themed = map.as_ref().clone();
                themed.remove("auto");
                resolve_color(&Any::Map(themed.into()), env)
            } else if map_bool(map, "auto") == Some(true)
                || map_string(map, "rgb").as_deref() == Some("auto")
            {
                None
            } else {
                resolve_color(fill, env)
            }
        }
        _ => resolve_color(fill, env),
    }
}

fn resolve_color(value: &Any, env: &RenderEnv) -> Option<String> {
    match value {
        Any::String(value) => Some(css_hex(value)),
        Any::Map(map) => {
            if map_bool(map, "auto") == Some(true) {
                return Some("#000000".to_owned());
            }
            let rgb = map_string(map, "rgb");
            let mut hex = if let Some(slot) = map_string(map, "themeColor") {
                theme_color(&slot, env).or(rgb)?
            } else {
                rgb?
            };
            hex = hex.trim_start_matches('#').to_ascii_uppercase();
            if let Some(tint) = map_string(map, "themeTint").and_then(|value| hex_byte(&value)) {
                hex = apply_tint(&hex, tint as f64 / 255.0);
            } else if let Some(shade) =
                map_string(map, "themeShade").and_then(|value| hex_byte(&value))
            {
                hex = apply_shade(&hex, shade as f64 / 255.0);
            }
            Some(format!("#{hex}"))
        }
        _ => None,
    }
}

fn theme_color(slot: &str, env: &RenderEnv) -> Option<String> {
    let canonical = match slot.to_ascii_lowercase().as_str() {
        "dark1" | "text1" | "tx1" => "dk1",
        "light1" | "background1" | "bg1" => "lt1",
        "dark2" | "text2" | "tx2" => "dk2",
        "light2" | "background2" | "bg2" => "lt2",
        "hyperlink" => "hlink",
        "followedhyperlink" => "folHlink",
        value => match value {
            "dk1" => "dk1",
            "lt1" => "lt1",
            "dk2" => "dk2",
            "lt2" => "lt2",
            "accent1" => "accent1",
            "accent2" => "accent2",
            "accent3" => "accent3",
            "accent4" => "accent4",
            "accent5" => "accent5",
            "accent6" => "accent6",
            "hlink" => "hlink",
            "folhlink" => "folHlink",
            _ => return None,
        },
    };
    env.theme_colors
        .get(slot)
        .or_else(|| env.theme_colors.get(canonical))
        .cloned()
        .or_else(|| default_theme_color(canonical).map(str::to_owned))
}

fn default_theme_color(slot: &str) -> Option<&'static str> {
    Some(match slot {
        "dk1" => "000000",
        "lt1" => "FFFFFF",
        "dk2" => "44546A",
        "lt2" => "E7E6E6",
        "accent1" => "4472C4",
        "accent2" => "ED7D31",
        "accent3" => "A5A5A5",
        "accent4" => "FFC000",
        "accent5" => "5B9BD5",
        "accent6" => "70AD47",
        "hlink" => "0563C1",
        "folHlink" => "954F72",
        _ => return None,
    })
}

fn resolve_highlight(value: &Any) -> Option<String> {
    let color = match value {
        Any::String(value) => value.as_ref(),
        Any::Map(map) => map.get("color").and_then(any_str)?,
        _ => return None,
    };
    let hex = match color {
        "black" => "000000",
        "blue" => "0000FF",
        "cyan" => "00FFFF",
        "darkBlue" => "00008B",
        "darkCyan" => "008B8B",
        "darkGray" => "A9A9A9",
        "darkGreen" => "006400",
        "darkMagenta" => "8B008B",
        "darkRed" => "8B0000",
        "darkYellow" => "808000",
        "green" => "00FF00",
        "lightGray" => "D3D3D3",
        "magenta" => "FF00FF",
        "red" => "FF0000",
        "white" => "FFFFFF",
        "yellow" => "FFFF00",
        "none" => return Some(String::new()),
        value => return Some(css_hex(value)),
    };
    Some(format!("#{hex}"))
}

fn apply_tint(hex: &str, tint: f64) -> String {
    let (r, g, b) = hex_rgb(hex);
    rgb_hex(
        r as f64 * tint + 255.0 * (1.0 - tint),
        g as f64 * tint + 255.0 * (1.0 - tint),
        b as f64 * tint + 255.0 * (1.0 - tint),
    )
}

fn apply_shade(hex: &str, shade: f64) -> String {
    let (r, g, b) = hex_rgb(hex);
    rgb_hex(r as f64 * shade, g as f64 * shade, b as f64 * shade)
}

fn hex_rgb(hex: &str) -> (u8, u8, u8) {
    let normalized = format!("{hex:0>6}");
    let normalized = &normalized[..normalized.len().min(6)];
    (
        u8::from_str_radix(&normalized[0..2], 16).unwrap_or(0),
        u8::from_str_radix(&normalized[2..4], 16).unwrap_or(0),
        u8::from_str_radix(&normalized[4..6], 16).unwrap_or(0),
    )
}

fn rgb_hex(r: f64, g: f64, b: f64) -> String {
    let channel = |value: f64| value.round().clamp(0.0, 255.0) as u8;
    format!("{:02X}{:02X}{:02X}", channel(r), channel(g), channel(b))
}

fn css_hex(value: &str) -> String {
    if value.eq_ignore_ascii_case("auto") {
        return "#000000".to_owned();
    }
    format!("#{}", value.trim_start_matches('#').to_ascii_uppercase())
}

fn hex_byte(value: &str) -> Option<u8> {
    u8::from_str_radix(value, 16).ok()
}

/// The number the layout contract carries for a yrs `{client}:{counter}` id:
/// the explicit [`RenderEnv::numeric_ids`] mapping when there is one,
/// otherwise a hash of the id folded into the JavaScript safe-integer range.
/// The fallback is stable within a document but cannot round-trip the string.
fn numeric_id(id: &str, env: &RenderEnv) -> f64 {
    if let Some(value) = env.numeric_ids.get(id) {
        return *value;
    }
    if let Ok(value) = id.parse::<f64>()
        && value.is_finite()
    {
        return value;
    }
    let hash = id.bytes().fold(0xcbf29ce484222325_u64, |hash, byte| {
        (hash ^ u64::from(byte)).wrapping_mul(0x100000001b3)
    });
    (hash & ((1_u64 << 53) - 1)) as f64
}

fn true_property(values: &BTreeMap<String, Any>, key: &str) -> Option<bool> {
    (values.get(key).and_then(any_bool) == Some(true)).then_some(true)
}

/// Returns only an authored false for a default-on toggle.
fn false_property(values: &BTreeMap<String, Any>, key: &str) -> Option<bool> {
    (values.get(key).and_then(any_bool) == Some(false)).then_some(false)
}

fn attribute<'a>(attributes: Option<&'a Attrs>, key: &str) -> Option<&'a Any> {
    attributes
        .and_then(|attributes| attributes.get(key))
        .filter(|value| !is_nullish(value))
}

fn attribute_map<'a>(
    attributes: Option<&'a Attrs>,
    key: &str,
) -> Option<&'a std::collections::HashMap<String, Any>> {
    attribute(attributes, key).and_then(any_map)
}

fn mark_bool(attributes: Option<&Attrs>, key: &str) -> Option<bool> {
    let value = attribute(attributes, key)?;
    match value {
        Any::Map(map) => map_bool(map, "enabled").or(Some(true)),
        _ => any_bool(value).or(Some(true)),
    }
}

fn any_map(value: &Any) -> Option<&std::collections::HashMap<String, Any>> {
    match value {
        Any::Map(map) => Some(map),
        _ => None,
    }
}

pub(crate) fn any_str(value: &Any) -> Option<&str> {
    match value {
        Any::String(value) => Some(value),
        _ => None,
    }
}

pub(crate) fn any_bool(value: &Any) -> Option<bool> {
    match value {
        Any::Bool(value) => Some(*value),
        Any::Number(value) => Some(*value != 0.0),
        Any::BigInt(value) => Some(*value != 0),
        _ => None,
    }
}

pub(crate) fn any_number(value: &Any) -> Option<f64> {
    match value {
        Any::Number(value) => Some(*value),
        Any::BigInt(value) => Some(*value as f64),
        Any::String(value) => value.parse().ok(),
        _ => None,
    }
}

pub(crate) fn value_string(value: Option<&Any>) -> Option<String> {
    value.and_then(any_str).map(str::to_owned)
}

pub(crate) fn value_number(value: Option<&Any>) -> Option<f64> {
    value.and_then(any_number)
}

fn map_string(map: &std::collections::HashMap<String, Any>, key: &str) -> Option<String> {
    value_string(map.get(key))
}

fn map_bool(map: &std::collections::HashMap<String, Any>, key: &str) -> Option<bool> {
    map.get(key).and_then(any_bool)
}

fn any_strings(value: Option<&Any>) -> Vec<String> {
    match value {
        Some(Any::Array(values)) => values
            .iter()
            .filter_map(any_str)
            .map(str::to_owned)
            .collect(),
        _ => Vec::new(),
    }
}

pub(crate) fn map_number(map: &std::collections::HashMap<String, Any>, key: &str) -> Option<f64> {
    map.get(key).and_then(any_number)
}

fn is_nullish(value: &Any) -> bool {
    matches!(value, Any::Null | Any::Undefined)
}

fn utf16_len(value: &str) -> u32 {
    value.encode_utf16().count() as u32
}

fn utf16_slice(value: &str, start: u32, end: u32) -> String {
    let mut utf16_offset = 0_u32;
    let mut byte_start = None;
    let mut byte_end = None;
    for (byte_index, ch) in value.char_indices() {
        if utf16_offset == start {
            byte_start = Some(byte_index);
        }
        if utf16_offset == end {
            byte_end = Some(byte_index);
            break;
        }
        utf16_offset += ch.len_utf16() as u32;
    }
    if utf16_offset == start && byte_start.is_none() {
        byte_start = Some(value.len());
    }
    if utf16_offset == end && byte_end.is_none() {
        byte_end = Some(value.len());
    }
    let start = byte_start.expect("yrs/comment offsets never split a UTF-16 surrogate pair");
    let end = byte_end.expect("yrs/comment offsets never split a UTF-16 surrogate pair");
    value[start..end].to_owned()
}

fn twips_to_pixels(twips: f64) -> f64 {
    twips / 1440.0 * 96.0
}

fn half_points_to_pixels(half_points: f64) -> f64 {
    half_points / 144.0 * 96.0
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;
    use std::sync::Arc;

    use serde_json::json;
    use yrs::{Any, Text, Transact};

    use super::*;
    use crate::{EditCtx, FormatPolicy, Position, RawOp, SimpleFormat, StoryRange};

    const DATE: &str = "2026-07-13T12:00:00Z";

    #[test]
    fn hard_break_spacing_suppression_clears_line_units_without_changing_authored_values() {
        let values = BTreeMap::from([
            ("spaceBeforeLines".to_owned(), Any::Number(200.0)),
            ("spaceAfterLines".to_owned(), Any::Number(100.0)),
            ("pageBreakBeforeRun".to_owned(), Any::Bool(true)),
        ]);
        let mut env = RenderEnv {
            paragraph_spacing_line_px: Some(32.0),
            ..RenderEnv::default()
        };
        let mut attrs = ParagraphAttrs::default();
        lower_paragraph_spacing(&values, &mut attrs, &env);
        assert_eq!(attrs.spacing.as_ref().unwrap().before, Some(64.0));
        env.compatibility_flags.suppress_sp_bf_after_pg_brk = true;
        lower_paragraph_spacing(&values, &mut attrs, &env);
        let spacing = attrs.spacing.unwrap();
        assert_eq!(spacing.before, Some(0.0));
        assert_eq!(spacing.before_lines, None);
        assert_eq!(spacing.after, Some(32.0));
        assert_eq!(spacing.after_lines, Some(100.0));
        assert_eq!(values["spaceBeforeLines"], Any::Number(200.0));
    }

    fn any_map(entries: impl IntoIterator<Item = (&'static str, Any)>) -> Any {
        Any::Map(Arc::new(
            entries
                .into_iter()
                .map(|(key, value)| (key.to_owned(), value))
                .collect::<HashMap<_, _>>(),
        ))
    }

    #[test]
    fn horizontal_rule_payloads_reject_invalid_values_and_recover_positions() {
        let cases: Vec<Value> = serde_json::from_str(include_str!(
            "../../tests/fixtures/horizontal_rule_payloads.json"
        ))
        .unwrap();
        let valid = Any::from_json(&cases[0]["payload"]["rule"].to_string()).unwrap();
        for case in cases {
            let doc = EditingDoc::new(7);
            doc.create_story("body", "AB", "Normal", "left").unwrap();
            let payload = case["payload"]
                .as_object()
                .unwrap()
                .iter()
                .map(|(key, value)| (key.clone(), Any::from_json(&value.to_string()).unwrap()))
                .collect();
            doc.apply_raw_ops(
                "body",
                vec![RawOp::InsertEmbed {
                    index: 1,
                    kind: "horizontalRule".to_owned(),
                    payload,
                    attrs: Attrs::new(),
                }],
                &EditCtx::local("", DATE),
            )
            .unwrap();
            let lowered = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default());
            if case["valid"] == true {
                assert!(lowered.is_ok(), "{}: {lowered:?}", case["name"]);
            } else {
                assert!(
                    matches!(lowered, Err(BridgeError::UnsupportedEmbed { story, index: 1 }) if story == "body"),
                    "{}",
                    case["name"]
                );
                doc.set_embed_attrs(
                    &EditCtx::local("", DATE),
                    Position::new("body", 1),
                    vec![("rule".to_owned(), valid.clone())],
                )
                .unwrap();
            }
            let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
            let LayoutBlock::Paragraph(paragraph) = &blocks[0] else {
                panic!()
            };
            let rules = &paragraph.attrs.as_ref().unwrap().horizontal_rules;
            assert_eq!(rules.len(), 1);
            assert_eq!((rules[0].pm_start, rules[0].pm_end), (2.0, 3.0));
            let Run::Text(tail) = paragraph.runs.last().unwrap() else {
                panic!()
            };
            assert_eq!(tail.text, "B");
            assert_eq!((tail.pm_start, tail.pm_end), (Some(3.0), Some(4.0)));
        }
    }

    #[test]
    fn paragraph_shading_distinguishes_automatic_background_from_text() {
        let env = RenderEnv::default();
        for (shading, expected) in [
            (json!({"pattern": "clear", "fill": {"auto": true}}), None),
            (json!({"fill": {"rgb": "auto"}}), None),
            (json!({"fill": "auto"}), None),
            (json!({"pattern": "nil", "fill": {"rgb": "123456"}}), None),
            (json!({"fill": {"rgb": "123456"}}), Some("#123456")),
            (json!({"fill": {"rgb": "000000"}}), Some("#000000")),
            (
                json!({"fill": {"auto": true, "themeColor": "accent1", "themeTint": "80"}}),
                Some("#A1B8E1"),
            ),
        ] {
            let values = BTreeMap::from([(
                "shading".to_owned(),
                Any::from_json(&shading.to_string()).unwrap(),
            )]);
            let attrs = lower_paragraph_attrs(&values, None, &env, &mut ListState::default());
            assert_eq!(attrs.shading.as_deref(), expected, "{shading}");
        }
        assert_eq!(
            resolve_color(&any_map([("auto", Any::Bool(true))]), &env).as_deref(),
            Some("#000000")
        );
    }

    #[test]
    fn list_markers_inherit_paragraph_mark_bold_italic_and_color() {
        let values = BTreeMap::from([
            ("listMarker".to_owned(), Any::String("1.".into())),
            (
                "listMarkerFontFamily".to_owned(),
                Any::String("Arial".into()),
            ),
            (
                "defaultTextFormatting".to_owned(),
                any_map([
                    ("bold", Any::Bool(true)),
                    ("italic", Any::Bool(false)),
                    ("color", any_map([("rgb", Any::String("FF0000".into()))])),
                ]),
            ),
        ]);
        let attrs = lower_paragraph_attrs(
            &values,
            None,
            &RenderEnv::default(),
            &mut ListState::default(),
        );
        assert_eq!(attrs.list_marker_font_family.as_deref(), Some("Arial"));
        assert_eq!(attrs.list_marker_bold, Some(true));
        assert_eq!(attrs.list_marker_italic, Some(false));
        assert_eq!(attrs.list_marker_color.as_deref(), Some("#FF0000"));
    }

    #[test]
    fn list_marker_level_off_overrides_paragraph_on() {
        let values = BTreeMap::from([
            ("listMarker".to_owned(), Any::String("1.".into())),
            ("listMarkerBold".to_owned(), Any::Bool(false)),
            ("listMarkerItalic".to_owned(), Any::Bool(false)),
            (
                "listMarkerColor".to_owned(),
                any_map([("rgb", Any::String("000000".into()))]),
            ),
            (
                "defaultTextFormatting".to_owned(),
                any_map([
                    ("bold", Any::Bool(true)),
                    ("italic", Any::Bool(true)),
                    ("color", any_map([("rgb", Any::String("FF0000".into()))])),
                ]),
            ),
        ]);
        let attrs = lower_paragraph_attrs(
            &values,
            None,
            &RenderEnv::default(),
            &mut ListState::default(),
        );
        assert_eq!(attrs.list_marker_bold, Some(false));
        assert_eq!(attrs.list_marker_italic, Some(false));
        assert_eq!(attrs.list_marker_color.as_deref(), Some("#000000"));
    }

    #[test]
    fn list_marker_level_on_overrides_body_off() {
        let values = BTreeMap::from([
            ("listMarker".to_owned(), Any::String("1.".into())),
            ("listMarkerBold".to_owned(), Any::Bool(true)),
            ("listMarkerItalic".to_owned(), Any::Bool(true)),
            (
                "listMarkerColor".to_owned(),
                any_map([("rgb", Any::String("FF0000".into()))]),
            ),
            (
                "defaultTextFormatting".to_owned(),
                any_map([
                    ("bold", Any::Bool(false)),
                    ("italic", Any::Bool(false)),
                    ("color", any_map([("rgb", Any::String("000000".into()))])),
                ]),
            ),
        ]);
        let attrs = lower_paragraph_attrs(
            &values,
            None,
            &RenderEnv::default(),
            &mut ListState::default(),
        );
        assert_eq!(attrs.list_marker_bold, Some(true));
        assert_eq!(attrs.list_marker_italic, Some(true));
        assert_eq!(attrs.list_marker_color.as_deref(), Some("#FF0000"));
    }

    #[test]
    fn table_cell_edges_preserve_fractional_borders_and_explicit_zero_padding() {
        let border = std::collections::HashMap::from([
            ("style".to_owned(), Any::String("single".into())),
            ("size".to_owned(), Any::Number(4.0)),
        ]);
        let edge = lower_cell_border(&border, &RenderEnv::default()).unwrap();
        assert_eq!(edge.width, Some(2.0 / 3.0));
        let cell = std::collections::HashMap::from([(
            "margins".to_owned(),
            Any::Map(
                std::collections::HashMap::from([("left".to_owned(), Any::Number(0.0))]).into(),
            ),
        )]);
        let table = std::collections::HashMap::from([
            ("left".to_owned(), Any::Number(108.0)),
            ("right".to_owned(), Any::Number(108.0)),
        ]);
        let padding = lower_cell_padding(&cell, Some(&table));
        assert_eq!(padding.left, 0.0);
        assert!((padding.right - 7.2).abs() < 1e-10);
    }

    #[test]
    fn none_format_without_level_formats_suppresses_an_existing_counter() {
        let mut state = ListState::default();
        state.counters.insert("41".to_owned(), vec![3]);
        let values = BTreeMap::from([
            (
                "numPr".to_owned(),
                any_map([("numId", Any::Number(41.0)), ("ilvl", Any::Number(0.0))]),
            ),
            ("listNumFmt".to_owned(), Any::String("none".into())),
            ("listMarker".to_owned(), Any::String("%1".into())),
        ]);
        assert_eq!(compute_list_marker(&values, &mut state), None);
        assert_eq!(state.counters["41"], [3]);
    }

    #[test]
    fn none_format_preserves_references_to_numbered_ancestors() {
        let mut state = ListState::default();
        state.counters.insert("41".to_owned(), vec![3, 0]);
        let values = BTreeMap::from([
            (
                "numPr".to_owned(),
                any_map([("numId", Any::Number(42.0)), ("ilvl", Any::Number(1.0))]),
            ),
            ("listAbstractNumId".to_owned(), Any::Number(41.0)),
            (
                "listLevelNumFmts".to_owned(),
                Any::from_json(r#"["decimal", "none"]"#).unwrap(),
            ),
            (
                "listMarker".to_owned(),
                Any::String("Parent %1 child %2".into()),
            ),
        ]);
        assert_eq!(
            compute_list_marker(&values, &mut state).as_deref(),
            Some("Parent 3 child ")
        );
    }

    fn format_range(doc: &EditingDoc, start: u32, end: u32, attrs: Vec<(&'static str, Any)>) {
        let mut txn = doc.doc.transact_mut_with(doc.client_id);
        let story = story_ref(&txn, "body").unwrap();
        let attrs: Attrs = attrs
            .into_iter()
            .map(|(key, value)| (Arc::from(key), value))
            .collect();
        story.format(&mut txn, start, end - start, attrs);
    }

    fn normalize_block_ids(value: &mut Value) {
        match value {
            Value::Array(values) => {
                for value in values {
                    normalize_block_ids(value);
                }
            }
            Value::Object(values) => {
                if values.contains_key("id") {
                    values.insert("id".to_owned(), Value::from("normalized"));
                }
                for value in values.values_mut() {
                    normalize_block_ids(value);
                }
            }
            _ => {}
        }
    }

    fn replace_story_with_paragraph(doc: &EditingDoc, story_id: &str, para_id: &str, text: &str) {
        doc.create_story(story_id, "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            story_id,
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::Insert {
                    index: 0,
                    text: text.to_owned(),
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: utf16_len(text),
                    kind: "pilcrow".to_owned(),
                    payload: vec![
                        ("paraId".to_owned(), Any::from(para_id)),
                        ("hangingIndent".to_owned(), Any::Bool(false)),
                    ],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();
    }

    #[test]
    fn native_two_by_two_table_lowers_to_expected_layout_json() {
        let doc = EditingDoc::new(41);
        for (story, para, text) in [
            ("body:t0:r0c0", "c00p", "A"),
            ("body:t0:r0c1", "c01p", "B"),
            ("body:t0:r1c0", "c10p", "C"),
            ("body:t0:r1c1", "c11p", "D"),
        ] {
            replace_story_with_paragraph(&doc, story, para, text);
        }
        doc.create_story("body", "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::InsertEmbed {
                    index: 0,
                    kind: "table".to_owned(),
                    payload: vec![
                        ("tblPr".to_owned(), Any::from_json("{}").unwrap()),
                        ("grid".to_owned(), Any::from_json("[]").unwrap()),
                        (
                            "rows".to_owned(),
                            Any::from_json(
                                r#"[
                                  {"trPr":{"isHeader":false,"trIns":{"id":"41:9","author":"Ada","date":"2025-01-01T00:00:00Z"}},"cells":[
                                    {"tcPr":{"colspan":1,"rowspan":1,"noWrap":false},"story":"body:t0:r0c0"},
                                    {"tcPr":{"colspan":1,"rowspan":1,"noWrap":false},"story":"body:t0:r0c1"}
                                  ]},
                                  {"trPr":{"isHeader":false},"cells":[
                                    {"tcPr":{"colspan":1,"rowspan":1,"noWrap":false},"story":"body:t0:r1c0"},
                                    {"tcPr":{"colspan":1,"rowspan":1,"noWrap":false},"story":"body:t0:r1c1"}
                                  ]}
                                ]"#,
                            )
                            .unwrap(),
                        ),
                    ],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();

        let mut actual = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();
        let stable_table_id = "body:table:body:t0:r0c0";
        assert_eq!(actual.pointer("/0/id"), Some(&Value::from(stable_table_id)));
        assert_eq!(
            actual.pointer("/0/rows/0/id"),
            Some(&Value::from(format!("{stable_table_id}:r0")))
        );
        let paragraph = |para_id: &str, text: &str, start: f64| {
            json!({
                "kind": "paragraph",
                "id": "placeholder",
                "paraId": para_id,
                "runs": [{
                    "kind": "text", "text": text, "fontSize": 10.0, "logicalOrder": 0,
                    "pmStart": start + 1.0, "pmEnd": start + 2.0
                }],
                "attrs": {"defaultFontSize": 10.0, "snapToGrid": false},
                "pmStart": start, "pmEnd": start + 3.0
            })
        };
        let cell = |para_id: &str, text: &str, start: f64| {
            json!({
                "id": "placeholder",
                "blocks": [paragraph(para_id, text, start)],
                "colSpan": 1.0,
                "rowSpan": 1.0,
                "padding": { "top": 0.0, "right": 0.0, "bottom": 0.0, "left": 0.0 }
            })
        };
        let mut expected = json!([{
            "kind": "table",
            "id": "placeholder",
            "tableLayout": "autofit",
            "rows": [
                {
                    "id": "placeholder", "isHeader": false,
                    "trackedIns": {
                        "revisionId": numeric_id("41:9", &RenderEnv::default()),
                        "author": "Ada", "date": "2025-01-01T00:00:00Z"
                    },
                    "cells": [cell("c00p", "A", 3.0), cell("c01p", "B", 8.0)]
                },
                {
                    "id": "placeholder", "isHeader": false,
                    "cells": [cell("c10p", "C", 15.0), cell("c11p", "D", 20.0)]
                }
            ],
            "pmStart": 0.0,
            "pmEnd": 26.0
        }]);
        normalize_block_ids(&mut actual);
        normalize_block_ids(&mut expected);
        assert_eq!(actual, expected);

        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Insert {
                    index: 0,
                    text: "prefix".to_owned(),
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 6,
                    kind: "pilcrow".to_owned(),
                    payload: vec![("paraId".to_owned(), Any::from("prefix-p"))],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        let shifted = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();
        assert_eq!(
            shifted.pointer("/1/id"),
            Some(&Value::from(stable_table_id))
        );
        assert_eq!(
            shifted.pointer("/1/rows/0/id"),
            Some(&Value::from(format!("{stable_table_id}:r0")))
        );
    }

    #[test]
    fn native_table_widths_honor_fixed_percent_and_automatic_preferences() {
        for (layout, table_width, width_type, cell_widths, expected) in [
            ("fixed", Some(9000), "dxa", [1500, 7500], [100.0, 500.0]),
            ("autofit", None, "pct", [2500, 2500], [36.0, 36.0]),
            ("autofit", None, "auto", [4500, 4500], [36.0, 36.0]),
        ] {
            let doc = EditingDoc::new(41);
            for (story, para) in [("body:t0:r0c0", "c00p"), ("body:t0:r0c1", "c01p")] {
                replace_story_with_paragraph(&doc, story, para, "Hello");
            }
            doc.create_story("body", "", "Normal", "left").unwrap();
            let tbl_pr = json!({
                "tableLayout": layout,
                "width": table_width,
                "widthType": if table_width.is_some() { "dxa" } else { "auto" }
            });
            let rows = json!([{"trPr": {}, "cells": [
                {"tcPr": {"width": cell_widths[0], "widthType": width_type},
                 "story": "body:t0:r0c0"},
                {"tcPr": {"width": cell_widths[1], "widthType": width_type},
                 "story": "body:t0:r0c1"}
            ]}]);
            doc.apply_raw_ops(
                "body",
                vec![
                    RawOp::Delete { index: 0, len: 1 },
                    RawOp::InsertEmbed {
                        index: 0,
                        kind: "table".to_owned(),
                        payload: vec![
                            (
                                "tblPr".to_owned(),
                                Any::from_json(&tbl_pr.to_string()).unwrap(),
                            ),
                            ("grid".to_owned(), Any::from_json("[4500,4500]").unwrap()),
                            (
                                "rows".to_owned(),
                                Any::from_json(&rows.to_string()).unwrap(),
                            ),
                        ],
                        attrs: Attrs::new(),
                    },
                ],
                &EditCtx::local("", DATE),
            )
            .unwrap();
            let mut blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
            let LayoutBlock::Table(table) = &mut blocks[0] else {
                panic!()
            };
            assert_eq!(table.layout_mode, None);
            assert_eq!(table.table_layout.as_deref(), Some(layout));
            assert_eq!(table.column_widths, Some(vec![300.0, 300.0]));
            for cell in &mut table.rows[0].cells {
                if width_type == "auto" {
                    assert_eq!(cell.width, None);
                    assert_eq!(cell.width_value, None);
                    assert_eq!(cell.preferred_width, None);
                    assert_eq!(cell.width_type.as_deref(), Some("auto"));
                } else if width_type == "pct" {
                    assert_eq!(cell.width, None);
                    assert_eq!(cell.width_value, Some(2500.0));
                }
                cell.min_content_width = Some(36.0);
                cell.max_content_width = Some(36.0);
            }
            let widths = docx_layout::table_grid::resolve_table_column_widths(table, 601.333_333);
            for (actual, expected) in widths.iter().zip(expected) {
                assert!((actual - expected).abs() < 1e-6, "{width_type}: {widths:?}");
            }
        }
    }

    #[test]
    fn docx_table_with_unmeasured_image_keeps_main_grid_through_lowering_and_measurement() {
        for layout in [None, Some("autofit"), Some("fixed")] {
            let doc = EditingDoc::new(41);
            let story = "body:t0:r0c0";
            replace_story_with_paragraph(&doc, story, "cell-p", "x");
            doc.apply_raw_ops(
                story,
                vec![RawOp::InsertEmbed {
                    index: 0,
                    kind: "image".to_owned(),
                    payload: vec![
                        ("src".to_owned(), Any::from("image")),
                        ("width".to_owned(), Any::Number(200.0)),
                        ("height".to_owned(), Any::Number(40.0)),
                    ],
                    attrs: Attrs::new(),
                }],
                &EditCtx::local("", DATE),
            )
            .unwrap();
            doc.create_story("body", "", "Normal", "left").unwrap();
            let tbl_pr = json!({"tableLayout": layout});
            let rows = json!([{"trPr": {}, "cells": [
                {"tcPr": {"width": 1500, "widthType": "dxa"}, "story": story}
            ]}]);
            doc.apply_raw_ops(
                "body",
                vec![
                    RawOp::Delete { index: 0, len: 1 },
                    RawOp::InsertEmbed {
                        index: 0,
                        kind: "table".to_owned(),
                        payload: vec![
                            (
                                "tblPr".to_owned(),
                                Any::from_json(&tbl_pr.to_string()).unwrap(),
                            ),
                            ("grid".to_owned(), Any::from_json("[4500]").unwrap()),
                            (
                                "rows".to_owned(),
                                Any::from_json(&rows.to_string()).unwrap(),
                            ),
                        ],
                        attrs: Attrs::new(),
                    },
                ],
                &EditCtx::local("", DATE),
            )
            .unwrap();
            let mut blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
            let LayoutBlock::Table(table) = &blocks[0] else {
                panic!()
            };
            assert_eq!(table.layout_mode, None);
            assert_eq!(
                table.table_layout.as_deref(),
                Some(layout.unwrap_or("autofit"))
            );
            assert_eq!(table.rows[0].cells[0].width, Some(100.0));
            assert_eq!(
                docx_layout::table_grid::resolve_table_column_widths(table, 600.0),
                vec![300.0]
            );
            let LayoutBlock::Paragraph(paragraph) = &table.rows[0].cells[0].blocks[0] else {
                panic!()
            };
            let Run::Image(image) = &paragraph.runs[0] else {
                panic!()
            };
            assert_eq!(image.width, 200.0);
            let config = docx_layout::measure_blocks::MeasurementConfig {
                defaults: json!({"fontFamily": "Arial", "fontSize": 12}),
                ..Default::default()
            };
            let docx_layout::types::BlockExtent::Table(measured) =
                docx_layout::measure_blocks::measure_block(&mut blocks[0], 600.0, &config).unwrap()
            else {
                panic!()
            };
            assert_eq!(measured.column_widths, vec![300.0]);
            assert_eq!(measured.total_width, 300.0);
            assert_eq!(measured.rows[0].cells[0].width, 300.0);
        }
    }

    #[test]
    fn native_note_ref_lowers_to_a_superscript_footnote_run() {
        let doc = EditingDoc::new(42);
        doc.create_story("body", "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::Insert {
                    index: 0,
                    text: "See ".to_owned(),
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 4,
                    kind: "noteRef".to_owned(),
                    payload: vec![("footnoteRefId".to_owned(), Any::Number(5.0))],
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 5,
                    kind: "pilcrow".to_owned(),
                    payload: vec![("paraId".to_owned(), Any::from("body-p"))],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        replace_story_with_paragraph(&doc, "fn:5", "fn-p", "Footnote text");

        let body = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();
        assert_eq!(body[0]["runs"][1]["text"], json!("5"));
        assert_eq!(body[0]["runs"][1]["footnoteRefId"], json!(5.0));
        assert_eq!(body[0]["runs"][1]["superscript"], json!(true));

        let footnote = yrs_doc_to_layout_blocks(&doc, "fn:5", &RenderEnv::default()).unwrap();
        assert_eq!(footnote.len(), 1);
    }

    #[test]
    fn native_multi_digit_note_ref_occupies_one_position() {
        let doc = EditingDoc::new(44);
        doc.create_story("body", "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::Insert {
                    index: 0,
                    text: "A".to_owned(),
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 1,
                    kind: "noteRef".to_owned(),
                    payload: vec![("footnoteRefId".to_owned(), Any::Number(12.0))],
                    attrs: Attrs::new(),
                },
                RawOp::Insert {
                    index: 2,
                    text: "B".to_owned(),
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 3,
                    kind: "pilcrow".to_owned(),
                    payload: vec![("paraId".to_owned(), Any::from("body-p"))],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        replace_story_with_paragraph(&doc, "fn:12", "fn-p", "Footnote text");

        let body = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();
        assert_eq!(body[0]["runs"][1]["text"], json!("12"));
        assert_eq!(body[0]["runs"][1]["pmStart"], json!(2.0));
        assert_eq!(body[0]["runs"][1]["pmEnd"], json!(3.0));
        assert_eq!(body[0]["runs"][2]["text"], json!("B"));
        assert_eq!(body[0]["runs"][2]["pmStart"], json!(3.0));
        assert_eq!(body[0]["pmEnd"], json!(5.0));
    }

    #[test]
    fn native_page_and_column_break_embeds_lower_without_fallback() {
        let doc = EditingDoc::new(43);
        doc.create_story("body", "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::InsertEmbed {
                    index: 0,
                    kind: "pageBreak".to_owned(),
                    payload: Vec::new(),
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 1,
                    kind: "columnBreak".to_owned(),
                    payload: Vec::new(),
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();

        let value = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();
        assert_eq!(
            value,
            json!([
                {
                    "kind": "pageBreak", "id": "body:pageBreak:0",
                    "pmStart": 0.0, "pmEnd": 1.0
                },
                {
                    "kind": "columnBreak", "id": "body:columnBreak:1",
                    "pmStart": 1.0, "pmEnd": 2.0
                }
            ])
        );
    }

    #[test]
    fn page_break_only_list_paragraphs_hide_the_marker_until_text_is_added() {
        for kind in ["pageBreak", "columnBreak"] {
            let doc = EditingDoc::new(43);
            doc.create_story("body", "", "Normal", "left").unwrap();
            doc.apply_raw_ops(
                "body",
                vec![
                    RawOp::Delete { index: 0, len: 1 },
                    RawOp::InsertEmbed {
                        index: 0,
                        kind: "pilcrow".to_owned(),
                        payload: vec![("listMarker".to_owned(), Any::from("2."))],
                        attrs: Attrs::new(),
                    },
                    RawOp::InsertEmbed {
                        index: 1,
                        kind: "pilcrow".to_owned(),
                        payload: vec![("listMarker".to_owned(), Any::from("■"))],
                        attrs: Attrs::new(),
                    },
                    RawOp::InsertEmbed {
                        index: 2,
                        kind: kind.to_owned(),
                        payload: Vec::new(),
                        attrs: Attrs::new(),
                    },
                ],
                &EditCtx::local("", DATE),
            )
            .unwrap();

            let lower = || {
                serde_json::to_value(
                    yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
                )
                .unwrap()
            };
            let blocks = lower();
            assert_eq!(blocks[2]["kind"], kind);
            assert_eq!(blocks[0]["attrs"]["listMarker"], "2.");
            assert_ne!(blocks[0]["attrs"]["listMarkerHidden"], true);
            assert_eq!(blocks[1]["attrs"]["listMarker"], "■");
            assert_eq!(
                blocks[1]["attrs"]["listMarkerHidden"] == true,
                kind == "pageBreak"
            );

            doc.apply_raw_ops(
                "body",
                vec![RawOp::Insert {
                    index: 1,
                    text: "Item".to_owned(),
                    attrs: Attrs::new(),
                }],
                &EditCtx::local("", DATE),
            )
            .unwrap();
            let blocks = lower();
            assert_eq!(blocks[1]["attrs"]["listMarker"], "■");
            assert_ne!(blocks[1]["attrs"]["listMarkerHidden"], true);
        }
    }

    #[test]
    fn inline_textless_shape_stays_one_paragraph_with_native_payload() {
        let doc = EditingDoc::new(60);
        doc.create_story("body", "AB", "Normal", "left").unwrap();
        let shape = json!({
            "shapeType": "rect",
            "size": {"width": 914400, "height": 457200},
            "geometryPath": [
                {"type": "move", "x": 0.1, "y": 0.2},
                {"type": "line", "x": 0.9, "y": 0.8},
                {"type": "close"}
            ],
            "fill": {"type": "solid", "color": {"rgb": "112233"}},
            "outline": {"color": {"rgb": "445566"}, "width": 19050},
            "transform": {"rotation": 12, "flipH": true},
            "children": [
                {"shapeType": "ellipse", "size": {"width": 91440, "height": 91440}}
            ]
        });
        doc.apply_raw_ops(
            "body",
            vec![RawOp::InsertEmbed {
                index: 1,
                kind: "shape".to_owned(),
                payload: vec![("shapeJson".to_owned(), Any::from(shape.to_string()))],
                attrs: Attrs::new(),
            }],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
        assert_eq!(blocks.len(), 1);
        let LayoutBlock::Paragraph(paragraph) = &blocks[0] else {
            panic!("expected single paragraph");
        };
        assert_eq!(paragraph.runs.len(), 3);
        let Run::Text(before) = &paragraph.runs[0] else {
            panic!("expected leading text");
        };
        assert_eq!(before.text, "A");
        let Run::Image(image) = &paragraph.runs[1] else {
            panic!("expected inline shape image");
        };
        assert_eq!(image.wrap_type.as_deref(), Some("inline"));
        assert_eq!(image.display_mode.as_deref(), Some("inline"));
        let inline = image.inline_shape.as_ref().expect("native payload");
        assert_eq!(inline.geometry_path.len(), 3);
        assert_eq!(inline.geometry_path[0]["x"], 0.1);
        assert_eq!(inline.fill.as_ref().unwrap()["color"], "#112233");
        assert_eq!(inline.stroke.as_ref().unwrap()["color"], "#445566");
        assert_eq!(inline.transform.as_ref().unwrap()["flipH"], true);
        assert_eq!(inline.children.len(), 1);
        assert_eq!((image.width, image.height), (96.0, 48.0));
        assert_eq!((image.pm_start, image.pm_end), (Some(2.0), Some(3.0)));
        let Run::Text(after) = &paragraph.runs[2] else {
            panic!("expected trailing text");
        };
        assert_eq!(after.text, "B");
        assert_eq!((after.pm_start, after.pm_end), (Some(3.0), Some(4.0)));
    }

    fn shape_embed_blocks(seed: u64, shape: Value) -> Vec<LayoutBlock> {
        let doc = EditingDoc::new(seed);
        doc.create_story("body", "AB", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![RawOp::InsertEmbed {
                index: 1,
                kind: "shape".to_owned(),
                payload: vec![("shapeJson".to_owned(), Any::from(shape.to_string()))],
                attrs: Attrs::new(),
            }],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap()
    }

    #[test]
    fn in_flow_text_shape_splits_paragraph() {
        let blocks = shape_embed_blocks(
            61,
            json!({
                "shapeType": "rect",
                "size": {"width": 914400, "height": 457200},
                "textBody": {"content": [{
                    "paraId": "p1",
                    "content": [{
                        "type": "run",
                        "content": [{"type": "text", "text": "hi"}]
                    }]
                }]}
            }),
        );
        assert_eq!(blocks.len(), 3);
        assert!(matches!(blocks[0], LayoutBlock::Paragraph(_)));
        assert!(matches!(blocks[1], LayoutBlock::Shape(_)));
        assert!(matches!(blocks[2], LayoutBlock::Paragraph(_)));
    }

    #[test]
    fn anchored_shape_leaves_its_paragraph_whole() {
        let blocks = shape_embed_blocks(
            64,
            json!({
                "shapeType": "rect",
                "size": {"width": 914400, "height": 457200},
                "position": {
                    "horizontal": {"relativeTo": "column", "posOffset": 0},
                    "vertical": {"relativeTo": "paragraph", "posOffset": 0}
                },
                "wrap": {"type": "square"}
            }),
        );
        assert_eq!(blocks.len(), 2);
        assert!(matches!(blocks[0], LayoutBlock::Shape(_)));
        let LayoutBlock::Paragraph(paragraph) = &blocks[1] else {
            panic!("expected one whole paragraph");
        };
        assert_eq!(paragraph.runs.len(), 2);
        assert_eq!(paragraph.pm_start, Some(0.0));
        assert_eq!(paragraph.pm_end, Some(5.0));
    }

    #[test]
    fn anchor_that_lost_its_position_still_leaves_its_paragraph_whole() {
        let blocks = shape_embed_blocks(
            66,
            json!({
                "shapeType": "rect",
                "size": {"width": 914400, "height": 457200},
                "wrap": {"type": "square"}
            }),
        );
        assert_eq!(blocks.len(), 2);
        assert!(matches!(blocks[0], LayoutBlock::Shape(_)));
        let LayoutBlock::Paragraph(paragraph) = &blocks[1] else {
            panic!("expected one whole paragraph");
        };
        assert_eq!(paragraph.runs.len(), 2);
    }

    #[test]
    fn paragraph_anchoring_only_shapes_still_charges_a_line() {
        let doc = EditingDoc::new(65);
        doc.create_story("body", "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![RawOp::InsertEmbed {
                index: 0,
                kind: "shape".to_owned(),
                payload: vec![(
                    "shapeJson".to_owned(),
                    Any::from(
                        json!({
                            "shapeType": "rect",
                            "size": {"width": 914400, "height": 457200},
                            "position": {
                                "horizontal": {"relativeTo": "column", "posOffset": 0},
                                "vertical": {"relativeTo": "paragraph", "posOffset": 0}
                            },
                            "wrap": {"type": "none"}
                        })
                        .to_string(),
                    ),
                )],
                attrs: Attrs::new(),
            }],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
        assert_eq!(blocks.len(), 2);
        assert!(matches!(blocks[0], LayoutBlock::Shape(_)));
        assert!(matches!(blocks[1], LayoutBlock::Paragraph(_)));
    }

    #[test]
    fn inline_shape_preserves_pm_revision_and_hidden() {
        let shape = json!({
            "shapeType": "rect",
            "size": {"width": 914400, "height": 457200}
        });
        let doc = EditingDoc::new(62);
        doc.create_story("body", "AB", "Normal", "left").unwrap();
        let mut revision_attrs = Attrs::new();
        revision_attrs.insert(
            Arc::from("ins"),
            any_map([
                ("id", Any::Number(7.0)),
                ("author", Any::from("Ada")),
                ("date", Any::from(DATE)),
            ]),
        );
        doc.apply_raw_ops(
            "body",
            vec![RawOp::InsertEmbed {
                index: 1,
                kind: "shape".to_owned(),
                payload: vec![("shapeJson".to_owned(), Any::from(shape.to_string()))],
                attrs: revision_attrs,
            }],
            &EditCtx::local("", DATE),
        )
        .unwrap();
        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
        assert_eq!(blocks.len(), 1);
        let LayoutBlock::Paragraph(paragraph) = &blocks[0] else {
            panic!();
        };
        let Run::Image(image) = &paragraph.runs[1] else {
            panic!();
        };
        assert_eq!(image.is_insertion, Some(true));
        assert_eq!(image.change_author.as_deref(), Some("Ada"));
        assert!(image.inline_shape.is_some());
        let hidden_doc = EditingDoc::new(63);
        hidden_doc
            .create_story("body", "AB", "Normal", "left")
            .unwrap();
        let mut hidden_attrs = Attrs::new();
        hidden_attrs.insert(Arc::from("hidden"), Any::Bool(true));
        hidden_doc
            .apply_raw_ops(
                "body",
                vec![RawOp::InsertEmbed {
                    index: 1,
                    kind: "shape".to_owned(),
                    payload: vec![("shapeJson".to_owned(), Any::from(shape.to_string()))],
                    attrs: hidden_attrs,
                }],
                &EditCtx::local("", DATE),
            )
            .unwrap();
        let blocks = yrs_doc_to_layout_blocks(&hidden_doc, "body", &RenderEnv::default()).unwrap();
        let LayoutBlock::Paragraph(paragraph) = &blocks[0] else {
            panic!();
        };
        assert!(
            !paragraph
                .runs
                .iter()
                .any(|run| matches!(run, Run::Image(_))),
            "hidden inline shape filtered"
        );
        let shown = yrs_doc_to_layout_blocks(
            &hidden_doc,
            "body",
            &RenderEnv {
                show_hidden_text: true,
                ..RenderEnv::default()
            },
        )
        .unwrap();
        let LayoutBlock::Paragraph(paragraph) = &shown[0] else {
            panic!();
        };
        assert!(
            paragraph
                .runs
                .iter()
                .any(|run| matches!(run, Run::Image(_))),
            "show_hidden_text keeps inline shape"
        );
    }

    #[test]
    fn native_shape_embed_lowers_raw_document_payload() {
        let doc = EditingDoc::new(44);
        doc.create_story("body", "", "Normal", "left").unwrap();
        let shape = json!({
            "type": "shape",
            "shapeType": "diamond",
            "size": {"width": 914400, "height": 457200},
            "fill": {"type": "solid", "color": {"rgb": "336699"}},
            "textBody": {"content": [{
                "content": [{
                    "type": "run",
                    "content": [{"type": "text", "text": "Native"}]
                }]
            }]}
        });
        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::InsertEmbed {
                    index: 0,
                    kind: "shape".to_owned(),
                    payload: vec![("shapeJson".to_owned(), Any::from(shape.to_string()))],
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 1,
                    kind: "pilcrow".to_owned(),
                    payload: vec![("paraId".to_owned(), Any::from("shape-anchor"))],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();

        let value = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();

        assert_eq!(value[0]["kind"], "shape");
        assert_eq!(value[0]["shapeType"], "diamond");
        assert_eq!(value[0]["fill"]["color"], "#336699");
        assert_eq!(value[0]["innerText"][0]["runs"][0]["text"], "Native");
        assert_eq!(value[0]["pmStart"], 1.0);
        assert_eq!(value[0]["pmEnd"], 2.0);
    }

    #[test]
    fn legacy_text_box_payload_lowers_to_a_rectangle() {
        let doc = EditingDoc::new(45);
        doc.create_story("body", "", "Normal", "left").unwrap();
        doc.apply_raw_ops(
            "body",
            vec![
                RawOp::Delete { index: 0, len: 1 },
                RawOp::InsertEmbed {
                    index: 0,
                    kind: "shape".to_owned(),
                    payload: vec![
                        ("shapeType".to_owned(), Any::from("textBox")),
                        ("width".to_owned(), Any::from(200.0)),
                        ("height".to_owned(), Any::from(100.0)),
                    ],
                    attrs: Attrs::new(),
                },
                RawOp::InsertEmbed {
                    index: 1,
                    kind: "pilcrow".to_owned(),
                    payload: vec![("paraId".to_owned(), Any::from("shape-anchor"))],
                    attrs: Attrs::new(),
                },
            ],
            &EditCtx::local("", DATE),
        )
        .unwrap();

        let value = serde_json::to_value(
            yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap(),
        )
        .unwrap();

        assert_eq!(value[0]["kind"], "shape");
        assert_eq!(value[0]["shapeType"], "textBox");
        assert_eq!(value[0]["geometryPath"].as_array().unwrap().len(), 5);
        assert_eq!(value[0]["width"], 200.0);
        assert_eq!(value[0]["height"], 100.0);
    }

    #[test]
    fn position_formula_accounts_for_paragraph_node_sizes() {
        // Story: "a😀¶¶wxyz¶". Paragraph node sizes are UTF-16 length plus two.
        assert_eq!(utf16_len("a😀"), 3);
        let paragraphs = [(0, 3, 0), (4, 4, 1), (5, 9, 2)];
        let expected_blocks = [(0, 5), (5, 7), (7, 13)];
        let actual: Vec<(u64, u64)> = paragraphs
            .into_iter()
            .map(|(start, pilcrow, before)| {
                (
                    pm_position(start, before) - 1,
                    pm_position(pilcrow, before) + 1,
                )
            })
            .collect();
        assert_eq!(actual, expected_blocks);

        // The non-empty runs sit one position after their paragraph opening tags.
        assert_eq!(pm_position(0, 0), 1);
        assert_eq!(pm_position(3, 0), 4);
        assert_eq!(pm_position(5, 2), 8);
        assert_eq!(pm_position(9, 2), 12);
    }

    #[test]
    fn lowers_authored_run_units_and_passive_formats() {
        let attributes: Attrs = [
            (
                Arc::from("fontSize"),
                any_map([("size", Any::Number(22.0)), ("sizeCs", Any::Number(24.0))]),
            ),
            (
                Arc::from("fontFamily"),
                any_map([
                    ("ascii", Any::from("Aptos")),
                    ("hAnsi", Any::from("Aptos")),
                    ("cs", Any::from("Arial")),
                    ("hint", Any::from("cs")),
                ]),
            ),
            (
                Arc::from("characterSpacing"),
                any_map([
                    ("spacing", Any::Number(15.0)),
                    ("position", Any::Number(12.0)),
                    ("scale", Any::Number(90.0)),
                    ("kerning", Any::Number(16.0)),
                ]),
            ),
            (
                Arc::from("language"),
                any_map([
                    ("latin", Any::from("en-US")),
                    ("eastAsia", Any::from("ja-JP")),
                    ("bidi", Any::from("ar-SA")),
                ]),
            ),
            (Arc::from("highlight"), Any::from("yellow")),
            (Arc::from("superscript"), Any::Bool(true)),
            (Arc::from("allCaps"), Any::Bool(true)),
            (Arc::from("smallCaps"), Any::Bool(true)),
            (Arc::from("imprint"), Any::Bool(true)),
            (Arc::from("emboss"), Any::Bool(true)),
            (Arc::from("textShadow"), Any::Bool(true)),
            (Arc::from("textOutline"), Any::Bool(true)),
            (Arc::from("hidden"), Any::Bool(true)),
            (Arc::from("rtl"), Any::Bool(true)),
            (
                Arc::from("complexScript"),
                any_map([
                    ("enabled", Any::Bool(true)),
                    ("bold", Any::Bool(true)),
                    ("italic", Any::Bool(false)),
                ]),
            ),
            (
                Arc::from("emphasisMark"),
                any_map([("type", Any::from("underDot"))]),
            ),
            (
                Arc::from("textEffect"),
                any_map([("effect", Any::from("shimmer"))]),
            ),
            (
                Arc::from("modernTextEffects"),
                any_map([(
                    "effects",
                    any_map([(
                        "glow",
                        any_map([
                            ("color", Any::from("#00FF00")),
                            ("radius", Any::Number(3.0)),
                        ]),
                    )]),
                )]),
            ),
        ]
        .into_iter()
        .collect();

        let actual = serde_json::to_value(lower_run_formatting(
            Some(&attributes),
            &RenderEnv::default(),
        ))
        .unwrap();
        assert_eq!(
            actual,
            json!({
                "highlight": "#FFFF00",
                "fontFamily": "Arial",
                "fontSlots": {
                    "ascii": "Aptos", "hAnsi": "Aptos", "cs": "Arial", "hint": "cs"
                },
                "fontSize": 12.0,
                "fontSizeCs": 12.0,
                "boldCs": true,
                "italicCs": false,
                "complexScript": true,
                "language": { "latin": "en-US", "eastAsia": "ja-JP", "bidi": "ar-SA" },
                "letterSpacing": 1.0,
                "superscript": true,
                "allCaps": true,
                "smallCaps": true,
                "positionPx": 8.0,
                "horizontalScale": 90.0,
                "kerningMinPt": 8.0,
                "imprint": true,
                "emboss": true,
                "textShadow": true,
                "textOutline": true,
                "emphasisMark": "underDot",
                "hidden": true,
                "rtl": true,
                "textEffect": "shimmer",
                "modernEffects": { "glow": { "color": "#00FF00", "radius": 3 } }
            })
        );
    }

    #[test]
    fn representative_story_lowers_to_expected_layout_json() {
        let doc = EditingDoc::new(41);
        doc.create_story("body", "Alpha link Omega", "Normal", "left")
            .unwrap();
        let split = doc
            .split_paragraph(
                &EditCtx::local("Bob", DATE).suggesting(),
                Position::new("body", 10),
                None,
            )
            .unwrap();
        // The first half keeps its ID and the second receives a new one.
        let first_para = split.first_para_id.clone();
        let second_para = split.second_para_id.clone();

        let direct = EditCtx::local("", DATE);
        doc.toggle_format(&direct, StoryRange::new("body", 0, 5), SimpleFormat::Bold)
            .unwrap();
        doc.toggle_format(
            &direct,
            StoryRange::new("body", 6, 10),
            SimpleFormat::Italic,
        )
        .unwrap();
        format_range(
            &doc,
            0,
            5,
            vec![("textColor", any_map([("themeColor", Any::from("accent1"))]))],
        );
        format_range(
            &doc,
            6,
            10,
            vec![
                (
                    "underline",
                    any_map([
                        ("style", Any::from("single")),
                        ("color", any_map([("rgb", Any::from("00FF00"))])),
                    ]),
                ),
                ("textColor", any_map([("rgb", Any::from("0563C1"))])),
                (
                    "hyperlink",
                    any_map([
                        ("href", Any::from("https://example.test")),
                        ("tooltip", Any::from("Example")),
                    ]),
                ),
            ],
        );

        doc.set_paragraph_attr(&first_para, "pStyle", Any::from("TOC1"))
            .unwrap();
        doc.set_paragraph_attr(&first_para, "alignment", Any::from("both"))
            .unwrap();
        doc.set_paragraph_attr(&first_para, "spaceBefore", Any::Number(120.0))
            .unwrap();
        doc.set_paragraph_attr(&first_para, "spaceAfter", Any::Number(240.0))
            .unwrap();
        doc.set_paragraph_attr(&first_para, "lineSpacing", Any::Number(360.0))
            .unwrap();
        doc.set_paragraph_attr(&first_para, "lineSpacingRule", Any::from("auto"))
            .unwrap();
        doc.set_paragraph_attr(
            &first_para,
            "spacingExplicit",
            any_map([("before", Any::Bool(true)), ("after", Any::Bool(false))]),
        )
        .unwrap();
        doc.set_paragraph_attr(
            &first_para,
            "numPr",
            any_map([("numId", Any::Number(7.0)), ("ilvl", Any::Number(1.0))]),
        )
        .unwrap();
        doc.set_paragraph_attr(
            &first_para,
            "tabs",
            Any::Array(Arc::from([any_map([
                ("alignment", Any::from("left")),
                ("position", Any::Number(720.0)),
                ("leader", Any::from("dot")),
            ])])),
        )
        .unwrap();
        for key in [
            "keepNext",
            "keepLines",
            "pageBreakBefore",
            "contextualSpacing",
            "bidi",
        ] {
            doc.set_paragraph_attr(&first_para, key, Any::Bool(true))
                .unwrap();
        }

        doc.set_paragraph_attr(&second_para, "alignment", Any::from("right"))
            .unwrap();
        doc.set_paragraph_attr(
            &second_para,
            "defaultTextFormatting",
            any_map([
                (
                    "fontFamily",
                    any_map([
                        ("ascii", Any::from("Courier New")),
                        ("hAnsi", Any::from("Courier New")),
                    ]),
                ),
                ("fontSize", Any::Number(20.0)),
            ]),
        )
        .unwrap();

        let insertion_id = doc
            .insert_text(
                &EditCtx::local("Alice", DATE).suggesting(),
                Position::new("body", 12),
                "NEW",
                FormatPolicy::Inherit,
            )
            .unwrap()
            .revision_ids
            .into_iter()
            .next()
            .unwrap();
        let comment_id = doc
            .add_comment(
                &[StoryRange::new("body", 6, 10)],
                "Reviewer",
                DATE,
                Any::from("anchor"),
            )
            .unwrap();

        assert_eq!(first_para, "41:0");
        assert_eq!(second_para, "41:1");
        assert_eq!(insertion_id, "41:3");
        assert_eq!(comment_id, "41:4");
        let env = RenderEnv {
            default_tab_stop_twips: Some(720.0),
            numeric_ids: BTreeMap::from([
                ("41:2".to_owned(), 2.0),
                (insertion_id, 3.0),
                (comment_id, 4.0),
            ]),
            ..RenderEnv::default()
        };

        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &env).unwrap();
        let mut actual = serde_json::to_value(blocks).unwrap();
        let mut expected = json!([
            {
                "kind": "paragraph",
                "id": "block-1",
                "paraId": "41:0",
                "runs": [
                    {
                        "kind": "text", "text": "Alpha", "bold": true, "fontSize": 10.0,
                        "color": "#4472C4", "logicalOrder": 0, "pmStart": 1.0, "pmEnd": 6.0
                    },
                    {
                        "kind": "text", "text": " ", "fontSize": 10.0, "logicalOrder": 1,
                        "pmStart": 6.0, "pmEnd": 7.0
                    },
                    {
                        "kind": "text", "text": "link", "italic": true, "fontSize": 10.0,
                        "color": "#0563C1", "underline": { "style": "single", "color": "#00FF00" },
                        "hyperlink": {
                            "href": "https://example.test", "tooltip": "Example",
                            "noDefaultStyle": true
                        },
                        "commentIds": [4.0], "logicalOrder": 2,
                        "pmStart": 7.0, "pmEnd": 11.0
                    }
                ],
                "attrs": {
                    "alignment": "justify",
                    "spacing": {
                        "before": 8.0, "after": 16.0, "line": 1.5,
                        "lineUnit": "multiplier", "lineRule": "auto"
                    },
                    "spacingExplicit": { "before": true, "after": false },
                    "indent": { "left": 96.0, "hanging": 24.0 },
                    "keepNext": true, "keepLines": true, "pageBreakBefore": true,
                    "styleId": "TOC1", "contextualSpacing": true, "bidi": true,
                    "tabs": [{ "val": "start", "pos": 720.0, "leader": "dot" }],
                    "numPr": { "numId": 7.0, "ilvl": 1.0 },
                    "listMarker": "1.",
                    "listMarkerRevision": "ins",
                    "defaultTabStopTwips": 720.0,
                    "defaultFontSize": 10.0,
                    "pPrIns": { "revisionId": 2.0, "author": "Bob", "date": DATE }
                },
                "pmStart": 0.0, "pmEnd": 12.0
            },
            {
                "kind": "paragraph",
                "id": "block-2",
                "paraId": "41:1",
                "runs": [
                    {
                        "kind": "text", "text": " ", "fontFamily": "Courier New",
                        "fontSlots": { "ascii": "Courier New", "hAnsi": "Courier New" },
                        "fontSize": 10.0, "logicalOrder": 0, "pmStart": 13.0, "pmEnd": 14.0
                    },
                    {
                        "kind": "text", "text": "NEW", "fontFamily": "Courier New",
                        "fontSlots": { "ascii": "Courier New", "hAnsi": "Courier New" },
                        "fontSize": 10.0, "isInsertion": true, "changeAuthor": "Alice",
                        "changeDate": DATE, "changeRevisionId": 3.0,
                        "logicalOrder": 1, "pmStart": 14.0, "pmEnd": 17.0
                    },
                    {
                        "kind": "text", "text": "Omega", "fontFamily": "Courier New",
                        "fontSlots": { "ascii": "Courier New", "hAnsi": "Courier New" },
                        "fontSize": 10.0, "logicalOrder": 2, "pmStart": 17.0, "pmEnd": 22.0
                    }
                ],
                "attrs": {
                    "alignment": "right", "styleId": "Normal",
                    "defaultTabStopTwips": 720.0, "defaultFontSize": 10.0,
                    "defaultFontFamily": "Courier New"
                },
                "pmStart": 12.0, "pmEnd": 23.0
            }
        ]);
        normalize_block_ids(&mut actual);
        normalize_block_ids(&mut expected);
        assert_eq!(actual, expected);
        assert_eq!(
            serde_json::to_vec(&actual).unwrap(),
            serde_json::to_vec(&expected).unwrap(),
            "normalized LayoutBlock[] JSON must be byte-identical"
        );
    }

    #[test]
    fn section_break_pilcrows_emit_section_break_blocks_with_margin_cascade() {
        let doc = EditingDoc::new(47);
        doc.create_story("body", "onetwothree", "Normal", "left")
            .unwrap();
        let direct = EditCtx::local("", DATE);
        let split = doc
            .split_paragraph(&direct, Position::new("body", 3), None)
            .unwrap();
        let first = split.first_para_id.clone();
        let split_two = doc
            .split_paragraph(&direct, Position::new("body", 7), None)
            .unwrap();
        let second = split_two.first_para_id.clone();
        assert_eq!(first, "47:0");
        assert_eq!(second, "47:1");

        // Section 1: full sectPr — page size, one overridden margin, columns.
        doc.set_paragraph_attr(
            &first,
            "sectPr",
            any_map([
                ("sectionStart", Any::from("nextPage")),
                ("pageWidth", Any::Number(15840.0)),
                ("pageHeight", Any::Number(12240.0)),
                ("orientation", Any::from("landscape")),
                ("marginTop", Any::Number(720.0)),
                ("columnCount", Any::Number(2.0)),
                ("columnSpace", Any::Number(360.0)),
                ("separator", Any::Bool(true)),
            ]),
        )
        .unwrap();
        // Section 2: break type from the `sectionBreakType` attr; its sectPr
        // overrides only the left margin — the other sides must inherit from
        // section 1's cascade (top 720), not reset to the OOXML default.
        doc.set_paragraph_attr(&second, "sectionBreakType", Any::from("continuous"))
            .unwrap();
        doc.set_paragraph_attr(
            &second,
            "sectPr",
            any_map([("marginLeft", Any::Number(2880.0))]),
        )
        .unwrap();

        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
        let value = serde_json::to_value(&blocks).unwrap();
        let kinds: Vec<&str> = value
            .as_array()
            .unwrap()
            .iter()
            .map(|block| block["kind"].as_str().unwrap())
            .collect();
        assert_eq!(
            kinds,
            [
                "paragraph",
                "sectionBreak",
                "paragraph",
                "sectionBreak",
                "paragraph"
            ]
        );
        assert_eq!(
            value[1],
            json!({
                "kind": "sectionBreak",
                "id": "sect:47:0",
                "type": "nextPage",
                "pageSize": { "w": 1056.0, "h": 816.0 },
                "margins": { "top": 48.0, "right": 96.0, "bottom": 96.0, "left": 96.0 },
                "columns": { "count": 2.0, "gap": 24.0, "equalWidth": true, "separator": true }
            })
        );
        assert_eq!(
            value[3],
            json!({
                "kind": "sectionBreak",
                "id": "sect:47:1",
                "type": "continuous",
                "margins": { "top": 48.0, "right": 96.0, "bottom": 96.0, "left": 192.0 }
            })
        );
    }

    #[test]
    fn bare_section_break_type_emits_a_type_only_section_break_block() {
        let doc = EditingDoc::new(48);
        let para = doc.create_story("body", "end", "Normal", "left").unwrap();
        doc.set_paragraph_attr(&para, "sectionBreakType", Any::from("oddPage"))
            .unwrap();

        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
        let value = serde_json::to_value(&blocks).unwrap();
        assert_eq!(value.as_array().unwrap().len(), 2);
        assert_eq!(
            value[1],
            json!({ "kind": "sectionBreak", "id": format!("sect:{para}"), "type": "oddPage" })
        );
    }

    #[test]
    fn next_column_section_start_reaches_the_layout_block() {
        let doc = EditingDoc::new(49);
        let para = doc.create_story("body", "end", "Normal", "left").unwrap();
        doc.set_paragraph_attr(
            &para,
            "sectPr",
            any_map([
                ("sectionStart", Any::from("nextColumn")),
                ("columnCount", Any::Number(2.0)),
                ("columnSpace", Any::Number(360.0)),
            ]),
        )
        .unwrap();

        let blocks = yrs_doc_to_layout_blocks(&doc, "body", &RenderEnv::default()).unwrap();
        let value = serde_json::to_value(&blocks).unwrap();
        assert_eq!(
            value[1],
            json!({
                "kind": "sectionBreak",
                "id": format!("sect:{para}"),
                "type": "nextColumn",
                "columns": { "count": 2.0, "gap": 24.0, "equalWidth": true }
            })
        );
    }

    #[test]
    fn authored_widow_control_off_reaches_the_layout_attrs() {
        let doc = EditingDoc::new(49);
        let para = doc.create_story("body", "text", "Normal", "left").unwrap();
        let attrs = |doc: &EditingDoc| {
            let blocks = yrs_doc_to_layout_blocks(doc, "body", &RenderEnv::default()).unwrap();
            serde_json::to_value(&blocks).unwrap()[0]["attrs"].clone()
        };

        assert_eq!(attrs(&doc).get("widowControl"), None);

        doc.set_paragraph_attr(&para, "widowControl", Any::Null)
            .unwrap();
        assert_eq!(attrs(&doc).get("widowControl"), None);

        doc.set_paragraph_attr(&para, "widowControl", Any::Bool(true))
            .unwrap();
        assert_eq!(attrs(&doc).get("widowControl"), None);

        doc.set_paragraph_attr(&para, "widowControl", Any::Bool(false))
            .unwrap();
        assert_eq!(attrs(&doc)["widowControl"], json!(false));
    }

    #[test]
    fn formatting_equal_matches_serialized_equality_on_nonfinite_values() {
        let finite = RunFormatting {
            font_size: Some(12.0),
            ..RunFormatting::default()
        };
        let nan_size = RunFormatting {
            font_size: Some(f64::NAN),
            ..RunFormatting::default()
        };
        let nan_size2 = RunFormatting {
            font_size: Some(f64::NAN),
            ..RunFormatting::default()
        };
        let pos_inf = RunFormatting {
            font_size: Some(f64::INFINITY),
            ..RunFormatting::default()
        };
        let neg_inf = RunFormatting {
            font_size: Some(f64::NEG_INFINITY),
            ..RunFormatting::default()
        };
        let nan_comments = RunFormatting {
            comment_ids: Some(vec![f64::NAN]),
            ..RunFormatting::default()
        };
        let nan_comments2 = RunFormatting {
            comment_ids: Some(vec![f64::NAN]),
            ..RunFormatting::default()
        };
        let nan_in_field = RunFormatting {
            font_size: Some(12.0),
            comment_ids: Some(vec![f64::NAN]),
            ..RunFormatting::default()
        };
        let positive_zero = RunFormatting {
            letter_spacing: Some(0.0),
            ..nan_size.clone()
        };
        let negative_zero = RunFormatting {
            letter_spacing: Some(-0.0),
            ..nan_size.clone()
        };

        for (a, b) in [
            (&finite, &nan_size),
            (&finite, &pos_inf),
            (&nan_size, &nan_size2),
            (&pos_inf, &neg_inf),
            (&pos_inf, &nan_size),
            (&nan_comments, &nan_comments2),
            (&nan_comments, &nan_in_field),
            (&nan_size, &nan_in_field),
            (&positive_zero, &negative_zero),
        ] {
            assert_eq!(
                formatting_equal(a, b),
                serde_json::to_value(a).unwrap() == serde_json::to_value(b).unwrap(),
                "{a:?} vs {b:?}"
            );
        }
        assert!(formatting_equal(&nan_size, &nan_size2));
        assert!(formatting_equal(&pos_inf, &neg_inf));
        assert!(!formatting_equal(&finite, &nan_size));
        assert!(!formatting_equal(&finite, &pos_inf));
        assert!(formatting_equal(&nan_comments, &nan_comments2));
        assert!(!formatting_equal(&nan_comments, &nan_in_field));
    }

    #[test]
    fn edited_image_borders_paint_the_edited_values() {
        let values = HashMap::from([
            ("borderWidth".to_owned(), Any::Number(2.0)),
            ("borderColor".to_owned(), Any::String("#0000FF".into())),
            ("borderColorValue".to_owned(), Any::Null),
            ("borderStyle".to_owned(), Any::String("double".into())),
        ]);
        let outline = image_outline(&values, &RenderEnv::default()).unwrap();
        assert_eq!(outline.width, Some(2.0));
        assert_eq!(outline.color.as_deref(), Some("#0000FF"));
        assert_eq!(outline.style.as_deref(), Some("solid"));
        let values = HashMap::from([("borderColorValue".to_owned(), Any::Null)]);
        assert!(image_outline(&values, &RenderEnv::default()).is_none());
        let values = HashMap::from([
            ("borderWidth".to_owned(), Any::Number(2.0)),
            (
                "borderColor".to_owned(),
                Any::String("rgb(0, 0, 255)".into()),
            ),
        ]);
        assert!(image_outline(&values, &RenderEnv::default()).is_none());
    }

    #[test]
    fn image_outlines_read_legacy_and_ordered_colour_modifiers_alike() {
        for color in [
            json!({"rgb":"FFFFFF","luminanceModulation":0.75}),
            json!({"rgb":"FFFFFF","transforms":[{"kind":"lumMod","value":0.75}]}),
        ] {
            let values = HashMap::from([(
                "borderColorValue".to_owned(),
                serde_json::from_value::<Any>(color).unwrap(),
            )]);
            let outline = image_outline(&values, &RenderEnv::default()).unwrap();
            assert_eq!(outline.color.as_deref(), Some("#BFBFBF"));
        }
    }
}
