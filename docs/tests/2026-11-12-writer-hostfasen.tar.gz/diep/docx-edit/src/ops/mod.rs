// OpenAEC: gewijzigd voor brongebonden plakbatches en begrensde lezingen (2026-11-03).
//! Mutating editing operations.

pub(crate) mod bookmarks;
pub(crate) mod content_control;
pub mod embed;
pub mod paragraph;
pub mod resolve;
pub mod table;
pub mod text;

#[cfg(test)]
mod tests;

use std::collections::{BTreeMap, HashSet};
use std::sync::Arc;

use yrs::types::Attrs;
use yrs::types::text::YChange;
use yrs::{Any, Map, MapRef, Out, ReadTxn, Text, TextRef, TransactionMut};

use crate::{
    DEL, INS, KIND_KEY, PARA_ID, PPR_CHANGE, PPR_DEL, PPR_INS, StoryRange, is_pilcrow, map_string,
    out_len,
};

pub(crate) struct IndexedStory {
    segments: Arc<crate::segments::SegmentIndex>,
    paragraphs: Arc<crate::segments::ParagraphIndex>,
}

impl IndexedStory {
    pub(crate) fn new(
        segments: Arc<crate::segments::SegmentIndex>,
        paragraphs: Arc<crate::segments::ParagraphIndex>,
    ) -> Self {
        Self {
            segments,
            paragraphs,
        }
    }

    pub(crate) fn in_txn(
        doc: &crate::EditingDoc,
        story_id: &str,
        txn: &TransactionMut<'_>,
    ) -> Option<Self> {
        if !txn.insert_set().is_empty() || !txn.delete_set().is_empty() {
            return None;
        }
        let epoch = doc.committed_epoch();
        let segments = doc.segment_indexes.lock().unwrap().get(story_id, epoch)?;
        segments.formatted_segment_units()?;
        let paragraphs = doc.paragraph_indexes.lock().unwrap().get(story_id, epoch)?;
        Some(Self {
            segments,
            paragraphs,
        })
    }

    /// `snapshot_range` from the indexed paragraph units, or `None` when their
    /// formatting may be stale.
    pub(crate) fn snapshot_window<T: ReadTxn>(
        &self,
        txn: &T,
        lo: u32,
        hi: u32,
        through_embeds: bool,
    ) -> Option<Vec<Chunk>> {
        let units = self.segments.formatted_segment_units()?;
        let (first, mut offset) = self.paragraphs.unit_at(lo);
        let mut chunks: Vec<Chunk> = Vec::new();
        for unit in units.iter().skip(first) {
            for (insert, attributes) in unit.iter() {
                if offset >= hi
                    && !(through_embeds && chunks.last().is_some_and(Chunk::is_map_embed))
                {
                    return Some(chunks);
                }
                let len = out_len(insert);
                if offset + len > lo {
                    chunks.push(chunk_at(insert, attributes.as_deref(), offset, txn));
                }
                offset += len;
            }
        }
        Some(chunks)
    }

    pub(crate) fn bounds_at<T: ReadTxn>(
        &self,
        txn: &T,
        index: u32,
    ) -> Option<crate::op::ParaBounds> {
        self.pilcrow_at(txn, index).map(|(bounds, _)| bounds)
    }

    /// [`IndexedStory::bounds_at`] with the paragraph's mark.
    pub(crate) fn pilcrow_at<T: ReadTxn>(
        &self,
        txn: &T,
        index: u32,
    ) -> Option<(crate::op::ParaBounds, MapRef)> {
        let para = self.paragraphs.para_at_clamped(index)?;
        let (slot, _) = self.paragraphs.unit_at(para.pilcrow);
        let (Out::YMap(map), _) = self.segments.formatted_segment_units()?.get(slot)?.last()?
        else {
            return None;
        };
        if !is_pilcrow(map, txn) {
            return None;
        }
        let bounds = crate::op::ParaBounds {
            para_id: map_string(map, txn, PARA_ID).unwrap_or_default(),
            start: para.start,
            pilcrow: para.pilcrow,
        };
        Some((bounds, map.clone()))
    }
}

/// One formatting-run chunk of a story, snapshotted for index-stable reverse walks.
pub(crate) struct Chunk {
    pub start: u32,
    pub len: u32,
    pub kind: ChunkKind,
    pub attrs: BTreeMap<String, Any>,
}

pub(crate) enum ChunkKind {
    Text(String),
    Pilcrow(MapRef),
    Embed(Option<MapRef>),
}

impl Chunk {
    pub fn end(&self) -> u32 {
        self.start + self.len
    }

    pub fn is_map_embed(&self) -> bool {
        matches!(self.kind, ChunkKind::Pilcrow(_) | ChunkKind::Embed(Some(_)))
    }

    pub fn attr_active(&self, key: &str) -> bool {
        matches!(self.attrs.get(key), Some(value) if *value != Any::Null)
    }

    pub fn is_block_embed<T: ReadTxn>(&self, txn: &T) -> bool {
        matches!(&self.kind, ChunkKind::Embed(Some(map)) if map_string(map, txn, KIND_KEY)
            .is_some_and(|kind| crate::segments::is_block_embed(&kind)))
    }

    pub fn block_revisions<T: ReadTxn>(&self, txn: &T) -> Option<[Option<Any>; 2]> {
        if !self.is_block_embed(txn) {
            return None;
        }
        let table = match &self.kind {
            ChunkKind::Embed(Some(map))
                if map_string(map, txn, KIND_KEY).as_deref() == Some("table") =>
            {
                table::table_revisions(map, txn)
            }
            _ => [None, None],
        };
        Some([INS, DEL].map(|key| {
            self.attrs
                .get(key)
                .filter(|stamp| **stamp != Any::Null)
                .cloned()
                .or_else(|| table[usize::from(key == DEL)].clone())
        }))
    }

    /// The `author` of an `ins`/`del` revision value on this chunk, if any.
    pub fn revision_author(&self, key: &str) -> Option<String> {
        let Some(Any::Map(revision)) = self.attrs.get(key) else {
            return None;
        };
        match revision.get("author") {
            Some(Any::String(author)) => Some(author.to_string()),
            _ => None,
        }
    }
}

pub(crate) fn revision_id_for_author(value: &Any, author: &str) -> Option<String> {
    let Any::Map(revision) = value else {
        return None;
    };
    if !matches!(revision.get("author"), Some(Any::String(value)) if value.as_ref() == author) {
        return None;
    }
    match revision.get("id").or_else(|| revision.get("revisionId")) {
        Some(Any::String(id)) => Some(id.to_string()),
        Some(Any::Number(id)) if id.is_finite() => Some(id.to_string()),
        Some(Any::BigInt(id)) => Some(id.to_string()),
        _ => None,
    }
}

/// Reuse a same-author revision touching an edit boundary. This models Word's
/// continuous suggestion run: separately dispatched keystrokes and paragraph
/// breaks stay one revision while their stamped units remain adjacent.
pub(crate) fn adjacent_revision_id(
    chunks: &[Chunk],
    index: u32,
    key: &str,
    author: &str,
) -> Option<String> {
    chunks
        .iter()
        .rev()
        .filter(|chunk| chunk.end() == index)
        .chain(chunks.iter().filter(|chunk| chunk.start == index))
        .find_map(|chunk| {
            chunk
                .attrs
                .get(key)
                .and_then(|value| revision_id_for_author(value, author))
        })
}

/// Reuse a same-author paragraph-property revision at an edit boundary.
///
/// A list command commonly authors `pPrChange` on an empty paragraph before
/// the first character is typed. Treat that pending property change as the
/// start of the same continuous suggestion run so the list formatting, text,
/// and subsequent paragraph breaks resolve from one sidebar card.
pub(crate) fn adjacent_paragraph_change_revision_id<T: ReadTxn>(
    chunks: &[Chunk],
    index: u32,
    txn: &T,
    author: &str,
) -> Option<String> {
    chunks
        .iter()
        .rev()
        .filter(|chunk| chunk.end() == index)
        .chain(chunks.iter().filter(|chunk| chunk.start == index))
        .find_map(|chunk| {
            let ChunkKind::Pilcrow(map) = &chunk.kind else {
                return None;
            };
            let Some(Out::Any(Any::Array(changes))) = map.get(txn, PPR_CHANGE) else {
                return None;
            };
            changes.iter().rev().find_map(|change| {
                let Any::Map(change) = change else {
                    return None;
                };
                change
                    .get("info")
                    .and_then(|info| revision_id_for_author(info, author))
            })
        })
}

pub(crate) fn revision_id_in_range(
    chunks: &[Chunk],
    start: u32,
    end: u32,
    key: &str,
    author: &str,
) -> Option<String> {
    chunks
        .iter()
        .filter(|chunk| chunk.end() > start && chunk.start < end)
        .find_map(|chunk| {
            chunk
                .attrs
                .get(key)
                .and_then(|value| revision_id_for_author(value, author))
        })
}

pub(crate) fn chunk_at<T: ReadTxn>(
    insert: &Out,
    attrs: Option<&Attrs>,
    offset: u32,
    txn: &T,
) -> Chunk {
    #[cfg(test)]
    crate::SNAPSHOT_CHUNKS_BUILT.with(|built| built.set(built.get() + 1));
    let kind = match insert {
        Out::Any(Any::String(value)) => ChunkKind::Text(value.to_string()),
        Out::YMap(map) if is_pilcrow(map, txn) => ChunkKind::Pilcrow(map.clone()),
        Out::YMap(map) => ChunkKind::Embed(Some(map.clone())),
        _ => ChunkKind::Embed(None),
    };
    let attrs = attrs
        .into_iter()
        .flat_map(|attrs| attrs.iter())
        .map(|(key, value)| (key.to_string(), value.clone()))
        .collect();
    Chunk {
        start: offset,
        len: out_len(insert),
        kind,
        attrs,
    }
}

pub(crate) fn snapshot<T: ReadTxn>(story: &TextRef, txn: &T) -> Vec<Chunk> {
    let mut offset = 0;
    story
        .diff(txn, YChange::identity)
        .into_iter()
        .map(|diff| {
            let chunk = chunk_at(&diff.insert, diff.attributes.as_deref(), offset, txn);
            offset += chunk.len;
            chunk
        })
        .collect()
}

/// `snapshot` over the chunks overlapping `[lo, hi)`.
pub(crate) fn snapshot_range<T: ReadTxn>(story: &TextRef, txn: &T, lo: u32, hi: u32) -> Vec<Chunk> {
    snapshot_window(story, txn, lo, hi, false)
}

/// `snapshot` over the chunks overlapping any of `ranges` (`[lo, hi)` pairs), from one story read.
pub(crate) fn snapshot_ranges<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    ranges: &mut [(u32, u32)],
) -> Vec<Chunk> {
    #[cfg(test)]
    crate::SNAPSHOT_DIFFS_BUILT.with(|built| built.set(built.get() + 1));
    ranges.sort_unstable();
    let mut next = 0;
    let mut offset = 0;
    let mut chunks = Vec::new();
    for diff in story.diff(txn, YChange::identity) {
        let len = out_len(&diff.insert);
        while next < ranges.len() && ranges[next].1 <= offset {
            next += 1;
        }
        let Some(&(lo, _)) = ranges.get(next) else {
            break;
        };
        if offset + len > lo {
            chunks.push(chunk_at(
                &diff.insert,
                diff.attributes.as_deref(),
                offset,
                txn,
            ));
        }
        offset += len;
    }
    chunks
}

/// `snapshot_range`, continued past `hi` through any map embeds and the unit after them: what
/// [`remove_units`] needs to keep their formatting without reading the story again.
pub(crate) fn snapshot_range_through_embeds<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    lo: u32,
    hi: u32,
) -> Vec<Chunk> {
    snapshot_window(story, txn, lo, hi, true)
}

fn snapshot_window<T: ReadTxn>(
    story: &TextRef, txn: &T, lo: u32, hi: u32, through_embeds: bool,
) -> Vec<Chunk> {
    #[cfg(test)]
    crate::SNAPSHOT_DIFFS_BUILT.with(|built| built.set(built.get() + 1));
    let mut chunks: Vec<Chunk> = Vec::new();
    story.visit_utf16_window(txn,lo,|offset,diff| {
        if offset >= hi && !(through_embeds && chunks.last().is_some_and(Chunk::is_map_embed)) { return false; }
        chunks.push(chunk_at(&diff.insert,diff.attributes.as_deref(),offset,txn));
        true
    });
    chunks
}

fn snapshot_window_indexed<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    lo: u32,
    hi: u32,
    through_embeds: bool,
    indexed: Option<&IndexedStory>,
) -> Vec<Chunk> {
    if let Some(chunks) =
        indexed.and_then(|index| index.snapshot_window(txn, lo, hi, through_embeds))
    {
        return chunks;
    }
    if through_embeds {
        snapshot_range_through_embeds(story, txn, lo, hi)
    } else {
        snapshot_range(story, txn, lo, hi)
    }
}

/// Whether the chunks a removal gets still hold the units after it.
#[derive(Clone, Copy)]
pub(crate) enum After {
    /// Unchanged since the chunks were taken.
    Known,
    /// Possibly changed since, so they are read from the story.
    Changed,
}

/// The formatting a removal of `[index, end)` can disturb: the keys set on the unit before it,
/// on its units and on the unit after the map embeds that follow it, and those embeds' formatting.
#[derive(Default)]
struct Surroundings {
    keys: HashSet<Arc<str>>,
    embeds: Vec<Attrs>,
}

impl Surroundings {
    /// Takes the chunk ending at `chunk_end`; false once it is the unit after the embeds.
    fn take(&mut self, chunk_end: u32, end: u32, map_embed: bool, attrs: Attrs) -> bool {
        if chunk_end > end && map_embed {
            self.embeds.push(attrs);
            return true;
        }
        self.keys.extend(attrs.into_keys());
        chunk_end <= end
    }

    /// Reads them from the story.
    fn read<T: ReadTxn>(story: &TextRef, txn: &T, index: u32, end: u32) -> Self {
        let mut around = Self::default();
        let mut offset = 0;
        for diff in story.diff(txn, YChange::identity) {
            offset += out_len(&diff.insert);
            if offset < index {
                continue;
            }
            let map_embed = !matches!(diff.insert, Out::Any(_));
            let attrs = diff.attributes.map(|attrs| *attrs).unwrap_or_default();
            if !around.take(offset, end, map_embed, attrs) {
                break;
            }
        }
        around
    }

    /// `read` from `chunks`, when they cover every unit it reads.
    fn known(chunks: &[Chunk], index: u32, end: u32, story_len: u32) -> Option<Self> {
        let mut around = Self::default();
        let before = index.checked_sub(1)?;
        let mut next = before;
        for chunk in chunks.iter().skip_while(|chunk| chunk.end() <= before) {
            let unknown_embed = matches!(chunk.kind, ChunkKind::Embed(None));
            if chunk.start > next || (chunk.end() > end && unknown_embed) {
                return None;
            }
            next = chunk.end();
            let attrs = chunk
                .attrs
                .iter()
                .map(|(key, value)| (Arc::from(key.as_str()), value.clone()))
                .collect();
            if !around.take(next, end, chunk.is_map_embed(), attrs) {
                return Some(around);
            }
        }
        (next == story_len).then_some(around)
    }
}

/// Removes `len` units at `index`, keeping the formatting of the paragraph marks and other map
/// embeds after them. yrs tidies the format markers a removal leaves behind up to the next text,
/// past any map embed, so formatting that closed before them could merge with the same formatting
/// reopening after them. Each such embed gets back its own value for every key set around the
/// removal, which inserts nothing where the value held. `chunks` hold the units on either side of
/// the range when known; with [`After::Known`] the embeds after it come from them too where they
/// reach (see `snapshot_range_through_embeds`).
pub(crate) fn remove_units(
    txn: &mut TransactionMut<'_>,
    story: &TextRef,
    index: u32,
    len: u32,
    chunks: &[Chunk],
    after: After,
) {
    let unit = |at: u32| {
        chunks
            .iter()
            .find(|chunk| chunk.start <= at && at < chunk.end())
    };
    let formatted_before = index.checked_sub(1).is_some_and(|before| {
        unit(before).is_none_or(|chunk| chunk.attrs.values().any(|value| *value != Any::Null))
    });
    let text_after =
        unit(index + len).is_some_and(|chunk| matches!(chunk.kind, ChunkKind::Text(_)));
    if !formatted_before || text_after {
        story.remove_range(txn, index, len);
        return;
    }
    let end = index + len;
    let Surroundings { mut keys, embeds } = match after {
        After::Known => Surroundings::known(chunks, index, end, story.len(txn)),
        After::Changed => None,
    }
    .unwrap_or_else(|| Surroundings::read(story, txn, index, end));
    story.remove_range(txn, index, len);
    keys.extend(embeds.iter().flat_map(|attrs| attrs.keys().cloned()));
    let mut restores: Vec<(u32, u32, Attrs)> = Vec::new();
    for (at, was) in (index..).zip(&embeds) {
        let restore: Attrs = keys
            .iter()
            .map(|key| (key.clone(), was.get(key).cloned().unwrap_or(Any::Null)))
            .collect();
        match restores.last_mut() {
            Some((_, len, attrs)) if *attrs == restore => *len += 1,
            _ => restores.push((at, 1, restore)),
        }
    }
    for (start, len, attrs) in restores {
        story.format(txn, start, len, attrs);
    }
}

pub(crate) fn block_embed_at<T: ReadTxn>(story: &TextRef, txn: &T, index: u32) -> bool {
    snapshot_range(story, txn, index, index.saturating_add(1))
        .first()
        .is_some_and(|chunk| chunk.is_block_embed(txn))
}

/// Moves `index` past the block embeds that start there: inline content may follow a
/// paragraph's leading blocks but never precede them.
pub(crate) fn past_leading_blocks<T: ReadTxn>(story: &TextRef, txn: &T, mut index: u32) -> u32 {
    while block_embed_at(story, txn, index) {
        index += 1;
    }
    index
}

pub(crate) fn past_leading_blocks_indexed<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    mut index: u32,
    indexed: Option<&IndexedStory>,
) -> u32 {
    while snapshot_window_indexed(story, txn, index, index.saturating_add(1), false, indexed)
        .first()
        .is_some_and(|chunk| chunk.is_block_embed(txn))
    {
        index += 1;
    }
    index
}

pub(crate) fn inherit_block_revisions(
    txn: &mut TransactionMut<'_>,
    story: &TextRef,
    index: u32,
    map: &MapRef,
    revisions: &[Option<Any>; 2],
) {
    for ((attr_key, ppr_key), stamp) in [(INS, PPR_INS), (DEL, PPR_DEL)].into_iter().zip(revisions)
    {
        if let Some(stamp) = stamp {
            map.insert(txn, ppr_key, stamp.clone());
            story.format(
                txn,
                index,
                1,
                Attrs::from([(attr_key.into(), stamp.clone())]),
            );
        }
    }
}

pub(crate) fn paragraph_content_before<T: ReadTxn>(story: &TextRef, txn: &T, index: u32) -> bool {
    index > 0
        && snapshot_range(story, txn, index - 1, index)
            .last()
            .is_some_and(|chunk| {
                !matches!(chunk.kind, ChunkKind::Pilcrow(_)) && !chunk.is_block_embed(txn)
            })
}

/// The story's last pilcrow as `(index, map)`.
pub(crate) fn last_pilcrow<T: ReadTxn>(story: &TextRef, txn: &T) -> Option<(u32, MapRef)> {
    let mut offset = 0;
    let mut last = None;
    for diff in story.diff(txn, YChange::identity) {
        if let Out::YMap(map) = &diff.insert
            && is_pilcrow(map, txn)
        {
            last = Some((offset, map.clone()));
        }
        offset += out_len(&diff.insert);
    }
    last
}

/// Captures every pilcrow property except the schema discriminator, plus the paraId.
pub(crate) fn capture_pilcrow<T: ReadTxn>(map: &MapRef, txn: &T) -> (String, Vec<(String, Any)>) {
    let para_id = map_string(map, txn, PARA_ID).unwrap_or_default();
    let props = map
        .iter(txn)
        .filter_map(|(key, value)| {
            if matches!(key, KIND_KEY | PARA_ID) {
                return None;
            }
            let Out::Any(value) = value else {
                return None;
            };
            Some((key.to_string(), value))
        })
        .collect();
    (para_id, props)
}

/// Replaces a pilcrow's ID and properties with the donor's.
pub(crate) fn adopt_pilcrow(
    txn: &mut TransactionMut<'_>,
    survivor: &MapRef,
    donor_para_id: &str,
    donor_props: &[(String, Any)],
) {
    let existing: Vec<String> = survivor
        .iter(txn)
        .map(|(key, _)| key.to_string())
        .filter(|key| key != KIND_KEY)
        .collect();
    for key in existing {
        survivor.remove(txn, &key);
    }
    survivor.insert(txn, PARA_ID, donor_para_id);
    for (key, value) in donor_props {
        survivor.insert(txn, key.clone(), value.clone());
    }
}

pub(crate) fn utf16_len(text: &str) -> u32 {
    text.encode_utf16().count() as u32
}

/// Whether UTF-16 `offset` falls between the two units of a surrogate pair in `text`.
fn inside_pair(text: &str, offset: u32) -> bool {
    text_boundary(text, offset).0
}

fn text_boundary(text: &str, offset: u32) -> (bool, u32) {
    let mut at = 0;
    let mut width = 0;
    for ch in text.chars() {
        if at >= offset {
            return (false, width);
        }
        width = ch.len_utf16() as u32;
        at += width;
        if at > offset {
            return (true, width);
        }
    }
    (false, if at == offset { width } else { 0 })
}

/// `index` moved off the middle of a surrogate pair in `chunks`: back to the pair's start, or
/// past its end when `forward`. yrs splits such an index after the pair while the new item's
/// id assumes the index itself, which corrupts the story.
fn code_point_index(chunks: &[Chunk], index: u32, forward: bool) -> u32 {
    code_point_boundary(chunks, index, forward).0
}

fn code_point_boundary(chunks: &[Chunk], index: u32, forward: bool) -> (u32, u32) {
    let Some(chunk) = chunks
        .partition_point(|chunk| chunk.start < index)
        .checked_sub(1)
        .and_then(|slot| chunks.get(slot))
    else {
        return (index, 0);
    };
    let ChunkKind::Text(text) = &chunk.kind else {
        return (index, 0);
    };
    let (inside, width) = text_boundary(text, index - chunk.start);
    let snapped = match (inside, forward) {
        (false, _) => index,
        (true, false) => index - 1,
        (true, true) => index + 1,
    };
    (snapped, width)
}

/// Chunks covering the units on both sides of `index`, after moving `index` off the middle of
/// a surrogate pair to the pair's start.
pub(crate) fn position_chunks<T: ReadTxn>(story: &TextRef, txn: &T, index: &mut u32) -> Vec<Chunk> {
    position_chunks_indexed(story, txn, index, None)
}

pub(crate) fn position_chunks_indexed<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    index: &mut u32,
    indexed: Option<&IndexedStory>,
) -> Vec<Chunk> {
    let take = |index: u32| {
        snapshot_window_indexed(
            story,
            txn,
            index.saturating_sub(1),
            index.saturating_add(1),
            false,
            indexed,
        )
    };
    let chunks = take(*index);
    let snapped = code_point_index(&chunks, *index, false);
    if snapped == *index {
        return chunks;
    }
    *index = snapped;
    take(snapped)
}

/// Chunks covering `range` and the unit on each side, after widening `range` to whole code
/// points (a collapsed range moves to the pair's start).
pub(crate) fn range_chunks<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    range: &mut StoryRange,
) -> Vec<Chunk> {
    range_chunks_observed(story, txn, range).0
}

pub(crate) fn range_chunks_observed<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    range: &mut StoryRange,
) -> (Vec<Chunk>, bool) {
    range_chunks_observed_indexed(story, txn, range, None)
}

pub(crate) fn range_chunks_observed_indexed<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    range: &mut StoryRange,
    indexed: Option<&IndexedStory>,
) -> (Vec<Chunk>, bool) {
    let take = |range: &StoryRange| {
        snapshot_window_indexed(
            story,
            txn,
            range.start.saturating_sub(1),
            range.end.saturating_add(1),
            true,
            indexed,
        )
    };
    let chunks = take(range);
    let start = code_point_index(&chunks, range.start, false);
    let (end, width) = if range.start == range.end {
        (start, 0)
    } else {
        code_point_boundary(&chunks, range.end, true)
    };
    let single = width != 0
        && end.checked_sub(start) == Some(width)
        && (start, end) == (range.start, range.end);
    if (start, end) == (range.start, range.end) {
        return (chunks, single);
    }
    range.start = start;
    range.end = end;
    (take(range), single)
}

/// `[start, end)` widened to whole code points, for ops that take no chunk snapshot; a
/// collapsed range moves to the pair's start.
pub(crate) fn code_point_range<T: ReadTxn>(
    story: &TextRef,
    txn: &T,
    start: u32,
    end: u32,
) -> (u32, u32) {
    let mut range = (start, end);
    for chunk in snapshot_range(story,txn,start.saturating_sub(1),end.saturating_add(1)) {
        let offset=chunk.start;
        if offset >= end { break; }
        if let ChunkKind::Text(text)=&chunk.kind {
            if offset < start && inside_pair(text,start-offset){range.0=start-1;}
            if start < end && inside_pair(text,end-offset){range.1=end+1;}
        }
    }
    if start == end {
        range.1 = range.0;
    }
    range
}
