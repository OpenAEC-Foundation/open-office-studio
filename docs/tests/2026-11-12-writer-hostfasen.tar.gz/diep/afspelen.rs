//! Eigen vastgelegde schema-2-aanvragen; geen venster of gebruikersdocument.
use office_writer_plakken::{BronSpiegel, BronVoorraad, IncrementeleTekstAanvraag};
use serde_json::{Value,json};
use std::{cell::RefCell,time::Instant};
#[path="../bronspiegel-gemeten.rs"] mod gemeten;
thread_local! { static MARKERINGEN: RefCell<Vec<(&'static str,Instant)>> = const { RefCell::new(Vec::new()) }; }
fn markeer(naam: &'static str) { MARKERINGEN.with(|m|m.borrow_mut().push((naam,Instant::now()))); }
fn ns(t:Instant)->u64 {t.elapsed().as_nanos().try_into().unwrap()}
fn wire(mut r: Value)->Value {
    let mut a=r.get_mut("resultaat").unwrap().take();
    a["schema"]=json!(2);a["basis"]=r["basis"].take();a["bronvector"]=r["bronvector"].take();a
}
fn zonder_tijd(mut v:Value)->Value {v.as_object_mut().unwrap().remove("preparationMs");v}
fn main()->Result<(),Box<dyn std::error::Error>> {
 let data=std::fs::read(std::env::args().nth(1).ok_or("Aanvraagbestand ontbreekt")?)?;
 if data.len()>32*1024*1024{return Err("Opname te groot".into())}
 let regels:Vec<Value>=serde_json::from_slice(&data)?;
 assert!(!regels.is_empty()&&regels.len()<=256);
 let mut metingen=Vec::new();
 for ronde in 0..3 {
  for route in ["direct","gemeten","voorraad"] {
   let mut spiegel=BronSpiegel::default();let mut proef=gemeten::BronSpiegel::default();let voorraad=BronVoorraad::default();
   for (i,regel) in regels.iter().enumerate() {
    let jsonbron=serde_json::to_vec(&json!({"aanvraag":regel["aanvraag"]}))?;
    let begin=Instant::now();let mut envelop:Value=serde_json::from_slice(&jsonbron)?;let json_ns=ns(begin);
    let begin=Instant::now();let a=envelop["aanvraag"].take();
    let mut fasen=json!({});
    let antwoord=if route=="gemeten" {
     let a:gemeten::IncrementeleTekstAanvraag=serde_json::from_value(a)?;let parse_ns=ns(begin);
     MARKERINGEN.with(|m|m.borrow_mut().clear());let begin=Instant::now();let r=proef.bereid_voor(a)?.ok_or("Onverwachte hersynchronisatie")?;let kern_ns=ns(begin);assert!(proef.bytes()>0);
     MARKERINGEN.with(|m|{let m=m.borrow();for p in m.windows(2){fasen[p[1].0]=json!(p[1].1.duration_since(p[0].1).as_nanos() as u64);}});
     {let begin=Instant::now();let value=serde_json::to_value(r)?;(value,parse_ns,kern_ns,ns(begin))}
    } else {
     let a:IncrementeleTekstAanvraag=serde_json::from_value(a)?;let parse_ns=ns(begin);let begin=Instant::now();
     let r=if route=="voorraad"{voorraad.bereid_voor("eigen-proef",a)?}else{spiegel.bereid_voor(a)?}.ok_or("Onverwachte hersynchronisatie")?;
     let kern_ns=ns(begin);{let begin=Instant::now();let value=serde_json::to_value(r)?;(value,parse_ns,kern_ns,ns(begin))}
    };
    let (_,parse_ns,kern_ns,value_ns)=(&antwoord.0,antwoord.1,antwoord.2,antwoord.3);let begin=Instant::now();let antwoord=wire(antwoord.0);let uitvoer=serde_json::to_vec(&antwoord)?;let antwoord_ns=ns(begin);
    assert_eq!(zonder_tijd(antwoord),zonder_tijd(regel["antwoord"].clone()),"Antwoord wijkt inhoudelijk af: {route}/{ronde}/{i}");
    metingen.push(json!({"ronde":ronde,"route":route,"aanvraag":i,"json_ns":json_ns,"parse_ns":parse_ns,"kern_ns":kern_ns,"naar_value_ns":value_ns,"antwoord_ns":antwoord_ns,"antwoordbytes":uitvoer.len(),"fasen_ns":fasen,"vendorfasen_ns":if route!="voorraad"{serde_json::to_value(docx_edit::oos_meetmomenten())?}else{Value::Null}}));
   }
  }
 }
 println!("{}",serde_json::to_string_pretty(&json!({"aanvragen":regels.len(),"rondes":3,"inhoud_exact":true,"metingen":metingen}))?);Ok(())
}
