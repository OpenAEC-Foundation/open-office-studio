from pathlib import Path
import shutil,json,hashlib,difflib
r=Path.cwd();u=r/'.local/integratiecontrole/hostfasen';d=u/'diep';d.mkdir(exist_ok=False);v=d/'docx-edit';shutil.copytree(r/'native/vendor/docx-edit',v)
p=v/'src/clipboard_batch.rs';s=p.read_text();s+='''
// Alleen deze afzonderlijke meetkopie; nooit onderdeel van de productbouw.
thread_local! { static OOS_FASEN: std::cell::RefCell<Vec<(&'static str,std::time::Instant)>> = const { std::cell::RefCell::new(Vec::new()) }; }
fn oos_start() { OOS_FASEN.with(|m|{let mut m=m.borrow_mut();m.clear();m.push(("begin",std::time::Instant::now()));}); }
fn oos_markeer(naam: &'static str) { OOS_FASEN.with(|m|m.borrow_mut().push((naam,std::time::Instant::now()))); }
pub fn oos_meetmomenten()->Vec<(String,u64)> { OOS_FASEN.with(|m|m.borrow().windows(2).map(|p|(p[1].0.to_owned(),p[1].1.duration_since(p[0].1).as_nanos().try_into().unwrap())).collect()) }
'''
marks=[('    let expected = StateVector::decode_v1(expected_vector)','START'),('    let cached = cached.filter','invoer'),('    let doc = if let Some(c) = cached','cache'),('    if doc.holds_pending_update()','import'),('    let snapshot = doc.encode_state_as_update_v1();','vector'),('    let batch = prepare_clipboard_in_doc','encode'),('    let replica = PreparedClipboardReplica','batch'),('    Ok(ConfirmedClipboardBatchResult','voorstel_hash'),('    let start=doc.locate','batch_vector'),('    for p in &fragment.paragraphs {','locate'),('    doc.begin_native_revisions(ctx)?;','fragmentcontrole'),('    let story_id=range.start.story.clone();','revisiebegin'),('    doc.persist_native_revisions(ctx)?;','mutatie'),('    let caret=doc.loc_at','revisiebewaren'),('    let update=doc.encode_diff_v1','caret'),('    Ok(ClipboardBatchResult','delta')]
for anchor,label in marks:
 assert s.count(anchor)==1,(anchor,s.count(anchor))
 s=s.replace(anchor,('    oos_start();' if label=='START' else f'    oos_markeer("{label}");')+'\n'+anchor)
s=s.replace('    let reused = cached.is_some();','    let reused = cached.is_some();\n    oos_markeer(if reused {"hergebruikt"}else{"nieuw"});')
p.write_text(s);p=v/'src/lib.rs';p.write_text(p.read_text()+'\npub use clipboard_batch::oos_meetmomenten;\n')
for n in ['clipboard_batch.rs','lib.rs']:
 oud=(r/'native/vendor/docx-edit/src'/n).read_text();nu=(v/'src'/n).read_text();(d/(n+'.diff')).write_text(''.join(difflib.unified_diff(oud.splitlines(True),nu.splitlines(True),fromfile=n,tofile=n+'.gemeten')))
s=(u/'afspelen.rs').read_text().replace('path="bronspiegel-gemeten.rs"','path="../bronspiegel-gemeten.rs"');s=s.replace('"fasen_ns":fasen','"fasen_ns":fasen,"vendorfasen_ns":if route!="voorraad"{serde_json::to_value(docx_edit::oos_meetmomenten())?}else{Value::Null}')
(d/'afspelen.rs').write_text(s)
(d/'bronpinnen.json').write_text(json.dumps({str(p.relative_to(v)):hashlib.sha256(p.read_bytes()).hexdigest() for p in v.rglob('*') if p.is_file()},indent=2))
