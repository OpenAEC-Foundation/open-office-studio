from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/hostfasen';h=r/'.local/integratiecontrole/journaal-host';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Eerste brede bytecheck wees terecht op latere uitsluitend test/documentatieverschillen.
(u/'eerste-afkeuring.txt').write_text('Brede git-diffcontrole sinds01351d0a was niet leeg. Uitsluitend latere sorteergoldentest/documentatie. Geen product- of proefresultaat afgekeurd. Vervolg controleert alle bestanden met een expliciete uitzondering voor die testinclusie.\n')
files=subprocess.check_output(['git','ls-tree','-r','--name-only','01351d0a','native/crates/office-writer-plakken/src','native/vendor/docx-edit/src'],text=True).splitlines()
for n in files:
 oud=subprocess.check_output(['git','show','01351d0a:'+n]);nu=(r/n).read_bytes()
 if n.endswith('/deterministic.rs'):nu=nu.replace(b'#[cfg(test)]\nmod sorteringproeven;\n\n',b'')
 assert oud==nu,n
c=json.loads((r/'.local/integratiecontrole/bronhergebruik/bouw-huidige-bronkosten.json').read_text())['opdracht'];extern={}
for i,v in enumerate(c):
 if v=='--extern':
  k,p=c[i+1].split('=',1);extern[k]=Path(p)
extern['office_writer_plakken']=h/'aan/liboffice_writer_plakken.rlib';extern['docx_edit']=h/'libdocx_edit_aan.rlib'
cmd=['/home/aia01/.cargo/bin/rustc','--edition=2024','-C','opt-level=3','-L',c[c.index('-L')+1],'-L','dependency='+str(h),'-L','dependency='+str(h/'aan'),str(u/'afspelen.rs'),'-o',str(u/'afspelen')]
for k,p in extern.items():cmd+=['--extern',k+'='+str(p)]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(u/'bouwen.log').write_text(p.stdout+p.stderr);(u/'bouw.json').write_text(json.dumps({'opdracht':cmd,'code':p.returncode,'bibliotheken':{str(p):sha(p) for p in extern.values()},'bronvergelijking':{'sinds':'01351d0a','bestanden':len(files),'uitzondering':'Alleen nieuwe cfg(test)-module-inclusie deterministic.rs verwijderd bij vergelijking; overige oorspronkelijke bestanden bytegelijk.'}},indent=2));print('bouw',p.returncode,p.stderr[-2000:]);assert p.returncode==0
