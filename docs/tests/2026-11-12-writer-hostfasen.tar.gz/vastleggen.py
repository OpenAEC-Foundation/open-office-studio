from pathlib import Path
import json,hashlib,base64,collections,statistics,tarfile,subprocess,datetime
r=Path.cwd();u=r/'.local/integratiecontrole/hostfasen';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
record=read(u/'rijk/rapport.json');assert record['geslaagd'] and not any(record['fouten'].values());assert record['bewaarde_tabellen_exact']==128
requests=read(u/'rijk/host-aanvragen.json');assert len(requests)==105
for i,x in enumerate(requests):
 a,b=x['aanvraag'],x['antwoord'];assert a['schema']==b['schema']==2
 assert hashlib.sha256(base64.b64decode(a['snapshot'],validate=True)).hexdigest()==a['snapshotSha256']
 assert all(a[k]==b[k] for k in ['requestId','documentId','sourceVersion','snapshotSha256','clientId']);assert a['sourceVector']==b['bronvector']
 assert not b.get('retryFull');assert x['antwoordMs']>=x['fetchStartMs']
 if i:assert a['basis']==requests[i-1]['antwoord']['basis'] and a['snapshot']==requests[i-1]['antwoord']['delta']
 else:assert not a.get('basis')
summary={}
for key,p in [('oorspronkelijke_bibliotheek',u/'afspelen.json'),('meetkopie',u/'diep/afspelen.json')]:
 d=read(p);assert d['inhoud_exact'] and len(d['metingen'])==945
 routes={}
 for route in ['direct','gemeten','voorraad']:
  m=[x for x in d['metingen'] if x['route']==route];assert len(m)==315
  routes[route]={k:round(sum(x[k] for x in m)/3e6,3) for k in ['json_ns','parse_ns','kern_ns','naar_value_ns','antwoord_ns']}
  routes[route]['eenheid']='ms per105aanvragen, gemiddelde van3vooraf bepaalde reeksen'
 summary[key]=routes
m=[x for x in read(u/'diep/afspelen.json')['metingen'] if x['route']=='gemeten'];phases=collections.defaultdict(float)
for x in m:
 for k,v in x['vendorfasen_ns']:phases[k]+=v/3e6
phases={k:round(v,3) for k,v in sorted(phases.items(),key=lambda x:-x[1])}
assert sum(k=='hergebruikt' for x in m for k,v in x['vendorfasen_ns'])==312
samples=record['nativefasen']['monsters'];assert len(samples)==105 and not record['nativefasen']['overgeslagen']
native={k:round(sum(x['stappen'].get(k,0) for x in samples),3) for k in ['cursor','bron','hash','aanvraag','transport','binding','mutatie','selectie']};native['rustBinnenMs']=sum(x['rustBinnenMs'] for x in samples);native['fetch_tot_json_ms']=sum(x['antwoordMs']-x['fetchStartMs'] for x in requests)
analysis={'aanvragen':105,'volledige_bronnen':1,'exacte_voorstelovernames':104,'native_fasen_ms':native,'afspelen':summary,'diepe_fasen_ms_per105':phases,'proces':{'oorspronkelijk':read(u/'afspeelproces.json'),'meetkopie':read(u/'diep/afspeelproces.json')}}
(u/'analyse.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n')
# Exacte bronpinnen en transparantie blijven geldig; geen productexpressie is aangepast.
pins=read(u/'pinnen-start.json');assert pins['head']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for n,w in pins['productbron'].items():assert sha(r/n)==w
assert sha(r/'native/crates/office-writer-plakken/src/bronspiegel.rs')==pins['bronspiegel']
# Alleen reguliere bronnen, logs, data en beelden; geen ELF, rlib of dist.
files={}
for p in u.rglob('*'):
 if p.is_file() and p.suffix in ['.py','.rs','.json','.log','.diff','.txt','.md','.toml','.lock','.png','.docx']:
  files[str(p.relative_to(u))]=p
for n in pins['productbron']:
 files['productbron/'+n]=r/n
files['productbron/native/crates/office-writer-plakken/src/bronspiegel.rs']=r/'native/crates/office-writer-plakken/src/bronspiegel.rs'
a=r/'docs/tests/2026-11-12-writer-hostfasen.tar.gz'
with tarfile.open(a,'w:gz') as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n,recursive=False)
with tarfile.open(a,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for t in tar.getmembers():assert t.isfile() and hashlib.sha256(tar.extractfile(t).read()).hexdigest()==sha(files[t.name]),t.name
report={'datum':'2026-11-12','basis_integratie':pins['head'],'productbron':'abe87e99e58d6483a0b30b9793d8932bc1917bd9','wijziging':'Alleen diagnose en bewijs. Productexpressies, appinstallatie en invoerprotocollen ongewijzigd.','conclusie':'Volledige bevestigde bron serialiseren domineert de geïsoleerde schema-2-Rust-kern. De voorraad kloont een Arc, geen document. Voorstelreplica al104van105keer hergebruikt. Geen nieuwe snelheids- of stabiliteitsfix geaccepteerd.','native':{'programma_sha256':record['programma_sha256'],'eigen_fixture':'docs/tests/writer-rust-plakbatch/bron-128-tabellen.docx','geslaagd':record['geslaagd'],'fysieke_invoer':record['lange_invoer'],'undo_groepen':record['undo_groepen_lange_invoer'],'functies':record['stappen'],'fouten':record['fouten'],'docx':read(u/'docx-nacontrole.json'),'beelden':'invoer-redo.png en snel-getypt-bewaard.png visueel bekeken: geselecteerde pagina’s behouden tekst en tabellen. Geen volledige65pagina-/pixel-/taalacceptatie.','opname':'Max256aanvragen/32MiB;105echte volledige schema-2-aanvragen en antwoorden van eigen fixture, alleen gewone invoerfase. Geen kunstmatige antwoordvertraging in die fase. Overige functieproeven houden antwoorden bewust vast.'},'analyse':analysis,'controle':{'exacte_antwoorden':1890,'vergelijking':'Twee drivers; ieder3vooraf bepaalde reeksen ×3routes ×105aanvragen. Alle antwoordvelden byte-/inhoudgelijk na normaliseren van alleen preparationMs. Geen nieuwe aanvragen gegenereerd, geen retries,104opeenvolgende exacte voorstelbytes en basisbindingen gecontroleerd.','routes':['Oorspronkelijke BronSpiegel rechtstreeks','Afzonderlijke bronspiegelkopie met faseklokken, dezelfde expressies','Oorspronkelijke BronVoorraad met eigen documentwerker'],'bibliotheken':'Geoptimaliseerde rustc-drivers met afzonderlijk gepinde echte afhankelijkheden. Alle oorspronkelijke host/vendorbronbestanden sinds01351d0a bytegelijk, afgezien van uitsluitend cfg(test)-module-inclusie voor latere sorteergoldentest. Ruwe diff bewaard. Diepe meetkopie heeft alleen tijdmarkeringen en publieke uitlezer;332overige vendorbestanden bytegelijk.','referenties':len(read(u/'referenties-nacontrole.json')),'checks':'Native volledige functieronde, zelfstandige ZIP/XML-/tekst-/tabelcontrole,1890exacte antwoordvergelijkingen, meetexpressie-/bronpinnen- en archiefcontrole. Geen frontend-,TypeScript-,Python-suite of volledige appbouw herhaald: uitsluitend diagnose/documentatie, geen productwijziging.','eerste_afkeuring':'Brede bronvergelijking sinds01351d0a was terecht niet leeg door latere test/documentatie. Beperkte expliciete uitzondering controleert daarna alle oorspronkelijke bronbytes. Eerste driverbouw had een ongebruikte bytes-methodewaarschuwing; definitieve bouw gebruikt deze buiten de tijdmeting en is zonder waarschuwing.'},'grenzen':['Native hash-/transportfasen zijn wandtijd inclusief WebKit-/eventloopwachten; rustBinnenMs is bestaande afgeronde binnenmeting. Transport minus binnenmeting is geen zuivere IPC-tijd. Tauri-scheduling/IPC-CPU niet afzonderlijk gemeten.','Losse Rust-fasen zijn synchrone wandtijd; proces-user/system-CPU afzonderlijk vastgelegd. Geen gelijkstelling van geïsoleerde3,2seconden met daadwerkelijke5,278seconden native Rust-binnenmeting. Meetkopie wijzigt timing; oorspronkelijke bibliotheek afzonderlijk gemeten.','Fysiek begin→frame16.906ms en verzonden→frame15.140ms blijven leidend. Ontvangen keyup→frame2.471ms alleen is onvoldoende. Renderlijst+twee rAFs bewijst geen fysieke paint/FPS.','Geen nieuwe app-ELF, Windows/macOS, releasevarianten, IME, urenlange stabiliteit of volledige functie-/visueledekking. Eerdere RefCell/geheugentoegangsfouten blijven open.','Geen issue gesloten of migratiegebied geaccepteerd; tien acceptatiegebieden blijven open. Geen nieuwe CI gestart voor deze productongewijzigde diagnose.'],'vervolg':'Onderzoek of de herhaalde volledige bevestigde bronserialisatie begrensd kan worden uitgesteld met exact behouden bronvector-, client-, document-, eigenaar-, voorstelbyte- en herstelbinding. Eerst apart schema-2-orakel inclusief cachemissers/afwijkende bytes/verkeerde vectoren/Undo/Redosynchronisatie; pas daarna eigen appkandidaat en vaste korte/rijke fysieke ABBA. Oude schema-3-route blijft uit totdat eigen appbewijs winst toont; oude sorteer-/hash-/wachtrijprototypes niet als fix overnemen.','bewijs':{'pad':str(a.relative_to(r)),'sha256':sha(a),'bytes':a.stat().st_size,'reguliere_leden':len(files),'alle_leden_bytegecontroleerd':True,'geen_elf_rlib_dist':True}}
p=r/'docs/tests/2026-11-12-writer-hostfasen.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'analyse':phases,'bewijs':report['bewijs']},ensure_ascii=False,indent=2))
