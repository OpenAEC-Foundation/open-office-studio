"""CPU-attributie van een eigen documentkopie in de native Linux-app.

Gebruik --bron <docx> en --paginas <aantal> naast --programma, --versie en --uitvoer.
De proef bedient echte toetsen en bewaart begrensde WebKit-ScriptProfilerdata.
Geen proces-CPUduur: deze runtime levert geen trackingUpdate-intervallen.
De stackvolgorde wordt op dezelfde runtime met drie geneste functies geijkt.
"""
import asyncio, importlib.util, json, os, signal, subprocess, sys, time, shutil, hashlib
from pathlib import Path
REPO = Path('/home/aia01/Documenten/GitHub/Open-Office-Studio')
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('basis', REPO / 'scripts/test-writer-lang-native.py')
basis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(basis)

async def proef(a):
    from Xlib import X, display
    from PIL import Image, ImageChops
    from gui.webkit_inspector import Inspector as BasisInspector
    from collections import Counter
    import gzip

    class Inspector(BasisInspector):

        async def __aenter__(self):
            self.gebeurtenissen = []
            self.notificatie_bytes = 0
            await super().__aenter__()
            self.ws.max_size = 64 * 1024 * 1024
            return self

        async def command(self, method, params=None):
            self.i += 1
            nummer = self.i
            await self.ws.send(json.dumps({'id': nummer, 'method': 'Target.sendMessageToTarget', 'params': {'targetId': self.target, 'message': json.dumps({'id': nummer, 'method': method, 'params': params or {}})}}))
            while True:
                bericht = json.loads(await asyncio.wait_for(self.ws.recv(), timeout=90))
                if bericht.get('method') != 'Target.dispatchMessageFromTarget':
                    if bericht.get('id') == nummer and bericht.get('error'):
                        raise RuntimeError(bericht['error'])
                    continue
                inhoud = bericht['params']['message']
                bericht = json.loads(inhoud)
                if 'method' in bericht:
                    if bericht['method'] == 'Console.messageAdded':
                        self.consoleberichten.append(bericht['params']['message'])
                    self.notificatie_bytes += len(inhoud)
                    if self.notificatie_bytes > 64 * 1024 * 1024:
                        raise RuntimeError('Profiel overschrijdt de datagrens')
                    self.gebeurtenissen.append(bericht)
                if bericht.get('id') == nummer:
                    return bericht

        async def worker(self, worker, method, params=None):
            nummer = 100000 + self.i
            vanaf = len(self.gebeurtenissen)
            antwoord = await self.command('Worker.sendMessageToWorker', {'workerId': worker, 'message': json.dumps({'id': nummer, 'method': method, 'params': params or {}})})
            if antwoord.get('error'):
                return antwoord
            einde = time.monotonic() + 15
            while time.monotonic() < einde:
                for ev in self.gebeurtenissen[vanaf:]:
                    if ev.get('method') == 'Worker.dispatchMessageFromWorker' and ev['params']['workerId'] == worker:
                        binnen = json.loads(ev['params']['message'])
                        if binnen.get('id') == nummer:
                            return binnen
                await self.ev('void 0')
                await asyncio.sleep(0.05)
            raise TimeoutError('Worker-profielantwoord ontbreekt')
    a.uitvoer.mkdir(parents=True, exist_ok=False)
    bron = a.uitvoer / 'Prestatieproef.docx'
    shutil.copyfile(Path(os.environ['OFFICE_PROFIEL_BRON']), bron)
    cfg = Path(os.environ['XDG_CONFIG_HOME']) / 'org.openaec.office-studio'
    cfg.mkdir(parents=True)
    (cfg / 'voorkeuren.json').write_text(json.dumps({'taal': 'en', 'thema': 'forge', 'updates': {'automatisch': False, 'kanaal': 'ontwikkel'}}))
    subprocess.run(['dbus-update-activation-environment', 'DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME'], check=True)
    d = display.Display()
    log = (a.uitvoer / 'programma.log').open('w')
    app = subprocess.Popen([str(a.programma), str(bron)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    paginas = int(os.environ['OFFICE_PROFIEL_PAGINAS'])
    tekst = os.environ['OFFICE_PROFIEL_TEKST']
    profiel = os.environ.get('OFFICE_PROFIEL_ZONDER') != '1'
    r = {'geslaagd': False, 'profiel_actief': profiel, 'paginas_verwacht': paginas, 'invoertekst': tekst, 'bron_sha256': hashlib.sha256(bron.read_bytes()).hexdigest(), 'omvang': 'Eigen documentkopie, echte toetsen en ScriptProfiler van WebKit; geen algemene snelheidsmeting. Runtime-polls van de proef staan mede in het hoofdthreadprofiel.'}
    try:
        einde = time.monotonic() + 60
        v = None
        while not v and time.monotonic() < einde:
            for w in d.screen().root.query_tree().children:
                prop = w.get_full_property(d.intern_atom('_NET_WM_NAME'), X.AnyPropertyType)
                naam = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else ''
                if w.get_attributes().map_state == X.IsViewable and 'Office Studio' in naam:
                    v = w
                    break
            await asyncio.sleep(0.1)
        assert v
        v.configure(x=0, y=0, width=1440, height=1000)
        v.set_input_focus(X.RevertToParent, X.CurrentTime)
        d.sync()
        await asyncio.sleep(12)
        async with Inspector(int(os.environ['OFFICE_PROEF_HTTP'])) as p:
            await p.run("window._profielPaginas="+str(paginas)+";window.api=()=>{let el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst');if(!el)return null;for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)for(let s=f.memoizedState,n=0;s&&n<200;n++,s=s.next){let v=s.memoizedState?.current;if(v?.getEditorRef&&v.commands)return v}return null};let eind=performance.now()+60000;while(api()?.getTotalPages()!==_profielPaginas||!api()?.getEditorRef()?.getYrsSession()?.hasStory('body')){if(performance.now()>eind)throw Error('Onverwacht aantal paginas');await new Promise(r=>setTimeout(r,100))}let e=api().getEditorRef(),alinea=e.getYrsSession().paragraphs('body').at(-1);window.voor=alinea.text;e.setSelection(e.yrsLocToDisplayPosition({story:'body',paraId:alinea.paraId,offset:e.getYrsSession().paragraphSpans('body').find(p=>p.paraId===alinea.paraId).length}));api().scrollToPage(_profielPaginas);api().focus();await api().flushPendingInput();return true;")
            await asyncio.sleep(3)
            r['volledige_layout'] = await p.run("\n              const begin=performance.now(),eind=begin+120000;let laatste=null;\n              while(performance.now()<eind){\n                const s=api().getEditorRef().getYrsSession(),layout=api().getEditorRef().getLayout();\n                const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst .paged-editor');\n                if(!el)throw Error('Actieve paginaview ontbreekt');\n                let gevonden=0;\n                for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)\n                  for(let slot=f.memoizedState,n=0;slot&&n<1500;n++,slot=slot.next){\n                    const v=slot.memoizedState?.current;\n                    if(v?.session!==s||!v.layout||typeof v.final!=='boolean')continue;\n                    gevonden++;\n                    laatste={final:v.final,versie_actueel:v.version===s.version(),layout_actief:v.layout===layout,paginas:v.layout.pages.length};\n                    if(laatste.final&&laatste.versie_actueel&&laatste.layout_actief)\n                      return {...laatste,wacht_ms:performance.now()-begin};\n                  }\n                if(!gevonden)laatste={gevonden,paginas:api().getTotalPages()};\n                await new Promise(r=>setTimeout(r,100));\n              }\n              throw Error('Laatste bron heeft geen voltooide paginering: '+JSON.stringify(laatste));\n            ", t=130)
            teksten_voor = await p.ev("Object.fromEntries(api().getEditorRef().getYrsSession().storyIds().map(id=>[id,api().getEditorRef().getYrsSession().paragraphs(id).map(p=>p.text)]))")
            await p.begin_foutbewaking()
            r['fouten_voor'] = await p.fouten()
            assert not any(r['fouten_voor'].values()), 'Enginefout voor de opname'
            r['programma_sha256'] = hashlib.sha256(a.programma.read_bytes()).hexdigest()
            r['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
            r['versie'] = await p.run("return await window.__TAURI_INTERNALS__.invoke('plugin:app|version');")
            assert r['versie'] == a.versie
            await p.ev("window._profielToetsen=[];window._profielToetsTijden=[];window.addEventListener('keyup',e=>{if(e.key.length===1){_profielToetsen.push(e.key);_profielToetsTijden.push(performance.now())}},true);true")
            r['inputmeting'] = 'Native laatste keyup en inputwachtrij; bron eenmaal buiten het profileringsvenster exact gecontroleerd. Inspectiecommando’s blijven onderdeel van de opname.'
            if profiel:
                r['worker_enable'] = await p.command('Worker.enable')
                await p.ev('void 0')
                await asyncio.sleep(0.2)
                await p.ev('void 0')
                workers = {ev['params']['workerId']: ev['params'] for ev in p.gebeurtenissen if ev.get('method') == 'Worker.workerCreated'}
                r['workers'] = workers
                r['begin_profielen'] = {}
                for worker in workers:
                    r['begin_profielen'][worker] = {'initialized': await p.command('Worker.initialized', {'workerId': worker}), 'profiel': await p.worker(worker, 'ScriptProfiler.startTracking', {'includeSamples': True})}
                r['begin_hoofdthread'] = await p.command('ScriptProfiler.startTracking', {'includeSamples': True})
            referentie = REPO / '.local/doorwerk-2026-11-04/incrementele-invoer/doortypen-38-zonder-profiel/profiel.png'
            roi = (395, 298, 1065, 366)
            def tekstmasker(im):
                masker = Image.new('L', im.size)
                masker.putdata([255 if min(rgb)>70 and max(rgb)-min(rgb)<40 else 0 for rgb in im.convert('RGB').getdata()])
                # Alleen de kleine, bekende cursorzone aan het alineaeinde.
                masker.paste(0, (491-roi[0],347-roi[1],496-roi[0],366-roi[1]))
                return masker
            verwacht_raster = tekstmasker(Image.open(referentie).crop(roi))
            verwachting = json.loads((referentie.parent/'profiel.json').read_text())
            assert tekst == verwachting['invoertekst'], 'De rasterreferentie hoort bij een andere invoerreeks'
            assert sum(v>0 for v in verwacht_raster.getdata()) > 1000, 'Lege tekstreferentie'
            r['verf_referentie'] = {'sha256':hashlib.sha256(referentie.read_bytes()).hexdigest(),'roi':roi,'cursorzone':[491,347,496,366],'grens':'Neutrale tekstpixels >70, kleurspreiding <40; rode spellingsgolven en alleen de cursorzone uitgesloten. Geen editorquery tijdens pixelpolls.'}
            await p.ev('/* Alleen een begrensde eigen test-WebView; geen productcode of documentinhoud. */\nfunction plaatsWachtrijmeting(w,rij,sessie) {\n  const begin=w.performance.now(),regels=[],herstel=[],grens=4096;let gemist=0,actief=true,taak=0,volgende=0,toetsen=0,frame=null,vorigFrame=begin;\n  const frames=[];\n  const tijd=()=>w.performance.now()-begin;\n  function meld(soort,extra={}){if(!actief)return;if(regels.length<grens)regels.push({soort,t:tijd(),taak,toetsen,...extra});else gemist++}\n  function vervang(o,k,fn){const eigen=Object.getOwnPropertyDescriptor(o,k),oud=o[k];if(typeof oud!==\'function\')throw Error(\'Meetmethode ontbreekt: \'+k);o[k]=fn(oud);if(o[k]===oud)throw Error(\'Meetmethode niet geplaatst: \'+k);herstel.push(()=>{if(eigen)Object.defineProperty(o,k,eigen);else delete o[k]})}\n  vervang(rij,\'admit\',oud=>function(fn,...rest){\n    const id=++volgende;meld(\'toelaten\',{id,diepte:this.depth});\n    return oud.call(this,function(...args){\n      taak=id;meld(\'taakbegin\',{id});let resultaat;\n      try{resultaat=fn.apply(this,args)}catch(e){meld(\'taakeinde\',{id,goed:false});taak=0;throw e}\n      const klaar=goed=>{meld(\'taakeinde\',{id,goed});taak=0};\n      if(resultaat&&typeof resultaat.then===\'function\')resultaat.then(()=>klaar(true),()=>klaar(false));else klaar(true);\n      return resultaat;\n    },...rest);\n  });\n  for(const naam of [\'applyLocalUpdate\',\'setSelection\'])vervang(sessie,naam,oud=>function(...args){meld(\'methodebegin\',{naam});try{return oud.apply(this,args)}finally{meld(\'methodeeinde\',{naam})}});\n  const oudFetch=w.fetch,doel=w.__TAURI_INTERNALS__.convertFileSrc(\'writer_tekst_voorbereiden\',\'ipc\');\n  vervang(w,\'fetch\',()=>async function(url,args,...rest){\n    if(String(url)!==doel)return oudFetch.call(this,url,args,...rest);\n    const a=JSON.parse(args.body).aanvraag;meld(\'nativebegin\',{tekens:a.text.length,incrementeel:typeof a.basis===\'string\'});\n    const antwoord=await oudFetch.call(this,url,args,...rest);meld(\'nativeontvangst\');\n    const json=antwoord.json;antwoord.json=async function(...params){const r=await json.apply(this,params);meld(\'nativejson\',{rustMs:r.preparationMs,retryFull:r.retryFull===true});return r};return antwoord;\n  });\n  const key=e=>{if(e.key.length===1&&!e.ctrlKey&&!e.metaKey){toetsen++;meld(\'toets\')}};\n  w.addEventListener(\'keydown\',key,true);herstel.push(()=>w.removeEventListener(\'keydown\',key,true));\n  const af=sessie.onUpdate(()=>meld(\'bronupdate\'));herstel.push(af);\n  function tick(t){if(!actief)return;if(frames.length<grens)frames.push({t:t-begin,tussen:t-vorigFrame});else gemist++;vorigFrame=t;frame=w.requestAnimationFrame(tick)}\n  frame=w.requestAnimationFrame(tick);\n  const m=w.__OPENAEC_WRITER_INVOERMETING__;if(!m||m.lees().monsters.length)throw Error(\'Schone optionele fasemeting ontbreekt\');m.start();\n  return {lees(){return{regels:regels.map(r=>({...r})),gemist,toetsen,frames:frames.slice()}},stop(){meld(\'stop\');actief=false;if(frame!==null)w.cancelAnimationFrame(frame);for(const fn of herstel.reverse())fn();return{schema:1,grens,gemist,toetsen,regels,frames,invoerfasen:m.stop()}}};\n}\nfunction zoekEigenInvoerrij(w){\n  const gevonden=new Set(),doelen=w.document.querySelectorAll(\'.paged-editor__yrs-input,[data-testid="yrs-input"]\');\n  if(!doelen.length)throw Error(\'Eigen actieve invoer ontbreekt\');\n  for(const el of doelen)for(let f=el[Object.keys(el).find(k=>k.startsWith(\'__reactFiber$\'))];f;f=f.return)\n    for(let h=f.memoizedState,n=0;h&&n<1500;n++,h=h.next){const v=h.memoizedState?.current;if(v&&typeof v.admit===\'function\'&&typeof v.enqueue===\'function\'&&typeof v.captureInteractionEpoch===\'function\')gevonden.add(v)}\n  if(gevonden.size!==1)throw Error(\'Geen unieke actieve invoerrij: \'+gevonden.size);\n  const rij=[...gevonden][0];if(rij.hasPending())throw Error(\'Invoerrij is nog bezet\');return rij;\n}\n\nwindow._wachtrijmeting=plaatsWachtrijmeting(window,zoekEigenInvoerrij(window),api().getEditorRef().getYrsSession());true')
            begin = time.monotonic()
            typen = await asyncio.create_subprocess_exec('xdotool', 'type', '--clearmodifiers', '--delay', '20', tekst)
            async def wacht_op_zender():
                code = await typen.wait()
                return code, time.monotonic()
            zendtaak = asyncio.create_task(wacht_op_zender())
            try:
                assert not profiel, 'De passieve rasterproef vereist --zonder-profiel'
                einde = time.monotonic()+90
                pogingen = 0
                while True:
                    pogingen += 1
                    raw = v.get_image(roi[0],roi[1],roi[2]-roi[0],roi[3]-roi[1],X.ZPixmap,4294967295)
                    im = Image.frombytes('RGB',verwacht_raster.size,raw.data,'raw','BGRX')
                    actueel = tekstmasker(im)
                    if ImageChops.difference(verwacht_raster,actueel).getbbox() is None:
                        r['getekende_tekst_ms'] = round((time.monotonic()-begin)*1000)
                        r['verf_pogingen'] = pogingen
                        im.save(a.uitvoer/'eerste-gelijke-tekst.png')
                        break
                    if pogingen == 150:
                        r['tussenmeting'] = await p.ev('_wachtrijmeting.lees()')
                        r['tussenfouten'] = await p.fouten()
                        (a.uitvoer/'tussenmeting.json').write_text(json.dumps({'meting':r['tussenmeting'],'fouten':r['tussenfouten']})+'\n')
                    if time.monotonic()>einde:
                        im.save(a.uitvoer/'afgekeurde-tekst.png')
                        r['wachtrijmeting'] = await p.ev('_wachtrijmeting.stop()')
                        r['fouten_bij_afkeuring'] = await p.fouten()
                        raise AssertionError('Getypte alinea binnen 90 seconden niet gelijk getekend')
                    await asyncio.sleep(0.02)
                if profiel:
                    # Een begrensd beginvenster voorkomt een onbegrensd profielbericht
                    # bij lange invoer. De overige toetsen blijven echt binnenkomen.
                    await asyncio.sleep(1.5)
                    r['stop_hoofdthread'] = await p.command('ScriptProfiler.stopTracking')
                    r['stop_workers'] = {worker: await p.worker(worker, 'ScriptProfiler.stopTracking') for worker in workers}
                    r['profielvenster'] = {'doel_ms': 1500, 'werkelijk_tot_stop_ms': round((time.monotonic()-begin)*1000), 'grens': 'Alleen het begin van de invoerreeks; geen CPU-profiel van de volledige reeks.'}
                code, verzonden = await zendtaak
                r['toetsen_verzonden_ms'] = round((verzonden-begin)*1000)
                assert code == 0, 'Native toetseninvoer mislukt'
            finally:
                if typen.returncode is None:
                    typen.terminate()
                    await typen.wait()
            await p.run("let einde=performance.now()+90000;while(_profielToetsen.length<"+str(len(tekst))+"){if(performance.now()>einde)throw Error('Laatste native toets ontbreekt');await new Promise(r=>setTimeout(r,50))}await api().flushPendingInput();return true;", t=100)
            r['wachtrijmeting'] = await p.ev('_wachtrijmeting.stop()')
            r['invoer_en_inspectie_ms'] = round((time.monotonic() - begin) * 1000)
            r['na_toetsen_verzenden_ms'] = r['invoer_en_inspectie_ms']-r['toetsen_verzonden_ms']
            r['toetsontvangst'] = await p.ev("({aantal:_profielToetsen.length,eerste_ms:_profielToetsTijden[0],laatste_ms:_profielToetsTijden.at(-1),tijdspan_ms:_profielToetsTijden.at(-1)-_profielToetsTijden[0]})")
            lijsten = {}
            r['samenvatting'] = {}
            if profiel:
                await p.ev('void 0')
                await asyncio.sleep(0.2)
                await p.ev('void 0')
                profiel_einde = len(p.gebeurtenissen)
                await p.command('ScriptProfiler.startTracking', {'includeSamples': True})
                await p.ev('(()=>{function profielOnder(){let einde=performance.now()+100,uit=0;while(performance.now()<einde)uit+=Math.sqrt(Math.random());return uit}function profielMidden(){return profielOnder()}function profielBoven(){return profielMidden()}return profielBoven()})()')
                await p.command('ScriptProfiler.stopTracking')
                await p.ev('void 0')
                kalibratie = [s for e in p.gebeurtenissen[profiel_einde:] if e.get('method') == 'ScriptProfiler.trackingComplete' for s in e['params'].get('samples', {}).get('stackTraces', [])]
                voorbeelden = []
                for sample in kalibratie:
                    namen = [f['name'] for f in sample['stackFrames']]
                    if all((n in namen for n in ['profielOnder', 'profielMidden', 'profielBoven'])):
                        voorbeelden.append(namen)
                assert voorbeelden, 'Geen geneste kalibratiestack'
                assert all((n.index('profielOnder') < n.index('profielMidden') < n.index('profielBoven') for n in voorbeelden)), 'Stackvolgorde niet eenduidig'
                r['stack_kalibratie'] = {'leaf_eerst': True, 'voorbeelden': voorbeelden[:2], 'aantal': len(voorbeelden)}
                with gzip.open(a.uitvoer / 'profielen.json.gz', 'wt', encoding='utf-8') as f:
                    json.dump(p.gebeurtenissen, f, ensure_ascii=False)
                lijsten = {'hoofdthread': []}
                for ev in p.gebeurtenissen[:profiel_einde]:
                    if ev.get('method', '').startswith('ScriptProfiler.'):
                        lijsten['hoofdthread'].append(ev)
                    elif ev.get('method') == 'Worker.dispatchMessageFromWorker':
                        binnen = json.loads(ev['params']['message'])
                        if binnen.get('method', '').startswith('ScriptProfiler.'):
                            lijsten.setdefault(ev['params']['workerId'], []).append(binnen)
                r['samenvatting'] = {}
                for naam, events in lijsten.items():
                    compleet = [e['params'] for e in events if e['method'] == 'ScriptProfiler.trackingComplete']
                    samples = [s for e in compleet for s in e.get('samples', {}).get('stackTraces', [])]
                    top = Counter()
                    inclusief = Counter()
                    for sample in samples:
                        frames = sample.get('stackFrames', [])
                        sleutel = lambda f: (f.get('name'), f.get('url'), f.get('line'), f.get('column'))
                        if frames:
                            top[sleutel(frames[0])] += 1
                        inclusief.update(set((sleutel(f) for f in frames)))
                    intervallen = sorted(((e['params']['event']['startTime'], e['params']['event']['endTime']) for e in events if e['method'] == 'ScriptProfiler.trackingUpdate'))
                    som = 0
                    einde = -1
                    for start, stop in intervallen:
                        som += max(0, stop - max(start, einde))
                        einde = max(einde, stop)
                    r['samenvatting'][naam] = {'events': len(events), 'voltooide_profielen': len(compleet), 'samples': len(samples), 'script_intervallen_unie_s': som if intervallen else None, 'interval_gebeurtenissen': len(intervallen), 'top': top.most_common(25), 'inclusief': inclusief.most_common(35)}
            r['layout_na_opname'] = await p.run("\n              const begin=performance.now(),eind=begin+120000;let laatste=null;\n              while(performance.now()<eind){\n                const s=api().getEditorRef().getYrsSession(),layout=api().getEditorRef().getLayout();\n                const el=document.querySelector('.office-tabpaneel:not([hidden]) .office-tekst .paged-editor');\n                if(!el)throw Error('Actieve paginaview ontbreekt');\n                let gevonden=0;\n                for(let f=el[Object.keys(el).find(k=>k.startsWith('__reactFiber$'))];f;f=f.return)\n                  for(let slot=f.memoizedState,n=0;slot&&n<1500;n++,slot=slot.next){\n                    const v=slot.memoizedState?.current;\n                    if(v?.session!==s||!v.layout||typeof v.final!=='boolean')continue;\n                    gevonden++;\n                    laatste={final:v.final,versie_actueel:v.version===s.version(),layout_actief:v.layout===layout,paginas:v.layout.pages.length};\n                    if(laatste.final&&laatste.versie_actueel&&laatste.layout_actief)\n                      return {...laatste,wacht_ms:performance.now()-begin};\n                  }\n                if(!gevonden)laatste={gevonden,paginas:api().getTotalPages()};\n                await new Promise(r=>setTimeout(r,100));\n              }\n              throw Error('Laatste bron heeft geen voltooide paginering: '+JSON.stringify(laatste));\n            ", t=130)
            # Pas na het profiel exacte bronbytes uit deze eigen binary halen.
            # Minificatienamen of kolommen nooit op een andere build projecteren.
            urls = sorted({f['url'] for events in lijsten.values() for sample in events
                           if sample.get('method') == 'ScriptProfiler.trackingComplete'
                           for s in sample['params'].get('samples', {}).get('stackTraces', [])
                           for f in s['stackFrames']
                           if f.get('url', '').startswith('tauri://localhost/assets/') and f['url'].endswith('.js')})
            assert len(urls) <= 8, 'Te veel hoofdthreadbronnen voor begrensde bronattributie'
            r['scriptbronnen'] = []
            omvang = 0
            for url in urls:
                inhoud = await p.run('const r=await fetch('+json.dumps(url)+');if(!r.ok)throw Error("Eigen scriptbron niet opgehaald");return await r.text();')
                data = inhoud.encode()
                omvang += len(data)
                assert len(data) <= 4*1024*1024 and omvang <= 12*1024*1024, 'Scriptbron overschrijdt de diagnosegrens'
                naam = 'bron-'+url.rsplit('/', 1)[-1]+'.gz'
                (a.uitvoer/naam).write_bytes(gzip.compress(data, mtime=0))
                r['scriptbronnen'].append({'url': url, 'bestand': naam, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
            r.update(await p.ev("({voor,na:api().getEditorRef().getYrsSession().paragraphs('body').at(-1).text,paginas:api().getTotalPages()})"))
            assert r['na'] == r['voor'] + tekst
            teksten_na = await p.ev("Object.fromEntries(api().getEditorRef().getYrsSession().storyIds().map(id=>[id,api().getEditorRef().getYrsSession().paragraphs(id).map(p=>p.text)]))")
            verwacht = {k: list(v) for k, v in teksten_voor.items()}
            verwacht['body'][-1] += tekst
            assert teksten_na == verwacht, 'Een andere alinea of celtekst is gewijzigd'
            r['broncontrole'] = {'verhalen': len(verwacht), 'alinea_en_celteksten': sum(map(len, verwacht.values())), 'exact': True}
            r['fouten_na'] = await p.fouten()
            assert not any(r['fouten_na'].values()), 'Enginefout tijdens de opname'
            g = v.get_geometry()
            raw = v.get_image(0, 0, g.width, g.height, X.ZPixmap, 4294967295)
            Image.frombytes('RGB', (g.width, g.height), raw.data, 'raw', 'BGRX').save(a.uitvoer / 'profiel.png')
            r['geslaagd'] = True
            print(json.dumps({'samples': {n: s['samples'] for n, s in r['samenvatting'].items()}, 'kalibratie': r.get('stack_kalibratie'), 'invoer_en_inspectie_ms': r['invoer_en_inspectie_ms']}, ensure_ascii=False), flush=True)
    except Exception as e:
        r['fout'] = repr(e)
        raise
    finally:
        if app.poll() is None:
            os.killpg(app.pid, signal.SIGTERM)
            try:
                app.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(app.pid, signal.SIGKILL)
                app.wait(timeout=10)
        d.close()
        log.close()
        (a.uitvoer / 'profiel.json').write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
    return 0
basis.proef = proef
basis.__file__ = str(Path(__file__).resolve())
if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('--bron', type=Path, default=os.environ.get('OFFICE_PROFIEL_BRON'))
    p.add_argument('--zonder-profiel', action='store_true', default=os.environ.get('OFFICE_PROFIEL_ZONDER') == '1')
    p.add_argument('--tekst', default=os.environ.get('OFFICE_PROFIEL_TEKST', ' Een proefzin.'))
    p.add_argument('--paginas', type=int, default=int(os.environ.get('OFFICE_PROFIEL_PAGINAS', '500')))
    eigen, overig = p.parse_known_args()
    os.environ['OFFICE_PROFIEL_ZONDER'] = '1' if eigen.zonder_profiel else '0'
    if not eigen.tekst or len(eigen.tekst) > 1000 or any(ord(c) < 32 or ord(c) > 126 for c in eigen.tekst):
        p.error('--tekst vereist 1 tot 1000 afdrukbare ASCII-tekens voor xdotool')
    os.environ['OFFICE_PROFIEL_TEKST'] = eigen.tekst
    if eigen.paginas <= 0:
        p.error('--paginas moet positief zijn')
    os.environ['OFFICE_PROFIEL_PAGINAS'] = str(eigen.paginas)
    if eigen.bron is None and '--help' not in overig:
        p.error('Geef --bron met een eigen DOCX; de proef werkt uitsluitend op een kopie.')
    if eigen.bron is not None:
        os.environ['OFFICE_PROFIEL_BRON'] = str(eigen.bron.resolve(strict=True))
    sys.argv = [sys.argv[0], *overig]
    basis.__doc__ = __doc__
    raise SystemExit(basis.main())
