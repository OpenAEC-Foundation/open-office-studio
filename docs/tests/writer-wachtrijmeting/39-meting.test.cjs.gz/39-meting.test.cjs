/* Controleer doorgifte, afwijzingen, begrenzing en volledig herstel van de observator. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const ctx=vm.createContext({});vm.runInContext(fs.readFileSync(__dirname+'/meting.js','utf8'),ctx);
function proef(){let klok=0,luisteraar,update;const callbacks=[];
 const proto={admit(fn,...rest){this.rest=rest;return this.laatste=Promise.resolve().then(fn)}};
 const rij=Object.create(proto);rij.depth=0;
 const sessie={applyLocalUpdate(v){update?.();return v},setSelection(v){return v},onUpdate(fn){update=fn;return()=>{update=null}}};
 const antwoord={preparationMs:4};const oud=async()=>({json:async()=>antwoord});
 const w={performance:{now:()=>++klok},fetch:oud,__TAURI_INTERNALS__:{convertFileSrc:n=>'ipc://'+n},addEventListener(n,fn){luisteraar=fn},removeEventListener(n,fn){assert.equal(fn,luisteraar);luisteraar=null},requestAnimationFrame(fn){callbacks.push(fn);return callbacks.length},cancelAnimationFrame(){},__OPENAEC_WRITER_INVOERMETING__:{lees:()=>({monsters:[]}),start(){this.actief=true},stop(){assert(this.actief);this.actief=false;return{monsters:[]}}}};
 const orig={...sessie},m=ctx.plaatsWachtrijmeting(w,rij,sessie);
 return{w,rij,sessie,m,oud,orig,antwoord,key(){luisteraar({key:'a',ctrlKey:false,metaKey:false})},frame(){callbacks.shift()(100)}};
}
(async()=>{
 const p=proef(),obj={eigen:true};p.key();p.frame();let binnen;
 const promise=p.rij.admit(async function(){binnen=await p.w.fetch('ipc://writer_tekst_voorbereiden',{body:JSON.stringify({aanvraag:{text:'eigen',basis:'abc'}})});assert.equal(await binnen.json(),p.antwoord);assert.equal(p.sessie.applyLocalUpdate(obj),obj);assert.equal(p.sessie.setSelection(obj),obj);return obj},true);
 assert.equal(promise,p.rij.laatste);assert.equal(await promise,obj);assert.deepEqual(p.rij.rest,[true]);
 const fout=new Error('eigen fout');await assert.rejects(p.rij.admit(()=>{throw fout}),e=>e===fout);
 await assert.rejects(p.rij.admit(async()=>{throw fout}),e=>e===fout);
 const r=p.m.stop();assert.equal(r.gemist,0);assert.equal(r.toetsen,1);assert(r.regels.some(x=>x.soort==='nativejson'&&x.rustMs===4&&x.taak===1));assert(r.regels.some(x=>x.soort==='taakeinde'&&x.goed===false));assert(r.regels.some(x=>x.soort==='bronupdate'));
 assert.equal(p.w.fetch,p.oud);assert.equal(p.sessie.applyLocalUpdate,p.orig.applyLocalUpdate);assert(!Object.hasOwn(p.rij,'admit'));assert(!JSON.stringify(r).includes('abc'));assert(!JSON.stringify(r).includes('eigen'));
 const q=proef();for(let i=0;i<4200;i++)q.key();const cap=q.m.stop();assert.equal(cap.regels.length,4096);assert(cap.gemist>0);
 const rij={admit(){},enqueue(){},captureInteractionEpoch(){},hasPending:()=>false};const el={__reactFiber$eigen:{memoizedState:{memoizedState:{current:rij},next:null},return:null}};
 assert.equal(ctx.zoekEigenInvoerrij({document:{querySelectorAll:()=>[el]}}),rij);assert.throws(()=>ctx.zoekEigenInvoerrij({document:{querySelectorAll:()=>[]}}),/invoer ontbreekt/);
 console.log('Doorgifte, async/sync fouten, taakbinding, begrenzing en herstel slagen.');
})().catch(e=>{console.error(e);process.exitCode=1});
