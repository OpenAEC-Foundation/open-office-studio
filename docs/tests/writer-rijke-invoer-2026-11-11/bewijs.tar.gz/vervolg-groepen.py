from pathlib import Path
import json,subprocess,os,time
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-rijk';p=u/'schema2-groepen/rapport.json'
for _ in range(420):
 if p.exists():break
 time.sleep(1)
x=json.loads(p.read_text());assert x['geslaagd'],x.get('fout')
env=os.environ.copy();env['OFFICE_TEST_JOURNAAL']='1';env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH']
cmd=['/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python',str(r/'scripts/test-writer-rijk-invoer-native.py'),'--programma',str(r/'.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal'),'--uitvoer',str(u/'schema3-groepen'),'--versie','2026.45.52']
with (u/'schema3-groepen.log').open('w') as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=420)
print('schema3',res.returncode,flush=True)
x=json.loads((u/'schema3-groepen/rapport.json').read_text());assert res.returncode==0 and x['geslaagd'],x.get('fout')
