//! Een revisie van een auteur mag geen wijziging van een andere auteur verwijderen.
use base64::{Engine as _, engine::general_purpose::STANDARD};
use docx_edit::{ChangeTarget, EditCtx, EditingDoc};
use office_writer_plakken::{Auteur, Cursor, TekstAanvraag, bereid_tekst_voor, snapshot_sha256};

#[test]
fn koude_voorbereidingen_houden_revisies_van_twee_auteurs_gescheiden() {
    let doc = EditingDoc::new(21);
    doc.keep_deleted();
    doc.create_story_with_paragraph_id("body", "p-body", "Basis", "Normal", "left")
        .unwrap();
    doc.create_story_with_paragraph_id("cell:tabel/0/0", "p-cel", "Cel", "Normal", "left")
        .unwrap();
    for (stap, story, para, tekst, auteur) in [
        (0, "body", "p-body", "A ", "Auteur A"),
        (1, "cell:tabel/0/0", "p-cel", "B ", "Auteur B"),
    ] {
        let bron = doc.encode_state_as_update_v1();
        let antwoord = bereid_tekst_voor(TekstAanvraag {
            schema: 1,
            request_id: format!("revisie-{stap}"),
            document_id: "eigen-revisieproef".into(),
            source_version: format!("bron-{stap}"),
            snapshot_sha256: snapshot_sha256(&bron),
            snapshot: STANDARD.encode(&bron),
            client_id: 21,
            position: Cursor {
                story: story.into(),
                para_id: para.into(),
                offset: 0,
            },
            text: tekst.into(),
            author: Some(Auteur {
                name: auteur.into(),
                date: "2026-11-04T00:00:00Z".into(),
            }),
        })
        .unwrap();
        assert_eq!(
            doc.encode_state_as_update_v1(),
            bron,
            "Voorbereiding verandert de levende bron niet"
        );
        doc.apply_update_v1(&STANDARD.decode(antwoord.delta).unwrap())
            .unwrap();
    }
    assert_eq!(doc.paragraphs("body").unwrap()[0].text, "A Basis");
    assert_eq!(doc.paragraphs("cell:tabel/0/0").unwrap()[0].text, "B Cel");
    let a = doc.list_changes("body").unwrap()[0].revision_id.clone();
    let b = doc.list_changes("cell:tabel/0/0").unwrap()[0]
        .revision_id
        .clone();
    doc.reject_change(&EditCtx::local("", ""), &ChangeTarget::Revision(a.clone()))
        .unwrap();
    assert_eq!(doc.paragraphs("body").unwrap()[0].text, "Basis");
    assert_eq!(
        doc.paragraphs("cell:tabel/0/0").unwrap()[0].text,
        "B Cel",
        "Alleen auteur A verwerpen moet auteur B behouden; revisie-ID's: {a} / {b}"
    );
    assert_ne!(a, b);
    doc.reject_change(&EditCtx::local("", ""), &ChangeTarget::Revision(b))
        .unwrap();
    assert_eq!(doc.paragraphs("cell:tabel/0/0").unwrap()[0].text, "Cel");
}
