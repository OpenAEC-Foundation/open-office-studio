import { createYrsSession } from '@betteroffice/docx/yrs';
import { readFile,writeFile } from 'node:fs/promises';
const uit=[];
for(const uitgesteld of [false,true]){
 const s=await createYrsSession({clientId:71});s.openDocx(new Uint8Array(await readFile('public/templates/nieuw.docx')),true);
 const p=s.paragraphs('body')[0],r={uitgesteld,terugroepen:0,vernietigd:false,fouten:[]};
 const sluit=()=>{try{s.destroy();r.vernietigd=true}catch(e){r.fouten.push({fase:'vernietigen',fout:String(e),stack:e.stack})}};
 s.onUpdate(()=>{r.terugroepen++;uitgesteld?queueMicrotask(sluit):sluit()});
 try{s.insertText({story:'body',paraId:p.paraId,offset:0},'Eigen proef')}catch(e){r.fouten.push({fase:'invoeren',fout:String(e),stack:e.stack})}
 await new Promise(r=>setTimeout(r,10));uit.push(r);
}
await writeFile('.local/doorwerk-2026-11-06/ci52-vervolg/vernietigen-terugroep.json',JSON.stringify(uit,null,2)+'\n');
console.log(JSON.stringify(uit.map(({uitgesteld,terugroepen,vernietigd,fouten})=>({uitgesteld,terugroepen,vernietigd,fouten:fouten.map(x=>x.fout)}))));
