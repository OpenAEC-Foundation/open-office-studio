from pathlib import Path
import hashlib,json,gzip
r=Path.cwd();u=r/'.local/doorwerk-2026-11-06/ci52-vervolg';out=r/'docs/tests/platformen-52-vervolg';out.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def lees(p):return json.loads(p.read_text())
def bewaar(p,naam):
 q=out/(str(naam)+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for f in sorted(u.glob('*')):
 if f.is_file()and f.suffix in ['.json','.log','.py','.mjs']:bewaar(f,f.name)
for naam in ['vernietigingsherhaling','layoutdiagnose']:
 for f in sorted((u/naam).rglob('*')):
  if f.is_file()and f.suffix in ['.json','.png','.log']:bewaar(f,f.relative_to(u))
for f in sorted((u/'geheugen/normaal').iterdir()):
 if f.is_file()and f.suffix in ['.json','.png','.log']:bewaar(f,'ci-geheugen/'+f.name)
p=u/'geheugen/foutcontext/uitgepakt/writer-foutcontext'
for f in [p/'context.json',p/'rapport.json',p/'SHA256SUMS',*sorted((p/'scripts').rglob('*'))]:
 if f.is_file():bewaar(f,'oorspronkelijk/'+str(f.relative_to(p)))
d=lees(u/'desktop.json');assert d['conclusion']=='success'and d['headSha']=='4516ef72ef086781669ec058bdeb4f7ab4bc2a3c'
assert all(j['conclusion']=='success'for j in d['jobs'])
neg=lees(u/'geheugen/normaal/rapport.json');calls=neg['native_leesaanroepen'];assert calls['layoutDocumentWithRegionsRetainedJson']['calls']==8 and not calls['worker_berichten'];assert neg['workerbron']['berichten']==0
l=lees(u/'layoutdiagnose/rapport.json');assert l['geslaagd'];assert l['native_leesaanroepen']['layoutDocumentWithRegionsRetainedJson']['calls']==0;assert l['native_leesaanroepen']['worker_voor_invoer'][0]['worker'];assert not l['native_leesaanroepen']['worker_voor_invoer'][0]['uitgevallen']
vern=[]
for f in sorted((u/'vernietigingsherhaling').glob('*/rapport.json')):
 v=lees(f);assert v['geslaagd'];assert [(m['soort'],m.get('id'))for m in v['vernietiging']]==[('begin',1),('eind',1)];vern.append({'ronde':f.parent.name,'geslaagd':True,'trace':v['vernietiging']})
node=lees(u/'vernietigen-terugroep.json');assert all(v['vernietigd']and not v['fouten']and v['terugroepen']==1 for v in node)
e=lees(u/'edities.json')
rapport={'schema':1,'datum':'2026-11-06','bronrevisie':'4516ef72ef086781669ec058bdeb4f7ab4bc2a3c','appversie':'2026.45.52','productiecode_gewijzigd':False}
rapport['desktop']={'run':42222568766,'conclusie':d['conclusion'],'platformen':[{'naam':j['name'],'conclusie':j['conclusion']}for j in d['jobs']]}
rapport['edities']={'run':42222572441,'status':e['status'],'conclusie':e['conclusion'],'taken':[{'naam':j['name'],'status':j['status'],'conclusie':j['conclusion']}for j in e['jobs']]}
rapport['geheugen']={
 'run':42222544683,'artifact':13504733624,'conclusie':'failure','primaire_fout':neg['fout'],'leesaanroepen':calls,'workerbron':neg['workerbron'],
 'vervolgfout':'Bronupdateproef heeft geen volledige reeks omdat de oorspronkelijke proef eerder is afgebroken; geen replayherstel claimen.',
 'latere_scenarios':'Spellingonderbreking na 128 tabellen niet uitgevoerd in deze CI-ronde; blijft alleen lokaal getoetst.',
 'context_sha256':h(u/'geheugen/foutcontext/writer-foutcontext.tar.gz'),'elf_sha256':h(p/'open-office-studio'),
 'binding':'Tar en interne SHA256SUMS gecontroleerd; ELF 3beec071... gelijk aan de eerdere 45.52-afkeuring.'}
rapport['layoutdiagnose']={
 'geslaagd':True,'programma_sha256':l['programma_sha256'],'native_leesaanroepen':l['native_leesaanroepen'],
 'omvang':'Eigen 500-paginabron, invoer, spellingweergave, frame-/workerbronbewaking, echte herstelkopie/heropenen/herstelkeuzes; oorspronkelijke limieten/asserties behouden.',
 'grens':'Extra begrensde workerstatus en stacks op de eigen sessie; geen ongestoorde prestatievergelijking. Oorspronkelijke CI-route zonder worker niet gereproduceerd of hersteld.'}
rapport['vernietigingsdiagnose']=vern
rapport['afgewezen_hypothese']={
 'proef':'Direct vernietigen vanuit een eigen update-terugroep op de werkelijke Node/Wasm-sessie, tegenover uitstellen via microtaak.',
 'uitkomsten':node,'besluit':'Beide routes slagen; deze eenvoudige terugroep verklaart de CI-leenfout niet. Geen uitstelpatch of foutonderdrukking overnemen.'}
rapport['opzetafkeuring']='Eerste inline archiefopzet had een Python-syntaxfout; voor bestandsmutaties gestopt. Deze afzonderlijke archiveringsbron vervangt die opzet.'
rapport['grenzen']=[
 'Geen productcode, SDK, versie, gebruikersprofiel of document gewijzigd.',
 'Groene desktopronde herstelt de eerdere leenfout en het lege venster niet.',
 'Nieuwe geheugenafkeuring blijft open; geen geheugen-/snelheidsacceptatie.',
 'Geen issue/migratievlag gesloten; volledige Rust-interface en suite blijven onvoltooid.',
 'Geen nieuwe devdownload onafhankelijk gecontroleerd; gebruiksgids blijft bij gecontroleerde cfa1059-download.']
rapport['volgende_stap']='Leg workerstatus en volledige layout-/lettertype-aanroepstacks vast wanneer de CI-hoofdthreadroute werkelijk optreedt. Leg oorspronkelijke exception.stack bij de leenfout vast vóór sluiten van de inspector; drie vernietigingsronden leveren nog geen foutstack. Onderzoek resterende invoernaloop met concrete oorzaakmeting; behoud negatieve ELF, bronnen en referentie.'
rapport['bestanden']={str(f.relative_to(r)):h(f)for f in sorted(out.rglob('*.gz'))}
(r/'docs/tests/2026-11-06-platformen-52-vervolg.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n')
print('Vervolgbewijs vastgelegd',len(rapport['bestanden']))
