from pathlib import Path
import hashlib, io, json, tarfile

r = Path.cwd()
p = r / '.local/integratiecontrole/projectie-context'
out = r / 'docs/tests'
label = '2026-11-16-writer-projectie-context'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
rounds = read('native-ronden.json')
previous = read('native-vorige.json')
assert len(rounds) == 8 and len(previous) == 2
assert all(x['geslaagd'] and x['code'] == 0 for x in rounds + previous)
for n in ['proef-geaccepteerde-kern.json', 'contextmatrix.json', 'react-proef.json', 'structuur-overdracht.json']:
    assert read(n)['geslaagd'], n
assert len(read('documenten-beelden.json')['documenten']) == 10
files = [f for f in sorted(p.rglob('*')) if f.is_file()
         and not set(f.relative_to(p).parts) & {'dist', 'standaarddist', '__pycache__', '.vite'}
         and not f.name.startswith('open-office-studio')]
manifest = {str(f.relative_to(p)): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in files}
archive = out / (label + '.tar.gz')
with tarfile.open(archive, 'w:gz', compresslevel=6) as t:
    for f in files:
        t.add(f, arcname=str(f.relative_to(p)), recursive=False)
    b = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json')
    info.size = len(b)
    t.addfile(info, io.BytesIO(b))
with tarfile.open(archive) as t:
    assert set(t.getnames()) == set(manifest) | {'manifest.json'}
    for name, item in manifest.items():
        b = t.extractfile(name).read()
        assert len(b) == item['bytes'] and hashlib.sha256(b).hexdigest() == item['sha256']
report = {
    'datum': '2026-11-16', 'basis_integratie': 'cac82c4d', 'basis_hoofdbranch': '2da1986c',
    'productbron': '41e7000198f89d992e1059e9715636a44b39d21a',
    'besluit': 'Private contextcorrectie slaagt functioneel en behoudt snelle hits tijdens openen/preview. Geen overtuigende native prestatiewinst: niet in product overgenomen. Ook de bewaarde vorige kandidaat reproduceert de eerdere circa9,3s niet; geen causaal nadeel aan alleen de correctie toegeschreven.',
    'implementatie': 'Huidige cachehit vergelijkt opgeslagen opening, previewing en workerroute met actuele waarden in plaats van hits tijdens openen/preview steeds te blokkeren. Het extra hergebruik na invalidatie blijft uitgesloten als oude of huidige context opent/previewt of niet de workerroute gebruikt. Sessie/generatie/gereedheid/segmentbron/bronversievoorwaarden en uitgebreide hookafhankelijkheden behouden. Alleen private editors-JS op acb770-basis; geen warm/R(k)/Wasm/productwijziging.',
    'variant': {'desktop': read('desktop.json'), 'bundel': read('bundel.json'),
                'bronpinnen': read('bronpinnen.json'), 'diff': read('diff-grenzen.json'),
                'sdk_contextcontract': read('core-contract.json'),
                'platform': 'Linux x86_64 release2026.45.52, writer-bronjournaal, runtimeschema2; eigen X11/DBus/XDG-profielen en eigen fixtures.'},
    'volledige_projectie': read('proef-geaccepteerde-kern.json'),
    'snelle_huidige_hits': read('contextmatrix.json'),
    'react_hook': read('react-proef.json'),
    'structuur_en_sessie': read('structuur-overdracht.json'),
    'native_abba': rounds,
    'extra_vorige_kandidaat': previous,
    'metingen': {kind: [{'naam': x['naam'], 'wall_ms': x['invoer']['wall_begin_tot_frame_ms'],
                         'keyup_frame_ms': x['invoer']['laatste_keyup_tot_frame_ms']}
                        for x in rounds + previous if x['naam'].startswith('native-' + kind)]
                 for kind in ['klein', 'rijk']},
    'documenten_en_beelden': read('documenten-beelden.json'),
    'pakketvergelijking': read('pakketvergelijking.json'),
    'beeldbeoordeling': read('beeldbeoordeling.json'),
    'behoud': read('behoud.json'), 'scriptcontroles': read('scriptcontroles.json'),
    'afkeuringen': [
        'De onderbroken eerste voorbereider van13november sloeg contextvelden nog niet op; geen eindrapport of geslaagde proef. Oude callbacks en lege runlog behouden. Voor hervatte uitvoering is de voorbereider gecorrigeerd.',
        'Eerste extra structuurharness vergat raw.track_undo(); undo gaf false voordat tracking begon. Na expliciet starten van tracking slagen echte split/undo/redo.',
        'Tweede structuurharness nam ten onrechte storyprefix cell: aan. Na lezen van de echte eerste tabelcelstory slagen nest/undo/redo en sessieoverdracht. Beide afkeuringen ongewijzigd bewaard; geen productregressie hieruit geclaimd.'
    ],
    'grenzen': [
        'Werkelijke volledige projectie en segmentcache uit vastgepinde bron op echte geaccepteerde Wasm. Gecontroleerde adapter invalideert alle stories bij versiewijziging; idle/digestplanner uitgeschakeld. Geen volledige SDK-/React-editorprojectie in componentproef.',
        'Negen rijke toestanden, tien contextgrenzen, dertig corpusgevallen met43 echte updates behouden node/locatie/target/blockBoundary/tabellen en staat/versie. Targets in corpus elke31 en aanwezige nodes; rijke toestanden alle posities. Hoofdproef heeft16434026locatie-,2478610target- en16565940nodecontroles.',
        'Zes contexttoestanden: normaal/openen/preview/geenworker/nietgereed/onbekendegeneratie. Elke toestand houdt16herhaalde huidige hits zonder nieuwe constructie of version()-lezing. Na invalidatie alleen normaal hergebruik; overige toestanden een verse constructie, daarna weer hits.',
        'Werkelijke React19/createRoot/useCallback in Chromium151 met verse coreobjecten en contextovergangen. De echte callback gebruikt hier een gecontroleerde sessie/projectiefactory; geen native WebKit/full-editor-overdracht. Negatieve afhankelijkhedencontrole houdt onterecht oude callback/projectie bij generatiewissel.',
        'Acht extra echte Wasm-toestanden: basis,cel splitsen,undo,redo,samenvoegen,nest,undo,redo. Twee aanvullende sessiefasen laden dezelfde bron in een andere echte Wasm-sessie,opening/nietgereed en gereed.1718958locatie- en1732866node/targetcontroles exact; geen echte Worker-timing/handoffprotocol of native tabel-GUI-acceptatie.',
        'ABBA zonder gelijktijdige bouw/componentproeven/profielopname. Twee extra vorige-kandidaatronden volgen erna; geen tweede volledige gerandomiseerde driewegvergelijking. Andere meetdag is geen bewijs voor een specifieke machineoorzaak.',
        'Wandklok vanaf fysieke verzending omvat wachten voor keyupontvangst; renderlijst+twee rAFs is geen fysieke schermpaint. Geen algemene causaliteit of snelheidswinst uit slechts minder gemodelleerde constructies.',
        'Tien DOCX onafhankelijk SHA/ZIP/CRC/XML/relaties/tabellen/UTF16 gecontroleerd:klein1tabel736UTF16,rijk128tabellen91423UTF16. Binnen corpus alleen core.xmlverschil.14/18 vaste ABBA-beeldparen pixelgelijk,twee geselecteerde beelden bekeken; geen volledige visuele acceptatie.'
    ],
    'niet_gecontroleerd': [
        'Geen productiepatch/SDK/vendorwijziging, volledige frontend/TypeScript/Python-productsuite, volledige SDK-typecheck of product-CI. Private Linux-featurebouw en genoemde gerichte proeven wel uitgevoerd.',
        'Geen Windows/macOS, installers, andere edities/features/schema/releasevarianten, volledige IME/accessibility/alle documenten/visuele dekking.',
        'Bestaande geheugen-/RefCell-fouten en migratiegebieden blijven open. Geen issue gesloten.'
    ],
    'vervolg': 'Tel op de gecorrigeerde ee89c80e-kandidaat begrensd de werkelijk uitgevoerde huidige cachehits, extra hergebruikshits en constructies/afwijzingsredenen, gekoppeld aan sessie/generatie/replicaReady/opening/preview/segmentbron en bron-/projectieversie. Gebruik normale JS-meetexpressies met verliesloze groepering, geen hoofdthread-Debugger. Verifieer eerst of de native route werkelijk hergebruikt voordat een nieuwe cache-/uitstelwijziging of productovername volgt. Behoud huidige contextcorrectie en volledige projecties. Vergelijk daarna dezelfde bron op vaste normale native ronden; geen prestatiewinst op13november als blijvend aannemen. R(k) apart, Database laatst.',
    'afhankelijkheden': [{'pad': 'docs/tests/2026-11-13-writer-projectie-hergebruik.tar.gz',
                         'sha256': sha(out / '2026-11-13-writer-projectie-hergebruik.tar.gz')}],
    'bewijs': {'pad': str(archive.relative_to(r)), 'sha256': sha(archive),
               'bytes': archive.stat().st_size, 'bestanden': len(files),
               'alle_leden_byteexact_gecontroleerd': True,
               'uitsluiting': 'Geen ELF/Wasm/dist. Wel callbacks/diff/modules/gecontroleerde planner,React-browserproef,component/corpusupdates/structuurproeven,alle afkeuringen,10nativefunctierapporten,DOCX/PNG/logs en bron/bouw/referentiepinnen.'}
}
(out / (label + '.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['bewijs']))
