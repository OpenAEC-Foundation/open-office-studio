import React,{useCallback,useRef} from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import code from '../callback-na.js?raw';
window.run = (negative=false) => {
 const element=document.createElement('div');document.body.append(element);const root=createRoot(element);let latest,builds=0,versionReads=0,sourceVersion='v1';
 const session={hasStory:s=>s==='body',version:()=>{versionReads++;return sourceVersion}};
 let segments={session,disposed:false,scheduleDigests(){}};
 const currentStorySegments=()=>segments;
 const createYrsPositionProjection=()=>({id:++builds});
 function Probe({core}){
  const projectionReplicaReadyRef=useRef(true),yrsProjectionVersionRef=useRef(0),yrsPositionProjectionCacheRef=useRef(null),yrsStorySegmentsRef=useRef(segments);
  const env={yrsCore:core,projectionReplicaReadyRef,yrsProjectionVersionRef,yrsPositionProjectionCacheRef,yrsStorySegmentsRef,currentStorySegments,createYrsPositionProjection};
  const factory=Function(...Object.keys(env),code)(...Object.values(env));
  const deps=negative?[currentStorySegments,core.session]:[currentStorySegments,core.session,core.sessionGeneration,core.replicaReady,core.replicaReadyRef,core.experimentalWorkerOpen,core.opening,core.previewing];
  const callback=useCallback(factory,deps);latest={callback,core,bump:()=>yrsProjectionVersionRef.current++,source:yrsStorySegmentsRef};return null;
 }
 const assert=(v,m)=>{if(!v)throw Error(m)};
 let core={session,sessionGeneration:1,replicaReady:true,replicaReadyRef:{current:true},experimentalWorkerOpen:true,opening:false,previewing:false};
 const render=patch=>{core={...core,...patch};flushSync(()=>root.render(React.createElement(Probe,{core})));};
 const rows=[];
 try{
  render({});let prev=latest.callback,projection=prev('body');assert(builds===1,'eerste bouw');render({});assert(latest.callback===prev,'gelijke nieuwe core');assert(latest.callback('body')===projection,'gelijke context');
  render({sessionGeneration:2});let next=latest.callback('body');
  if(negative)return {negatieve_controle:true,verouderde_callback:latest.callback===prev,verouderde_projectie:next===projection,bouw:builds};
  assert(latest.callback!==prev&&next!==projection&&builds===2,'verse generatie');rows.push('verse core met nieuwe generatie');
  for(const patch of [{opening:true},{opening:false},{previewing:true},{previewing:false},{experimentalWorkerOpen:false},{experimentalWorkerOpen:true},{replicaReady:false,replicaReadyRef:{current:false}},{replicaReady:true,replicaReadyRef:{current:true}},{sessionGeneration:undefined},{sessionGeneration:3}]){
   const old=latest.callback('body');render(patch);const count=builds;next=latest.callback('body');assert(next!==old&&builds===count+1,'contextovergang '+JSON.stringify(patch));
   const reads=versionReads;for(let i=0;i<16;i++)assert(latest.callback('body')===next,'huidige hit');assert(builds===count+1&&versionReads===reads,'hit zonder bronlezing');
   latest.bump();const permitted=core.experimentalWorkerOpen&&core.replicaReady&&core.sessionGeneration!==undefined&&!core.opening&&!core.previewing;
   const after=latest.callback('body');assert((after===next)===permitted,'invalidatie '+JSON.stringify(patch));rows.push({patch,huidige_hits:16,hergebruik_na_invalidatie:permitted});
  }
  sourceVersion='v2';latest.bump();const b=builds;latest.callback('body');assert(builds===b+1,'nieuwe bronversie');rows.push('nieuwe bronversie');
  segments={session,disposed:false,scheduleDigests(){}};latest.source.current=segments;const c=builds;latest.callback('body');assert(builds===c+1,'nieuwe segmentbron');rows.push('nieuwe segmentbron');
  return {geslaagd:true,gevallen:rows,builds,versionReads,grens:'Werkelijke React19/createRoot/useCallback in Chromium; echte callback, gecontroleerde sessie/projectiefactory. Geen native WebKit/volledige editor/replicaoverdracht.'};
 }finally{flushSync(()=>root.unmount());element.remove();}
};window.ready=true;
