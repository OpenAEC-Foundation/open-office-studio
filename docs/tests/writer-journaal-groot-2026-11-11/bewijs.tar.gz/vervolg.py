from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-groot';python='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-02/gui-python/bin/python';env=os.environ.copy();env['PATH']='/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin:'+env['PATH']
p=u/'schema2-eerste/rapport.json'
for _ in range(180):
 if p.exists():break
 time.sleep(1)
assert json.loads(p.read_text())['geslaagd']
scenario=[('referentie-schema2',r/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding',2,False),('schema3-tweede',r/'.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal',3,False),('negatieve-route',r/'.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal',2,True)]
for naam,exe,schema,neg in scenario:
 cmd=[python,str(r/'scripts/test-writer-lang-native.py'),'--programma',str(exe),'--uitvoer',str(u/naam),'--versie','2026.45.52','--tekstschema',str(schema),'--verwacht-rust-tekst']
 cmd+=['--verwacht-bronjournaal'] if schema==3 or neg else ['--verwacht-incrementele-bron']
 with (u/(naam+'.log')).open('w') as log:
  res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rapport=json.loads((u/naam/'rapport.json').read_text());print(naam,res.returncode,rapport.get('invoer_tot_bron_en_golven_ms'),rapport.get('fout'),flush=True)
 if neg:
  assert res.returncode!=0 and 'Geen volledige echte schema-3-journaalroute' in rapport['fout'] and all(x['schema']==2 for x in rapport['rust_teksttransport']['bindingen'])
 else:assert res.returncode==0 and rapport['geslaagd']
