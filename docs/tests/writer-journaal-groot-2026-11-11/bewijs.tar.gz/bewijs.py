from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import json,hashlib,tarfile,subprocess
from PIL import Image,ImageChops
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-groot';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
namen=['schema3-eerste','schema2-eerste','referentie-schema2','schema3-tweede'];uitkomsten={}
for naam in namen:
 gegevens=json.loads((u/naam/'rapport.json').read_text());assert gegevens['geslaagd'] and len(gegevens['stappen'])==8 and all(stap['exact'] for stap in gegevens['stappen'])
 assert gegevens['getypt_frame']['getypte_tekst_aanwezig']
 uitkomsten[naam]={'programma_sha256':gegevens['programma_sha256'],'script_sha256':gegevens['script_sha256'],'invoer_tot_bron_en_golven_ms':gegevens['invoer_tot_bron_en_golven_ms'],'rAF_max_ms':gegevens['frame_tussenpozen_ms']['maximum'],'rAF_p95_ms':gegevens['frame_tussenpozen_ms']['p95'],'native_aanvragen':len(gegevens['rust_teksttransport']['aanvragen']),'werkelijke_schemas':sorted(set(b['schema'] for b in gegevens['rust_teksttransport']['bindingen'])),'stappen':gegevens['stappen'],'bewaar_sha256':sha(u/naam/'Prestatieproef.docx')}
neg=json.loads((u/'negatieve-route/rapport.json').read_text());assert not neg['geslaagd'] and 'Geen volledige echte schema-3-journaalroute' in neg['fout'] and all(b['schema']==2 for b in neg['rust_teksttransport']['bindingen'])
vergelijk={}
for naam in namen[1:]:
 with ZipFile(u/namen[0]/'Prestatieproef.docx') as links,ZipFile(u/naam/'Prestatieproef.docx') as rechts:
  assert set(links.namelist())==set(rechts.namelist())
  verschillend=[n for n in links.namelist() if links.read(n)!=rechts.read(n)]
  assert verschillend==['docProps/core.xml'] or verschillend==[]
  if verschillend:
   la,ra=ET.fromstring(links.read(verschillend[0])),ET.fromstring(rechts.read(verschillend[0]));assert la.tag==ra.tag and la.attrib==ra.attrib and len(la)==len(ra)
   velden=[]
   for l,v in zip(la,ra):
    assert l.tag==v.tag and l.attrib==v.attrib
    if l.text!=v.text:velden.append(l.tag)
   assert velden==['{http://purl.org/dc/terms/}modified']
  vergelijk[naam]={'onderdelen':len(links.namelist()),'verschillend':verschillend,'alleen_bewaarmoment_verschilt':bool(verschillend)}
beelden={}
for naam in namen[1:]:
 beelden[naam]={}
 for beeld in ['getypt-pagina-500','startlint','kopvoetlint']:
  a=Image.open(u/namen[0]/(beeld+'.png')).convert('RGB');b=Image.open(u/naam/(beeld+'.png')).convert('RGB');d=ImageChops.difference(a,b);beelden[naam][beeld]={'bbox':d.getbbox(),'afwijkende_pixels':sum(v!=(0,0,0) for v in d.getdata()),'zichtbaar_document_bbox':d.crop((332,231,1126,978)).getbbox()}
(u/'vergelijking.json').write_text(json.dumps({'pakketten':vergelijk,'beelden':beelden},indent=2))
assert 'Ran 127 tests' in (u/'python.log').read_text() and '\nOK\n' in (u/'python.log').read_text()
(u/'bron.diff').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','scripts/test-writer-lang-native.py']))
subprocess.run(['git','diff','--check'],check=True)
d=r/'docs/tests/writer-journaal-groot-2026-11-11';d.mkdir(exist_ok=True,parents=True);archief=d/'bewijs.tar.gz';leden={}
with tarfile.open(archief,'w:gz') as tar:
 for p in u.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.py','.diff','.png','.docx']:
   n=str(p.relative_to(u));tar.add(p,arcname=n);leden[n]=sha(p)
 p=r/'scripts/test-writer-lang-native.py';tar.add(p,arcname='bron/'+p.name);leden['bron/'+p.name]=sha(p)
with tarfile.open(archief,'r:gz') as tar:
 for n,h in leden.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==h
rapport={'datum':'2026-11-11','appbron':'4c13723b0f5dec055ea79e1dfb1be3629f5c9bb9','appgewijzigd':False,'geinstalleerd':False,'methode':'Opeenvolgende eigen DBus/Xvfb-profielen, gegenereerde bron met500pagina’s en500alinea’s. Fysieke toetsen20msinterval, geen kunstmatige IPC-antwoordvertraging. Dezelfde feature-ELF kiest2/3 vóór verse editoropening. Geen gelijktijdige benchmarkprocessen.','resultaten':uitkomsten,'native_bewijs':'Werkelijke IPC-URL en request-envelop onderschept. Schema3 vereist volledige bronbinding, exacte levensduur en opeenvolgende volgnummers1..N. Negatieve schema2/verwacht3 wordt terecht afgekeurd.','pakketvergelijking':vergelijk,'visuele_duiding':'Getypt-pagina-500 van schema3-eerste, schema2-eerste en referentie is volledig pixelgelijk. Lintbeelden worden kort na Ctrl+S genomen: zichtbare bewaarmeldingen bevatten verschillende eigen uitvoerpaden en zijn niet uitgefilterd. Het referentie-startlint en schema3-getypte beeld zijn visueel bekeken. Geen volledige pixelacceptatie op deze niet-gestabiliseerde lintbeelden.','beelden':beelden,'testen':'127Python-tests en diffcheck groen. Acht functionele controles per positieve ronde, inclusief selectie/Backspace, Undo/Redo, onafhankelijk gelezen Ctrl+S-pakket en volledig nieuw proces met heropende500alinea’s.','ci':'43048315760:Windows/macOS geslaagd. Linux faalt vóór bouwen bij apt wegens DNS azure.archive.ubuntu.com; werkelijk foutlog bewaard. Alleen mislukte taak opnieuw gestart. Nieuwe uitslag nog volgen.','grenzen':['Schema3 wordt vóór de eerste verse editoropening gezet; de afsluitende nieuwe-procesheropening gebruikt de gewone standaardroute2. Dit bewijst bestandscompatibiliteit, niet schema3 na procesherstart.','Invoertijd loopt vanaf begin fysieke toetsreeks tot flush/bron/golven. Geen zuivere laatste-keyup-tot-pixelvertraging; frame-inhoud apart na nawacht gecontroleerd.','rAF-intervallen zijn geen fysieke beeldscherm-FPS. Virtuele X11-server zonder DRI3-versnelling; zelfde runtime maar geen gebruikersmachine-acceptatie.','Eén synthetische500paginafixture en korte toetsreeks; geen enorme plakreeks, rijke tabellen, IME of langdurig geheugenbewijs.','Voorlopige enkele ronde schema2/referentie; geen statistische snelheidsconclusie of automatische activatie op basis van deze metingen.','Beelden ongecorrigeerd vergeleken; afwijkingen blijven vermeld. Geen volledige pixel-, suite-, releasevariant- of platformacceptatie.'], 'volgende_stap':'Meet dezelfde echte routes met fysieke keyup-tot-rendered-framebarrière en meerdere omgekeerde paren. Profileer resterende hoofdthreadkosten. Bewaak rijke/lange invoer en gesloten sessies; opt-in blijft uit tot voldoende bewijs.','bewijs':{'pad':str(archief.relative_to(r)),'sha256':sha(archief),'bytes':archief.stat().st_size,'leden':len(leden)}}
(r/'docs/tests/2026-11-11-writer-journaal-groot.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'resultaten':{n:{k:v for k,v in g.items() if k in ['invoer_tot_bron_en_golven_ms','rAF_max_ms','rAF_p95_ms']} for n,g in uitkomsten.items()},'beelden':beelden,'bewijs':rapport['bewijs']}))
