from pathlib import Path
import tarfile,hashlib,json,os,shutil,stat
r=Path.cwd();u=r/'.local/integratiecontrole/invoerwachtrij';a=u/'vorige-standaardbundel.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mappen=[r/'dist'];leden={}
for d in mappen:
 assert d.is_dir() and not d.is_symlink() and d.resolve()==r/'dist'
 for p in d.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():
   s=p.stat();leden[str(p.relative_to(r))]={'sha256':sha(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'inode':s.st_ino}
assert leden
with tarfile.open(a,'w:gz',compresslevel=3) as t:
 for d in mappen:t.add(d,arcname=str(d.relative_to(r)))
herstelnaam=None;gezien=set()
with tarfile.open(a,'r|gz') as t:
 for lid in t:
  if not lid.isfile():continue
  n=lid.name;assert n in leden;m=leden[n];inhoud=t.extractfile(lid).read();assert hashlib.sha256(inhoud).hexdigest()==m['sha256'];gezien.add(n)
  if herstelnaam is None and n.endswith('.wasm'):
   herstelnaam=n;p=u/'herstelde-eigen-asset.wasm';p.write_bytes(inhoud);os.chmod(p,m['mode']);os.utime(p,ns=(m['mtime_ns'],m['mtime_ns']));assert sha(p)==m['sha256'] and p.stat().st_mtime_ns==m['mtime_ns'] and stat.S_IMODE(p.stat().st_mode)==m['mode'];p.unlink()
assert gezien==set(leden) and herstelnaam

for n,m in leden.items():
 p=r/n;s=p.stat();assert s.st_ino==m['inode'] and s.st_mtime_ns==m['mtime_ns'] and s.st_size==m['bytes'] and sha(p)==m['sha256']
manifest={'archief':str(a.relative_to(r)),'sha256':sha(a),'bytes':a.stat().st_size,'oorspronkelijke_bytes':sum(m['bytes'] for m in leden.values()),'leden':leden,'bronmappen':[str(d.relative_to(r)) for d in mappen],'alle_leden_teruggelezen':True,'herstelproef':herstelnaam,'geen_programmas_of_documenten':True,'status':'geverifieerd_vóór_verwijderen_losse_cache'}
(u/'standaardbundelarchief.json').write_text(json.dumps(manifest,indent=2))
for d in mappen:shutil.rmtree(d)
manifest['status']='alleen_losse_eigen_bundelcache_verwijderd_archief_behouden';(u/'standaardbundelarchief.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in manifest.items() if k!='leden'}))
