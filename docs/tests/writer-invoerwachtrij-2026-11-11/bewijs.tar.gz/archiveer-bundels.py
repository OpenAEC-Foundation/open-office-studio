from pathlib import Path
import tarfile,hashlib,json,os,shutil,stat
r=Path.cwd();u=r/'.local/integratiecontrole/invoerwachtrij';a=u/'oude-eigen-bundels.tar.gz';assert not a.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mappen=[r/'.local/integratiecontrole/journaal-desktop/dist-voor-bouw',r/'.local/integratiecontrole/journaal-profiel/dist-voor-bouw',r/'.local/integratiecontrole/journaal-frontend/dist'];leden={}
for d in mappen:
 assert d.is_dir() and not d.is_symlink() and str(d.resolve()).startswith(str(r/'.local/integratiecontrole')+'/')
 for p in d.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():
   s=p.stat();leden[str(p.relative_to(r))]={'sha256':sha(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'inode':s.st_ino}
assert leden
with tarfile.open(a,'w:gz',compresslevel=3) as t:
 for d in mappen:t.add(d,arcname=str(d.relative_to(r)))
with tarfile.open(a,'r:gz') as t:
 for n,m in leden.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==m['sha256']
 # Echte herstelproef van een eigen wasm-asset, inclusief vastgelegde metadata.
 n=next(n for n in leden if n.endswith('.wasm'));m=leden[n];p=u/'herstelde-eigen-asset.wasm';p.write_bytes(t.extractfile(n).read());os.chmod(p,m['mode']);os.utime(p,ns=(m['mtime_ns'],m['mtime_ns']));assert sha(p)==m['sha256'] and p.stat().st_mtime_ns==m['mtime_ns'];p.unlink()
for n,m in leden.items():
 p=r/n;s=p.stat();assert s.st_ino==m['inode'] and s.st_mtime_ns==m['mtime_ns'] and s.st_size==m['bytes'] and sha(p)==m['sha256']
manifest={'archief':str(a.relative_to(r)),'sha256':sha(a),'bytes':a.stat().st_size,'oorspronkelijke_bytes':sum(m['bytes'] for m in leden.values()),'leden':leden,'bronmappen':[str(d.relative_to(r)) for d in mappen],'alle_leden_teruggelezen':True,'herstelproef':n,'geen_programmas_of_documenten':True,'status':'geverifieerd_vóór_verwijderen_losse_cache'}
(u/'bundelarchief.json').write_text(json.dumps(manifest,indent=2))
for d in mappen:shutil.rmtree(d)
manifest['status']='alleen_losse_eigen_bundelcache_verwijderd_archief_behouden';(u/'bundelarchief.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in manifest.items() if k!='leden'}))
