from pathlib import Path
import json,hashlib,tarfile,zipfile
from PIL import Image,ImageChops
r=Path.cwd();u=r/'.local/integratiecontrole/invoerwachtrij';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();namen=['nieuw-rijk2','nieuw-klein2-definitief','oud-klein2','nieuw-rijk3','oud-rijk2','nieuw-rijk2-herhaling','oud-klein2-herhaling','nieuw-klein2-herhaling'];result={};alleen_gereed=True
for n in namen:
 p=u/n/'rapport.json'
 assert p.exists(),n
 a=json.loads(p.read_text());assert a['geslaagd'] is True,n
 tekst=(' Een langere proefzin met gewone woorden en spaties.'*20+' EINDEPROEF.') if 'rijk' in n else ' Een korte zin. EINDEPROEF.'
 samen='';totaal=0;met_caret=0
 for v in a['native_opdrachten']:
  totaal+=1
  if v.get('caret'):samen+=v['text'];met_caret+=1
  assert tekst.startswith(samen),n
  if samen==tekst:break
 assert samen==tekst,n
 result[n]={'schema':a['schema'],'programma_sha256':a['programma_sha256'],'script_sha256':a['script_sha256'],'invoer':a['lange_invoer'],'gewone_native_aanvragen':totaal,'gewone_met_caret':met_caret,'native_tekst_exact':True,'undo_groepen':a['undo_groepen_lange_invoer'],'bewaarde_tabellen_exact':a['bewaarde_tabellen_exact'],'stappen':a['stappen'],'fouten':a['fouten']}
print(json.dumps(result,ensure_ascii=False,indent=2))
(u/'samenvatting.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
