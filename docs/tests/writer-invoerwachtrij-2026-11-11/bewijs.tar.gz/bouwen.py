from pathlib import Path
import hashlib,json,subprocess,os,signal,shutil,time,re
r=Path.cwd();u=r/'.local/integratiecontrole/invoerwachtrij';root=r.parent/'Open-Office-Studio';target=root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '2334 passed (2334)' in (u/'volledig.log').read_text();assert not (u/'typescript-definitief.log').read_text();assert 'built in' in (u/'vite.log').read_text()
status=subprocess.check_output(['git','status','--porcelain']);head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();diff=subprocess.check_output(['git','diff','--binary','HEAD']);testsha=sha(r/'src/tekst/invoer-tijdspan.test.ts');assert set(x[3:] for x in status.decode().splitlines())=={'patches/@betteroffice__docx-react@0.5.1.patch','pnpm-lock.yaml','src/tekst/invoer-tijdspan.test.ts'}
(u/'bron.diff').write_bytes(diff);(u/'bronpinnen.json').write_text(json.dumps({'head':head,'diff_sha256':hashlib.sha256(diff).hexdigest(),'test_sha256':testsha},indent=2))
refs={root/'.local/doorwerk-2026-11-06/autocorrectie-invoer/open-office-studio-45.52-autocorrectie':'98d34a5d2ffe86c6bab8832ba751cd3fc22edd13935c26579f34f49b481be039',r/'.local/integratiecontrole/invoer-zonder-projectiemelding/open-office-studio-kandidaat-zonder-projectiemelding':'c88c5d82f1b0b44bf1279645a6b3e930dc8f302e5e3f7bec57605b8d2df42c59',r/'.local/integratiecontrole/journaal-desktop/open-office-studio-4c13723b-journaal':'16f35e7f811654d5c7bdffa5d3071b96851c2582badd7a581257e4674cb898fc'}
for p,h in refs.items():assert sha(p)==h
manifest={str(p.relative_to(u/'dist')):sha(p) for p in (u/'dist').rglob('*') if p.is_file()};assert manifest
(u/'bundelpinnen.json').write_text(json.dumps(manifest,indent=2));assert (u/'standaardbundelarchief.json').exists() and not (r/'dist').exists();(u/'dist').rename(r/'dist')
assert manifest=={str(p.relative_to(r/'dist')):sha(p) for p in (r/'dist').rglob('*') if p.is_file()}
vrij=shutil.disk_usage(r).free;assert vrij>3.25*1024**3,'Alleen de appcrate mag begrensd herbouwen; onvoldoende ruimte'
env=os.environ.copy();env.update(PATH='/home/aia01/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true')
cmd=['/home/aia01/.cargo/bin/cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal'];begin=time.monotonic();reden=None
with (u/'desktop.log').open('x') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (u/'actief.json').write_text(json.dumps({'status':'bouwen','supervisor_pid':os.getpid(),'cargo_pid':p.pid,'startgrens_gib':3.25,'stopgrens_gib':3,'alleen':'open-office-studio'},indent=2))
 while p.poll() is None:
  time.sleep(2);tekst=(u/'desktop.log').read_text(errors='replace');crates=set(re.findall(r'^\s*Compiling ([^ ]+)',tekst,re.M))
  if crates-{'open-office-studio'} or shutil.disk_usage(r).free<3*1024**3 or time.monotonic()-begin>1200:
   reden='Onverwachte afhankelijkheidsherbouw, vrije ruimte onder3GiB of20min';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
result={'code':p.returncode,'reden':reden,'seconden':time.monotonic()-begin,'head':head,'diff_sha256':hashlib.sha256(diff).hexdigest(),'opdracht':cmd,'vrije_bytes_start':vrij,'vrije_bytes_eind':shutil.disk_usage(r).free}
assert subprocess.check_output(['git','status','--porcelain'])==status and subprocess.check_output(['git','diff','--binary','HEAD'])==diff and sha(r/'src/tekst/invoer-tijdspan.test.ts')==testsha
for p,h in refs.items():assert sha(p)==h
if result['code']==0:
 exe=u/'open-office-studio-bundel16';shutil.copy2(target/'release/open-office-studio',exe);result.update(programma=str(exe),programma_sha256=sha(exe))
(u/'desktop.json').write_text(json.dumps(result,indent=2));(u/'actief.json').write_text(json.dumps({'status':'klaar' if result['code']==0 else 'afgekeurd','resultaat':result},indent=2));print(json.dumps(result));raise SystemExit(result['code'])
