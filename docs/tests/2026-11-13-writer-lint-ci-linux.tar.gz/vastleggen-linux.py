from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
import hashlib,json,tarfile
r=Path.cwd();u=r/'.local/integratiecontrole/lint-ci';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());ci=read(u/'ci-origineel.json');assert ci['headSha']=='41e7000198f89d992e1059e9715636a44b39d21a';jobs={j['name']:j['conclusion'] for j in ci['jobs']};assert jobs['desktop (ubuntu-22.04)']==jobs['desktop (macos-latest)']=='success' and jobs['desktop (windows-latest)']=='failure';ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};docs={};tests={}
for p in u.glob('native-*/**/rapport.json'):
 d=read(p);assert d['geslaagd'];assert d['programma_sha256']=='a31ab9f2b0069abb9509253f69b01bf5062e992ba7fcd3726cd120933d9de29a'
 if 'fouten' in d:assert not any(d['fouten'].values())
 else:assert not d['gui_fouten'] and not d['console_fouten'] and not d['engine_fouten']
 tests[str(p.relative_to(u))]={'geslaagd':True,'programma_sha256':d['programma_sha256'],'script_sha256':d['script_sha256'],'stappen':d.get('stappen'),'grenzen':d.get('grenzen')}
for p in u.glob('native-*/**/*.docx'):
 with ZipFile(p) as z:
  assert z.testzip() is None;x=E.fromstring(z.read('word/document.xml'))
 text=''.join(e.text or '' for e in x.findall('.//w:t',ns));docs[str(p.relative_to(u))]={'sha256':sha(p),'tabellen':len(x.findall('.//w:tbl',ns)),'tekens_utf16':len(text.encode('utf-16-le'))//2}
for rel in ['native-volgorde/proef-native-writer-volgorde','native-volgorde/proef-native-writer-tekst']:
 assert docs[rel+'/Ontwerpnotitie.docx']['sha256']==read(u/rel/'rapport.json')['bewaring_sha256']
b=read(u/'native-bewaren/rapport.json');assert docs['native-bewaren/geplakt.docx']['sha256']==b['onafhankelijk_docx']['sha256'];assert docs['native-bewaren/tussenbewaring.docx']['sha256']==b['tussenbewaring']['sha256'];assert len(docs)==5
(u/'linux-nacontrole.json').write_text(json.dumps({'native':tests,'docx':docs},ensure_ascii=False,indent=2)+'\n')
files={str(p.relative_to(u)):p for p in u.rglob('*') if p.is_file() and (p.relative_to(u).parts[0] in ['native-volgorde','native-bewaren'] or p.name in ['ci-origineel.json','linux-nacontrole.json','vastleggen-linux.py'])};a=r/'docs/tests/2026-11-13-writer-lint-ci-linux.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(a,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for m in t.getmembers():assert m.isfile() and hashlib.sha256(t.extractfile(m).read()).hexdigest()==sha(files[m.name])
out={'datum':'2026-11-13','bron':ci['headSha'],'ci':{'id':43320225062,'url':ci['url'],'status':'completed','conclusion':'failure','taken':jobs},'native_linux':{'artifact_ids':[13993035439,13992037948],'zip_sha256':{n:sha(u/n) for n in ['native-volgorde.zip','native-bewaren.zip']},'zip_crc_en_paden_gecontroleerd':True,'proeven':tests,'docx':docs,'visueel':'Rijke native-volgorde/snel-getypt-bewaard.png en native-bewaren/na-plakken.png bekeken. Tekst, tabelrijen, paginaovergang en bewaartoestand zichtbaar; geen volledige pixelpariteit of alle pagina’s geaccepteerd.','elf_grens':'CIrapporten binden alle drie proeven aan ELF a31ab9f2; appbinary zelf niet gedownload of lokaal herhaald. Deze remote ELF verschilt van lokale acb770; geen runtimegelijkheid geclaimd.'},'interpretatie':'Deze normale Linux-run reproduceert de oudere geheugenfouten niet. Dat bewijst geen oorzaak of oplossing. Windows is alleen tot Python-tests gekomen; testcorrectie4793522d wordt apart gecontroleerd in43324642811. macOS-taak groen, lokale macOS-pakket/GUI-inspectie niet uitgevoerd.','niet_gecontroleerd':['Geen nieuwe releasevariant-, installatie-, volledige pixel-, langdurige stabiliteits- of migratieacceptatie.','Alleen deze twee Linux-bewijsartifacts lokaal geopend; overige Linux-artifacts en macOS-installatie niet lokaal nagekeken.','Geen algemene Writer-snelheidsclaim uit deze doelbewust vertraagde native antwoordvolgordeproeven.'],'bewijs':{'pad':str(a.relative_to(r)),'sha256':sha(a),'bytes':a.stat().st_size,'reguliere_leden':len(files),'alle_leden_bytegecontroleerd':True}}
(r/'docs/tests/2026-11-13-writer-lint-ci-linux.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');p=r/'docs/voortgang-migratie.md';s=p.read_text();at=s.index('\n\n')+2;p.write_text(s[:at]+'''- Normale lintfix-CI `43320225062` afgerond: Linux en macOS groen, Windows afgekeurd op de inmiddels gecorrigeerde Python-rechtenassertie. Twee Linux-bewijsartifacts lokaal ZIP-/CRC-/padgecontroleerd: drie native functierapporten groen op ELF `a31ab9f2`, vijf DOCX-bestanden onafhankelijk gelezen/gehasht en twee geselecteerde GUI-beelden bekeken. Rijke invoervolgorde en bewerken na herstelkopie behouden inhoud; deze run reproduceert eerdere geheugenfouten niet, maar bewijst geen oplossing. Remote ELF niet lokaal gedownload/herhaald; geen volledige platform-/release-/pixelacceptatie. Nieuwe testcorrectie-CI `43324642811` afzonderlijk volgen. [Uitslagen, bestanden, beelden en exacte grenzen](tests/2026-11-13-writer-lint-ci-linux.json).

'''+s[at:]);print(out['bewijs']);print(json.dumps(docs,indent=2))
