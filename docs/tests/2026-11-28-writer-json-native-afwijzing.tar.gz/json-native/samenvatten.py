from pathlib import Path
import json,re,hashlib,statistics
p=Path(__file__).resolve().parent;r=p.parents[2];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
# Elke claim verwijst naar de werkelijk uitgevoerde ronde, inclusief afkeuringen.
assert(p/'baseline-echt.json').exists();baseline=(p/'baseline-echt.log').read_text();assert 'running 984 tests'in baseline and '7 failed'in baseline
unit=(p/'unit-bouw.log').read_text();assert 'running 985 tests'in unit and '974 passed; 9 failed; 2 ignored'in unit
failed=lambda t:sorted(re.findall(r'^test ([^ ]+) \.\.\. FAILED$',t,re.M))
bf=failed(baseline);uf=failed(unit);assert len(bf)==7 and set(bf)<set(uf)and all(x.startswith('batch::direct_tests::')for x in bf)
corpus=json.loads((p/'corpus-hertest.json').read_text());assert corpus['code']==0;bron=json.loads((p/'bronproef-kandidaat.json').read_text());assert bron['code']==0 and bron['uitkomst']['toestanden']==141 and bron['uitkomst']['werkelijke_geschiedenisstappen']==12
rounds=json.loads((p/'native-ronden.json').read_text());assert len(rounds)==4 and all(x['code']==0 and x['geslaagd']for x in rounds);med={v:statistics.median(x['invoer']['wall_begin_tot_frame_ms']for x in rounds if x['variant']==v)for v in ['basis','kandidaat']}
refs=json.loads((p.parent/'bronfasen/referenties-nacontrole.json').read_text());assert len(refs)==49 and all(sha(Path(f))==h for f,h in refs.items());refs[str(p/'open-office-studio-json-geleend')]=sha(p/'open-office-studio-json-geleend');(p/'referenties-nacontrole.json').write_text(json.dumps(refs,indent=2)+'\n')
std=json.loads((p.parent/'projectie-context-telling-herbouw/standaardbundel.json').read_text());assert len(std)==529
for f,m in std.items():
 q=r/'dist'/f;assert sha(q)==m['sha256']and(q.stat().st_mode&0o777)==m['mode']and q.stat().st_mtime_ns==m['mtime_ns'],f
(p/'bronreferentie-hashes.json').write_text(json.dumps({str(f.relative_to(p/'bronreferentie')):sha(f)for f in sorted((p/'bronreferentie').glob('*'))},indent=2)+'\n')
# Het testpakket is onder een eigen manifest gebouwd. Alleen de daadwerkelijke
# desktop-kandidaat gebruikt de oorspronkelijke app-lock met --locked.
report={'eenheid':{'volledige_kandidaat':re.findall(r'test result:.*',unit)[-1],'baseline':re.findall(r'test result:.*',baseline)[-1],'overblijvende_baseline_afkeuringen':bf,'oorspronkelijke_kandidaat_afkeuringen':uf,'corpus_hertest':corpus,'bron':bron['uitkomst']},'native_ronden':rounds,'native_medianen_ms':med,'native_verschil_procent':100*(med['kandidaat']/med['basis']-1),'behoud':{'bestaande_elf_paden_exact':49,'nieuwe_kandidaat':1,'standaardbundel_byte_mode_mtime_exact':529},'encoder_sha256':sha(p/'docx-edit/src/deterministic.rs')};(p/'samenvatting.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
