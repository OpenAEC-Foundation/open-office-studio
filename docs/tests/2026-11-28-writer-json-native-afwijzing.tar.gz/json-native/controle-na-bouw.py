from pathlib import Path
import subprocess,time,json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/json-native';exe=p/'open-office-studio-json-geleend'
while not exe.exists():time.sleep(10)
res=subprocess.run(['python3',str(p/'vervolg-bewijs.py')]);assert res.returncode==0
res=subprocess.run(['python3',str(p/'native-ronden.py')]);assert res.returncode==0
