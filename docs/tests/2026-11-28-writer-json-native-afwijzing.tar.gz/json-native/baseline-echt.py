from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/json-native';base=p/'docx-edit-basis';assert (base/'src/deterministic.rs').read_bytes()==(r/'native/vendor/docx-edit/src/deterministic.rs').read_bytes();(base/'src/lib.rs').touch();old=json.loads((p/'bouwen.json').read_text())[0]['opdracht'];cmd=[str(base/'Cargo.toml')if v==str(p/'docx-edit/Cargo.toml')else v for v in old];env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_TARGET_DIR':str(p/'baseline-target'),'CARGO_BUILD_JOBS':'1','CARGO_NET_OFFLINE':'true'};start=time.monotonic()
with(p/'baseline-echt.log').open('x')as log:
 proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while proc.poll()is None:
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:print('BASELINE ACTIEF',round(time.monotonic()-start),flush=True)
text=(p/'baseline-echt.log').read_text();assert 'running 984 tests'in text and 'geleende_json_behoudt'not in text;assert '7 failed'in text and proc.returncode==101
(p/'baseline-echt.json').write_text(json.dumps({'code':proc.returncode,'opdracht':cmd,'seconden':time.monotonic()-start,'oorspronkelijke_encoder_sha256':hashlib.sha256((base/'src/deterministic.rs').read_bytes()).hexdigest()},indent=2)+'\n');print('BASELINE AFGEROND',flush=True)
