from pathlib import Path
import subprocess,os,json,shutil,time
r=Path.cwd();p=r/'.local/integratiecontrole/json-native';f=p/'docx-edit/src/deterministic.rs';s=f.read_text();s+=('' if 'fn geleende_json_behoudt_de_oorspronkelijke_waardeboom' in s else '''
#[cfg(test)]
#[test]
fn geleende_json_behoudt_de_oorspronkelijke_waardeboom() {
    use std::sync::Arc;
    let mut waarden = vec![Any::Undefined, Any::Null, Any::Bool(true), Any::BigInt(i64::MIN), Any::BigInt(i64::MAX), Any::String("\\n\\t\\\"\\\\😀".into()), Any::Buffer(Arc::from([0u8,127,255]))];
    for n in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, -0., 0., f64::MIN_POSITIVE, f64::MAX, 1.5, 1e30, 9007199254740992., i64::MAX as f64, i64::MIN as f64] { waarden.push(Any::Number(n)); }
    for waarde in waarden {
        let map = Any::Map(Arc::new([("é".into(),waarde.clone()), ("".into(),Any::Null), ("😀".into(),waarde.clone())].into_iter().collect()));
        for v in [waarde, map.clone(), Any::Array(Arc::from([map]))] {
            assert_eq!(serde_json::to_vec(&GeleendeJson(&v)).unwrap(), serde_json::to_vec(&json_value(&v)).unwrap());
        }
    }
}
''');f.write_text(s);subprocess.run(['/home/aia01/.cargo/bin/rustfmt','--edition','2024',str(f)],check=True);(p/'encoder.patch').write_text(subprocess.run(['diff','-u',str(r/'native/vendor/docx-edit/src/deterministic.rs'),str(f)],capture_output=True,text=True).stdout)
target=p/'native-target';shutil.copytree(p.parent/'digest-spans/native-target',target) if not target.exists() else None;cfg={'build':{'frontendDist':str(p.parent/'digest-spans/dist-kandidaat')}};env={**os.environ,'TAURI_CONFIG':json.dumps(cfg),'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','CARGO_NET_OFFLINE':'true','PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH']};over='patch.crates-io.betteroffice-docx-edit.path='+json.dumps(str(p/'docx-edit'));rows=[]
commands=[('unit',['cargo','test','--manifest-path',str(p/'docx-edit/Cargo.toml'),'--lib','--release','--offline','--features','writer-bronjournaal','--config','patch.crates-io.yrs.path='+json.dumps(str(r/'native/vendor/yrs')),'--config','patch.crates-io.betteroffice-docx-parse.path='+json.dumps(str(r/'native/vendor/docx-parse'))]),('native',['cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal','--config',over])]
for label,cmd in commands:
 begin=time.monotonic()
 with(p/(label+'-bouw.log')).open('x')as log:
  proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll()is None:
   try:proc.wait(timeout=20)
   except subprocess.TimeoutExpired:print(label,'ACTIEF',round(time.monotonic()-begin),flush=True)
 rows.append({'fase':label,'code':proc.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd});(p/'bouwen.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,'GEREED',proc.returncode,flush=True);assert proc.returncode==0
shutil.copy2(target/'release/open-office-studio',p/'open-office-studio-json-geleend')
