from pathlib import Path
import os,shutil,subprocess,json,time,hashlib,re
r=Path.cwd();p=r/'.local/integratiecontrole/json-native';sdk=p.parent/'digest-spans/bron';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();resources={}
for relative in ['crates/docx-edit/tests/fixtures','crates/betteroffice-docx/tests/corpus/fixtures','packages/docx/src/yrs/__fixtures__']:
 for f in(sdk/relative).rglob('*'):
  if f.is_file():
   d=p.parent/f.relative_to(sdk);d.parent.mkdir(parents=True,exist_ok=True)
   if d.exists():assert sha(d)==sha(f),str(d)
   else:shutil.copyfile(f,d)
   resources[str(d)]={'bron':str(f),'sha256':sha(f)}
(p/'corpus-fixtures.json').write_text(json.dumps(resources,indent=2)+'\n')
# Baselinekopie gebruikt exact dezelfde eigen unit-lock en resources.
base=p/'docx-edit-basis';shutil.copytree(r/'native/vendor/docx-edit',base);shutil.copyfile(p/'docx-edit/Cargo.lock',base/'Cargo.lock');target=p/'baseline-target';shutil.copytree(p/'native-target',target)
old=json.loads((p/'bouwen.json').read_text())[0]['opdracht'];cmd=[str(base/'Cargo.toml')if v==str(p/'docx-edit/Cargo.toml')else v for v in old];env={**os.environ,'PATH':'/home/aia01/.cargo/bin:'+os.environ['PATH'],'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'1','CARGO_NET_OFFLINE':'true'}
# Kandidaatdesktop bouwt op een afzonderlijk target; een mislukte algemene
# librarysuite wordt nergens als groen geregistreerd.
cfg={'build':{'frontendDist':str(p.parent/'digest-spans/dist-kandidaat')}};native=['cargo','build','--manifest-path','src-tauri/Cargo.toml','--release','--locked','--offline','--features','tauri/custom-protocol,writer-bronjournaal','--config','patch.crates-io.betteroffice-docx-edit.path='+json.dumps(str(p/'docx-edit'))];tasks=[]
for label,args,e in [('baseline-unit',cmd,env),('native',native,{**env,'CARGO_TARGET_DIR':str(p/'native-target'),'TAURI_CONFIG':json.dumps(cfg)})]:
 log=(p/(label+'-bouw.log')).open('x');proc=subprocess.Popen(args,env=e,stdout=log,stderr=subprocess.STDOUT);tasks.append((label,args,proc,log,time.monotonic()))
rows=[]
while tasks:
 for item in list(tasks):
  label,args,proc,log,start=item
  if proc.poll()is None:continue
  log.close();row={'fase':label,'code':proc.returncode,'seconden':time.monotonic()-start,'opdracht':args};rows.append(row);(p/'herstel-bouwen.json').write_text(json.dumps(rows,indent=2)+'\n');print('GEREED',json.dumps(row),flush=True);tasks.remove(item)
  if label=='native'and proc.returncode==0:shutil.copy2(p/'native-target/release/open-office-studio',p/'open-office-studio-json-geleend')
 if tasks:time.sleep(10)
# De twee corpusproeven opnieuw, met echte oorspronkelijke corpusbestanden.
unitlog=(p/'unit-bouw.log').read_text();match=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',unitlog);assert match,unitlog[-500:];binary=Path(match.group(1));assert binary.exists(),binary
with(p/'corpus-hertest.log').open('w')as log:res=subprocess.run([str(binary),'peer_bootstrap::tests::peer_','--nocapture'],stdout=log,stderr=subprocess.STDOUT)
(p/'corpus-hertest.json').write_text(json.dumps({'code':res.returncode,'opdracht':[str(binary),'peer_bootstrap::tests::peer_','--nocapture']},indent=2));print('CORPUSHERTEST',res.returncode,flush=True)
