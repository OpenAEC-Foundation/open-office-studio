use docx_edit::EditingDoc;
use serde_json::{Value,json};
use std::path::Path;
fn controle(d:&EditingDoc,p:&Path,nummer:usize,schrijf:bool)->Result<(),Box<dyn std::error::Error>>{
 let bytes=d.encode_state_as_update_v1();let vector=d.encode_state_vector_v1();let bron=p.join(format!("{nummer:03}.bin"));let v=p.join(format!("{nummer:03}.vector"));
 if schrijf{std::fs::write(bron,&bytes)?;std::fs::write(v,&vector)?;}else{assert_eq!(bytes,std::fs::read(bron)?,"Bron {nummer}");assert_eq!(vector,std::fs::read(v)?,"Vector {nummer}");}
 assert_eq!(bytes,d.encode_state_as_update_v1());assert_eq!(vector,d.encode_state_vector_v1());Ok(())
}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let p=std::path::PathBuf::from(std::env::args().nth(1).ok_or("Proefmap ontbreekt")?);let schrijf=std::env::args().nth(2).as_deref()==Some("schrijf");let frames=p.join("bronreferentie");std::fs::create_dir_all(&frames)?;let mut n=0;
 let orakel=p.join("../digest-fasen");let cases:Value=serde_json::from_slice(&std::fs::read(orakel.join("orakel.json"))?)?;
 for case in cases["cases"].as_array().unwrap(){let d=EditingDoc::new(case["client_id"].as_u64().unwrap());d.keep_deleted();for f in case["frames"].as_array().unwrap(){d.apply_update_v1(&std::fs::read(orakel.join(f["file"].as_str().unwrap()))?)?;controle(&d,&frames,n,schrijf)?;n+=1;}}
 let raw=p.join("../digest-spans/route-capture/raw");let d=EditingDoc::new(3525307561);d.keep_deleted();d.apply_update_v1(&std::fs::read(raw.join("initial.bin"))?)?;
 for i in 0..=58 {if i>0{d.apply_update_v1(&std::fs::read(raw.join(format!("updates/{:03}.bin",i-1)))?)?;}controle(&d,&frames,n,schrijf)?;n+=1;}
 let d=EditingDoc::new(999);d.keep_deleted();d.apply_update_v1(&std::fs::read(raw.join("initial.bin"))?)?;d.apply_update_v1(&std::fs::read(raw.join("updates/001.bin"))?)?;assert!(d.holds_pending_update());controle(&d,&frames,n,schrijf)?;n+=1;d.apply_update_v1(&std::fs::read(raw.join("updates/000.bin"))?)?;assert!(!d.holds_pending_update());controle(&d,&frames,n,schrijf)?;n+=1;
 println!("{}",json!({"geslaagd":true,"schrijven":schrijf,"toestanden":n,"bron_vector_exact":true}));Ok(())
}
