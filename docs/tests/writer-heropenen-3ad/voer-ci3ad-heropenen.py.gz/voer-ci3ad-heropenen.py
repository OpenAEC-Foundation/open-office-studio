from pathlib import Path
import os,subprocess,json,time
repo=Path.cwd();r=repo/'.local/doorwerk-2026-11-04/incrementele-invoer/ci-3ad-desktop';env=os.environ.copy();env['PATH']=str(repo/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
cmd=[str(repo/'.local/doorwerk-2026-11-02/gui-python/bin/python'),'scripts/test-writer-lang-native.py','--programma',str(r/'open-office-studio-ci-3ad'),'--versie','2026.45.39','--uitvoer',str(r/'hertest-eerste'),'--verwacht-rust-tekst','--verwacht-incrementele-bron','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--lettertypebewijs']
begin=time.monotonic()
with (r/'hertest-eerste.log').open('w') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/'hertest-eerste-uitkomst.json').write_text(json.dumps({'code':p.returncode,'seconden':time.monotonic()-begin,'opdracht':cmd,'grens':'Exacte negatieve ELF en bytegelijk CI-testscript; eigen XDG/DBus/Xvfb. Een groene hertest bewijst geen herstel.'},indent=2)+'\n');print('Exacte CI3ad-hertest',p.returncode,flush=True)
raise SystemExit(p.returncode)
