from pathlib import Path
import json,hashlib,subprocess,ast,collections
from zipfile import ZipFile
from xml.etree import ElementTree as ET
r=Path.cwd();p=r/'.local/integratiecontrole/werker-uitvoering';old=r/'.local/integratiecontrole/warm-layout-request';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();native=json.loads((p/'native-functie/rapport.json').read_text());assert native['geslaagd'];workers=[]
for x in native['werkers_binnen_eind']:
 v=x['antwoord']['result']['result']['value'];e=v['uitvoering'];assert not e['errors'] and not e['overflow'];assert v['berichten']['hersteld'];assert dict(collections.Counter(z['tag']for z in e['rows']))==e['counts'];workers.append({'werker':x['werker'],'telling':e['counts'],'fouten':e['errors'],'overflow':e['overflow']})
e=native['werkers_binnen_eind'][1]['antwoord']['result']['result']['value']['uitvoering'];assert e['counts']=={'fonts':72,'ea':14,'adapter':14,'warm':14,'part':14,'layout-json':14};ordered=[z['tag']for z in e['rows']if z['tag']!='fonts'];assert ordered==['ea','adapter','warm','part','layout-json']*14
assert [z['data']['revision']for z in e['rows']if z['tag']=='ea']==list(range(2,16))
for x in native['uitvoeringspunten']:
 assert 'error'not in x['antwoord'];assert len(x['antwoord']['result']['locations'])==(0 if x['werker']['name']=='spelling'else 1)
assert len(native['uitvoeringspunten_verwijderd'])==20 and all(x.get('result')=={}for x in native['uitvoeringspunten_verwijderd'])
(p/'tellingen.json').write_text(json.dumps({'werkers':workers,'volgorde':ordered,'revisies':list(range(2,16)),'opgeloste_punten_documentwerker':10,'verwijderde_punten':20,'grens':'Telling van JS-aanroepgrenzen tijdens lange invoer, geen CPU-/snelheidsmeting, geen bewijs van raw Rust-succes per aanroep. Uitgaande nieuwe warmroute direct waargenomen; getterresultaten van R niet apart gemeten.'},ensure_ascii=False,indent=2)+'\n')
contracts=[('docx-react/src/components/DocxEditor/hooks/useDisplayList.ts',[(2858,2884),(2938,2981)]),('docx/src/editor/computeLayout.ts',[(190,233)]),('docx/src/yrs/layoutMeta.ts',[(1,80)]),('docx-react/src/components/DocxEditor/hooks/useDocxEditorRefApi.ts',[(1138,1165)]),('docx-react/src/components/DocxEditor/hooks/useDisplayList.workerLayout.test.ts',[(2670,2705),(2784,2843)])]
base=r/'.local/integratiecontrole/font-hergebruik/bron/packages';snap=[]
for name,ranges in contracts:
 f=base/name;lines=f.read_text().splitlines();snap.append({'pad':str(f.relative_to(r)),'sha256':sha(f),'uitsneden':[{'begin':a,'eind':min(b,len(lines)),'regels':lines[a-1:b]}for a,b in ranges]})
(p/'broncontract.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2)+'\n')
refs=json.loads((old/'referenties-nacontrole.json').read_text());assert len(refs)==23
for f,h in refs.items():assert sha(Path(f))==h
expected=json.loads((old/'standaardbundel.json').read_text());actual={str(f.relative_to(r/'dist')):{'sha256':sha(f),'mode':f.stat().st_mode&0o777,'mtime_ns':f.stat().st_mtime_ns}for f in(r/'dist').rglob('*')if f.is_file()};assert actual==expected and len(actual)==529
pins=json.loads((old/'behoud.json').read_text())['sdk_vendor_npm_exact']
for f,h in pins.items():assert sha(r/f)==h
source=json.loads((old/'bron-hersteld.json').read_text())['bestanden']
for f,h in source.items():assert sha(r/f)==h
checks=[]
for f in p.glob('*.py'):ast.parse(f.read_text());checks.append({'pad':f.name,'controle':'Python AST','code':0})
node='/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
for f in list(p.glob('*.mjs'))+list(p.glob('*.js')):
 z=subprocess.run([node,'--check',str(f)],capture_output=True);assert z.returncode==0,(f,z.stderr);checks.append({'pad':f.name,'controle':'node --check','code':0})
f=p/'native-functie/Ontwerpnotitie.docx';assert sha(f)==native['bewaring_sha256'];parts={}
with ZipFile(f)as z:
 assert z.testzip()is None
 for n in z.namelist():
  data=z.read(n)
  if n.endswith(('.xml','.rels')):ET.fromstring(data)
  parts[n]=hashlib.sha256(data).hexdigest()
 root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};tables=len(root.findall('.//w:tbl',ns));text=''.join(x.text or''for x in root.findall('.//w:t',ns));units=len(text.encode('utf-16-le'))//2;assert tables==128 and units==91423
with ZipFile(old/'native-functie/Ontwerpnotitie.docx')as z:previous={n:hashlib.sha256(z.read(n)).hexdigest()for n in z.namelist()}
assert set(parts)==set(previous);diff=[n for n in parts if parts[n]!=previous[n]];assert set(diff)<={'docProps/core.xml'}
(p/'documentcontrole.json').write_text(json.dumps({'sha256':sha(f),'zip_crc_xml':True,'tabellen':tables,'utf16':units,'verschil_met_vorige_zelfde_ELF':diff},indent=2)+'\n');(p/'behoud.json').write_text(json.dumps({'elf_referenties_exact':refs,'standaarddist_byte_mode_mtime_exact':529,'sdk_vendor_npm_exact':pins,'canonieke_bron_exact':source,'scripts':checks,'wasm_ongewijzigd':sha(old/'kern/docx_edit_bg.wasm')},indent=2)+'\n');print('TELLING14/72;BEHOUD23/529/6;DOCX128/91423')
