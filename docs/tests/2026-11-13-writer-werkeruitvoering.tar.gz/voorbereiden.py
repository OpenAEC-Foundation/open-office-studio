from pathlib import Path
import json,hashlib
r=Path.cwd();p=r/'.local/integratiecontrole/werker-uitvoering';src=r/'.local/integratiecontrole/warm-layout-request/dist/assets/chunk-Q7OC7M5Q-BzppsI5m.js';s=src.read_text();sites=[
 ('ea','function Ea(e,t,r=!0,n=!0,i,a,o,s=!0){',"({layout:s,regions:e.layoutWithRegions,revision:e.layoutRevision,fonts:e.fontsRevision,workerAuthoritative:e.workerAuthoritative,renders:e.renderInputs?.map(x=>({story:x.story,keys:x.env?Object.keys(x.env):null,plain:x.env?Object.getPrototypeOf(x.env)===Object.prototype:false})),newMethod:typeof N?.warmStoryForRegionLayout})"),
 ('adapter-eerste','warmStoryForRegionLayout:(_,P,k)=>{',"({story:_,keys:Object.keys(P??{}),plain:P?Object.getPrototypeOf(P)===Object.prototype:false,capType:typeof e.supports_region_layout_warm,cap:typeof e.supports_region_layout_warm==='function'?e.supports_region_layout_warm():null})"),
 ('adapter','warmStoryForRegionLayout:(w,x,k)=>{',"({story:w,keys:Object.keys(x??{}),plain:x?Object.getPrototypeOf(x)===Object.prototype:false,capType:typeof r.supports_region_layout_warm,cap:typeof r.supports_region_layout_warm==='function'?r.supports_region_layout_warm():null})"),
 ('warm','warm_story_for_region_layout(e,t){',"({story:e,bytes:t.length})"),
 ('oud','yrs_blocks_for_story(e,t){',"({story:e,env:t.slice(0,2048)})"),
 ('part','R=w=>{if(!s&&!l&&!d&&r.part_metadata_json()',"({parts:s,margins:l,sections:d})"),
 ('fonts','layout_font_requirements_json(e){',"({bytes:e.length})"),
 ('layout','layout_document_with_regions_retained(e){',"({bytes:e.length})"),
 ('layout-json','layout_document_with_regions_retained_json(e){',"({bytes:e.length})"),
 ('layout-meta','layout_document_with_regions_retained_meta(e){',"({bytes:e.length})")]
config=[]
for tag,anchor,data in sites:
 assert s.count(anchor)==1,(tag,s.count(anchor));i=s.index(anchor)+anchor.index('{')+1;prefix=s[:i];line=prefix.count('\n');last=prefix.rfind('\n');col=len(prefix[last+1:].encode('utf-16-le'))//2;action="try{self._officeExecProbe.note("+json.dumps(tag)+","+data+")}catch{self._officeExecProbe.error()}";config.append({'tag':tag,'lineNumber':line,'columnNumber':col,'urlRegex':r'chunk-Q7OC7M5Q-BzppsI5m\.js','options':{'autoContinue':True,'actions':[{'type':'evaluate','data':action}]},'anchor':anchor})
(p/'punten.json').write_text(json.dumps({'bron_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'punten':config,'protocolbron':'https://raw.githubusercontent.com/WebKit/WebKit/main/Source/JavaScriptCore/inspector/protocol/Debugger.json'},indent=2)+'\n')
s=(r/'.local/integratiecontrole/warm-layout-request/native-proef.py').read_text();s=s.replace("(REPO / '.local/integratiecontrole/bewaar-werker/binnen.js').read_text()", "(REPO / '.local/integratiecontrole/bewaar-werker/binnen.js').read_text()+';'+(REPO / '.local/integratiecontrole/werker-uitvoering/collector.js').read_text()")
a="                r['profiel_begin'] = await p.command('ScriptProfiler.startTracking', {'includeSamples': True})";assert s.count(a)==1
insert='''                r['uitvoeringspunten'] = []
                puntconfig = json.loads((REPO / '.local/integratiecontrole/werker-uitvoering/punten.json').read_text())['punten']
                for werker in werkers:
                    enabled = await p.worker(werker['workerId'], 'Debugger.enable')
                    assert not enabled.get('error'), enabled
                    active = await p.worker(werker['workerId'], 'Debugger.setBreakpointsActive', {'active': True})
                    assert not active.get('error'), active
                    for punt in puntconfig:
                        params = {k: v for k, v in punt.items() if k not in ['tag', 'anchor']}
                        antwoord = await p.worker(werker['workerId'], 'Debugger.setBreakpointByUrl', params)
                        r['uitvoeringspunten'].append({'werker': werker, 'punt': punt, 'antwoord': antwoord})
                        assert not antwoord.get('error'), antwoord
'''
s=s.replace(a,insert+a)
a="                r['werkers_binnen_eind'] = []";assert s.count(a)==1
insert='''                r['uitvoeringspunten_verwijderd'] = []
                for punt in r['uitvoeringspunten']:
                    antwoord = await p.worker(punt['werker']['workerId'], 'Debugger.removeBreakpoint', {'breakpointId': punt['antwoord']['result']['breakpointId']})
                    r['uitvoeringspunten_verwijderd'].append(antwoord)
                    assert not antwoord.get('error'), antwoord
                for werker in werkers:
                    antwoord = await p.worker(werker['workerId'], 'Debugger.disable')
                    assert not antwoord.get('error'), antwoord
'''
s=s.replace(a,insert+a).replace("'self._bewaarBinnen.stop()'","'({berichten:self._bewaarBinnen.stop(),uitvoering:self._officeExecProbe.stop()})'")
(p/'native-proef.py').write_text(s)
