"""Eindige Writer-GUI-proeven op alleen de eigen geïntegreerde testbinary."""
from pathlib import Path
import os,json,hashlib,subprocess,time
wt=Path(__file__).resolve().parents[2]
root=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio');uit=wt/'.local/integratiecontrole'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((uit/'desktop.json').read_text());assert meta['code']==0
exe=Path(meta['programma']);assert sha(exe)==meta['programma_sha256']
env=os.environ.copy();env['PATH']=str(root/'.local/controle-2026-10-31/gui-hulpmiddelen/uitgepakt/usr/bin')+':/home/aia01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
py=str(root/'.local/doorwerk-2026-11-02/gui-python/bin/python')
proeven=[('tekst','scripts/test-writer-rust-tekst-native.py',[]),('plakken','scripts/test-writer-rijk-plakken-native.py',['--rondes','3','--bewaar-na-ronde','1','--maxduur','180','--vereis-rust-plakken']),('lang','scripts/test-writer-lang-native.py',['--herstelstart','--verwacht-rust-tekst','--verwacht-incrementele-bron','--verwacht-worker-layout','--verwacht-worker-lettertypen','--spelling-weergave','--framebasis','--workerbron'])]
rapport=[]
for naam,script,args in proeven:
 assert sha(exe)==meta['programma_sha256']
 cmd=[py,str(wt/script),'--programma',str(exe),'--versie','2026.45.52','--uitvoer',str(uit/('gui-'+naam)),*args]
 print('START',naam,flush=True);start=time.monotonic()
 with(uit/('gui-'+naam+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 rapport.append({'fase':naam,'code':p.returncode,'seconden':time.monotonic()-start,'programma_sha256':sha(exe),'testbron_sha256':sha(wt/script),'opdracht':cmd})
 (uit/'gui.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n');print('EINDE',naam,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('Canonieke GUI-proeven geslaagd; beelden en prestatielimieten afzonderlijk beoordelen.',flush=True)
