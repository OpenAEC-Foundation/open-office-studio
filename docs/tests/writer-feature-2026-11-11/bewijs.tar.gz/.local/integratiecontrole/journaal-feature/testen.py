from pathlib import Path
import json,subprocess,os,hashlib,time,shutil
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-feature';cache=Path('/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release');fp=json.loads((cache/'.fingerprint/office-writer-plakken-6c28f4e48422749f/lib-office_writer_plakken.json').read_text());libs={}
for d in fp['deps']:
 naam=d[1]
 if naam=='docx_edit':continue
 keus=[p for p in (cache/'.fingerprint').glob('*/lib-'+naam) if int.from_bytes(bytes.fromhex(p.read_text().strip()),'little')==d[3]];assert len(keus)==1,(naam,keus)
 h=keus[0].parent.name.rsplit('-',1)[1];libs[naam]=next(p for p in [cache/'deps'/f'lib{naam}-{h}.rlib',cache/'deps'/f'lib{naam}.rlib'] if p.exists())
libs['yrs']=cache/'deps/libyrs-07f01d28fbed520f.rlib'
env=os.environ.copy();env.pop('WRITER_EIGEN_REEKS',None);env['CARGO_MANIFEST_DIR']=str(r/'native/crates/office-writer-plakken');env['CARGO_PKG_VERSION']='2026.45.0-alpha.57';result=[]
def bouw(c,naam):
 t=time.monotonic();p=subprocess.run(c,env=env,capture_output=True,text=True,timeout=120);(u/f'{naam}-bouw.log').write_text(p.stdout+p.stderr);v={'naam':naam,'code':p.returncode,'seconden':time.monotonic()-t,'opdracht':c};result.append(v);(u/'controles.json').write_text(json.dumps(result,indent=2));assert p.returncode==0,p.stderr;return v
for modus in ['aan','uit']:
 d=u/modus;d.mkdir(exist_ok=True);lib=u/f'libdocx_edit_{modus}.rlib';alias=u/f'libdocx_edit_feature_{modus}.rlib'
 if not alias.exists():alias.symlink_to(lib.name)
 c=['/home/aia01/.cargo/bin/rustc','--edition=2024','--crate-name','office_writer_plakken','-C','opt-level=3','-C','metadata=journaal-'+modus,'-L','dependency='+str(cache/'deps'),'-L','dependency='+str(u),str(r/'native/crates/office-writer-plakken/src/lib.rs')]
 for naam,p in libs.items():c+=['--extern',naam+'='+str(p)]
 c+=['--extern','docx_edit='+str(lib)]
 if modus=='aan':c+=['--cfg','feature="writer-bronjournaal"']
 b=c+['--test','-o',str(d/'unittests')];v=bouw(b,'tests-'+modus);p=subprocess.run([str(d/'unittests'),'--test-threads=1'],env=env,capture_output=True,text=True,timeout=120);(u/f'tests-{modus}.log').write_text(p.stdout+p.stderr);v['testcode']=p.returncode;v['binary_sha256']=hashlib.sha256((d/'unittests').read_bytes()).hexdigest();(u/'controles.json').write_text(json.dumps(result,indent=2));print(modus,p.returncode,p.stdout[-170:],flush=True);assert p.returncode==0,p.stdout+p.stderr
 bouw(c+['--crate-type','rlib','-o',str(d/'liboffice_writer_plakken.rlib')],'lib-'+modus)
# Directe consumptie van de echte crate; de standaardbouw mag het nieuwe module niet hebben.
p=u/'consument.rs';p.write_text('''use office_writer_plakken::bronjournaal::{Voorraad,VoorraadFout};\nfn main(){assert!(matches!(Voorraad::nieuw(false,4,67108864),Err(VoorraadFout::Uitgeschakeld)));let v=Voorraad::nieuw(true,1,67108864).unwrap();let b=v.open("eigen","proef").unwrap();v.vergeet("eigen",&b).unwrap();println!("Opt-in API aanwezig; runtime blijft expliciet");}\n''')
for modus in ['aan','uit']:
 c=['/home/aia01/.cargo/bin/rustc','--edition=2024','-L','dependency='+str(cache/'deps'),'-L','dependency='+str(u),'--extern','office_writer_plakken='+str(u/modus/'liboffice_writer_plakken.rlib'),str(p),'-o',str(u/f'consument-{modus}')];p1=subprocess.run(c,env=env,capture_output=True,text=True,timeout=30);(u/f'consument-{modus}.log').write_text(p1.stdout+p1.stderr)
 if modus=='aan':assert p1.returncode==0,p1.stderr;p2=subprocess.run([str(u/f'consument-{modus}')],capture_output=True,text=True,timeout=15);assert p2.returncode==0,p2.stderr
 else:assert p1.returncode!=0 and 'could not find `bronjournaal`' in p1.stderr,p1.stderr
 result.append({'naam':'API-'+modus,'code':p1.returncode,'verwachte_afkeuring':modus=='uit','opdracht':c});(u/'controles.json').write_text(json.dumps(result,indent=2))
print('Alle crate- en featurecontroles klaar',flush=True)
