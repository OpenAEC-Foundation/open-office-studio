from pathlib import Path
import json,subprocess,os,time,shutil,signal,hashlib
r=Path.cwd();u=r/'.local/integratiecontrole/journaal-feature';j=json.loads((r/'.local/integratiecontrole/bronjournaal/bouw-import.json').read_text());base=j['opdracht'];uit=[]
assert shutil.disk_usage(r).free>1024**3
for modus in ['aan','uit']:
 c=base.copy();c[c.index('--crate-name')+1]='docx_edit_feature_'+modus;c[c.index('-o')-1]=str(r/'native/vendor/docx-edit/src/lib.rs');c[c.index('-o')+1]=str(u/f'libdocx_edit_{modus}.rlib')
 if modus=='aan':c+=['--cfg','feature="writer-bronjournaal"']
 env=os.environ.copy();env['CARGO_PKG_VERSION']='0.5.1';env['CARGO_MANIFEST_DIR']=str(r/'native/vendor/docx-edit');begin=time.monotonic();reden=None
 with(u/f'vendor-{modus}.log').open('w')as log:
  p=subprocess.Popen(c,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   if shutil.disk_usage(r).free<512*1024**2 or time.monotonic()-begin>300:
    reden='Eigen bouw begrensd wegens ruimte/tijd';os.killpg(p.pid,signal.SIGTERM);p.wait();break
   time.sleep(.5)
 v={'modus':modus,'code':p.returncode,'seconden':time.monotonic()-begin,'stopreden':reden,'opdracht':c,'binary_sha256':hashlib.sha256((u/f'libdocx_edit_{modus}.rlib').read_bytes()).hexdigest() if p.returncode==0 else None};uit.append(v);(u/'vendorbouw.json').write_text(json.dumps(uit,indent=2));print(modus,p.returncode,round(v['seconden'],2),flush=True);assert p.returncode==0
