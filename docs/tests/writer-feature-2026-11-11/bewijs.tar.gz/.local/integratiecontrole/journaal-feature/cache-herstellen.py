"""Herstel één expliciet gekozen eigen Cargo-cachebestand, zonder overschrijven."""
from pathlib import Path
import argparse,json,hashlib,subprocess,tarfile,os,shutil
p=argparse.ArgumentParser(description=__doc__);p.add_argument('naam');p.add_argument('--proef',action='store_true');args=p.parse_args();r=Path.cwd();u=r/'.local/cargo-cache-archief-2026-11-11';j=json.loads((u/'manifest.json').read_text());v=next(x for x in j['bestanden'] if Path(x['cachepad']).name==args.naam);a=r/j['gezamenlijk_archief']['pad'];assert hashlib.sha256(a.read_bytes()).hexdigest()==j['gezamenlijk_archief']['sha256']
doel=(u/'herstelproef'/args.naam) if args.proef else (r/v['cachepad']);doel.parent.mkdir(exist_ok=True);assert not doel.exists();assert args.proef or doel.parent.resolve()==(r/'.local/doorwerk-2026-11-06/autocorrectie-invoer/target/release/deps').resolve();assert shutil.disk_usage(r).free>v['bytes']+512*1024**2
tmp=doel.with_suffix('.herstel-tijdelijk');assert not tmp.exists();proc=subprocess.Popen(['/usr/bin/zstd','--long=27','-dc',str(a)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);gevonden=False
with tarfile.open(fileobj=proc.stdout,mode='r|') as t:
 for m in t:
  if m.name!=v['lid']:continue
  h=hashlib.sha256()
  with t.extractfile(m) as bron,tmp.open('xb') as f:
   while b:=bron.read(1024**2):h.update(b);f.write(b)
  assert h.hexdigest()==v['sha256'] and tmp.stat().st_size==v['bytes'];gevonden=True
assert proc.wait(timeout=30)==0 and gevonden;os.chmod(tmp,v['modus']);os.utime(tmp,ns=(v['atime_ns'],v['mtime_ns']));os.link(tmp,doel);tmp.unlink();assert hashlib.sha256(doel.read_bytes()).hexdigest()==v['sha256'];uit={'pad':str(doel.relative_to(r)),'sha256':v['sha256'],'modus_gelijk':(doel.stat().st_mode&0o7777)==v['modus'],'mtime_ns_gelijk':doel.stat().st_mtime_ns==v['mtime_ns'],'proef':args.proef};assert uit['modus_gelijk'] and uit['mtime_ns_gelijk']
if args.proef:doel.unlink();(u/'herstelproef.json').write_text(json.dumps(uit,indent=2))
print(json.dumps(uit,indent=2))
