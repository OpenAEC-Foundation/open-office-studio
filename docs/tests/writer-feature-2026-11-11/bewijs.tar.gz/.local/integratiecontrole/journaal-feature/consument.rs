use office_writer_plakken::bronjournaal::{Voorraad,VoorraadFout};
fn main(){assert!(matches!(Voorraad::nieuw(false,4,67108864),Err(VoorraadFout::Uitgeschakeld)));let v=Voorraad::nieuw(true,1,67108864).unwrap();let b=v.open("eigen","proef").unwrap();v.vergeet("eigen",&b).unwrap();println!("Opt-in API aanwezig; runtime blijft expliciet");}
