export default {"test": {"include": ["/home/aia01/Documenten/GitHub/Open-Office-Studio/.local/doorwerk-2026-11-06/fontbundeling/host.test.ts"], "exclude": []}};
